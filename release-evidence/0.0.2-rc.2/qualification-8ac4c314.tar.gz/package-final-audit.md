# RC.2 final package archive audit

**PASS:** all four final archives match committed source
`58976649f5fb2bf716cb5e2a3694dbb6bf2b2548`. The committed source receipt records
digest `8ac4c314fdfe944a53ddf4395b1feb4cfa5bd18465f0c559201823030e3ef73d`.
The working tree was clean during inspection. The initial audit and its archive
hashes remain preserved in `package-audit.md`.

Inspected the four top-level archives under
`/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI/package/`:

| Archive | Files | SHA-256 |
| --- | ---: | --- |
| `vthread-stack-0.0.2-rc.2.crate` | 44 | `c2fc7f8c6a6a88f2f649ffa9e2b00b81ec900a503368d4d4d64c2b212c456b50` |
| `vthread-sync-core-0.0.2-rc.2.crate` | 27 | `5fda1ac6ad87d3943e126601a9aa7fd6fc167f873e463437babee0823cf17226` |
| `vthread-0.0.2-rc.2.crate` | 350 | `c90d1faf690f1a55d6263232357feb0753181f78e3f8a60b269494e63ddeee24` |
| `vthreads-0.0.2-rc.2.crate` | 8 | `2136d9487b3bad1e86aaab8728e6a6094ee70ff6b4a801ed88eff0369c5209ba` |

Every archive contains `LICENSE` identical to the committed root license, SHA-256
`03cf56f4486aac8f6c1d18cc2dc7f8223a2d875ea2bfddec342e5fabc431daca`.
The initial synchronization-core license omission is resolved.

Every `.cargo_vcs_info.json` names the full commit above and the correct package
subdirectory. Cargo omits the `dirty` field in these clean archives; none retains
the initial `dirty: true` metadata or old parent commit. An initial inspection
assertion expected an explicit `dirty: false`; checking the actual omitted-field
representation resolved that audit assumption without changing any archive.

All 405 committed Rust files are included and byte-identical: 38 stack, 21
synchronization-core, 344 runtime and 2 alias files. Comparison used `git archive`
of the explicit commit, not the working tree. Every other non-generated shipped
file also matches that commit, including original manifests, READMEs and licenses.
Generated normalized manifests, package lockfiles and VCS metadata were checked
separately. The stack archive therefore contains the corrected cleanup comments,
both native architecture ports and all committed regression tests.

All normalized manifests declare version `0.0.2-rc.2`, Rust `1.96` and
`Apache-2.0`. Normal dependencies have exact versions and no local paths:

| Package | Normal dependency pins |
| --- | --- |
| `vthread-stack` | `libc =0.2.189` |
| `vthread-sync-core` | None |
| `vthread` | `vthread-stack =0.0.2-rc.2`, `vthread-sync-core =0.0.2-rc.2`, `crossbeam-queue =0.3.13`, `libc =0.2.189`, `socket2 =0.6.5`, `zio =0.0.1-dev.1` |
| `vthreads` | `vthread =0.0.2-rc.2` |

The synchronization core retains only `loom =0.7.2` as a development dependency.
Every internal dependency lock entry uses the exact RC.2 version and registry
identity. Its checksum equals the corresponding final archive hash above,
including both support archives in the runtime lock and all three dependency
archives in the alias lock.

No competitor source, dependency, comparison report, benchmark harness, historical
archive or generated target output is present. Every archive entry is a regular
file within its expected package prefix, with no duplicate or traversal paths.
Runtime diagnostic evidence modules remain ordinary product source.

The audit read archives with Python `tarfile`, parsed TOML and JSON metadata,
compared committed file bytes, and checked hashes with SHA-256. It performed no
builds, test runs, source edits or publication. This confirms package identity and
contents; execution qualification and registry publication remain separate work.
