# RC audit scope and cross-review

This receipt records the retained runtime review and subsequent frozen-tree
scheduler cross-review. Stack fixes are committed as `cb63921`; scheduler fixes
as `fa9c974`. Canonical qualification was running when this receipt was written.

The release coordinator reports current source digest
`8ac4c314fdfe944a53ddf4395b1feb4cfa5bd18465f0c559201823030e3ef73d`.
It differs from the prior digest beginning `a794` only through corrected
`Fiber::into_stack` cleanup comments. The root license was also added to the
sync-core package. The earlier focused test logs retain their original source
and binary identities; this receipt does not relabel them as final RC evidence.

## Retained areas inspected

- Virtual mutex direct ownership, queue selection, selected-ticket cancellation
  recovery, outstanding-ticket bounds, and the exclusive-cell/spin-mutex unsafe
  boundary; relevant native regressions and bounded model proof boundaries.
- Channel FIFO tickets, selected-waiter capacity, resident wait reuse, endpoint
  cleanup, unsent-value ownership, and shutdown regressions.
- Readiness descriptor ownership and caching, exact-generation registration,
  bounded registration accounting, driver reconciliation, and shutdown paths.
- Native stack mapping and guards, pool ownership, entry placement, execution
  stages, typed context mounting, borrowed leases and lexical reclamation, forced
  unwind, and both architecture context-switch implementations. The review also
  inspected terminal, register, floating-point, nesting, and guard-page tests,
  plus configured platform qualification workflows.
- Rust source size and sibling-test structure. All initially scanned Rust files
  were below 300 lines; modified stack production files remained at most 225.

No additional concrete ownership, FIFO, or capacity defect was identified in
the retained synchronization and readiness slices. This is a bounded source
review, not an exhaustive correctness or memory-safety proof.

## Three stack defects repaired

1. A typed context callback could suspend while holding a reference valid only
   for the current resume. The existing RAII core mount now suppresses that
   fiber's suspension until the callback returns or unwinds. Nested fibers keep
   their own suspension context.
2. Dropping an unstarted fiber mounted its never-saved core while its captured
   destructors ran on the caller's stack. Only suspended executions now install
   their core for reclamation; unstarted entries retain the actual caller.
3. Forced-unwind cookie exhaustion advanced the global block counter and could
   subsequently reissue old identities; the last local cookie also overflowed
   in debug. Block allocation now rejects exhaustion permanently, and consuming
   the last cookie requests a fresh block through the existing zero sentinel.

Negative regressions were recorded before repairs. They used assertions without
dereferencing expired references or attempting invalid context switches. Nine
new tests cover the repairs, including actual destructor suspension in a child
process. The focused stack suite passed 79 tests in debug and 79 in release,
including completion/reuse, panic propagation, forced unwind, guard pages, and
register preservation over one million switches. See the adjacent README,
negative/final patch receipts, test logs, and source/binary hashes.

## Preserved invariants

Started fibers remain carrier-affine. Borrowed executable frames are reclaimed
before their lexical environment expires. Stack and synchronization unsafe
operations remain inside their support crates; the public runtime stays safe
Rust. Queue capacity includes selected waiters, FIFO/no-barging ownership stays
intact, and wake selection remains tied to one exact park generation. No
assembly was changed and no optional performance candidate was promoted.

## Frozen scheduler cross-review

The read-only cross-review covered `ready_queue_inspection.rs`, ready-queue
cohort selection, and the abort, cleanup, and revoked-task paths, including
their destructor and publication call chains. No concrete concern was found.

- Inspection checks every original entry once, retaining entries in their own
  lane and leaving the dispatch cohort unchanged. It completes before other
  ready-queue mutation; cleanup publications preserve intermediate task counts.
- Cleanup callbacks can publish local/mailbox work but do not mutate the ready
  queue during inspection. Other retained tasks remain visible to snapshots.
- Retained in-flight ownership is restored by removing the exact `TaskKey`,
  without consuming an ordinary dispatch opportunity.
- Eligible selection follows the existing cohort policy over eligible entries;
  skipped entries retain their order and consume no dispatch opportunity.
- The inspected revocation path visits both original lanes before consuming the
  scan, with the middle-wake regression preserving the demonstrated failure.

No source changes, builds, or tests were performed during this cross-review.

## Remaining limits

The focused execution evidence is Linux x86-64. This audit did not rerun native
macOS ARM64 qualification or verify fresh hosted artifacts for the final RC.
Configured workflows and earlier target evidence are not substitutes for that
execution. No new sanitizer, large mixed-lifetime, or performance qualification
was produced. Final canonical, packaging, and supported-platform release
verdicts belong to the release coordinator's complete RC evidence.
