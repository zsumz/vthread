# RC stack safety review

Linux x86-64 qualification before the workspace RC version bump. These receipts
cover the stack source fixes; the combined RC still needs its canonical check
and native platform qualification.

## Regressions before fixes

- `negative-mount_borrow_test.log`: three failures, one pass. The old context
  callback could suspend beyond the resume that lent its reference.
- `negative-fiber_drop_test.log`: two failures. Unstarted entry destruction
  installed its own never-saved core instead of retaining the actual caller.
- `negative-context_cookie_test.log`: two failures. Exhaustion advanced the
  global block counter, and returning the final cookie overflowed in debug.

The negatives used assertions that did not dereference expired references or
attempt invalid context switches. The cookie helper was extracted without
changing its allocator behavior to permit isolated counter injection. The
`negative-*.patch` files preserve this test-first state against the retained
branch source.

## Fixed source

- `final-context-mount.patch`: the existing core mount guard suppresses this
  fiber's suspension while a context callback borrows its mounted value. Nested
  fibers still install their own core; return and unwind restore the caller.
- `final-unstarted-drop.patch`: only suspended executions install their core
  during destruction; unstarted captures are dropped in the actual caller.
- `final-cookie-allocation.patch`: the global block allocator rejects exhaustion
  without advancing; the last local cookie transitions to the fresh-block sentinel.

The `final-*_test.patch` files preserve nine added tests, including a subprocess
that actually tries suspension from unstarted-entry destructors on both a carrier
and a running outer fiber. Source and executed binary hashes are recorded in
`final-source.sha256` and `final-binaries.sha256`.

## Verification

Commands used `CARGO_TARGET_DIR` set to the existing shared build cache:

```sh
cargo test --locked -p vthread-stack --lib
cargo test --locked -p vthread-stack --lib --release
```

Both completed with 79 passed, zero failed, zero ignored. See `final-debug.log`
and `final-release.log`. The suite includes terminal completion and reuse, panic
propagation, forced unwind, guard-page checks, register preservation over one
million switches, context nesting, and both new safety regressions.

No assembly or held performance candidate was changed. This run provides no new
ARM64, sanitizer, performance, or complete workspace release verdict.
