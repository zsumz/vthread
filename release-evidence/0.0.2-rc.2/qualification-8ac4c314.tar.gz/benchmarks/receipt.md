# RC.2 benchmark cleanup verification

Recorded 2026-09-07T15:09:14Z in `/root/vthread` on `release/0.0.2-rc.2`.
The working tree is based on `6e7121cd00dc7b3efdc93e128b55f83cdf89c2d0` with
the release preparation and scheduler repair applied. Cargo reports the three
runtime dependencies at `0.0.2-rc.2`; the standalone unpublished harness is `0.0.0`.

All four commands below ran sequentially. Each exited 0 on its first attempt.
No failed attempts, corrective edits, or test reruns occurred in this verification.

| Check | Result | Output |
| --- | --- | --- |
| Formatting | Passed | `01-format.log` (empty successful output) |
| Clippy, all targets and features | Passed with warnings denied | `02-clippy.log` |
| Default tests | 45 passed, 0 failed or ignored | `03-test-default.log` |
| All-feature tests | 53 passed, 0 failed or ignored | `04-test-all-features.log` |

The all-feature suite also launches its allocator check as one isolated child test;
that child passed with 52 tests filtered out. This isolates its process-global
allocation counters from the other harness tests. The retained-scenario test covers
all ten workloads, two completed rounds each, and placement observation boundaries.
Other coverage includes exact channel delivery, sampled channel evidence, command
validation/dispatch, TCP byte fidelity and incomplete-round errors.

Exact commands (Bash pipelines used `set -o pipefail`):

```sh
CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI CARGO_INCREMENTAL=0 cargo fmt --manifest-path benchmarks/Cargo.toml --all -- --check 2>&1 | tee target/rc2-review/benchmarks/01-format.log
CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI CARGO_INCREMENTAL=0 cargo clippy --locked --offline --manifest-path benchmarks/Cargo.toml --all-targets --all-features -- -D warnings 2>&1 | tee target/rc2-review/benchmarks/02-clippy.log
CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI CARGO_INCREMENTAL=0 cargo test --locked --offline --manifest-path benchmarks/Cargo.toml --all-targets 2>&1 | tee target/rc2-review/benchmarks/03-test-default.log
CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI CARGO_INCREMENTAL=0 cargo test --locked --offline --manifest-path benchmarks/Cargo.toml --all-targets --all-features 2>&1 | tee target/rc2-review/benchmarks/04-test-all-features.log
```

`source.sha256` records the benchmark manifest, lock and every Rust source file
present after these checks. `logs.sha256` records the four raw output files.
Both manifests use paths relative to the repository root.

This is targeted harness verification on Linux x86-64. It does not replace the
root-owned canonical gate, other-platform qualification, or performance acceptance.
Timing printed by tests is diagnostic output, not a benchmark acceptance result.
This agent did not modify versions or locks, commit, tag, push, or publish.
