# RC2 source-keyed local qualification

Prepared candidate, not a published release or a stable-release verdict.
The preserved source checkpoint is
`58976649f5fb2bf716cb5e2a3694dbb6bf2b2548` on `release/0.0.2-rc.2`.
Code/manifest digest:
`8ac4c314fdfe944a53ddf4395b1feb4cfa5bd18465f0c559201823030e3ef73d`.
`source.tar` contains that commit's complete checkout under `source/`, without
Git history. Its release document precedes the final package audit; the receipts
below supply that later result. The coordinating documentation commit does not
change executable source, manifests, architecture permissions, or dependencies.

## Results and identities

| Evidence | Result and boundary |
| --- | --- |
| `source-committed.json` | Clean commit, code/lock hashes, compiler, host and configuration |
| `canonical-final/receipt.json` | All 18 canonical gates passed; repository preserved |
| `application-final/receipt.json` | Full 22-case matrix passed and internally hash-verified on final code digest |
| `reference-final.log` | 13 standalone downstream tests passed on final code digest |
| `package-final.log` | Four clean committed crate archives built and verified offline; nothing published |
| `package-final-audit.md` | Final archive hashes, source/VCS identity, licenses and dependency closure |
| `packages-final/` | Four distributable RC crate archives, not uploaded |
| `executed-binaries-final.sha256` | 28 executed canonical test binary identities captured before later builds |
| `soak-receipt.md` | Three bounded processes, 530,361 lifetimes, exact cleanup; not a large-population or performance verdict |
| `scheduler/` and `stack/` | Review scope, independent cross-reviews, failed-before-fix regressions, repair patches and focused passing logs |
| `benchmarks/` | Standalone runtime-only harness review and targeted qualification |
| `architecture-lock.md` | Reviewed internal RC version-pin and inventory refresh; no expanded boundaries |

All final gates passed on their first final attempt. The earlier `canonical/`
pass also passed all 18 gates. Initial stack and scheduler failures are deliberate
negative controls, not hidden qualification failures. The initial package audit
found that the synchronization support crate omitted its license text. That
omission was repaired before final clean packaging. Initial archives remain in
`packages-initial/`; they have dirty VCS metadata and are not the final artifacts.

`source.json`, `canonical/`, `application-full/`, and the soak identify the earlier
code digest beginning `a794`. The subsequent Rust delta is documentation-only,
preserved in `final-comment-delta.patch`; the added license is outside the code
digest's suffix set. Final canonical, full application and reference qualification
were nevertheless repeated on the final digest. Do not relabel the earlier logs
or initial archives as later executions.

## Reproduction

Use the repository's pinned toolchain and tools, and an absolute build directory.
These local commands used Rust 1.96.1, `CARGO_INCREMENTAL=0`, and
`CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI`.
The path is a local ext4 build cache, not a required external service. Substitute
an appropriate local absolute path. Qualification used `CARGO_NET_OFFLINE=true`
after dependencies were already cached. Fetch the locked dependencies first when
replaying on a fresh host. Do not reuse existing application output directories.

```sh
zcheck run check --logs-dir target/rc-check --receipt target/rc-check/receipt.json
python3 scripts/run-application.py --out target/rc-application \
  --context 'local qualification; not performance acceptance' \
  --offered-rates 2000 --offered-count 256
cargo test --locked --offline --manifest-path reference/Cargo.toml --all-targets
cargo package --locked --offline --workspace --exclude vthread-lab
```

Run clean packaging in a clean checkout. The application matrix is one/four
carriers, 1/16/64/256 concurrent clients, 128 closed-loop rounds, three failure
rounds per carrier count, and 256 independently scheduled offered arrivals per
cell at 2,000/second. Payload digests, bounded occupancy, failure recovery and
shutdown are verified. Local timing observations do not qualify loaded tails on
controlled hardware. Soak commands and executed binary identity are recorded in
their separate receipt. No benchmark comparison or held optimization was run.

## Release decision

Main, remote branches, tags and published crates were not changed in this pass.
Historical performance reports and experiments remain on the preserved perf
branch and in existing stashes; they are outside this RC checkout and bundle.

Historical inbox-refill stall classification, cancellation-history timing,
exact-source native ARM64 execution, supported alternate-stack sanitizer
integration, large simultaneous/mixed-lifetime populations, footprint and
controlled-load tails/CPU remain separate open gates. The mandatory cancellation
semantics pass; two explicitly manual performance probes remain ignored.
Capacity-dependent wake observation and whole-map readiness reconciliation remain
known scaling limitations. This evidence neither waives those gates nor proves
all concurrency compositions or all advertised platforms.

`SHA256SUMS` covers every other payload in this bundle. Verify it after extracting
into a fresh directory. Archive hashes in the repository's release-evidence README
identify the complete bundle. Source hashes are content identities, not a claim
that local virtualized-host measurements establish new performance wins.
