# Source snapshot validation

`source.tar` was generated without modifying the checkout:

```sh
git archive --format=tar --prefix=source/ --output=target/rc2-review/source.tar 58976649f5fb2bf716cb5e2a3694dbb6bf2b2548
```

Reading the archive found 539 regular source files. Hashing sorted relative names,
NUL separators and file bytes for the exact suffix set used by
`scripts/evidence.py::source_digest` independently reproduced
`8ac4c314fdfe944a53ddf4395b1feb4cfa5bd18465f0c559201823030e3ef73d`.
The archived synchronization-core license matches the archived root license.
The final application receipt records this same source digest, full coverage,
22 cases, and passed status. Its internal payload inventory was validated by the
existing application verifier. The archive contains no Git history or build output.

The source checkpoint's RELEASE.md predates the final package audit. The outer
release-evidence README and `package-final-audit.md` record that completed audit;
later documentation does not change the qualified code/manifest digest.
