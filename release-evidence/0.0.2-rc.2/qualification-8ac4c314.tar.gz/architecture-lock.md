# RC2 architecture-lock review

The reviewed update was based on retained commit
`6e7121cd00dc7b3efdc93e128b55f83cdf89c2d0`.
It replaces four internal workspace dependency requirements from `=0.0.2-rc.1`
to `=0.0.2-rc.2`: runtime to stack, runtime to synchronization core, lab to
runtime, and alias to runtime. No new external dependency, macro grant, feature
world, architecture contract, or boundary permission was introduced.

The source inventory changes from 425 to 431 Rust files and 2,972 to 3,007 base
contexts, with zero unresolved bindings. The inventory digest is
`57b3fbb184fa845603e4d48b6a8150a77759e28442d8f64f4d43da82364d36db`;
the workspace lock digest is
`d343bb90ccca0c18449a0f4e3ffccbd83a832269a81a711752068faeb7e27181`.

The initial read-only update preview required four grants, four corresponding
revocations, and two evidence refreshes for inventory and lock bytes. It did not
write the lock without acceptance. The exact semantic delta was announced before
using the user's existing explicit session-wide approval for future grants:

```sh
zrail update --base 6e7121cd00dc7b3efdc93e128b55f83cdf89c2d0 --accept-grants --format json
```

The update passed. `zrail check` also passed independently after the final comment
correction with zero errors, warnings, notes, or unresolved bindings. Canonical
architecture output is retained in the corresponding `canonical*/0011-zrail.log`.
This approval was not authority to push, merge, tag, or publish the release.
