# RC.2 initial package archive audit

Read-only inspection of the four top-level archives in
`/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI/package/`.
No builds, extraction into the working tree, or source edits were performed.
Archives were read with Python `tarfile`, manifests/locks parsed with `tomllib`,
and every shipped non-generated file compared byte-for-byte with the repository.

**Finding:** the initial `vthread-sync-core` archive lacks `LICENSE`, although its
manifest declares `Apache-2.0`. The other three include license text identical to
the root license. The missing file has since been added to the source tree, but
that repair is not present in these initial archives and requires repackaging.

| Archive | Files | SHA-256 |
| --- | ---: | --- |
| `vthread-stack-0.0.2-rc.2.crate` | 44 | `814182eab0e15571320b03305ff32bdc40a1dd919ddf67644e76e2b9740ce54d` |
| `vthread-sync-core-0.0.2-rc.2.crate` | 26 | `d6c3b08f22718959ffa0d66620caf7fdba497db0c5ace3f6deef6a7ebef4635d` |
| `vthread-0.0.2-rc.2.crate` | 350 | `306aab29ad28e339c8c09ac941c8e5c1f3f454e833f99e99cf1a12f20000a772` |
| `vthreads-0.0.2-rc.2.crate` | 8 | `adbfa1bcf4767c0d9670629437a3fd537f5190a7429e30a5595384ea72ef2f96` |

The included license text in all three archives has SHA-256
`03cf56f4486aac8f6c1d18cc2dc7f8223a2d875ea2bfddec342e5fabc431daca`.

All four normalized manifests declare version `0.0.2-rc.2`, Rust `1.96`, and
`Apache-2.0`. Publishable dependency declarations have no local paths:

| Package | Normal dependencies |
| --- | --- |
| `vthread-stack` | `libc =0.2.189` |
| `vthread-sync-core` | None |
| `vthread` | `vthread-stack =0.0.2-rc.2`, `vthread-sync-core =0.0.2-rc.2`, `crossbeam-queue =0.3.13`, `libc =0.2.189`, `socket2 =0.6.5`, `zio =0.0.1-dev.1` |
| `vthreads` | `vthread =0.0.2-rc.2` |

`socket2` and `zio` retain disabled default features. The alias forwards all five
public opt-in features. The support crate's `loom =0.7.2` remains a development-only
dependency; its `generator` transitive appears only in that support crate's test
lock closure. The runtime and alias locks exclude this model-testing closure.
Internal dependency lock entries all use the exact RC.2 version and registry
identities. `Cargo.toml.orig` retains workspace/path declarations as source
metadata; consumers use the normalized manifest. External registry availability
and publication were not checked by this archive inspection.

All 405 repository Rust files belonging to these four packages are present and
byte-identical: 38 stack, 21 synchronization core, 344 runtime, and 2 alias files.
The native stack archive includes Linux x86-64 and macOS ARM64 architecture modules,
stack mapping/context machinery, and the new regression tests. The synchronization
core includes its unsafe exclusive-value and spin-mutex kernels and model tests.
Both public crates retain `#![forbid(unsafe_code)]` and contain no unsafe keyword
tokens. Inclusion of both native ports does not establish their execution on both
platforms; this audit executes neither.

No competitor source, dependency, comparison report, benchmark harness, historical
archive, target output, unexpected link, or path traversal entry was found. All
archive members are regular files. Runtime diagnostic evidence modules are normal
product source and remain included. Each packaged README's relative Markdown links
resolve inside its archive. No build script or external source-inclusion macro
requires an omitted file. Unit/model tests are intentionally packaged alongside
source; manifests, package locks, VCS metadata, README and license text account for
the other entries.

Every `.cargo_vcs_info.json` records `dirty: true` and parent commit
`6e7121cd00dc7b3efdc93e128b55f83cdf89c2d0`, with the correct package subdirectory.
That commit alone does not identify the shipped RC.2 changes. The inspected source
receipt records digest
`a794281116bfb7708c564345e5b740d9da4bb70389e1502c711a570088f5f3ed`;
archive hashes above identify these exact initial payloads. License-text addition
does not change that code/manifest digest, so the package hash must also be checked.
Repackage committed source and audit the resulting hashes, license inclusion and
VCS metadata before treating a later package set as the final release artifacts.
