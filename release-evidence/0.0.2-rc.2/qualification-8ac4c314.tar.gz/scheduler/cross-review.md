# Scheduler audit and stack cross-review

Scope: read-only inspection of retained scheduler and lifecycle changes against
`origin/main`, followed by the authorized queue-inspection repair and focused
debug verification. This receipt is local, ignored RC evidence.

Integration identifiers supplied by the coordinating agent:

- Scheduler repair: `fa9c974`.
- Stack repair: `cb63921`.
- Current source digest:
  `8ac4c314fdfe944a53ddf4395b1feb4cfa5bd18465f0c559201823030e3ef73d`.
- The source delta from the preceding qualified digest beginning `a794` is the
  accurate `Fiber::into_stack` cleanup comment; a license file was also added to
  `vthread-sync-core`. This reviewer did not independently recompute those digests.

## Retained areas inspected

- Ready-queue cohorts, oldest-wake and normal service, remote admission pressure,
  coalesced ingress visibility, bounded materialization, and idle notification.
- Generation-checked wake and timer routing, incomplete-publication deferral,
  completion-interest registration, abort retention, and shutdown cleanup.
- Borrowed occupancy and revocation epochs, task-slot ownership, completion
  batching, scope progress, carrier lifecycle, and cancellation subscriptions.
- Historical qualification dispositions and current ordered regressions for
  inbox refill, joins, timers, readiness retries, and cancellation history.

Inspection identified one queue-traversal defect with four demonstrated effects:
an eligible wake could be missed during deferred abort, selective abort could
skip a matching wake, cleanup could restore the wrong in-flight identity, and
revocation could consume its epoch while retaining a revoked borrowed wake.
All four deterministic regressions failed before the repair and passed afterward.
Commands and original outputs are retained in `receipt.md` and its linked logs.

The repair inspects each original queue entry once, retains survivors in their
original lanes, preserves the cohort state during cleanup, and restores the exact
in-flight key. Predicate selection applies the existing cohort policy to eligible
entries without moving skipped entries. Ordinary dispatch is unchanged. The
repair adds no inspection allocation and leaves admission limits, carrier affinity,
generation validation, selected-wake ownership, timer policy, cancellation
checkpoints, and structured cleanup ownership unchanged.

Focused default debug checks passed: 71 kernel tests with one existing manual
probe ignored, and nine queue-filter tests. Queue checks include all cohort
phases, small lane populations, and eligibility/removal subsets. These checks
support the bounded repair; they are not exhaustive runtime verification.

## Stack cross-review

Read-only cross-review covered `ContextKey::with`, mount guards, `Fiber::drop`,
execution stages, cookie allocation, entry disposal, leases, lexical scope drain,
and the new regression tests. It examined nested fiber suspension, forced cleanup,
callback unwinding, caller mount restoration, safe context-reference lifetimes,
and permanent cookie exhaustion. No additional concrete concern was established
in those fixes. No source changes, builds, or tests were performed during the
cross-review while canonical qualification was running.

## Limits

This was a scoped source review and targeted Linux debug verification, not an
exhaustive proof of retained performance work, a benchmark, or evidence of a new
performance improvement. Held performance candidates were not restored. This
reviewer did not run the final canonical, optimized, all-feature, cross-platform,
sanitizer, large-population, or controlled-load release matrix; the coordinating
agent owns those receipts and their verdicts.

The historical inbox-refill stall and cancellation-history timing excursion remain
separate evidence obligations. The queue repair and passing reruns do not recover
the missing historical state or establish the causes of those findings.
