# Scheduler queue inspection repair

Base: preserved production commit `6e7121c`, integration branch `release/0.0.2-rc.2`.
No held performance candidate was restored. No benchmark was run.

Four deterministic regressions were added and observed failing before production
repair:

- Deferred abort missed the eligible middle wake: selected `None`, expected task 4.
- Selective abort missed its middle wake: aborted credit 0, expected 1.
- Selective cleanup restored the wrong in-flight task: task 6, expected task 2.
- Revocation consumed the epoch while retaining the middle borrowed wake: live
  borrowed count 1, expected 0.

Every command below ran in `/root/vthread` with:

```sh
CARGO_INCREMENTAL=0
CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI
```

| Order | Command | Captured result | Log |
| --- | --- | --- | --- |
| 1 | `cargo test --locked -p vthread --lib kernel_ -- --test-threads=1` | Exit 101; 67 passed, 3 expected failures, 1 existing manual probe ignored | `negative-debug.log` |
| 2 | `cargo test --locked -p vthread --lib revoked_middle_wake -- --test-threads=1` | Exit 101; 1 expected failure | `negative-revoked-debug.log` |
| 3 | `cargo test --locked -p vthread --lib kernel_ -- --test-threads=1` | Exit 0; 71 passed, 1 existing manual probe ignored | `repaired-kernel-debug.log` |
| 4 | `cargo test --locked -p vthread --lib ready_queue -- --test-threads=1` | Exit 0; 9 passed | `repaired-queue-debug.log` |

The queue tests cover every cohort phase, 0 through 4 entries in each lane,
and every eligibility/removal subset: single inspection per entry, retained lane
order, exact identity removal, and selection parity with ordinary dispatch over
eligible entries. Normal dispatch implementation is unchanged. Cleanup uses a
linear per-lane inspection without allocation and keeps remaining live tasks
visible in intermediate snapshots.

`scheduler.patch` preserves the complete scheduler slice, including new files.
`SHA256SUMS` covers the patch and captured logs. Formatting and `git diff --check`
passed. All changed Rust files remain below 300 lines, with separate tests.

This is focused debug evidence, not full release qualification. Root owns the
final frozen-source canonical default debug/release and all-feature runs. The
shared tree also contains other agents' release and stack work; these logs do
not claim qualification of those changes. The historical inbox-refill stall and
cancellation-history timing finding remain separate evidence obligations.
