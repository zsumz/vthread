# RC2 bounded mixed-workload qualification

Source digest: `a794281116bfb7708c564345e5b740d9da4bb70389e1502c711a570088f5f3ed`.
Native Linux x86-64 default release binary SHA-256:
`ced4bd14c8820d15d4744e39ee9cf3de7ed49445803122ef8a52f57cd3f79e8c`.
Compiler and host identity are in `source.json`; build output is `soak-build.log`.

All three planned processes ran sequentially, without hardware counters, with no
concurrent benchmark or qualification build. Each first attempt exited zero.

| Command arguments | Iterations | Spawned/completed | Parks/wakes | Stack allocations/reuse |
| --- | ---: | ---: | ---: | ---: |
| `soak 30 1 64` | 2,662 | 183,678 | 1,945,923 | 68 / 183,610 |
| `soak 30 4 64` | 2,862 | 197,478 | 2,022,467 | 68 / 197,410 |
| `soak 30 4 1024` | 145 | 149,205 | 1,632,906 | 1,028 / 148,177 |

The executed binary was
`/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI/release/vthread-lab`.
Every invocation used `timeout 90s BINARY ARGUMENTS`; `set -euo pipefail` retained
its exit status while teeing output to `soak-CARRIERS-TASKS.log`.

The existing fixture exercises synchronization, persistent TCP pairs, timers,
native blocking, affinity, cancellation, stack reuse, service drainage and final
shutdown. It asserts exact resource cleanup after every batch and at shutdown.
Total completed task lifetimes: 530,361. Total park/wake pairs: 5,601,296.

This is bounded correctness evidence on an uncontrolled local host. It is not
performance acceptance, a large simultaneous-population test, or completion of
the separate ten-million mixed-lifetime release target.
