"""One predeclared confirmation, with twelve new bare pairs per protected cell."""

from panel import run
from readiness_cases import SCENARIOS


def plan():
    jobs = []
    for rep in range(1, 13):
        for scenario in (SCENARIOS if rep % 2 else reversed(SCENARIOS)):
            for pinned in ([False, True] if rep % 2 else [True, False]):
                case = dict(scenario, name=scenario['name'] + ('-pinned' if pinned else '-default'),
                            pinned=pinned, args=scenario['args'] + (['--pin-carriers'] if pinned else []))
                for arm in (['A', 'B'] if rep % 2 else ['B', 'A']):
                    jobs.append(dict(prefix=f'confirmation-{rep}-{case["name"]}-bare-{arm}',
                                     repetition=rep, collector='bare', arm=arm, case=case))
    return jobs


def decisions(groups):
    result = {}
    for key, group in groups.items():
        checks = {'time': (group['timing_effect'], 1.05), 'process_cpu': (group['cpu_effect'], 1.05)}
        for phase, effects in group.get('endpoint_effects', {}).items():
            for field, effect in effects.items():
                if field in ['p99_9_ns', 'p99_99_ns'] or (phase == 'fairness' and field in [
                        'task_median_max_ns', 'task_p99_9_max_ns', 'task_worst_ns']):
                    checks[f'{phase}.{field}'] = (effect, 1.10)
        result[key] = {name: ('pass' if effect['upper_95'] <= margin else
                             'regression' if effect['lower_95'] > margin else 'inconclusive')
                       for name, (effect, margin) in checks.items()}
    return result


if __name__ == '__main__':
    import json
    from panel import OUT
    groups = run('confirmation', plan())
    result = decisions(groups)
    with (OUT / 'confirmation-decisions.json').open('x') as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2), flush=True)
    print('Promotion requires all protected checks plus intended scaling and full qualification.', flush=True)
