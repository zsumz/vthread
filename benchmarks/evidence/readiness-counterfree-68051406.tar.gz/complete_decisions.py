"""Include already-collected worst-task fields without replacing runs or prior decisions."""

import json

from confirmation import decisions
from panel import OUT

groups = json.loads((OUT / 'confirmation-analysis.json').read_text())
result = decisions(groups)
with (OUT / 'confirmation-complete-decisions.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))
