"""Archive held readiness recovery with full paired outcomes and source reconstruction."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

assert evidence.source_digest() == json.loads((OUT / 'A-source.json').read_text())['source_sha256']
for name, count in [('screen', 128), ('confirmation', 192)]:
    jobs = json.loads((OUT / f'{name}-plan.json').read_text())
    assert len(jobs) == len(list(OUT.glob(f'{name}-*.result.json'))) == count
    for job in jobs:
        assert json.loads((OUT / f'{job["prefix"]}.result.json').read_text())['returncode'] == 0
for name in ['screen-analysis.json', 'confirmation-analysis.json', 'confirmation-complete-decisions.json', 'LEDGER.md']:
    assert (OUT / name).is_file()
assert '23 passed; 0 failed' in (OUT / 'targeted-readiness.log').read_text()
with (OUT / 'verification-tests.log').open('x') as stream:
    subprocess.run(['python3', '-m', 'unittest', 'discover', '-s', str(OUT), '-p', '*_test.py', '-v'],
                   cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=True)
reference = ROOT / 'target/finish-line/may-refresh.yvxHtB'
dependencies = OUT / 'replay-dependencies'
dependencies.mkdir(exist_ok=False)
for name in ['analyze.py', 'cases.py', 'bare-default-1-tcp4-vthread.log']:
    shutil.copy2(reference / name, dependencies / name)
shutil.copy2(ROOT / 'benchmarks/counter-free-acceptance.md', OUT / 'predeclared-acceptance.md')
for arm in ['A', 'B']:
    manifest = json.loads((OUT / f'{arm}-source.json').read_text())
    assert manifest['binary_sha256'] == evidence.digest(OUT / f'benchmark-{arm}')
    with tarfile.open(OUT / f'{arm}-source.tar.gz') as archive:
        source = hashlib.sha256()
        for member in sorted(archive.getmembers(), key=lambda member: member.name):
            assert member.isfile()
            source.update(member.name.encode() + b'\0' + archive.extractfile(member).read() + b'\0')
        assert source.hexdigest() == manifest['source_sha256']
        if arm == 'B':
            paths = evidence.output('git', 'diff', '--name-only', '495c931', 'f127ed1', '--',
                                    'crates/vthread/src/readiness.rs', 'crates/vthread/src/readiness').splitlines()
            assert len(paths) == 11
            for name in paths:
                original = subprocess.check_output(['git', 'show', f'f127ed1:{name}'], cwd=ROOT)
                assert original == archive.extractfile(name).read(), name
destination = ROOT / 'benchmarks/evidence/readiness-counterfree-68051406.tar.gz'
paths = sorted(path for path in OUT.rglob('*') if path.is_file() and '__pycache__' not in path.parts
               and not path.name.startswith('benchmark-') and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(destination, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
with tarfile.open(destination) as archive:
    assert len(archive.getmembers()) == len(paths) + 1
    for line in archive.extractfile('SHA256SUMS').read().decode().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
print(destination, evidence.digest(destination), len(paths), 'verified hashes; original candidate bytes verified')
