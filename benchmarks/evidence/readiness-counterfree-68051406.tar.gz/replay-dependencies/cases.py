"""Frozen default-contract scorecard; mechanisms and spare capacity stay separate."""

CASES = [
    dict(name='yield4', mask='0-3', args=['yield', '100000', '4', '64', '9'],
         operation='yield', workers=4, tasks=64, per_task=100000, rounds=9),
    dict(name='spawn1000', mask='0-3', args=['spawn', '4', '1000', '101'],
         operation='task', workers=4, tasks=1000, per_task=1, rounds=101),
    dict(name='spawn10000', mask='0-3', args=['spawn', '4', '10000', '101'],
         operation='task', workers=4, tasks=10000, per_task=1, rounds=101),
    dict(name='park4', mask='0-3', args=['park', '100000', '4', '64', '9'],
         operation='park-handoff', workers=4, tasks=64, per_task=100000, rounds=9),
    dict(name='mutex4', mask='0-3', args=['mutex', '100000', '4', '64', '9'],
         operation='mutex-handoff', workers=4, tasks=64, per_task=100000, rounds=9),
    dict(name='mutex-local', mask='7', args=['mutex-uncontended', '10000000', '1', '1', '9'],
         operation='mutex-uncontended', workers=1, tasks=1, per_task=10000000, rounds=9),
    dict(name='channel4', mask='0-3', args=['channel', '100000', '4', '64', '9'],
         operation='channel-handoff', workers=4, tasks=64, per_task=100000, rounds=9),
    dict(name='bounded-spsc4', mask='0-3', args=['channel-bounded-spsc', '100000', '1', '4', '64', '9'],
         operation='bounded-spsc-channel-1-handoff', workers=4, tasks=64, per_task=100000, rounds=9),
    dict(name='wake4', mask='0-3', args=['wake-tail', '10000', '4', '64', '9'],
         operation='wake-to-resume', workers=4, tasks=64, per_task=10000, rounds=9),
    dict(name='tcp4', mask='0-3', args=['tcp', '1000', '4', '8', '9'],
         operation='tcp-round-trip', workers=4, tasks=8, per_task=1000, rounds=9),
]


def plan():
    result = []
    for repetition in range(1, 5):
        cases = CASES if repetition % 2 else list(reversed(CASES))
        for index, case in enumerate(cases):
            # Each case has two V-first and two M-first process pairs.
            engines = ['vthread', 'may'] if repetition in (1, 4) else ['may', 'vthread']
            if CASES.index(case) % 2:
                engines.reverse()
            for engine in engines:
                result.append(dict(prefix=f'default-{repetition}-{case["name"]}-{engine}',
                                   repetition=repetition, engine=engine, case=case))
    return result
