"""Require the full balanced panel; distinguish round throughput from endpoint tails."""

import ast
import csv
import json
from pathlib import Path
import re
import statistics

from cases import CASES, plan

OUT = Path(__file__).resolve().parent
EVENTS = {'cycles', 'instructions', 'task-clock', 'context-switches', 'cpu-migrations'}


def fields(line):
    return dict(re.findall(r'([a-zA-Z0-9_]+)=([^\s]+)', line))


def parse(text, job):
    case, engine = job['case'], job['engine']
    lines = text.splitlines()
    reports = [line for line in lines if ' ns_per_operation=' in line]
    assert len(reports) == 1
    report = fields(reports[0])
    assert report['engine'] == engine and report['operation'] == case['operation']
    assert int(report['workers']) == case['workers'] and int(report['tasks']) == case['tasks']
    samples = ast.literal_eval(re.search(r'\bsamples=(\[.*\])', reports[0])[1])
    assert len(samples) == case['rounds'] and all(isinstance(n, int) and n > 0 for n in samples)
    assert samples == sorted(samples)
    for key, percentile in [('median_ns', 50), ('p95_ns', 95), ('p99_ns', 99)]:
        assert int(report[key]) == samples[(len(samples) * percentile + 99) // 100 - 1]
    assert int(report['max_ns']) == samples[-1]
    operations = case.get('operation_tasks', case['tasks']) * case['per_task']
    ns_per_operation = int(report['median_ns']) / operations
    assert abs(float(report['ns_per_operation']) - ns_per_operation) <= 0.005001
    if engine == 'vthread':
        configuration = [fields(line) for line in lines if 'phase=configuration ' in line]
        assert len(configuration) == 1
        assert configuration[0]['pin_carriers'] == 'false'
        assert int(configuration[0]['max_vthreads']) == case.get('capacity', max(case['tasks'], case['workers']))
    phases = {}
    for phase in ['latency', 'fairness', 'pair-fairness', 'placement', 'migration']:
        found = [line for line in lines if f'phase={phase} ' in line]
        assert len(found) <= 1
        if found:
            values = fields(found[0])
            assert values['engine'] == engine and values['operation'] == case['operation']
            phases[phase] = {key: int(value) for key, value in values.items() if value.isdigit()}
    if case['name'] in ('wake4', 'tcp4'):
        latency = phases['latency']
        assert latency['observations'] == operations * case['rounds']
        values = [latency[key] for key in ('median_ns', 'p95_ns', 'p99_ns', 'p99_9_ns', 'p99_99_ns', 'max_ns')]
        assert values == sorted(values) and values[0] > 0
        assert phases['fairness']['task_streams'] == case['tasks']
        if case['name'] == 'wake4':
            assert phases['pair-fairness']['pair_streams'] == case['tasks'] // 2
    return dict(ns_per_operation=ns_per_operation, round_samples_ns=samples,
                phases=phases, process_operations=operations * (case['rounds'] + 1))


def counters(path):
    values = {}
    for row in csv.reader(path.read_text().splitlines()):
        if len(row) < 5 or row[2] not in EVENTS:
            continue
        assert '<' not in row[0] and float(row[4]) >= 99.5, row
        assert row[2] not in values
        values[row[2]] = float(row[0])
    assert set(values) == EVENTS
    return values


def selected(job):
    prefix = job['prefix']
    assert json.loads((OUT / f'{prefix}.result.json').read_text())['returncode'] == 0
    for stage in ['before', 'after']:
        assert not (OUT / f'{prefix}.{stage}.guard').read_text().strip()
    value = parse((OUT / f'{prefix}.log').read_text(), job)
    value.update(prefix=prefix, counters=counters(OUT / f'{prefix}.csv'))
    value['process_counters_per_operation'] = {key: count / value['process_operations']
                                             for key, count in value['counters'].items()}
    return value


def spread(values):
    return dict(values=values, median=statistics.median(values), minimum=min(values), maximum=max(values))


def summarize():
    jobs = plan()
    assert len(jobs) == 80 and json.loads((OUT / 'plan.json').read_text()) == jobs
    assert len(list(OUT.glob('default-*.result.json'))) == 80, 'incomplete or extra process panel'
    values = {job['prefix']: selected(job) for job in jobs}
    report = {}
    for case in CASES:
        arms = {engine: [values[f'default-{rep}-{case["name"]}-{engine}'] for rep in range(1, 5)]
                for engine in ['vthread', 'may']}
        summaries = {}
        for engine, processes in arms.items():
            summaries[engine] = dict(
                ns_per_operation=spread([row['ns_per_operation'] for row in processes]),
                process_counters={event: spread([row['process_counters_per_operation'][event] for row in processes])
                                  for event in sorted(EVENTS)},
                phases={phase: {key: spread([row['phases'][phase][key] for row in processes])
                                for key in processes[0]['phases'][phase]}
                        for phase in processes[0]['phases']}, processes=processes)
        report[case['name']] = dict(case=case, engines=summaries,
            paired_vthread_over_may=[a['ns_per_operation'] / b['ns_per_operation']
                                    for a, b in zip(arms['vthread'], arms['may'])])
    return report


def main():
    report = summarize()
    with (OUT / 'analysis.json').open('x') as stream:
        json.dump(report, stream, indent=2)
    print('| Case | Vthread ns/op | May ns/op | V/M time | V/M process cycles |')
    print('| --- | ---: | ---: | ---: | ---: |')
    for name, record in report.items():
        v, m = record['engines']['vthread'], record['engines']['may']
        vt, mt = v['ns_per_operation']['median'], m['ns_per_operation']['median']
        vc, mc = v['process_counters']['cycles']['median'], m['process_counters']['cycles']['median']
        print(f'| {name} | {vt:.2f} | {mt:.2f} | {vt / mt:.3f} | {vc / mc:.3f} |')
    print('Validated all 80 guarded current-source processes; no missing repetitions inferred.')


if __name__ == '__main__':
    main()
