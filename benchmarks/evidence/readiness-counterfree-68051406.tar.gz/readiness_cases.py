"""Predeclared small TCP and tight/spare lifecycle screens, before observing B."""

SCENARIOS = [
    dict(name='tcp1', mask='7', args=['tcp', '3000', '1', '1', '7'],
         operation='tcp-round-trip', workers=1, tasks=1, capacity=1, per_task=3000, rounds=7),
    dict(name='tcp4', mask='0-3', args=['tcp', '1000', '4', '8', '9'],
         operation='tcp-round-trip', workers=4, tasks=8, capacity=8, per_task=1000, rounds=9),
    dict(name='spawn1000', mask='0-3', args=['spawn', '4', '1000', '501'],
         operation='task', workers=4, tasks=1000, capacity=1000, per_task=1, rounds=501),
    dict(name='spawn-spare', mask='0-3', args=['spawn', '4', '1000', '101', '--max-vthreads', '65536'],
         operation='task', workers=4, tasks=1000, capacity=65536, per_task=1, rounds=101),
]


def screen_plan():
    jobs = []
    for rep in range(1, 5):
        for scenario in (SCENARIOS if rep % 2 else reversed(SCENARIOS)):
            for pinned in ([False, True] if rep % 2 else [True, False]):
                case = dict(scenario, name=scenario['name'] + ('-pinned' if pinned else '-default'),
                            pinned=pinned, args=scenario['args'] + (['--pin-carriers'] if pinned else []))
                collectors = ['bare', 'perf'] if (rep % 2) != pinned else ['perf', 'bare']
                for collector in collectors:
                    arms = ['A', 'B'] if rep in [1, 4] else ['B', 'A']
                    if collector == 'perf':
                        arms.reverse()
                    for arm in arms:
                        jobs.append(dict(prefix=f'screen-{rep}-{case["name"]}-{collector}-{arm}',
                                         repetition=rep, collector=collector, arm=arm, case=case))
    return jobs
