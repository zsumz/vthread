# Existing incremental readiness: held after counter-free confirmation

Retained source e344a60e; candidate source 68051406, based on `fe6eb0a`.
All eleven restored readiness files exactly match `f127ed1`; no new reactor,
polling, stack, mutex or channel change. The older population fixture is not
added: the protected screen must pass before rerunning scaling qualification.
Candidate retained at stash `2c57469096150f28b4ae2bd76076792b859535b0`.

- Both default benchmark builds pass formatting, 47 tests, clippy and feature
  capture. Baseline executable is byte-identical to the quiet-window baseline.
- All 23 current-source native debug readiness tests pass, including the existing
  production-State model (247/1400 states, 1541/9941 edges). No new full canonical
  candidate run, optimized runtime suite, sanitizer or ARM64 execution is claimed.
- All 128 screen processes complete with clear endpoint build guards. No bare
  cell meets the predeclared three-loss gross-stop condition.
- All 192 fresh confirmation processes complete: twelve bare pairs per protected
  cell, no replacement processes. Timing/CPU/tail non-regression is inconclusive
  in protected cells. No promotion, extra sampling or population run follows.
- The first decision table omitted worst-task checks because its field-name
  selector expected `worst*` rather than the actual `task_*` names. Raw analysis
  already included every fairness ratio. The initial table is retained; the
  complete table applies the same predeclared margins to those fields. A negative
  analysis test proves omission no longer passes. The held decision is unchanged.
- Seven analysis tests pass. Post-exit CPU includes wrappers/setup/teardown; peak
  RSS is not a runtime-only footprint. Individual pinning is verified at setup,
  not a measurement of every task's execution placement throughout the workload.
- Reproduction initially refused a patch containing the word `truncated` in a
  model assertion; no files changed in that refused attempt. Actual token count
  verified complete, then exact patch applied. This was not a Rust failure.

Keep the historical population scaling result and its original counter-mode
caveats; this bundle does not establish a new scaling or May result. Absolute
one-carrier TCP tails and multimodal pinned lifecycle controls remain visible.
Do not infer a stable production regression from an inconclusive protected cell.

Replay dependencies and sample log are included under replay-dependencies;
adjust recorded absolute paths when replaying elsewhere. All raw results, both
source archives, predeclared rules and executed binary identities are retained.
