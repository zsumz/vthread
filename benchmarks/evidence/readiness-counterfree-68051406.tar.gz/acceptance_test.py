"""Validate the extended screen without running any performance processes."""

import copy
from pathlib import Path
import unittest

from acceptance import paired, parse
from confirmation import decisions, plan
from readiness_cases import screen_plan


class AcceptanceTests(unittest.TestCase):
    def test_confirmation_uses_twelve_fresh_balanced_pairs(self):
        jobs = plan()
        self.assertEqual(len(jobs), 192)
        self.assertEqual(len({job['prefix'] for job in jobs}), 192)
        for name in {job['case']['name'] for job in jobs}:
            first = [job['arm'] for index, job in enumerate(jobs)
                     if index % 2 == 0 and job['case']['name'] == name]
            self.assertEqual(first.count('A'), 6)
            self.assertEqual(first.count('B'), 6)
        self.assertTrue(all(job['collector'] == 'bare' for job in jobs))

    def test_uncertainty_cannot_become_non_regression(self):
        group = dict(timing_effect=dict(lower_95=0.99, upper_95=1.06),
                     cpu_effect=dict(lower_95=0.99, upper_95=1.01))
        self.assertEqual(decisions({'case': group})['case']['time'], 'inconclusive')
        group['timing_effect']['lower_95'] = 1.055
        self.assertEqual(decisions({'case': group})['case']['time'], 'regression')

    def test_actual_worst_task_field_names_are_protected(self):
        effect = dict(lower_95=1.11, upper_95=1.20)
        group = dict(timing_effect=effect, cpu_effect=effect,
                     endpoint_effects={'fairness': {field: effect for field in [
                         'task_median_max_ns', 'task_p99_9_max_ns', 'task_worst_ns']}})
        result = decisions({'case': group})['case']
        for field in group['endpoint_effects']['fairness']:
            self.assertEqual(result[f'fairness.{field}'], 'regression')

    def test_complete_balanced_plan(self):
        jobs = screen_plan()
        self.assertEqual(len(jobs), 128)
        self.assertEqual(len({job['prefix'] for job in jobs}), 128)
        for name in {job['case']['name'] for job in jobs}:
            for collector in ['bare', 'perf']:
                first = [job['arm'] for index, job in enumerate(jobs)
                         if index % 2 == 0 and job['case']['name'] == name and job['collector'] == collector]
                self.assertEqual(first.count('A'), 2)
                self.assertEqual(first.count('B'), 2)
            first = [job['collector'] for index, job in enumerate(jobs)
                     if index % 4 == 0 and job['case']['name'] == name]
            self.assertEqual(first.count('bare'), 2)
            self.assertEqual(first.count('perf'), 2)

    def test_known_log_and_missing_endpoint_samples(self):
        job = next(copy.deepcopy(job) for job in screen_plan() if job['case']['name'] == 'tcp4-default')
        path = Path('/root/vthread/target/finish-line/may-refresh.yvxHtB/bare-default-1-tcp4-vthread.log')
        text = path.read_text()
        self.assertGreater(parse(text, job)['ns_per_operation'], 0)
        with self.assertRaises((AssertionError, KeyError)):
            parse('\n'.join(line for line in text.splitlines() if 'phase=latency' not in line), job)

    def test_early_stop_and_missing_pairs(self):
        self.assertTrue(paired([1] * 4, [1.2] * 4)['gross_bare_stop'])
        self.assertFalse(paired([1] * 4, [0.9, 1, 1.5, 1.5])['gross_bare_stop'])
        with self.assertRaises(AssertionError):
            paired([1] * 4, [1] * 3)

    def test_mismatched_pinning_cannot_pass(self):
        job = next(copy.deepcopy(job) for job in screen_plan() if job['case']['name'] == 'tcp4-default')
        text = Path('/root/vthread/target/finish-line/may-refresh.yvxHtB/bare-default-1-tcp4-vthread.log').read_text()
        job['case']['pinned'] = True
        with self.assertRaises(AssertionError):
            parse(text, job)


if __name__ == '__main__':
    unittest.main()
