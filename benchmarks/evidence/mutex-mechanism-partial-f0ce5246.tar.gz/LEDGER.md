# Partial resumption of exact-owner mutex controls

No runtime, fixture, ownership, fairness or polling change. A detached worktree at
80b3ba1 verifies the exact qualified fixture source f0ce5246 and saved default /
diagnostic executables. The complete preceding fixture patch and receipt are
retained. All original setup/negative-control qualification is in the preceding
mutex-mechanism-f0ce5246.tar.gz bundle. The current perf branch at 4107adb differs
only by subsequent test/policy/evidence repairs; the only non-test Rust difference
is a cfg(test) I/O module declaration (runtime-since-control.patch).

The existing runner and analyzer are copied, changing only the verified source
root and result prefix. Four parser tests pass. The full analyzer rejects the
excluded record and writes no complete analysis. partial.py explicitly inventories
an incomplete panel instead of replacing missing repetitions with smoke data.

Twelve default processes completed. Eleven have clear before/after build guards;
resumed-default2-2-local-1000 is excluded because the after guard observed cargo
PID 3006228. A guard hit is grounds for exclusion, not proof that this process's
individual samples were delayed by that build. Six planned default processes did
not run. The diagnostic phase also stops at its before guard: zero diagnostic
processes ran. No silent replacement, retry, or complete-panel claim follows.

The six 10,000-handoff processes give two independent observations per control:
local p50 190-191 ns, remote-active 321-340 ns, observed-sleep 10,466-10,486 ns.
Their p99.9 ranges are 250-271 ns, 501 ns and 45,459-54,611 ns respectively.
Observed-sleep maxima reach 19,224,784 ns (the 1,000-handoff group reaches
19,244,254 ns). All extrema remain visible. These are incomplete forced-state
controls, not the default contended-mutex workload, a new speedup or May evidence.

Full process counters include setup, command handshakes, source/keeper yields,
procfs observation, shutdown and raw-sample output. At 10,000 handoffs local
process cycles/handoff are 19,318-22,852, remote-active 40,806-52,901 and observed
sleep 384,552-392,898. Those are not the costs of a mutex operation or the measured
unlock-to-lock-return interval. Two work counts expose the fixed/process overhead;
there is no fitted causal attribution or instruction-level optimization claim.

Exact owner IDs/TIDs and affinity are verified on the measured tasks. Sleep is
observed before release, not atomically established at publication. Command parks
contribute to recipient_parks, and this one-successor fixture is not a fairness or
offered-load test. No frequency of these states in the production benchmark can
be inferred from forcing them here. The diagnostic routing/native-wait breakdown
and complete balanced repetition panel remain open.

Replay requires restoring the frozen 80b3ba1 source worktree and the saved binaries
matching frozen-identity.json, then selecting an unused prefix. Do not modify or
overwrite these attempts. Executed binaries remain local and are excluded from
the durable archive, consistent with the preceding fixture bundle.
