"""Validate exact frozen fixture source and previously qualified executables."""

import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/tmp/vthread-mutex-frozen.1euCDs')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

manifest = evidence.metadata('resumed exact-owner mutex controls at frozen 80b3ba1; no runtime candidate')
assert manifest['head'] == '80b3ba1b51abe1f471faf430e05c3d80f2d0a5d5'
assert manifest['dirty'] is False
assert manifest['source_sha256'] == 'f0ce5246d87b7846b36b0d1ddc8f3f7c1b95e5509922f20f2fe8b4bbdfe9b9c5'
manifest['binaries'] = {}
for arm in ['default2', 'diagnostic2']:
    original = json.loads((OUT / f'{arm}-source.json').read_text())
    assert original['source_sha256'] == manifest['source_sha256']
    digest = evidence.digest(OUT / f'{arm}-binary')
    assert digest == original['binary_sha256']
    manifest['binaries'][arm] = digest
with (OUT / 'frozen-identity.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
print(json.dumps(manifest, indent=2))
