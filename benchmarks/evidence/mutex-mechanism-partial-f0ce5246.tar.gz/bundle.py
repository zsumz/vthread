"""Archive all partial controls, exclusions and frozen identities, without binaries."""

import hashlib
from pathlib import Path
import subprocess
import tarfile
import tempfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
archive_path = ROOT / 'benchmarks/evidence/mutex-mechanism-partial-f0ce5246.tar.gz'
paths = sorted(path for path in OUT.rglob('*') if path.is_file()
               and '__pycache__' not in path.parts and path.name != 'SHA256SUMS'
               and not path.name.endswith('-binary'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(archive_path, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
verify = Path(tempfile.mkdtemp(prefix='mutex-mechanism-partial-verify.', dir=ROOT / 'target/finish-line'))
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    assert all(member.isfile() and not Path(member.name).is_absolute()
               and '..' not in Path(member.name).parts for member in members)
    archive.extractall(verify, members=members)
with (verify / 'verification.log').open('x') as stream:
    subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=verify, stdout=stream,
                   stderr=subprocess.STDOUT, check=True)
print('archive', archive_path)
print('sha256', digest(archive_path))
print('verified', len(paths), 'internal hashes', verify)
