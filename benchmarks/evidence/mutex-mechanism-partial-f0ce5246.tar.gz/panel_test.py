import unittest
import panel


VALID = '''phase=affinity tid=1 cpu=6 verified=true
schema=1 workload=mutex-mechanism mode=local iterations=2 sender_tid=1 recipient_tid=1 sender_carrier=0 recipient_carrier=0 recipient_parks=4 source_yields=10 keeper_yields=0 queued_handoffs=2 sleep_observations=0 elapsed_ns=100 p50_ns=4 p99_ns=8 p999_ns=8 max_ns=8
sample=0 nanoseconds=8
sample=1 nanoseconds=4
'''


class EvidenceTest(unittest.TestCase):
    def test_complete_unsorted_sequence_is_retained_and_quantiles_checked(self):
        report, diagnostics = panel.parse(VALID)
        self.assertEqual(report['max_ns'], '8')
        self.assertEqual(diagnostics, [])

    def test_missing_duplicate_or_corrupt_samples_are_rejected(self):
        for bad in [VALID.replace('sample=1 nanoseconds=4\n', ''),
                    VALID.replace('sample=1', 'sample=0'), VALID.replace('p99_ns=8', 'p99_ns=7')]:
            with self.assertRaises(AssertionError):
                panel.parse(bad)

    def test_unverified_topology_cannot_be_labeled_remote(self):
        for bad in [VALID.replace('mode=local', 'mode=remote-active'),
                    VALID.replace('verified=true', 'verified=false'),
                    VALID.replace('affinity tid=1', 'affinity tid=2')]:
            with self.assertRaises(AssertionError):
                panel.parse(bad)

    def test_unobserved_sleep_and_incomplete_handoffs_are_rejected(self):
        for bad in [VALID.replace('sleep_observations=0', 'sleep_observations=2'),
                    VALID.replace('queued_handoffs=2', 'queued_handoffs=1'),
                    VALID.replace('recipient_parks=4', 'recipient_parks=1')]:
            with self.assertRaises(AssertionError):
                panel.parse(bad)


if __name__ == '__main__':
    unittest.main()
