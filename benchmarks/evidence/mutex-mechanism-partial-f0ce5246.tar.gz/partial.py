"""Inventory incomplete controls without presenting them as the planned panel."""

import json
from pathlib import Path

from analyze import counters
from panel import parse

OUT = Path(__file__).resolve().parent
records = []
groups = {}
for path in sorted(OUT.glob('resumed-default2-*.result.json')):
    prefix = path.name.removesuffix('.result.json')
    result = json.loads(path.read_text())
    guards = {stage: (OUT / f'{prefix}.{stage}.guard').read_text().strip()
              for stage in ('before', 'after')}
    report, diagnostics = parse((OUT / f'{prefix}.log').read_text())
    record = {'prefix': prefix, 'returncode': result['returncode'], 'guards': guards,
              'report': report, 'counters': counters(OUT / f'{prefix}.csv')}
    record['clean_endpoint_guards'] = result['returncode'] == 0 and not any(guards.values())
    records.append(record)
    if record['clean_endpoint_guards']:
        key = f'{report["mode"]}-{report["iterations"]}'
        groups.setdefault(key, []).append(record)
assert len(records) == 12
assert sum(record['clean_endpoint_guards'] for record in records) == 11
assert not list(OUT.glob('resumed-diagnostic2-*.result.json'))
summary = {}
for key, values in groups.items():
    count = int(values[0]['report']['iterations'])
    ranges = {}
    for field in ['p50_ns', 'p99_ns', 'p999_ns', 'max_ns', 'recipient_parks', 'source_yields', 'keeper_yields']:
        observations = [int(value['report'][field]) for value in values]
        ranges[field] = [min(observations), max(observations)]
    for field in values[0]['counters']:
        observations = [value['counters'][field] / count for value in values]
        ranges[f'process_{field}_per_handoff'] = [min(observations), max(observations)]
    summary[key] = {'processes': len(values), 'ranges': ranges}
with (OUT / 'partial-inventory.json').open('x') as stream:
    json.dump({'planned_panel_complete': False, 'completed_default': 12,
               'clear_endpoint_guards': 11, 'excluded': 1, 'default_unrun': 6,
               'diagnostic_unrun': 9, 'groups': summary, 'records': records}, stream, indent=2)
print(json.dumps(summary, indent=2))
