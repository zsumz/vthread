"""Record ordered cross-runtime join evidence without native test gates."""

import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
ENV = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_TARGET_DIR='/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def run(label, command, expected=0):
    with (OUT / f'{label}.command.json').open('x') as stream:
        json.dump({'argv': command, 'environment': {key: ENV[key] for key in ('CARGO_INCREMENTAL', 'CARGO_TARGET_DIR')},
                   'source': evidence.metadata(label)}, stream, indent=2)
    with (OUT / f'{label}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    with (OUT / f'{label}.result.json').open('x') as stream:
        json.dump({'returncode': result.returncode, 'expected': expected}, stream)
    print(label, result.returncode, flush=True)
    assert result.returncode == expected


mode = sys.argv[1]
if mode in ('initial', 'negative-order', 'negative-ownership', 'negative-panic', 'restored'):
    run(mode, ['cargo', 'test', '--locked', '-p', 'vthread', 'kernel_cross_join_test', '--', '--nocapture'],
        101 if mode.startswith('negative') else 0)
    log = (OUT / f'{mode}.log').read_text()
    if mode == 'negative-order':
        assert 'left: Stale' in log and 'right: Published' in log
    elif mode == 'negative-ownership':
        assert 'retained target: Err(ResultAlreadyTaken)' in log
    elif mode == 'negative-panic':
        assert 'completed-panic' in log and 'TaskPanicked' in log and '1 failed' in log
    else:
        assert 'test result: ok. 2 passed;' in log
elif mode == 'canonical':
    run(mode, ['zcheck', 'run', 'check', '--logs-dir', str(OUT / mode),
               '--receipt', str(OUT / f'{mode}-receipt.json')])
elif mode == 'repeat':
    profile = sys.argv[2]
    log = OUT / f'canonical/{"0007-test-native.log" if profile == "debug" else "0008-test-native-release.log"}'
    binaries = re.findall(r'Running unittests src/lib.rs \(([^)\s]*/deps/vthread-[0-9a-f]+)\)', log.read_text())
    assert len(binaries) == 1, binaries
    binary = binaries[0]
    with (OUT / f'repeat-{profile}-binary.json').open('x') as stream:
        json.dump({'path': binary, 'sha256': evidence.digest(Path(binary))}, stream)
    for index in range(20):
        label = f'repeat-{profile}-{index:02}'
        run(label, ['taskset', '-c', '6', binary, 'kernel_cross_join_test', '--nocapture'])
        log = (OUT / f'{label}.log').read_text()
        assert 'test result: ok. 2 passed;' in log
        assert 'cross-join recovery completed=Ok(42) repeated=Err(ResultAlreadyTaken)' in log
elif mode == 'timers':
    run(mode, ['cargo', 'test', '--locked', '-p', 'vthread', 'kernel_timer_deadline_test', '--', '--nocapture'])
else:
    raise SystemExit(f'unknown mode {mode}')
