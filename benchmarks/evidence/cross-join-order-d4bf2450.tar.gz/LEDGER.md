# Cross-runtime join: typed interruption and recovery

Base dd81a31. No production join, deadline, parking, completion, ownership or
scheduler protocol changes. The kernel only declares cfg(test) modules. The
ordinary-thread owner fixture is extracted from the preceding timer test;
those timer cases are rerun independently as well as canonically.

## Captured finding and classification

The preserved loaded-3.log explicitly shows a target task's five-second native
test gate timing out and panicking, the waiter's deadline-only assertion failing,
then a disconnected handle-return channel. Neither of the latter two observations
prints the actual join result. The fixture failure is established; the precise
original scheduling trace and returned error cannot be recovered from that log.
It is not evidence that runtime interruption consumed a handle or lost a result.

The replacement first drives the foreign target to a real virtual park, then
drives a distinct runtime's waiter to an exact Join(target) generation. Local
task IDs deliberately collide across the distinct runtime identities. The real
deadline is selected and observed Published before permitting resumption. The
typed result carries both the interruption and target handle, without a native
observer channel. The target remains unfinished/WouldBlock, is explicitly
released, and returns 42 once; the second take reports ResultAlreadyTaken.

A separate case explicitly completes the target with a panic before running an
overdue joiner. The completed task's TaskPanicked outcome wins the immediate
completion path; the caller's next checkpoint observes DeadlineExceeded. This
ordered counterexample demonstrates why the historical deadline-only oracle was
invalid after its native test gate failed. It does not invent the missing error
text in the old log.

Both owners keep their native stacks on the same ordinary test thread. This is
cross-runtime identity/ownership proof, not concurrent OS-carrier scheduling,
sleep/wake latency, a new migration policy or performance acceptance. Real clocks
are unchanged; only the ordinary driver waits. A missed first-park precondition
preserves the actual waiter outcome instead of an anonymous timeout.

## All attempts

- initial: both tests pass. A later assertion explicitly requires colliding task
  IDs; the resulting final source is saved separately in ordered-source.txt.
- negative-order: omit production expiry; exact Stale/Published assertion fails.
- negative-ownership: deliberately mark the join handle taken when wait errors;
  the retained unfinished target incorrectly reports ResultAlreadyTaken and fails.
- negative-panic: use the old deadline-only expectation for a completed panic;
  the captured typed TaskPanicked outcome fails it.
- restored: both tests pass after byte-comparison with ordered-source.txt and
  removal of the production join mutation. Production join/parking files have no
  retained diff.
- timers: the extracted driver retains both prior selected-timer tests.
- zrail: one analyzed-inventory change, two new test files, no grants/revokes/debt.
- canonical and repeats: exact commands, full source identities, logs, results
  and binary hashes remain separate. Bundle creation requires all planned runs
  to pass; no failed or missing attempt is silently removed.

Final planned repetitions: twenty default-native debug and twenty release
invocations on CPU 6, two tests each. These eighty native test executions exercise
semantic order and ownership, not timing or throughput. The deliberate target
panic printed by the passing counterexample is expected and retained in full.
