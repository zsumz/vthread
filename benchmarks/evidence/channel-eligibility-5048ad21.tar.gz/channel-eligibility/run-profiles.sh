#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/channel-eligibility
for round in 1 2 3; do
    engines='baseline candidate'
    if [[ $round == 2 ]]; then engines='candidate baseline'; fi
    for engine in $engines; do
        prefix=$evidence_dir/profile-$round-$engine
        if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then exit 125; fi
        ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
        timeout 90s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations \
            -o "$prefix.csv" taskset -c 0-3 "$evidence_dir/$engine-profile-benchmark" \
            vthread channel-mpmc 10000 1 4 8 3 --pin-carriers > "$prefix.log" 2>&1
        ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
        printf 'profile round=%s engine=%s complete\n' "$round" "$engine"
    done
done
