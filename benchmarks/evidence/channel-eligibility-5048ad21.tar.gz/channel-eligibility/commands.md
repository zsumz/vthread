# Channel eligibility: useful work versus carrier idling

Baseline: 5b63f266fd6dfc39de3c13d6e28c7ec850de2d42. The runtime-only candidate
and its source/binary identities are in candidate.patch, source.json and
binaries.sha256. It is preserved at stash 19eb1d3c4d41b8ceecaa97f2771e30c3ed625af7.
This candidate is rejected as a standalone performance change. Only targeted
correctness qualification ran; there is no claimed final canonical or tail gate.

```sh
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib channel::eligibility_test -- --test-threads=1
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib channel:: -- --test-threads=1
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
zrail update --format json
zrail update --accept-grants --format json
bash target/finish-line/channel-eligibility/run-controls.sh
python3 target/finish-line/channel-eligibility/analyze.py
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml --features scheduler-profiling
bash target/finish-line/channel-eligibility/run-profiles.sh
python3 target/finish-line/channel-eligibility/analyze-profiles.py
```

The two ordered old-code regressions both observed four parks and three wakes for
two useful transfers, instead of three parks and two wakes. They passed after the
eligibility change, alongside all 18 channel tests and the 160-state real-wait-word
predicate matrix. The architecture refresh changes inventory only, with zero new
grants, dependencies, revocations or debt; its previews are preserved.

run-controls.sh and control-commands.log retain exact default-build commands.
Seven complete cases have three balanced process pairs. In the eighth, another
project's compiler appeared after the third baseline process; the guard stopped
before its candidate. That incomplete spare-capacity case is not compared. Later
unaffected controls were not run. All raw logs, counters and host observations
remain; no incomplete case is substituted with a different process order.

The separate diagnostic matrix uses opt-in scheduler profiling on both sources.
Its six processes each perform 160,000 transfers including warm-up and expose final
owner counters after shutdown. Instrumentation perturbs timing, so those times are
not mixed with the default-build panel. Native wait-function calls do not prove
individual syscalls or sleeps; the independent OS context-switch counters support
investigation of sleep/wake behavior, not a complete trace of each handoff.

The uninstrumented binaries were preserved before building either diagnostic
variant. Executables are omitted from the archive; their hashes are retained.
