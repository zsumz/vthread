"""Final-only owner activity for the same 160,000 shared-channel transfers."""

import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
records = []
for path in sorted(ROOT.glob("profile-[1-3]-*.log")):
    result, totals = {"log": path.name}, {}
    for line in path.read_text().splitlines():
        fields = dict(re.findall(r"(\w+)=(\S+)", line))
        if "ns_per_operation" in fields:
            result["ns_per_operation"] = float(fields["ns_per_operation"])
        if fields.get("phase") == "scheduler-idle":
            for key in ("mounts", "idle_entries", "empty_idle_entries", "poll_probes", "poll_hits", "wait_calls"):
                totals[key] = totals.get(key, 0) + int(fields[key])
    result["profile"] = totals
    records.append(result)
assert len(records) == 6
print(json.dumps(records, indent=2))
