#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/channel-eligibility

run_pair() {
    local label=$1 mask=$2
    shift 2
    if [[ ${VTHREAD_CONTROL_CASES:-all} != all && " ${VTHREAD_CONTROL_CASES:-} " != *" $label "* ]]; then return; fi
    for round in ${VTHREAD_CONTROL_ROUNDS:-1 2 3}; do
        local engines='baseline candidate'
        if (( round % 3 == 2 )); then engines='candidate baseline'; fi
        for engine in $engines; do
            local binary=$evidence_dir/candidate-benchmark
            if [[ $engine == baseline ]]; then
                binary=target/finish-line/shared-channel-control/baseline-benchmark
            fi
            local prefix=$evidence_dir/control-$round-$engine-$label
            if [[ -e $prefix.log ]]; then
                printf 'refusing to overwrite an earlier process: %s\n' "$prefix" >&2
                return 126
            fi
            if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
                printf 'control deferred: other build activity before %s\n' "$prefix" >&2
                return 125
            fi
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            printf '%q ' timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@" >> "$evidence_dir/control-commands.log"
            printf '\n' >> "$evidence_dir/control-commands.log"
            timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@" > "$prefix.log" 2>&1
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'control round=%s engine=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

run_pair mpmc-local-cap1 7 channel-mpmc 20000 1 1 8 9
run_pair mpmc-local-cap64 7 channel-mpmc 20000 64 1 8 9
run_pair mpmc-local-cap1024 7 channel-mpmc 20000 1024 1 8 9
run_pair mpmc-remote-cap1 0-3 channel-mpmc 20000 1 4 8 9 --pin-carriers
run_pair mpmc-remote-cap64 0-3 channel-mpmc 20000 64 4 8 9 --pin-carriers
run_pair mpmc-remote-cap1024 0-3 channel-mpmc 20000 1024 4 8 9 --pin-carriers
run_pair mpmc-population64 0-3 channel-mpmc 10000 1 4 64 9 --pin-carriers
run_pair mpmc-spare65536 0-3 channel-mpmc 1000 1 4 64 5 --max-vthreads 65536 --pin-carriers
run_pair yield 0-3 yield 100000 4 64 9
run_pair spawn1000 0-3 spawn 4 1000 501
run_pair spawn10000 0-3 spawn 4 10000 501
run_pair park 0-3 park 100000 4 64 9 --pin-carriers
run_pair mutex 0-3 mutex 10000 4 64 9 --pin-carriers
run_pair channel 0-3 channel 10000 4 64 9 --pin-carriers
run_pair wake 0-3 wake-tail 10000 4 64 9 --pin-carriers
run_pair capacity 0-3 park 10000 4 64 5 --max-vthreads 65536 --pin-carriers
