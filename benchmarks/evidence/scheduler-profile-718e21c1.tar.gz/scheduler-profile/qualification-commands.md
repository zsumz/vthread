# Qualification commands

Working directory: `/root/vthread`. See `source.json` and `candidate.patch` for
source identity; the executable hashes are in `binaries.sha256`.

```sh
CARGO_INCREMENTAL=0 zcheck run check
CARGO_INCREMENTAL=0 cargo test --locked --workspace --all-targets
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --features scheduler-profiling --lib
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/root/vthread/target cargo test --locked --manifest-path benchmarks/Cargo.toml --all-features
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/root/vthread/target cargo clippy --locked --manifest-path benchmarks/Cargo.toml --all-targets --all-features -- -D warnings
cargo fmt --manifest-path benchmarks/Cargo.toml -- --check
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml --features scheduler-profiling
timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations -o profile-spawn-4-10000-first.csv taskset -c 0-3 profile-benchmark vthread spawn 4 10000 501
```

Both release executables were copied to distinct immutable names before any
timings. `run-default-controls.sh` and `control-commands.log` record the 32
default controls. Their host observations contain unrelated build activity;
these controls are not accepted performance evidence. `analyze.py` reproduces
the process-level comparisons and the final-only profile sums from the raw logs.

The archive excludes executable files; their hashes describe the original
local copies. Recoverable compression of two older, unused diagnostic executables
is recorded separately; neither was used for this qualification.
