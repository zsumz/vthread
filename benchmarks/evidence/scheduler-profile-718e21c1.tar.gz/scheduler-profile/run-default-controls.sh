#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/scheduler-profile

run_case() {
    local label=$1
    shift
    local binary=$evidence_dir/default-benchmark
    if [[ $engine == previous ]]; then
        binary=target/finish-line/admission/candidate-benchmark
    fi
    local prefix=$evidence_dir/control-$round-$engine-$label
    ps -eo pid,comm,pcpu,etime > "$prefix.host"
    printf '%q ' timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c 0-3 "$binary" vthread "$@" >> "$evidence_dir/control-commands.log"
    printf '\n' >> "$evidence_dir/control-commands.log"
    timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations \
        -o "$prefix.csv" taskset -c 0-3 "$binary" vthread "$@" > "$prefix.log" 2>&1
    printf 'control round=%s engine=%s case=%s complete\n' "$round" "$engine" "$label"
}

for round in 1 2; do
    engines='previous current'
    if [[ $round == 2 ]]; then engines='current previous'; fi
    for engine in $engines; do
        run_case yield yield 100000 4 64 9
        run_case spawn1000 spawn 4 1000 101
        run_case spawn10000 spawn 4 10000 101
        run_case park park 100000 4 64 9
        run_case mutex mutex 10000 4 64 9
        run_case channel channel 10000 4 64 9
        run_case wake wake-tail 10000 4 64 9
        run_case capacity park 10000 4 64 5 --max-vthreads 65536
    done
done
