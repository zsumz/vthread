# Selected timer: ordered evidence, not elapsed-time inference

Base: 32188c5 on perf/scheduler-hot-path. Production timer, parking, wait,
checkpoint and ownership behavior is unchanged. The only production-file edit
declares a cfg(test) module. Reviewed zrail inventory adds one file/five contexts,
with zero grants, revokes or debt.

The historical loaded-4.log records only an unlabeled support_test::until timeout.
It does not identify which gate or recover the task result. The original test
held a carrier while waiting for a deadline; elapsed time did not prove selection
by that carrier. Admission also did not guarantee first mount before expiry.
The original schedule is not reconstructed or attributed uniquely to host load.

The repaired test manually drives real native fibers and production timer expiry.
For explicit deadlines earlier than, equal to, and later than inherited expiry,
it observes the exact route/token as Published with no ready task or resumption,
then permits resumption only after inherited expiry. It preserves typed outcomes,
panic errors, checkpoint policy and scope-policy evidence. A second scenario
accepts a packet before expiry but mounts it afterwards: a valid deadline result
has zero parks, disproving the unconditional old parked-state oracle.

Cold configuration setup precedes deadline creation. Actual monotonic deadlines
remain unchanged; no test reschedules a timer or substitutes a fake clock. Only
the ordinary test driver waits. If setup-to-first-park loses its precondition,
the failure includes the actual task result rather than an anonymous watchdog.
Shared::wait is a drain operation; scope_options.check separately tests root
deadline policy. These manual-owner tests do not qualify OS scheduling latency.

## Attempts retained

- initial-targeted: compile failure from an inaccessible existing test helper;
  corrected with a self-contained fixture, before any runtime interpretation.
- configured-targeted: the three deadline cases pass.
- ordered-plus-admission: all three selected cases and late-admission case pass.
- negative-order: omit expiry; the exact publication assertion fails Stale vs
  Published. Clock passage cannot satisfy this proof.
- negative-checkpoint: check current policy immediately after park suspension;
  the selected earlier timeout is incorrectly replaced by DeadlineExceeded.
- negative-tie: change inherited <= explicit to <; the equal deadline incorrectly
  returns TimedOut instead of DeadlineExceeded.
- negative-admission: require one outstanding park in the late-mount case;
  actual typed DeadlineExceeded has zero parks/pending entries.
- restored: both final Rust tests pass after all mutations are removed. Restored
  test source was byte-compared and both production mutation files have no diff.
- canonical and repeat-*: exact commands, source/binary hashes, outcomes and
  traces are stored separately; bundle creation requires every planned run pass.

Negative-order/checkpoint used the first one-test fixture. Tie/admission used
the final two-test fixture. Their command source hashes and patch variants remain
separate rather than being presented as one identical source world. Early
targeted logs predate the structured runner; commands are cargo test --locked -p
vthread with the relevant selected timer test filter, CARGO_INCREMENTAL=0 and
the same external build target recorded in later command manifests.

Repeats are ten default-native debug and ten release invocations on CPU 6,
two Rust tests/four ordered cases per invocation. They are correctness exercises,
not benchmark or cross-platform release acceptance. All artifacts and failures
are preserved. No new May comparison or performance improvement is claimed.
