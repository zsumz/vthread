# Publisher deferral working design; not integrated or qualified

Base runtime unchanged at 6150e0a (qualification-only commit after 0b67337).
Committed slice 1: mandatory native debug/release, 14 canonical gates pass;
first cancellation-history timing failure retained, all six loaded findings open.
No runtime code has been edited in slice 2 as of this note. Three untracked
Loom model files under vthread-sync-core/tests are the current working change.

## Proposed handshake

WaitWord's permit bit is absent in valid Active/Claim generations: activation
consumes stored permits before publishing Active, notify waits on Claim, and
resource offers cannot modify a claim. The proposal reuses that bit for owner
publication interest only while claimed, preserving generation width and record
size. Word encoding itself need not change: WaitInner's publication CAS must
clear the interest bit when selecting; ordinary Selected/Idle permit semantics
remain unchanged. This reachability invariant needs explicit qualification.

Owner query: validate exact token and generation, report Selected as published,
Idle/wrong generation as stale, and CAS Claim -> Claim|interest before returning
in-flight. An already requested interest is idempotent. Publisher replaces Claim
with Selected using AcqRel CAS, notices requested interest on CAS failure, retains
the exact hub BEFORE its successful CAS, and signals that independent hub after
selection. No route/state/target accesses may follow releasing the claim. Normal
publication adds a CAS instead of a store but no allocation; rare deferral may
clone the hub. Cost is a correctness tradeoff, not a promised optimization.

Owner retains at most one deferred record per live parked route/token. Completion
uses existing Signal::notify epoch/waiter protocol, not only next-tick polling.
The ordinary ready loop must not mount in-flight claims.

## Cleanup requirements found by source audit

- Kernel::abort and sweep_revoked currently call blocking retirement on parked
  waits. A dispatch-only repair leaves their carrier dependency.
- Parent stack destruction may reclaim borrowed child stacks through FiberScope.
  Deferring only the child cannot make dropping its parent safe.
- Candidate: scope-abort preflight must try-retire every matching parked wait
  atomically, retain the scope's frames if ANY claim remains, and remember the
  abort reason. Ready tasks in such a scope cannot be mounted/dropped meanwhile;
  unrelated scopes remain eligible. A bounded pending-abort record must be backed
  by an outstanding claim (or the one global-stop request), not an unbounded map.
  Retired waits can remain in parked records during scope preflight; their tickets
  and selected resources stay owned until legal stack cleanup. Reject queued
  stale notices before route reuse. Claim may race preflight of an Active wait:
  observing Active is insufficient; successful retirement CAS is required.
- Tick's abort_requested path currently drops in-flight directly, so it must obey
  that same preflight. Carrier::drive currently exits immediately after global
  abort, so pending global cleanup needs completion discovery before retirement.
- Registration error/panic before actual suspension can also run ParkGuard's
  spinning rollback while an external cancellation publisher holds Claim. Kernel
  parked-task deferral alone cannot fix this path. A possible private failure-only
  park keeps the original error/panic and resource guards until publication is
  complete; it must not call public yield/checkpoints during half-retirement.
  Catching setup panic before cleanup may permit such a private suspension without
  suspending an active unwind. Forced-unwind payload identity must be preserved.
  This is an unimplemented design obligation, not permission to skip those tests.

## Model evidence and boundaries

The model imports production WaitWord. Route is a one-slot abstraction, NOT the
production intrusive MPSC queue; native multi-route/target-binding/stack cleanup
composition remains unproved. All mutable shared model state uses Loom.

Initial model failed in Signal: Loom 0.7.2 README explicitly says SeqCst accesses
are treated as AcqRel and may produce false alarms. The trace allows producer
epoch increment -> waiter read zero, then owner register -> read OLD epoch,
which the production SC total order forbids. Model-only SC fences after producer
epoch increment and owner waiter registration enforce that obligation; a separate
test exhausts the six legal four-event SC orders. No production ordering changed.
`sleep-trace.log` retains the trace using Loom's trace-subscriber entrypoint;
the regular model restores explicit bounds and no cutoff. Model adapter is not a
full C11 or native Signal proof.

Then the model exposed a genuine proposed owner bug: try_abandon returns in-flight,
publication completes, and the same iteration consumed normally. The corrected
Published branch retains the abandonment decision and recovers ownership.
`composed-sc-adapter.log` preserves the failed assertion (recovered=0, expected=1).

The oversized combined cause/sleep exploration in `composed-generation-tests.log`
was stopped without claiming a pass. The factored replacement in
`factored-composition-tests.log` completed all 13 tests in 44.13 seconds: eight
composition tests including two negative controls, one SC-order test, and four
production-word tests. Active-owner cause competition is separate from winner
sleep; a losing selector performs no route, ownership or signal writes. Production
integration must verify this factorization assumption. Builders
use max_threads=3, max_branches=1000, no permutation/preemption/time cutoff.
The missing-notification deadlock negative uses ManuallyDrop only to prevent a
secondary Loom Arc destructor panic from masking its expected deadlock; normal
executions drop it and still receive leak checks.
