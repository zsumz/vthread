# Test-only publication deferral evidence

Base: 6150e0ad406e7619f34f55d2ce0b618048a05312. `model.patch` contains three new
Loom test files, the inventory-only lock refresh and the pre-archive review.
Production runtime source, Cargo.lock and configuration are unchanged by this
slice. Source digest: e9214dc308feba6c81f53d0bc6830a2c2bd4a986ef4fca567dfae9a0d1e19e58.

`factored-composition-tests.log` passes 13 tests in 44.13 seconds. Replay:

```sh
CARGO_INCREMENTAL=0 cargo test --locked -p vthread-sync-core --test wait_publication_model -- --test-threads=1
CARGO_INCREMENTAL=0 cargo clippy --locked -p vthread-sync-core --test wait_publication_model -- -D warnings
CARGO_INCREMENTAL=0 zcheck run check
```

The actual external build directory was
`/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI`, supplied as
CARGO_TARGET_DIR. It is not a required replay path. `source.json` identifies the
host/toolchain; `model-binaries.sha256` identifies the final debug/release model
binaries, which are not archived. Canonical `qualification/receipt.json` records
all 14 passing gates and preserved state. Default debug/release execute the native
stack engine. No benchmark comparison or performance acceptance ran for this slice.

## Preserve failures without promoting them to proof

- `abandon-first.log` used an incorrectly qualified exact test name and ran zero
  tests. It establishes nothing.
- `abandon-counterexample.log`, `sleep-counterexample.log` and `sleep-trace.log`
  preserve the SeqCst adapter false alarm described in DESIGN.md and the review.
  Loom 0.7.2's documented weakening is not a production lost-wake finding.
- `composed-sc-adapter.log` captures the actual proposed owner-abandonment bug.
  The repaired branch preserves abandonment when publication completes between
  owner checks.
- `composed-generation-tests.log` is an incomplete oversized exploration, stopped
  after inspecting and terminating only its exact model-test child process.
- The final cause/sleep exploration is explicitly factored, not silently bounded
  by a permutation or time cutoff. Losing selectors must have no publication
  side effects; production integration must verify that assumption.
- Negative controls are part of the passing suite: omitted completion notification
  produces a deadlock; mounting an incomplete claim violates the state assertion.

WaitWord is imported production source. One-route transport, resource counters and
the SC adapter are limited abstractions. Native queue, target binding, ancestor
cleanup, registration panic and resource-ticket composition remain open. This is
a design checkpoint, not the paused-publisher runtime repair or release proof.

`zrail-diff.log` reports zero semantic grants/revokes. The first update refused
the new inventory digest; the accepted update records only that reviewed delta.
No architecture permission, package dependency or API was added.
