# Handoff attribution evidence ledger

Base commit: 88e2fd1549ec840e9407c065f68fb6294d5d2cdc.
Qualified source: f57b1db1457fc45f855e561e5eb89e489c72bcf166ef4c50400596057840c976.
`source.patch` contains the full source change, including new files; apply to the
base in a separate checkout. `tracked-source.patch` is an incomplete intermediate
captured before new files were staged and is not the replay patch. Source helper
`scripts/evidence.py` excludes Markdown and archives from the source digest.

## Measurements

- `run-profiles.sh`: 36 final-source handoff-profile processes, three repetitions
  of 12 cases. `run-defaults.sh`: 36 matching default-build processes. Case order
  reverses in repetition two. Separate panels, not paired A/B acceptance.
- Exact executed commands: `profile-commands.log`, `default-commands.log`.
  Native hardware/syscall counters, stdout, endpoint process/CPU observations and
  pre-run build guards are kept for every process. No own build/test overlap.
- `analyze.py DIRECTORY` validates all 72 records, required counters, endpoint
  guards and profile conservation. It prints the complete per-process results
  and medians/ranges; reproduce `analysis.json` with it. Its initial placement-
  record parsing error was corrected by requiring `ns_per_operation`, not every
  `operation` line. No measurement was removed to fix that parser.
- Normalization includes warm-up: 160,000 or 256,000 shared-channel values,
  1,280,000 park handoffs, 512,000 mutex acquisitions, 320,000 task lifetimes,
  8,000/16,000 acknowledged burst wakes. Quiet control has no per-op denominator.
- Timing binaries, libraries and text sections are identified in `binaries.sha256`,
  `default-text.sha256` and `source-final.json`. Default idle controls use the
  previous identical-policy native public-API baseline; its hash is recorded in
  `idle-baseline.sha256`. `idle_control.rs` adds final profile validation/reporting;
  no operation or idle-policy change is made to that helper's workload.
- `run-traces.sh` and `trace-commands.log` describe four independent default-build
  recordings. The syscall trace requests used `-c 97`, but the decoded output
  cannot be treated as a clean 1-in-97 sample. `yield8` and `yield64` report 17/86
  lost chunks and perturb execution: retain for qualitative call-site inspection
  only. Cycle runs report no lost chunks; they are single-process samples, not
  definitive percentages. `capacity-annotation.txt` locates the hot scan loop.
- `trace-*.data.gz` are recoverably compressed original perf recordings, verified
  against `perf-data.sha256`; reports/stacks and decode warnings are also retained.
  `perf-data-compressed.sha256` covers compressed bytes. Original recorded binary
  paths/build IDs are in the perf data. Rebuilds may need perf's symbol-path/build-ID
  setup to decode; saved symbolized reports and instruction annotation stand alone.
- `uname.txt`, `topology.json`, `cpuinfo.txt`, `rustc.txt`, `perf-version.txt` and
  `frequency-policy.txt` identify the guest environment. Endpoints do not establish
  physical-host exclusivity; no hypervisor/frequency/topology assumption is added.

## Qualification

Environment for final canonical/native builds:

```
CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI
CARGO_INCREMENTAL=0
```

The task-specific external-disk directory avoids removing existing build artifacts.
Native runs have real socket/thread permissions. Commands and corresponding logs:

```
zcheck run check                                      # canonical/receipt.json
cargo test --locked --workspace                       # default-native-workspace.log
cargo test --locked -p vthread --features handoff-profiling # handoff-native-suite.log
cargo test --locked --manifest-path benchmarks/Cargo.toml --all-features
cargo clippy --locked --manifest-path benchmarks/Cargo.toml --all-targets --all-features -- -D warnings
cargo build --locked --release -p vthread-lab --features vthread/handoff-profiling
timeout 60s "$CARGO_TARGET_DIR/release/vthread-lab" soak 20 1 64
timeout 60s "$CARGO_TARGET_DIR/release/vthread-lab" soak 20 4 64
```

Canonical run `run-1788653744-301476461-2531550`: all 11 gates pass with exact
repository preservation. Native runtime: 515 default / 529 feature-on tests pass,
one pre-existing manual borrowed-maintenance probe ignored. Native stack: 70 pass.
Standalone benchmark: 52 pass; strict all-feature Clippy passes. The two soaks
complete 125,442 / 141,381 lifetimes with matching spawned/completed, matching
parks/wakes and service/queue reclamation assertions. This is short mixed-traffic
qualification, not ten-million-lifetime release burn-in or ARM64/sanitizer proof.

The manual burst-profile helper and reused final-only report pass three native
tests. Compile against the release profile library selected from
`profile-build.jsonl` (`libvthread-844ad4fd3edb9d1b.rlib` here):

```
rustc --edition=2024 -D warnings --test --cfg 'feature="handoff-profiling"' \
  --crate-name idle_profile_test idle_control.rs \
  --extern vthread=PATH_TO_PROFILE_RLIB -L dependency=BENCH_RELEASE_DEPS \
  -o idle-profile-test
./idle-profile-test
```

Restore the helper at its recorded repository-relative path
`target/finish-line/handoff-attribution/idle_control.rs` so its `#[path]` reference
reaches the benchmark report module. `control_test.rs` is its sibling.

## Exploratory records and boundaries

- Initial tests/builds and architecture preview are retained. Plain built-in
  macros failed exact architecture binding; explicit `::core` paths fix them
  without grants. The final lock adds the handoff feature world and inventory.
- First opt-out build differed at two code bytes. Reinstating the original
  branch expression makes final `.text` identical to the pushed baseline;
  final full executable hashes still differ. `default-codegen-differences.txt`
  describes the superseded first build, not the accepted final one.
- `recoverable-*.sha256` and old-handle observations identify debug artifacts
  compressed to recover root disk space. They are not timing binaries or part
  of the source change. Executables and object files are not in this bundle.
- No policy, atomic ordering, direct mutex ownership, channel reservation, queue
  shape, readiness map or post-mount affinity change is shipped. Timed counters
  materially perturb contended channel execution. Do not turn profile timings,
  sum overlapping regions, or lossy syscall samples into performance acceptance.
- Existing loaded-suite findings and full release evidence remain open. There
  is no new May comparison in this slice.
