#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/handoff-attribution
trace_one() {
    local label=$1 event=$2 period_flag=$3 period=$4
    shift 4
    local prefix=$evidence_dir/trace-$label
    test ! -e "$prefix.data"
    if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then return 125; fi
    ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
    local command=(timeout 90s perf record -e "$event" "$period_flag" "$period" --call-graph dwarf,2048
        -o "$prefix.data" -- taskset -c 0-3 "$evidence_dir/default-benchmark-final" vthread "$@")
    printf '%q ' "${command[@]}" >> "$evidence_dir/trace-commands.log"
    printf '\n' >> "$evidence_dir/trace-commands.log"
    "${command[@]}" > "$prefix.log" 2>&1
    ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
    perf report -i "$prefix.data" --stdio --no-children --percent-limit 0.1 > "$prefix.report" 2>&1
    perf script -i "$prefix.data" > "$prefix.stacks" 2> "$prefix.decode.log"
    printf 'trace %s complete\n' "$label"
}
trace_one yield8 syscalls:sys_enter_sched_yield -c 97 channel-mpmc 10000 1 4 8 3 --pin-carriers
trace_one yield64 syscalls:sys_enter_sched_yield -c 97 channel-mpmc 2000 1 4 64 3 --pin-carriers
trace_one cycles64 cycles:u -F 199 channel-mpmc 2000 1 4 64 7 --pin-carriers
trace_one cycles-spare cycles:u -F 199 channel-mpmc 2000 1 4 64 3 --pin-carriers --max-vthreads 65536
