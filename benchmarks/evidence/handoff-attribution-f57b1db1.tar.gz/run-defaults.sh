#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/handoff-attribution

run_one() {
    local round=$1 kind=$2 label=$3 mask=$4
    shift 4
    local prefix=$evidence_dir/default-$round-$label
    test ! -e "$prefix.log"
    if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
        printf 'default deferred before %s\n' "$prefix" >&2
        return 125
    fi
    local binary=$evidence_dir/default-benchmark-final
    local arguments=(vthread "$@")
    if [[ $kind == idle ]]; then
        binary=target/finish-line/idle-budget/baseline-control
        arguments=("$@")
    fi
    ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
    sed -n '1,9p' /proc/stat > "$prefix.before.cpu"
    printf '%q ' timeout 120s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations,syscalls:sys_enter_futex,syscalls:sys_enter_sched_yield -o "$prefix.csv" taskset -c "$mask" "$binary" "${arguments[@]}" >> "$evidence_dir/default-commands.log"
    printf '\n' >> "$evidence_dir/default-commands.log"
    timeout 120s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations,syscalls:sys_enter_futex,syscalls:sys_enter_sched_yield \
        -o "$prefix.csv" taskset -c "$mask" "$binary" "${arguments[@]}" > "$prefix.log" 2>&1
    sed -n '1,9p' /proc/stat > "$prefix.after.cpu"
    ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
    printf 'default round=%s case=%s complete\n' "$round" "$label"
}

cases=(mpmc1c8 mpmc4c8 mpmc4c64 mpmc4c64-spare mpmc4c64-cap64 mpmc4c64-cap1024 park4 mutex4 spawn4-spare burst4-1ms burst4-100us quiet4-spare)
for round in 1 2 3; do
    for offset in "${!cases[@]}"; do
        index=$offset
        if (( round % 2 == 0 )); then index=$(( ${#cases[@]} - 1 - offset )); fi
        case ${cases[$index]} in
            mpmc1c8) run_one "$round" bench mpmc1c8 7 channel-mpmc 10000 1 1 8 3 --pin-carriers ;;
            mpmc4c8) run_one "$round" bench mpmc4c8 0-3 channel-mpmc 10000 1 4 8 3 --pin-carriers ;;
            mpmc4c64) run_one "$round" bench mpmc4c64 0-3 channel-mpmc 2000 1 4 64 3 --pin-carriers ;;
            mpmc4c64-spare) run_one "$round" bench mpmc4c64-spare 0-3 channel-mpmc 2000 1 4 64 3 --pin-carriers --max-vthreads 65536 ;;
            mpmc4c64-cap64) run_one "$round" bench mpmc4c64-cap64 0-3 channel-mpmc 2000 64 4 64 3 --pin-carriers ;;
            mpmc4c64-cap1024) run_one "$round" bench mpmc4c64-cap1024 0-3 channel-mpmc 2000 1024 4 64 3 --pin-carriers ;;
            park4) run_one "$round" bench park4 0-3 park 5000 4 64 3 --pin-carriers ;;
            mutex4) run_one "$round" bench mutex4 0-3 mutex 2000 4 64 3 --pin-carriers ;;
            spawn4-spare) run_one "$round" bench spawn4-spare 0-3 spawn 4 10000 31 --max-vthreads 65536 ;;
            burst4-1ms) run_one "$round" idle burst4-1ms 0-3 4 8 8 1000 1000 ;;
            burst4-100us) run_one "$round" idle burst4-100us 0-3 4 8 8 100 2000 ;;
            quiet4-spare) run_one "$round" idle quiet4-spare 0-3 4 8 65536 1000000 0 ;;
        esac
    done
done
