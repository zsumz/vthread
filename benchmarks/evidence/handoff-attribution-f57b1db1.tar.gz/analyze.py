"""Replay whole-process counter and instrumented attribution evidence, not speed claims."""

import csv
import json
from collections import defaultdict
from pathlib import Path
import re
from statistics import median
import sys

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
FIELDS = re.compile(r"(\w+)=([^\s\[]+|\[[^\]]*\])")
EVENTS = (
    "task-clock", "cycles", "instructions", "context-switches", "cpu-migrations",
    "syscalls:sys_enter_futex", "syscalls:sys_enter_sched_yield",
)
CASES = {
    "mpmc1c8": 160_000, "mpmc4c8": 160_000, "mpmc4c64": 256_000,
    "mpmc4c64-spare": 256_000, "mpmc4c64-cap64": 256_000,
    "mpmc4c64-cap1024": 256_000, "park4": 1_280_000,
    "mutex4": 512_000, "spawn4-spare": 320_000,
    "burst4-1ms": 8_000, "burst4-100us": 16_000, "quiet4-spare": None,
}


def fields(line):
    result = dict(FIELDS.findall(line))
    for key, value in result.items():
        if value.isdecimal():
            result[key] = int(value)
        elif value.startswith("["):
            result[key] = json.loads(value)
    return result


def profile(lines, case):
    duration = defaultdict(lambda: {"count": 0, "total_ns": 0, "max_ns": 0, "bins": [0] * 10})
    channel = defaultdict(int)
    routes = defaultdict(int)
    idle = defaultdict(int)
    by_direction = defaultdict(int)
    for line in lines:
        row = fields(line)
        phase = row.get("phase")
        if phase == "handoff-duration":
            assert row["count"] == sum(row["bins"])
            assert row["max_ns"] <= row["total_ns"]
            target = duration[row["stage"]]
            target["count"] += row["count"]
            target["total_ns"] += row["total_ns"]
            target["max_ns"] = max(target["max_ns"], row["max_ns"])
            target["bins"] = [a + b for a, b in zip(target["bins"], row["bins"], strict=True)]
        elif phase == "handoff-channel":
            assert row["calls"] == row["transfers"] + row["failed_calls"]
            assert row["park_returns"] == row["retries"] + row["resumed_transfers"] + row["resumed_exits"]
            for key, value in row.items():
                if isinstance(value, int) and key != "carrier":
                    channel[key] += value
            by_direction[row["direction"]] += row["transfers"]
        elif phase == "handoff-routes":
            for key in ("local", "shared"):
                routes[key] += row[key]
        elif phase == "scheduler-idle":
            for key, value in row.items():
                if isinstance(value, int) and key != "carrier":
                    idle[key] += value
    assert len(duration) == 11
    values = CASES[case] if case.startswith("mpmc") else 0
    assert by_direction["Send"] == values == by_direction["Receive"]
    notifications = sum(channel[key] for key in (
        "selected_notifications", "stored_notifications", "closed_notifications"))
    channel["notifications"] = notifications
    channel["ineligible_percent"] = 100 * channel["ineligible_notifications"] / notifications if notifications else 0
    if values:
        for key in ("parks", "retries", "notifications", "selected_notifications", "stored_notifications"):
            channel[key + "_per_value"] = channel[key] / values
    for row in duration.values():
        row["mean_ns"] = row["total_ns"] / row["count"] if row["count"] else 0
    polls = sum(duration[stage]["count"] for stage in ("PollWork", "PollControl", "PollExhausted"))
    return {
        "duration": dict(duration), "channel": dict(channel), "routes": dict(routes),
        "scheduler_idle": dict(idle), "poll_work_percent": 100 * duration["PollWork"]["count"] / polls if polls else 0,
        "native_wait_per_api": duration["NativeWait"]["count"] / max(1, duration["WaitApi"]["count"]),
    }


def process(kind, round_id, case):
    prefix = ROOT / f"{kind}-{round_id}-{case}"
    assert not prefix.with_suffix(".guard").read_text().strip(), prefix
    for suffix in (".before.host", ".after.host"):
        assert not re.search(r"^\s*\d+\s+(cargo|rustc|clippy-driver|zrail)\s", Path(str(prefix) + suffix).read_text(), re.M), prefix
    counters = {}
    for row in csv.reader(prefix.with_suffix(".csv").read_text().splitlines()):
        if len(row) > 4 and row[2] in EVENTS:
            assert float(row[4]) >= 99, (prefix, row)
            counters[row[2]] = float(row[0])
    assert counters.keys() == set(EVENTS), prefix
    lines = prefix.with_suffix(".log").read_text().splitlines()
    result = {"case": case, "round": round_id, "kind": kind, "perf": counters}
    denominator = CASES[case]
    if denominator:
        result["perf_per_unit"] = {key: value / denominator for key, value in counters.items()}
    if kind == "profile":
        result.update(profile(lines, case))
    for line in lines:
        row = fields(line)
        if "ns_per_operation" in row:
            result["ns_per_operation"] = float(row["ns_per_operation"])
        elif row.get("phase") == "interval":
            result["idle_interval"] = row
    return result


def flat(value, prefix=""):
    for key, item in value.items():
        name = f"{prefix}.{key}" if prefix else key
        if isinstance(item, dict):
            yield from flat(item, name)
        elif isinstance(item, (int, float)) and key != "round":
            yield name, item


runs = [process(kind, round_id, case) for kind in ("profile", "default")
        for round_id in (1, 2, 3) for case in CASES]
summary = {}
for kind in ("profile", "default"):
    for case in CASES:
        values = defaultdict(list)
        for run in runs:
            if run["kind"] == kind and run["case"] == case:
                for key, value in flat(run):
                    values[key].append(value)
        assert all(len(samples) == 3 for samples in values.values())
        summary[f"{kind}/{case}"] = {
            key: {"median": median(samples), "min": min(samples), "max": max(samples)}
            for key, samples in values.items()
        }
print(json.dumps({"scope": "three independent processes per case and build; separate panels, not paired A/B",
                  "normalization": CASES, "runs": runs, "summary": summary}, indent=2))
