# Ordered readiness retry finding

Base: 80b3ba1 on perf/scheduler-hot-path. This is a test-only repair, not a
retry, polling, readiness, admission or scheduling change. io.rs only gains a
cfg(test) sibling module. Existing retry code is restored after the mutations.

The captured original oversubscribed-suite failure is copied intact from
target/finish-line/wait-qualification/ordered-loaded-3.log. It reports one
readiness wait where the old test expects zero. That historical run did not trace
the exact arrival/selection interleaving, so its unique timing cause is unknown.

The old oracle was unconditional after admission. Selection samples a cached
carrier-runnable hint before mounting. Admission may happen after that sample;
it does not prove the writer was materialized when the reader was selected.
The new late-admission counterexample orders that legal interleaving through the
real Shared/Kernel/operation path and observes exactly one outstanding wait.
Replacing its expected one with the old expected zero fails with the same 1/0
assertion after successful I/O and cleanup. This demonstrates an invalid test
oracle rather than relying on a quiet rerun or asserting an unobserved historical
OS schedule.

Two ordered behavior tests use a real nonblocking Unix socket and reactor:

- Both peers are materialized before the first dispatch. The first empty read
  yields with zero subscriptions; only the second dispatch may write. Exactly
  two reads, one yield, no park and no remaining subscription are required.
- The peer stays runnable, with no write allowed through 128 empty-read yields.
  The 129th attempt must park with exactly one subscription. Only then does the
  ordinary driver write; the 130th read completes and retires the subscription.

The immediate-registration mutation fails the first test with (1,0,1,1) instead
of (1,1,0,0). The <= retry-budget mutation fails the second with (129,0,0)
instead of (129,1,1). Both restore the exact production comparator afterwards.
The initial fixture attempt failed configuration before any task admission due
to the default stack cache exceeding its deliberately small task bound; the
explicit four-slot cache fixes only the fixture. That failed attempt remains.

readiness_waits measures admitted outstanding subscriptions, not proof that a
backend registration has already been installed. First-crossing observations
are captured before explicit writes and asserted after cleanup. Five-second
watchdogs only bound post-write completion, not the semantic ordering.

The first zrail update is a preview: no grants, one UNKNOWN analyzed-inventory
delta, and no write without explicit acceptance. The first canonical invocation
was started before applying that inventory update; retain its outcome rather
than modifying the repository during a preserve-state run. The reviewed final
update adds one test file (417 -> 418) and five contexts (2939 -> 2944), with no
dependency, feature, macro, unsafe, debt or runtime-policy grant.

The first canonical attempt passes 12 tasks and fails the unapplied zrail
inventory plus the dependent final gate. The reviewed rerun
run-1788690281-711800275-2964180 passes all fourteen gates with preserved repository
state: 540 default runtime tests in debug/release and 569 all-feature runtime
tests, with one manual probe ignored. Fifty debug and fifty release invocations
on one allowed CPU each pass all three ordered tests: 300 additional test
executions. The source remains identical throughout those repeated checks.

The finding is classified as an invalid admission/selection test oracle. No
production I/O defect or unique original OS scheduling trace is claimed. The
five other loaded findings and cross-platform release matrix remain open.
