"""Ordered readiness retry regressions, mutations and canonical receipts."""

import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
ENV = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_TARGET_DIR='/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def run(label, command, expected=0):
    with (OUT / f'{label}.command.json').open('x') as stream:
        json.dump({'argv': command, 'environment': {key: ENV[key] for key in ('CARGO_INCREMENTAL', 'CARGO_TARGET_DIR')},
                   'source': evidence.metadata(label)}, stream, indent=2)
    with (OUT / f'{label}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    with (OUT / f'{label}.result.json').open('x') as stream:
        json.dump({'returncode': result.returncode, 'expected': expected}, stream)
    print(label, result.returncode, flush=True)
    assert result.returncode == expected


mode = sys.argv[1]
if mode in ('negative-immediate', 'negative-boundary', 'negative-admission', 'restored'):
    target = {'negative-immediate': 'blocked_io_yields_to_runnable_work_before_registering_readiness',
              'negative-boundary': 'blocked_io_registers_at_the_exact_retry_boundary',
              'negative-admission': 'admission_after_selection_can_legally_register',
              'restored': 'io_retry_test'}[mode]
    run(mode, ['cargo', 'test', '--locked', '-p', 'vthread', target, '--', '--nocapture'],
        0 if mode == 'restored' else 101)
elif mode.startswith('canonical'):
    run(mode, ['zcheck', 'run', 'check', '--logs-dir', str(OUT / mode),
               '--receipt', str(OUT / f'{mode}-receipt.json')])
elif mode == 'repeat':
    profile = sys.argv[2]
    log = OUT / f'canonical-reviewed/{"0007-test-native.log" if profile == "debug" else "0008-test-native-release.log"}'
    binaries = re.findall(r'Running unittests src/lib.rs \(([^)\s]*/deps/vthread-[0-9a-f]+)\)', log.read_text())
    assert len(binaries) == 1, binaries
    binary = binaries[0]
    with (OUT / f'repeat-{profile}-binary.json').open('x') as stream:
        json.dump({'path': binary, 'sha256': evidence.digest(Path(binary))}, stream)
    for index in range(50):
        label = f'repeat-{profile}-{index:02}'
        # Pin the test and its real reactor to one allowed CPU. This is a
        # correctness repetition, not a headline performance measurement.
        run(label, ['taskset', '-c', '6', binary, 'io_retry_test', '--nocapture'])
        assert 'test result: ok. 3 passed;' in (OUT / f'{label}.log').read_text()
else:
    raise SystemExit(f'unknown mode {mode}')
