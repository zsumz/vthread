# Incremental readiness experiment: hold, not promoted

Base commit: `495c931069f1f7831a2d3d32067f3bd551d9416e`.
Candidate source: `01b3303835bef9e3f4b658512c4cc8355fa4525c3d3057e119d924ee5daa485a`.
The complete source patch includes every new Rust file and the inventory-only
architecture-lock update. It applies to the base above. No runtime source changed
between the canonical receipt and the complete performance panels.

Decision: preserve the candidate on `perf/readiness-incremental`, not as the
production perf-branch runtime. Scaling improves repeatably, but protected CPU,
throughput and tail results do not establish the required non-regression gate.
Some protected differences are highly variable; this is not a causal diagnosis or
a claim that every higher median is a demonstrated production regression. No
polling, assembly, affinity, checkpoints, channel or mutex policy was changed.

## Implementation and proof

The production State owns a preallocated dirty queue bounded by I/O capacity.
An identity stays admitted while install/delete is queued or in flight; drop
marks cancellation without requiring command space or waiting for acknowledgement.
The sole poll owner takes at most 64 changes and events at a time. Backend
registration/deletion and wake publication hold no shared metadata lock. Ready
deletion is acknowledged before waking, allowing immediate capacity reuse. Close
retains descriptor/entry ownership until Poll drops. Shutdown's population walk
is deliberate; ordinary unchanged iterations do not walk the registration map.

The metadata model imports production State and explores 247/1,400 states and
1,541/9,941 edges at capacities one/two with three admissions. Metadata operations
are serialized by the production mutex. The model splits backend work from its
acknowledgement; it has one in-flight owner operation, not a full 64-command batch,
OS poller, wait-word or native-signaling model. Native ordered tests cover the
backend windows, command/event bounds, generation reuse and real publication.

Old-driver negative tests fail for a capacity scan (256 examined instead of zero),
early removal-capacity release and backend mutation while holding metadata. The
first 1,024-entry fixture exceeded the process descriptor limit; it is not scan
proof. The corrected 128-entry fixture reaches all three intended assertions.

Deliberately losing cancelled-install deletion and removing the event bound fail
four tests, including the model and actual backend pause test. `state-before-negative.rs`
and `driver-before-negative.rs` are byte-for-byte equal to the restored source.
The final candidate passes 23 targeted readiness tests, including RAII publication
abandonment. All 23 repeat 20 times per profile on CPU 7: 920 test executions in
40 processes, not 920 distinct schedules. No long mixed-lifetime soak or real ARM64
execution is claimed for this candidate.

All 14 canonical gates pass in `canonical-receipt/` (original receipt
`run-1788676633-358052789-2770840`). Default debug/release each pass 554 runtime
tests; all-features passes 583. One manual borrowed-maintenance probe is ignored.
Workspace stack/model/lab/reexport suites, doctests, architecture and application
smoke pass. The source hash above matches after all performance runs.

## Performance evidence and interpretation

Default features only. Population lab uses the workspace release profile;
protected/idle controls use one codegen unit and thin LTO. A/B within each harness
use identical profiles. None enables timed handoff profiling. Four AB/BA/BA/AB
pairs form each group. Small cases and two active work counts distinguish process
setup from useful traffic. Every population process asserts exact values, initial
installed population, final descriptor drain and runtime shutdown.

Seven complete population groups (`screen2,3,4,5,6,8,10`) contain 56 processes.
`screen1,7,9` stopped on the host-build guard before their first invocation.
The separate 1,024-idle smoke is not a paired performance result. Initial setup
and final idle cleanup are outside the lab exchange timer but inside perf's whole
process counters. Per-exchange time is throughput-derived, not individual latency.

The 4,096-idle/one-pair/10,000-exchange group reduces median process cycles 82.38%,
instructions 91.09%, CPU 80.90% and exchange time 86.46%. Its park totals are
essentially equal (about 20,000). This is not an improvement obtained by avoiding
suspension. The four-active-pair controls often avoid actual readiness through the
retained runnable retry path; their raw park counts are preserved.

Protected groups `protected2,4` contain 32 TCP processes; `protected3,5` contain
48 burst/quiet processes; `protected6` contains 56 other controls. `protected1`
stopped before any invocation. Total: 192 completed guarded counter processes,
plus the unpaired population smoke. No completed process is excluded. Every
source/binary/command, counter CSV, stdout and endpoint guard is retained.

TCP process-cycle medians rise roughly 3-4% in both groups, with mixed paired
effects. The first four-carrier p99.9 increase does not repeat consistently.
100-us burst CPU medians rise 12.92% then 3.38%, while cycles fall; no cause is
assigned. One-ms and quiet controls do not show a persistent penalty. Spare
lifecycle cycles rise 11.20% in the first protected group, with pairs from -7.37%
to +27.79%; the channel time median rises 32.86% with nearly flat cycles and large
paired variation. These results are not a demonstrated universal loss, but they
do not establish safe promotion. No extra layout or polling candidates follow.

The quiet/burst binary is the unchanged existing `idle_control.rs`; default builds
of both exact runtimes use identical dependency locks, all versions present in the
reviewed workspace lock. The baseline checkout is detached at the base commit on
the external volume. These waves are explicitly closed-loop, not offered-load tail
qualification. The full May comparison remains historical.

CPU masks: 7 for one carrier, 0-3 for four. Population placement is normal, not
forced; protected benchmark cases use existing carrier pinning where recorded.
Population processes raise only their inherited descriptor limit to 32,768; the
original soft/hard limits are in each manifest. Endpoint observations reject known
builds, but do not prove physical-host isolation or attribute VM scheduling tails.

## Reproduction

1. Check out the base and apply `candidate-complete.patch` for B. A's population
   binary uses the same lab files plus the mechanical reconciliation extraction in
   the saved old-source files; release builds omit the test counters, not that
   helper extraction. Its code generation is not claimed identical to pristine A.
   Its exact source
   manifest is `baseline-source.json`, distinct from the pre-readiness runtime's
   source identity used by the protected benchmark.
2. Run `cargo test --locked -p vthread --lib readiness:: -- --test-threads=1`, then
   default debug/release workspace tests and `zcheck run check`. Reproduce the
   documented negative mutations separately and restore before building B.
3. Build the lab with `cargo build --locked --release -p vthread-lab --bin vthread-readiness`.
   Build protected benchmarks with `cargo build --locked --release --manifest-path benchmarks/Cargo.toml`.
   Build the existing idle control using each saved adapter manifest and lockfile.
4. Adapt checkout/build/output paths in the scripts and manifests. Copies of
   `control.py`, `evidence.py`, idle source/tests and analysis programs are included;
   their original imports reference earlier evidence directories and must be
   pointed at those bundled copies. Do not reuse saved executables as a rebuild.
5. Replay exact `*.command.json` arguments with their recorded CPU/descriptor
   limits, alternating engines as in the manifests. Run the population/protected/
   idle analysis scripts only on complete four-pair groups. They reject missing
   guards, missing results and incomplete groups rather than imputing samples.

Executables are represented by hashes, not embedded in this bundle. Candidate
population binary: `2a16a442f97d5ba1329d6275024756e2ea8dacc2ab6be9d35fc7d7d1879e52cb`;
population A: `b31402c2d207cd9a7d42fb3025f43ee377f492f7340738135a61d785f801d0b1`.
Protected B: `8de502c92f05cb8a4c9a6dfe1b7e3ede1a10a6cfbe6eb53bd71184fc797520f2`;
protected A: `e3a6a5f7647de0efbb773fd2c59d96e790c011f824df2677d082ad9ddf74620a`.
Idle A: `b8327a390e52898b79076b8a9783aff87f3844815a35ffd09c665fcf07d630e7`;
idle B: `838332373650c6572534b29783c7ab4ae6d65841993ee204f7cd3750f4d9c14c`.
