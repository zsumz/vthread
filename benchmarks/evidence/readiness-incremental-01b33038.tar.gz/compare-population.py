"""Reuse the guarded default-build perf capture for the readiness population lab."""

import importlib.util
import json
from pathlib import Path
import resource
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('control', ROOT / 'target/finish-line/native-control.R84U9h/control.py')
control = importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
control.OUT = OUT
evidence = control.evidence
BINARY = {'A': OUT / 'baseline-readiness', 'B': OUT / 'candidate-readiness'}


def main(cohort, idle, active, exchanges, carriers):
    previous_limits = resource.getrlimit(resource.RLIMIT_NOFILE)
    resource.setrlimit(resource.RLIMIT_NOFILE, (32768, previous_limits[1]))
    candidate = json.loads((OUT / 'candidate-source.json').read_text())
    assert candidate['source_sha256'] == evidence.source_digest()
    case = f'population-i{idle}-a{active}-n{exchanges}-c{carriers}'
    manifest = evidence.metadata('readiness population; balanced default release; process counters include setup and cleanup; elapsed interval excludes idle setup/cleanup')
    manifest['binaries'] = {arm: evidence.digest(path) for arm, path in BINARY.items()}
    manifest['sources'] = {arm: json.loads((OUT / name).read_text()) for arm, name in [('A', 'baseline-source.json'), ('B', 'candidate-source.json')]}
    manifest['fd_limits_before'] = previous_limits
    manifest['fd_limits_process'] = resource.getrlimit(resource.RLIMIT_NOFILE)
    manifest['orders'] = ['AB', 'BA', 'BA', 'AB']
    with (OUT / f'{cohort}-{case}-manifest.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
    for pair, order in enumerate(manifest['orders'], 1):
        for arm in order:
            prefix = f'{cohort}-{pair}-{case}-{arm}'
            assert not (OUT / f'{prefix}.command.json').exists()
            control.observe(prefix, 'before')
            command = ['timeout', '120s', 'perf', 'stat', '-x,', '-e',
                       'task-clock,cycles,instructions,context-switches,cpu-migrations',
                       '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', '7' if carriers == 1 else '0-3',
                       str(BINARY[arm]), str(idle), str(active), str(exchanges), str(carriers), '1']
            with (OUT / f'{prefix}.command.json').open('x') as stream:
                json.dump(command, stream)
            with (OUT / f'{prefix}.log').open('x') as stream:
                result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            control.observe(prefix, 'after')
            assert result.returncode == 0, (prefix, result.returncode)
            print(f'completed {prefix}', flush=True)
    assert candidate['source_sha256'] == evidence.source_digest()
    assert manifest['binaries'] == {arm: evidence.digest(path) for arm, path in BINARY.items()}


if __name__ == '__main__':
    main(sys.argv[1], *map(int, sys.argv[2:]))
