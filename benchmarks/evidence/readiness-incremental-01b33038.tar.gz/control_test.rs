use super::{Config, run};

fn parse(input: &str) -> Result<Config, String> {
    Config::parse(input.split_whitespace().map(str::to_owned))
}

#[test]
fn dimensions_are_bounded_and_zero_waves_is_an_explicit_quiet_control() {
    let config = parse("4 64 65536 5000000 0").unwrap();
    assert_eq!(config.waves, 0);
    assert_eq!(config.gap.as_secs(), 5);
    assert_eq!(config.capacity, 65_536);
    for args in [
        "0 64 64 100 10",
        "65 64 65 100 10",
        "4 0 64 100 10",
        "4 4097 65536 100 10",
        "4 64 63 100 10",
        "4 1 3 100 10",
        "4 64 1000001 100 10",
        "4 64 64 0 10",
        "4 64 64 5000001 10",
        "4 64 64 100 1000001",
        "4 64 64 100 10 extra",
        "4 64 64 100",
    ] {
        assert!(parse(args).is_err(), "accepted {args}");
    }
}

#[test]
fn quiet_and_wave_controls_observe_actual_parks_and_drain_native_tasks() {
    for carriers in [1, 4] {
        for waves in [0, 2] {
            run(parse(&format!("{carriers} 8 8 1000 {waves}")).unwrap()).unwrap();
        }
    }
}
