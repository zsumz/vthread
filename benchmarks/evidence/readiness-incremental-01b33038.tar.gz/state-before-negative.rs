//! Each subscription reserves one dirty-queue slot until backend deletion is acknowledged.

use super::{Error, Result, WaitRegistration};
use std::{
    collections::{BTreeMap, VecDeque},
    os::fd::OwnedFd,
    sync::Arc,
};
use vthread_stack::ParkToken;

#[cfg_attr(test, derive(Clone))]
pub(super) struct Waiter {
    pub(super) token: ParkToken,
    pub(super) wake: WaitRegistration,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Phase {
    InstallQueued,
    Installing,
    Installed,
    RetireQueued,
    Retiring,
}

#[cfg_attr(test, derive(Clone))]
pub(super) struct Entry {
    fd: Arc<OwnedFd>,
    interest: zio::Interest,
    waiter: Option<Waiter>,
    ready: bool,
    phase: Phase,
}

pub(super) enum Change {
    Install {
        key: u64,
        fd: Arc<OwnedFd>,
        interest: zio::Interest,
    },
    Retire {
        key: u64,
        installed: bool,
    },
}

#[cfg_attr(test, derive(Clone))]
pub(super) struct State {
    pub(super) entries: BTreeMap<u64, Entry>,
    dirty: VecDeque<u64>,
    capacity: usize,
    next: u64,
    pub(super) waiting: usize,
    pub(super) stopped: bool,
    pub(super) error: Option<String>,
}

impl State {
    pub(super) fn new(capacity: usize) -> Self {
        Self {
            entries: BTreeMap::new(),
            dirty: VecDeque::with_capacity(capacity),
            capacity,
            next: 1,
            waiting: 0,
            stopped: false,
            error: None,
        }
    }

    pub(super) fn admit(
        &mut self,
        fd: Arc<OwnedFd>,
        interest: zio::Interest,
        waiter: Waiter,
    ) -> Result<u64> {
        if self.error.is_some() {
            return Err(Error::ReadinessFailed);
        }
        if self.stopped {
            return Err(Error::RuntimeStopped);
        }
        if self.entries.len() == self.capacity {
            return Err(Error::Capacity {
                resource: crate::error::CapacityResource::Readiness,
                limit: self.capacity,
            });
        }
        let key = self.next;
        self.next = key.checked_add(1).ok_or_else(|| {
            Error::fault(
                crate::error::FaultComponent::Readiness,
                "readiness identity exhausted",
            )
        })?;
        self.entries.insert(
            key,
            Entry {
                fd,
                interest,
                waiter: Some(waiter),
                ready: false,
                phase: Phase::InstallQueued,
            },
        );
        self.waiting += 1;
        self.enqueue(key);
        Ok(key)
    }

    pub(super) fn cancel(&mut self, key: u64) -> Option<Waiter> {
        let entry = self.entries.get_mut(&key)?;
        let waiter = entry.waiter.take()?;
        self.waiting -= 1;
        // Queued/in-flight work already owns the removal obligation. Never add a
        // second command, including when drop races an in-flight deletion.
        if entry.phase == Phase::Installed {
            entry.phase = Phase::RetireQueued;
            self.enqueue(key);
        }
        Some(waiter)
    }

    pub(super) fn ready(&mut self, key: u64) {
        if self.stopped {
            return;
        }
        let Some(entry) = self.entries.get_mut(&key) else {
            return;
        };
        if entry.phase == Phase::Installed && entry.waiter.is_some() {
            entry.ready = true;
            entry.phase = Phase::RetireQueued;
            self.enqueue(key);
        }
    }

    pub(super) fn pop_change(&mut self) -> Option<Change> {
        let key = self.dirty.pop_front()?;
        let entry = self
            .entries
            .get_mut(&key)
            .expect("dirty entry retains capacity");
        Some(match entry.phase {
            Phase::InstallQueued if entry.waiter.is_some() => {
                entry.phase = Phase::Installing;
                Change::Install {
                    key,
                    fd: Arc::clone(&entry.fd),
                    interest: entry.interest,
                }
            }
            Phase::InstallQueued | Phase::RetireQueued => {
                let installed = entry.phase == Phase::RetireQueued;
                entry.phase = Phase::Retiring;
                Change::Retire { key, installed }
            }
            _ => unreachable!("one queued command per subscription"),
        })
    }

    pub(super) fn installed(&mut self, key: u64) {
        let entry = self
            .entries
            .get_mut(&key)
            .expect("installation retains identity");
        assert_eq!(entry.phase, Phase::Installing);
        if entry.waiter.is_some() && !self.stopped {
            entry.phase = Phase::Installed;
        } else {
            entry.phase = Phase::RetireQueued;
            self.enqueue(key);
        }
    }

    pub(super) fn retired(&mut self, key: u64) -> Entry {
        let entry = self
            .entries
            .remove(&key)
            .expect("deletion retains identity until ack");
        assert_eq!(entry.phase, Phase::Retiring);
        self.waiting -= usize::from(entry.waiter.is_some());
        entry
    }

    pub(super) fn has_changes(&self) -> bool {
        !self.dirty.is_empty()
    }

    pub(super) fn close_waiters(&mut self) -> Vec<Waiter> {
        self.stopped = true;
        self.waiting = 0;
        // Shutdown may visit the population once. Entry/descriptor ownership is
        // retained until the poll owner has dropped the backend.
        self.entries
            .values_mut()
            .filter_map(|entry| entry.waiter.take())
            .collect()
    }

    pub(super) fn backend_dropped(&mut self) -> BTreeMap<u64, Entry> {
        assert!(self.stopped);
        self.dirty.clear();
        std::mem::take(&mut self.entries)
    }

    fn enqueue(&mut self, key: u64) {
        assert!(
            self.dirty.len() < self.capacity,
            "admission reserves command space"
        );
        self.dirty.push_back(key);
    }
}

impl Entry {
    pub(super) fn ready_waiter(&mut self) -> Option<Waiter> {
        if self.ready { self.waiter.take() } else { None }
    }
}

#[cfg(test)]
#[path = "state_test.rs"]
mod state_test;

#[cfg(test)]
#[path = "state_model_test.rs"]
mod state_model_test;
