"""Complete guarded pairs only; process counters are not isolated operation counters."""

import csv
import json
from pathlib import Path
import statistics
import sys

OUT = Path(__file__).resolve().parent


def record(prefix):
    for stage in ['before', 'after']:
        guard = OUT / f'{prefix}.{stage}.guard'
        assert guard.exists() and not guard.read_text().strip(), (prefix, stage)
    results = [json.loads(line) for line in (OUT / f'{prefix}.log').read_text().splitlines() if line.startswith('{')]
    assert len(results) == 1, prefix
    data = results[0]
    assert data['initial_registered'] == data['idle'] + data['active_pairs']
    data['ns/exchange'] = data['elapsed_ns'] / data['exchanges']
    for row in csv.reader((OUT / f'{prefix}.csv').read_text().splitlines()):
        if len(row) > 2 and row[2] in ['cycles', 'instructions', 'task-clock', 'context-switches', 'cpu-migrations']:
            data[row[2]] = float(row[0])
    assert all(key in data for key in ['cycles', 'instructions', 'task-clock', 'context-switches'])
    return data


def summarize(cohort, idle, active, exchanges, carriers):
    case = f'population-i{idle}-a{active}-n{exchanges}-c{carriers}'
    records = {arm: [record(f'{cohort}-{pair}-{case}-{arm}') for pair in range(1, 5)] for arm in 'AB'}
    output = {'cohort': cohort, 'case': case, 'processes': 8, 'metrics': {}}
    for metric in ['ns/exchange', 'cycles', 'instructions', 'task-clock', 'context-switches', 'parks']:
        a, b = [[entry[metric] for entry in records[arm]] for arm in 'AB']
        middle_a, middle_b = statistics.median(a), statistics.median(b)
        output['metrics'][metric] = {
            'A': middle_a, 'B': middle_b,
            'median_change_percent': 100 * (middle_b / middle_a - 1) if middle_a else None,
            'paired_changes_percent': [100 * (right / left - 1) if left else None for left, right in zip(a, b)],
            'A_raw': a, 'B_raw': b,
        }
    return output


if __name__ == '__main__':
    print(json.dumps(summarize(sys.argv[1], *map(int, sys.argv[2:])), indent=2))
