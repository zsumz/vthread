"""Existing protected workloads; no timed instrumentation or policy search."""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('control', ROOT / 'target/finish-line/native-control.R84U9h/control.py')
control = importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
control.OUT = OUT
evidence = control.evidence
BENCH = {'A': ROOT / 'target/finish-line/native-deferral.jBIgJM/candidate-benchmark', 'B': OUT / 'candidate-benchmark'}
IDLE = {arm: OUT / f'{name}-idle' for arm, name in [('A', 'baseline'), ('B', 'candidate')]}
CASES = {
    'tcp1': ('7', ['tcp', '3000', '1', '1', '7', '--pin-carriers']),
    'tcp4': ('0-3', ['tcp', '1000', '4', '8', '7', '--pin-carriers']),
    'yield4': ('0-3', ['yield', '100000', '4', '64', '7', '--pin-carriers']),
    'spawn1000': ('0-3', ['spawn', '4', '1000', '501']),
    'spawn-spare': ('0-3', ['spawn', '4', '1000', '101', '--max-vthreads', '65536']),
    'park4': ('0-3', ['park', '10000', '4', '64', '7', '--pin-carriers']),
    'mutex4': ('0-3', ['mutex', '2000', '4', '64', '7', '--pin-carriers']),
    'channel4c8': ('0-3', ['channel-mpmc', '10000', '1', '4', '8', '7', '--pin-carriers']),
    'wake4': ('0-3', ['wake-tail', '2000', '4', '64', '7', '--pin-carriers']),
    'idle-100us': ('0-3', ['4', '8', '8', '100', '2000']),
    'idle-1ms': ('0-3', ['4', '8', '8', '1000', '1000']),
    'idle-quiet': ('0-3', ['4', '8', '65536', '1000000', '0']),
}


def main(cohort, cases):
    manifest = evidence.metadata('readiness protected panel; default features; 495c931 runtime baseline; separate protected and population harness profiles; no May comparison')
    assert manifest['source_sha256'] == json.loads((OUT / 'candidate-source.json').read_text())['source_sha256']
    manifest['benchmarks'] = {arm: evidence.digest(path) for arm, path in BENCH.items()}
    manifest['idle'] = {arm: evidence.digest(path) for arm, path in IDLE.items()}
    manifest['orders'] = ['AB', 'BA', 'BA', 'AB']
    with (OUT / f'{cohort}-manifest.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
    for case in cases:
        mask, arguments = CASES[case]
        for pair, order in enumerate(manifest['orders'], 1):
            for arm in order:
                prefix = f'{cohort}-{pair}-{case}-{arm}'
                assert not (OUT / f'{prefix}.command.json').exists()
                control.observe(prefix, 'before')
                binary = IDLE[arm] if case.startswith('idle-') else BENCH[arm]
                args = arguments if case.startswith('idle-') else ['vthread', *arguments]
                command = ['timeout', '120s', 'perf', 'stat', '-x,', '-e',
                           'task-clock,cycles,instructions,context-switches,cpu-migrations',
                           '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', mask, str(binary), *args]
                with (OUT / f'{prefix}.command.json').open('x') as stream:
                    json.dump(command, stream)
                with (OUT / f'{prefix}.log').open('x') as stream:
                    result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
                control.observe(prefix, 'after')
                assert result.returncode == 0, (prefix, result.returncode)
                print(f'completed {prefix}', flush=True)
    assert manifest['source_sha256'] == evidence.source_digest()


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2:])
