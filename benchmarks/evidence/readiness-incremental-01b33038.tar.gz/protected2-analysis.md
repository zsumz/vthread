| Case | Baseline ns/op | Repair ns/op | Cycles change | Instructions change |
| --- | ---: | ---: | ---: | ---: |
| tcp1 | 132526.77 | 137745.90 | +3.83% | +3.14% |
| tcp4 | 47763.24 | 47663.07 | +2.60% | -1.65% |
Validated 16 guarded processes; raw process samples in protected2-analysis.json
