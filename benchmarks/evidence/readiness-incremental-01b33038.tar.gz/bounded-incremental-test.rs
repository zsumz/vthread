//! Ordered algorithm and retirement-capacity regressions, without a live driver.

use super::{initialize, reconcile};
use crate::{
    Error, TaskId,
    readiness::Reactor,
    task_slab::TaskKey,
    wait::{WaitBegin, WaitCell, WaitHub, WaitRegistration},
};
use std::{
    collections::BTreeMap,
    os::{fd::AsFd, unix::net::UnixStream},
    sync::{Arc, atomic::Ordering},
};
use vthread_stack::ParkToken;

fn driver(capacity: usize) -> (Reactor, zio::Poll) {
    let (inner, poll, _) = initialize(capacity, std::sync::Weak::new()).unwrap();
    (
        Reactor {
            inner,
            workers: Arc::new(crate::join_slot::JoinSlots::default()),
        },
        poll,
    )
}

fn waiter() -> (WaitCell, ParkToken, WaitRegistration) {
    let cell = WaitCell::new();
    let hub = Arc::new(WaitHub::new(1, Arc::default()));
    let WaitBegin::Park {
        request,
        registration,
    } = cell
        .begin(TaskId::new(1), TaskKey::owned(0), &hub, None)
        .unwrap()
    else {
        panic!("waiter");
    };
    (cell, request.token(), registration)
}

#[test]
fn unchanged_registrations_do_not_enter_the_next_change_batch() {
    let (reactor, mut poll) = driver(128);
    let (socket, _peer) = UnixStream::pair().unwrap();
    let (_cell, token, wait) = waiter();
    let leases = (0..128)
        .map(|_| {
            reactor
                .register(socket.as_fd(), zio::Interest::READABLE, token, wait.clone())
                .unwrap()
        })
        .collect::<Vec<_>>();
    let mut installed = BTreeMap::new();
    for _ in 0..128 {
        if installed.len() == leases.len() {
            break;
        }
        assert!(reconcile(&reactor.inner, &mut poll, &mut installed).unwrap());
    }
    assert_eq!(installed.len(), leases.len());
    let before = reactor.inner.entries_examined.load(Ordering::Relaxed);
    assert!(reconcile(&reactor.inner, &mut poll, &mut installed).unwrap());
    assert_eq!(
        reactor.inner.entries_examined.load(Ordering::Relaxed) - before,
        0,
        "unchanged population was examined"
    );
}

#[test]
fn dropped_subscription_keeps_its_removal_reservation_until_acknowledged() {
    let (reactor, mut poll) = driver(1);
    let (socket, _peer) = UnixStream::pair().unwrap();
    let (_cell, token, wait) = waiter();
    let lease = reactor
        .register(socket.as_fd(), zio::Interest::READABLE, token, wait.clone())
        .unwrap();
    let mut installed = BTreeMap::new();
    assert!(reconcile(&reactor.inner, &mut poll, &mut installed).unwrap());
    assert_eq!(installed.len(), 1);
    drop(lease);
    assert!(matches!(
        reactor.register(socket.as_fd(), zio::Interest::READABLE, token, wait.clone()),
        Err(Error::Capacity { .. })
    ));
    assert!(reconcile(&reactor.inner, &mut poll, &mut installed).unwrap());
    assert!(installed.is_empty());
    assert!(
        reactor
            .register(socket.as_fd(), zio::Interest::READABLE, token, wait)
            .is_ok()
    );
}

#[test]
fn backend_installation_does_not_hold_subscription_metadata() {
    let (reactor, mut poll) = driver(1);
    let (socket, _peer) = UnixStream::pair().unwrap();
    let (_cell, token, wait) = waiter();
    let _lease = reactor
        .register(socket.as_fd(), zio::Interest::READABLE, token, wait)
        .unwrap();
    reactor
        .inner
        .require_unlocked_mutations
        .store(true, Ordering::Release);
    assert!(reconcile(&reactor.inner, &mut poll, &mut BTreeMap::new()).unwrap());
}
