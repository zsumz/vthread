| Case | Baseline ns/op | Repair ns/op | Cycles change | Instructions change |
| --- | ---: | ---: | ---: | ---: |
| tcp1 | 127833.10 | 149804.29 | +3.86% | +2.63% |
| tcp4 | 49953.85 | 48132.60 | +3.96% | -1.51% |
Validated 16 guarded processes; raw process samples in protected4-analysis.json
