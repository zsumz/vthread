//! Public-API diagnostic: externally paced wake waves and genuinely quiet parks.
#![forbid(unsafe_code)]

#[cfg(feature = "handoff-profiling")]
#[path = "../../../benchmarks/src/handoff_profile.rs"]
mod handoff_report;

use std::{
    sync::mpsc,
    time::{Duration, Instant},
};
use vthread::{
    Runtime,
    diagnostics::CarrierStatus,
    parking::{ParkOutcome, UnparkResult},
};

#[derive(Clone, Copy)]
struct Config {
    carriers: usize,
    tasks: usize,
    capacity: usize,
    gap: Duration,
    waves: usize,
}

impl Config {
    fn parse(args: impl Iterator<Item = String>) -> Result<Self, String> {
        let numbers = args
            .map(|value| value.parse::<u64>().map_err(|e| e.to_string()))
            .collect::<Result<Vec<_>, _>>()?;
        let [carriers, tasks, capacity, gap_us, waves] = numbers.as_slice() else {
            return Err("expected: CARRIERS TASKS CAPACITY GAP_US WAVES".into());
        };
        if !(1..=64).contains(carriers)
            || !(1..=4096).contains(tasks)
            || *capacity < (*tasks).max(*carriers)
            || *capacity > 1_000_000
            || !(1..=5_000_000).contains(gap_us)
            || *waves > 1_000_000
        {
            return Err("invalid diagnostic bounds".into());
        }
        Ok(Self {
            carriers: *carriers as usize,
            tasks: *tasks as usize,
            capacity: *capacity as usize,
            gap: Duration::from_micros(*gap_us),
            waves: *waves as usize,
        })
    }
}

fn failure(message: impl Into<String>) -> vthread::Error {
    std::io::Error::other(message.into()).into()
}

fn await_parked(runtime: &Runtime, tasks: usize) -> vthread::Result<()> {
    let deadline = Instant::now() + Duration::from_secs(5);
    loop {
        let snapshot = runtime.snapshot();
        if snapshot.parked() == tasks
            && snapshot.carriers().iter().all(|carrier| {
                carrier.status() == CarrierStatus::Idle
                    && carrier.runnable() == 0
                    && carrier.pending_starts() == 0
                    && carrier.pending_wakes() == 0
            })
        {
            let owned: Vec<_> = snapshot
                .carriers()
                .iter()
                .map(|carrier| carrier.parked())
                .collect();
            println!(
                "phase=initial-parked parked={tasks} owner_counts={owned:?} timers={}",
                snapshot.timers()
            );
            if snapshot.timers() != 0 {
                return Err(failure("unexpected timer"));
            }
            return Ok(());
        }
        if Instant::now() >= deadline {
            let mut dump = String::new();
            snapshot.write_dump(&mut dump).expect("string dump");
            return Err(failure(format!("initial parks not observed: {dump}")));
        }
        std::thread::yield_now();
    }
}

fn run(config: Config) -> vthread::Result<()> {
    let runtime = Runtime::builder()
        .carriers(config.carriers)
        .max_vthreads(config.capacity)
        .carrier_queue_capacity(config.tasks)
        .stack_size(64 * 1024)
        .stack_cache_capacity(config.tasks)
        .blocking_threads(1)
        .blocking_capacity(1)
        .io_capacity(1)
        .build()?;
    println!(
        "phase=contract carriers={} tasks={} capacity={} quiet_gap_us={} waves={} placement=normal process_mask=external individual_pinning=false acknowledgement=bounded-native-try-send cpu_scope=whole-process open_loop=false",
        config.carriers,
        config.tasks,
        config.capacity,
        config.gap.as_micros(),
        config.waves
    );
    let result = runtime.run_scope(|scope| {
        let (ack_sender, ack_receiver) = mpsc::sync_channel(config.tasks);
        let mut wakers = Vec::with_capacity(config.tasks);
        let mut handles = Vec::with_capacity(config.tasks);
        for id in 0..config.tasks {
            let (parker, waker) = vthread::parking::park_pair();
            wakers.push(waker);
            let ack = ack_sender.clone();
            handles.push(scope.spawn("idle-budget", move || {
                for wave in 0..config.waves {
                    if parker.park()? != ParkOutcome::Ready {
                        return Err(failure("unexpected park outcome"));
                    }
                    // Capacity covers one outstanding acknowledgement per task.
                    // Never block a carrier on the native measurement channel.
                    ack.try_send((wave, id)).map_err(|e| failure(e.to_string()))?;
                }
                if parker.park()? != ParkOutcome::Closed {
                    return Err(failure("final parked generation was not closed"));
                }
                Ok::<_, vthread::Error>(())
            })?);
        }
        drop(ack_sender);
        await_parked(&runtime, config.tasks)?;
        // Initial proof/observation is outside the interval; no snapshots within it.
        std::thread::sleep(Duration::from_millis(50));
        let started = Instant::now();
        let mut woke = 0_u64;
        let mut stored = 0_u64;
        let mut seen = vec![false; config.tasks];
        for wave in 0..config.waves {
            std::thread::sleep(config.gap);
            for waker in &wakers {
                match waker.unpark() {
                    UnparkResult::Woke => woke += 1,
                    UnparkResult::Stored => stored += 1,
                    other => return Err(failure(format!("unexpected unpark: {other:?}"))),
                }
            }
            seen.fill(false);
            let deadline = Instant::now() + Duration::from_secs(5);
            for _ in 0..config.tasks {
                let (ack_wave, id) = ack_receiver.recv_timeout(deadline.saturating_duration_since(Instant::now()))
                    .map_err(|e| failure(format!("wave {wave}: {e}")))?;
                if ack_wave != wave || id >= config.tasks || seen[id] {
                    return Err(failure(format!("invalid acknowledgement {ack_wave}/{id}")));
                }
                seen[id] = true;
            }
        }
        // Also exercise the no-work budget: zero waves means one quiet interval.
        std::thread::sleep(config.gap);
        let elapsed = started.elapsed().as_nanos();
        println!("phase=interval elapsed_ns={elapsed} selected_wakes={woke} stored_permits={stored} acknowledgements={}", config.waves * config.tasks);
        for waker in &wakers { waker.close(); }
        for handle in &mut handles { handle.join()??; }
        Ok(())
    });
    let shutdown = runtime.shutdown();
    result?;
    shutdown?;
    let snapshot = runtime.snapshot();
    if snapshot.active() != 0 || snapshot.stats().completed() != config.tasks as u64 {
        return Err(failure("incomplete final drain"));
    }
    println!(
        "phase=drained completed={} parks={} wakes={} active={}",
        snapshot.stats().completed(),
        snapshot.stats().parks(),
        snapshot.stats().wakes(),
        snapshot.active()
    );
    #[cfg(feature = "handoff-profiling")]
    handoff_report::report(&mut std::io::stdout().lock(), &snapshot, Some(0)).map_err(failure)?;
    Ok(())
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let config = Config::parse(std::env::args().skip(1))?;
    run(config)?;
    Ok(())
}

#[cfg(test)]
#[path = "control_test.rs"]
mod control_test;
