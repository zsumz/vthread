//! The poll owner processes bounded changes and events without a population scan.

mod changes;

use super::{Inner, State, io_error};
use crate::signal::lock;
use std::{
    collections::BTreeMap,
    panic::{AssertUnwindSafe, catch_unwind},
    sync::{Arc, atomic::Ordering},
    time::Duration,
};

const BATCH: usize = 64;

pub(super) fn start(
    capacity: usize,
    ready: std::sync::mpsc::SyncSender<crate::Result<Arc<Inner>>>,
    owner: std::sync::Weak<crate::control::Shared>,
) {
    match initialize(capacity, owner) {
        Ok((inner, poll, events)) => {
            if ready.send(Ok(Arc::clone(&inner))).is_ok() {
                run(inner, poll, events);
            }
        }
        Err(error) => {
            let _ = ready.send(Err(error));
        }
    }
}

fn initialize(
    capacity: usize,
    owner: std::sync::Weak<crate::control::Shared>,
) -> crate::Result<(Arc<Inner>, zio::Poll, zio::Events)> {
    let mut poll = zio::Poll::with_capacity(capacity.max(2), capacity).map_err(io_error)?;
    let events = poll.events().map_err(io_error)?;
    let waker = poll.waker(zio::Key::ZERO).map_err(io_error)?;
    let inner = Arc::new(Inner {
        owner,
        state: std::sync::Mutex::new(State::new(capacity)),
        waker,
        capacity,
        registered: std::sync::atomic::AtomicUsize::new(0),
        #[cfg(test)]
        fail_wait: std::sync::atomic::AtomicBool::new(false),
        #[cfg(test)]
        entries_examined: std::sync::atomic::AtomicUsize::new(0),
        #[cfg(test)]
        require_unlocked_mutations: std::sync::atomic::AtomicBool::new(false),
        #[cfg(test)]
        change_hook: std::sync::Mutex::new(None),
    });
    Ok((inner, poll, events))
}

fn run(inner: Arc<Inner>, mut poll: zio::Poll, mut events: zio::Events) {
    let outcome = catch_unwind(AssertUnwindSafe(|| drive(&inner, &mut poll, &mut events)));
    match outcome {
        Ok(Ok(())) => {}
        Ok(Err(error)) => inner.close(Some(error)),
        Err(payload) => inner.close(Some(
            crate::PanicReport::capture(payload).message().to_owned(),
        )),
    }
    drop(poll);
    let entries = lock(&inner.state).backend_dropped();
    drop(entries);
    inner.registered.store(0, Ordering::Release);
}

fn drive(inner: &Inner, poll: &mut zio::Poll, events: &mut zio::Events) -> Result<(), String> {
    let mut installed = BTreeMap::new();
    let mut batch = Vec::with_capacity(BATCH);
    let mut cursor = 0;
    let mut recovery = None;
    loop {
        if !changes::reconcile(inner, poll, &mut installed, &mut batch)? {
            return Ok(());
        }
        // Consume at most one event batch before offering another command batch.
        if cursor < events.len() {
            cursor = consume_events(inner, events, cursor);
            continue;
        }
        if let Some(error) = recovery.take() {
            return Err(error);
        }
        #[cfg(test)]
        if inner.fail_wait.swap(false, Ordering::AcqRel) {
            return Err("injected readiness wait failure".to_owned());
        }
        // A command flood cannot postpone polling; idle waits retain the waker
        // and bounded shutdown fallback. Register/drop races wake this poll.
        let wait = if lock(&inner.state).has_changes() {
            zio::Wait::NoBlock
        } else {
            zio::Wait::For(Duration::from_millis(100))
        };
        let report = match poll.wait(events, wait) {
            Ok(report) => report,
            Err(zio::Error::Io { source, .. })
                if source.kind() == std::io::ErrorKind::Interrupted =>
            {
                continue;
            }
            Err(error) => return Err(error.to_string()),
        };
        cursor = consume_events(inner, events, 0);
        recovery = report.into_recovery().map(|error| error.to_string());
    }
}

fn consume_events(inner: &Inner, events: &zio::Events, start: usize) -> usize {
    let end = (start + BATCH).min(events.len());
    let mut state = lock(&inner.state);
    for event in &events.as_slice()[start..end] {
        if event.readiness().is_some() {
            #[cfg(test)]
            inner.entries_examined.fetch_add(1, Ordering::Relaxed);
            state.ready(event.key().get());
        }
    }
    end
}

#[cfg(test)]
fn check_mutation_unlocked(inner: &Inner) {
    if inner.require_unlocked_mutations.load(Ordering::Acquire) {
        assert!(
            inner.state.try_lock().is_ok(),
            "backend mutation holds shared metadata"
        );
    }
}

#[cfg(test)]
#[path = "driver_test.rs"]
mod driver_test;

#[cfg(test)]
#[path = "incremental_test.rs"]
mod incremental_test;

#[cfg(test)]
#[path = "incremental_race_test.rs"]
mod incremental_race_test;

#[cfg(test)]
#[path = "incremental_event_test.rs"]
mod incremental_event_test;
