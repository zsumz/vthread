| Case | Baseline ns/op | Repair ns/op | Cycles change | Instructions change |
| --- | ---: | ---: | ---: | ---: |
| channel4c8 | 1382.24 | 1836.49 | +1.07% | +1.39% |
| mutex4 | 557.21 | 490.60 | -24.72% | -11.24% |
| park4 | 124.17 | 133.94 | +1.88% | +0.42% |
| spawn-spare | 1626.19 | 1600.65 | +11.20% | -1.53% |
| spawn1000 | 422.97 | 422.55 | +0.49% | +1.23% |
| wake4 | 97.02 | 81.41 | -10.20% | -1.59% |
| yield4 | 15.61 | 15.86 | +1.74% | +0.03% |
Validated 56 guarded processes; raw process samples in protected6-analysis.json
