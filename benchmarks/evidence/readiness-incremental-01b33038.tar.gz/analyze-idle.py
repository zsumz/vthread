"""Check all closed-loop wave acknowledgements and report guarded process CPU."""

import csv
import json
from pathlib import Path
import re
import statistics
import sys

OUT = Path(__file__).resolve().parent


def record(prefix):
    for stage in ['before', 'after']:
        assert (OUT / f'{prefix}.{stage}.guard').read_text() == ''
    text = (OUT / f'{prefix}.log').read_text()
    fields = {key: int(value) for key, value in re.findall(r'\b(quiet_gap_us|waves|tasks|elapsed_ns|selected_wakes|stored_permits|acknowledgements|completed|parks|wakes|active)=(\d+)', text)}
    assert fields['acknowledgements'] == fields['tasks'] * fields['waves']
    assert fields['selected_wakes'] + fields['stored_permits'] == fields['acknowledgements']
    assert fields['completed'] == fields['tasks'] and fields['active'] == 0
    data = {'elapsed_ns': fields['elapsed_ns']}
    for row in csv.reader((OUT / f'{prefix}.csv').read_text().splitlines()):
        if len(row) > 2 and row[2] in ['cycles', 'instructions', 'task-clock', 'context-switches', 'cpu-migrations']:
            data[row[2]] = float(row[0])
    assert len(data) == 6
    return data


def main(cohort):
    results = {}
    for case in ['idle-100us', 'idle-1ms', 'idle-quiet']:
        values = {arm: [record(f'{cohort}-{pair}-{case}-{arm}') for pair in range(1, 5)] for arm in 'AB'}
        results[case] = {}
        for key in values['A'][0]:
            a, b = [[record[key] for record in values[arm]] for arm in 'AB']
            median_a, median_b = statistics.median(a), statistics.median(b)
            results[case][key] = {'A': median_a, 'B': median_b,
                'change_percent': 100 * (median_b / median_a - 1) if median_a else None,
                'paired_changes_percent': [100 * (r / l - 1) if l else None for l, r in zip(a, b)],
                'A_raw': a, 'B_raw': b}
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])
