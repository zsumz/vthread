#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/shared-channel-control
binary=$evidence_dir/baseline-benchmark
for carriers in 1 4; do
    for capacity in 1 64 1024; do
        timeout 30s taskset -c 0-3 "$binary" vthread channel-mpmc 1000 "$capacity" "$carriers" 8 3 \
            > "$evidence_dir/smoke-$carriers-$capacity.log" 2>&1
    done
done
set +e
"$binary" may channel-mpmc 1000 1 4 8 3 > "$evidence_dir/may-rejected.log" 2>&1
result=$?
set -e
[[ $result == 1 ]]
rg -q 'vthread-only control' "$evidence_dir/may-rejected.log"
printf 'six native controls and explicit May rejection passed\n'
