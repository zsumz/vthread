# Shared bounded-channel benchmark control

Apply candidate.patch to 741028506fe151abf6bc6520d3c65411f50d3e1c for the source
identified in source.json. This slice changes only the standalone benchmark and
documentation, not runtime or architecture-lock source.

```sh
cargo fmt --manifest-path benchmarks/Cargo.toml -- --check
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/root/vthread/target cargo test --locked --manifest-path benchmarks/Cargo.toml --all-features
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/root/vthread/target cargo clippy --locked --manifest-path benchmarks/Cargo.toml --all-targets --all-features -- -D warnings
CARGO_INCREMENTAL=0 zcheck run check
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
bash target/finish-line/shared-channel-control/run-smoke.sh
```

The native command matrix uses one/four carriers and capacities 1/64/1024. These
short runs qualify the harness contract, not performance against another binary.
Every measured and warm-up round checks exact delivery outside the elapsed clock.
Source patch, compiler/environment identity, native/benchmark qualification,
canonical receipt and executed-binary hashes are preserved; executables are omitted.
