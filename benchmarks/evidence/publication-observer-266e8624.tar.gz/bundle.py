"""Archive exact test-only source, original failure, negative control and gates."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

manifest = evidence.metadata('test-only publication observer ordering repair; production code and architecture lock unchanged')
with (OUT / 'source.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
with (OUT / 'candidate.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--binary', '--', 'crates/vthread/src/kernel_publication_sleep_test.rs', 'crates/vthread/src/wait_publication_probe_test.rs'], cwd=ROOT))
ARCHIVE = ROOT / f'benchmarks/evidence/publication-observer-{manifest["source_sha256"][:8]}.tar.gz'
paths = sorted(path for path in OUT.rglob('*') if path.is_file()
               and '__pycache__' not in path.parts and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(ARCHIVE, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
verify = Path(tempfile.mkdtemp(prefix='publication-observer-verify.', dir=ROOT / 'target/finish-line'))
with tarfile.open(ARCHIVE) as archive:
    members = archive.getmembers()
    assert all(member.isfile() and not Path(member.name).is_absolute()
               and '..' not in Path(member.name).parts for member in members)
    archive.extractall(verify, members=members)
with (verify / 'verification.log').open('x') as stream:
    subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=verify, stdout=stream,
                   stderr=subprocess.STDOUT, check=True)
print('archive', ARCHIVE)
print('sha256', evidence.digest(ARCHIVE))
print('verified', len(paths), 'internal hashes', verify)
