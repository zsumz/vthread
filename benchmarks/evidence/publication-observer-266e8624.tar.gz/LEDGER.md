# Test-only publication observer ordering repair

The canonical attempt captured in `original-canonical-failure.log` failed
`a_failed_carrier_recovers_held_mutex_ownership` because OwnerDeferred reached the
test's observer before NoticePublished. 564 other runtime tests passed. The
production publisher routes the notice before it emits its diagnostic message;
an active recipient can dequeue/defer it in between. Receiving those messages
in the opposite order is not a lost wake or a production publication inversion.

The mutex measurement slice is preserved in stash
`1371b71e7f790bd6e32622b60fd106d99d81a1e5` and the separate mutex evidence directory;
no new mutex performance results had been collected. Its first canonical attempt
passed, but a later final attempt exposed this existing observer assumption.
This repair is isolated on base d79b802 and changes only two `_test.rs` files.

The deterministic negative control (`old-order.*`) uses the same consecutive
`observe(NoticePublished); observe(OwnerDeferred)` calls as the failed test,
factored into `observe_routed_pair`. It supplies both legal arrival orders and
fails the reversed order with the same assertion as the canonical failure.
The repaired helper consumes exactly two observations, validates the permitted
pair and exact ParkToken, and returns them by meaning rather than arrival order.
There is no new queue, buffer, timing tolerance or production protocol change.

Three helper tests accept both orders and reject different generations or
FinishWaiting in place of owner deferral. The original remaining assertions
still require unrelated work before releasing the publisher, retained ownership,
legal retirement, native sleep completion and clean shutdown. A quiet rerun is
not the basis for this classification; the controlled reverse-order failure is.

The six previously reviewed loaded findings remain separate and unresolved.

The first repetition driver completed 25 debug invocations, then refused to run
a release binary because its initial path pattern matched four executables in the
shared cache. No incorrect binary ran. The matcher now requires an exact
`/deps/vthread-HEX` basename; release repetitions run separately with preserved
prefixes. The final gate is `run-1788686133-417208506-2867869`: all fourteen tasks
pass with repository state preserved, including 539 default runtime tests in
debug and release, and 568 with all features (one manual probe ignored each).
