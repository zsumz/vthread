"""Deterministic negative control for a test-only observation ordering defect."""

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
ENV = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_TARGET_DIR='/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')


def run(label, command, expected=0):
    with (OUT / f'{label}.command.json').open('x') as stream:
        json.dump(command, stream)
    with (OUT / f'{label}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    with (OUT / f'{label}.result.json').open('x') as stream:
        json.dump({'returncode': result.returncode, 'expected': expected}, stream)
    print(label, result.returncode, flush=True)
    assert result.returncode == expected


if __name__ == '__main__':
    if sys.argv[1] == 'old':
        run('old-order', ['cargo', 'test', '--locked', '-p', 'vthread', 'a_routed_pair_preserves', '--', '--nocapture'], 101)
    elif sys.argv[1] == 'new':
        run('new-order', ['cargo', 'test', '--locked', '-p', 'vthread', 'a_routed_pair', '--', '--nocapture'])
        run('native-sleep', ['cargo', 'test', '--locked', '-p', 'vthread', 'kernel_publication_sleep_test', '--', '--nocapture'])
    elif sys.argv[1] == 'full':
        run('canonical', ['zcheck', 'run', 'check', '--logs-dir', str(OUT / 'canonical'),
                          '--receipt', str(OUT / 'canonical-receipt.json')])
    elif sys.argv[1] == 'repeat':
        for profile, expected in [('debug', 8), ('release', 8)]:
            if len(sys.argv) > 2 and profile != sys.argv[2]:
                continue
            # Resolve the exact default test binary from this slice's cargo
            # output, never a stale feature-on executable sharing the cache.
            log = (OUT / ('native-sleep.log' if profile == 'debug' else 'canonical/0008-test-native-release.log')).read_text()
            import re
            matches = re.findall(r'Running unittests src/lib.rs \(([^)\s]*/deps/vthread-[0-9a-f]+)\)', log)
            assert len(matches) == 1, matches
            binary = matches[0]
            for index in range(25):
                label = f'repeat-{profile}-{index:02}'
                run(label, [binary, 'kernel_publication_sleep_test', '--nocapture'])
                assert f'test result: ok. {expected} passed;' in (OUT / f'{label}.log').read_text()
