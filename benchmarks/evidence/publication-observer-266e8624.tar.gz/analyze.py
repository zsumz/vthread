"""Count exact test repetitions and actual observation order by wait token."""

import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
result = {'processes': 0, 'tests': 0, 'owner_observed_first': 0, 'publisher_observed_first': 0}
for profile in ['debug', 'release']:
    for index in range(25):
        prefix = f'repeat-{profile}-{index:02}'
        assert json.loads((OUT / f'{prefix}.result.json').read_text())['returncode'] == 0
        log = (OUT / f'{prefix}.log').read_text()
        assert 'test result: ok. 8 passed;' in log
        pairs = {}
        for stage, wait, generation in re.findall(r'publication probe: Observation \{ stage: (\w+), token: ParkToken \{ wait: (\d+), generation: (\d+) \}', log):
            if stage in ['NoticePublished', 'OwnerDeferred']:
                pairs.setdefault((wait, generation), []).append(stage)
        assert len(pairs) == 8, (prefix, pairs)
        for events in pairs.values():
            assert sorted(events) == ['NoticePublished', 'OwnerDeferred']
            result['owner_observed_first' if events[0] == 'OwnerDeferred' else 'publisher_observed_first'] += 1
        result['processes'] += 1
        result['tests'] += 8
with (OUT / 'analysis.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print(result)
