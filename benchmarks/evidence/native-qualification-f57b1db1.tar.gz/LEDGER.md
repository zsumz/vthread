# Required native qualification and unchanged-source control

Base: pristine `0b673376703186596d3f942864163c1f01914c21`.
Control source SHA-256: `f57b1db1457fc45f855e561e5eb89e489c72bcf166ef4c50400596057840c976`.
Default release executable SHA-256:
`9e28c2e1697674c253c2b70137317b3d826fcdaf18a17405b0ff358d89b03a5f`.
`source.json` records compiler, features, host, source and lock identities.
The binary was rebuilt before control processes; no own compilation, test or
runtime source edit overlapped measurement. Binary contents are not archived.

The first ten cases completed in pristine-source condition. A reversed second
round completed wake and spare-capacity controls, then the channel4c64 endpoint
guard detected an unrelated host build (PID recorded in its guard file). Thirteen
processes completed, twelve with clean endpoint guards; one is excluded. The
remaining seventeen planned processes did not run. No incomplete repeat is called
an independent full panel. Endpoint observations cannot establish continuous
guest or physical-host isolation. These are baseline controls, not optimization
acceptance, individual latency inferred from throughput, or a May comparison.

`control.py` records exact perf/affinity/work-count commands, default throughput
and sampled wake output, whole-process counters and endpoint host/CPU evidence.
Counter totals include startup, warm-up, validation and teardown. Rebuild at the
base before replay; adapt explicit checkout/build paths, use a fresh output
directory, and do not overwrite these raw files.

The canonical change is qualification-only. `qualification.patch` captures the
tested zcheck/policy configuration and documents; no Rust or lock change. Policy
negative controls reject missing native gates, all-feature substitution, omitted
release and broken dependency edges. Task output explicitly reports the native
engine and configuration; both feature worlds use vthread-stack at this revision.

The failed first canonical attempt and successful second attempt are both retained:

- `qualification-failed`: the old cancellation-history wall-time-ratio assertion
  failed after 543 runtime test passes; required native stages did not run.
- `qualification-passed`: all 14 required gates pass, including default-feature
  workspace tests in debug and release. Suites do not overlap one another or the
  application smoke workload. Repository state was preserved.

The successful run is not closure of the loaded cancellation-history finding.
No ARM64 run, new sanitizer qualification, performance improvement or release
readiness is implied. The historical May table is not refreshed here.

Verify every archived file with `sha256sum -c SHA256SUMS` after extraction.
`control-summary.json` explicitly records accepted-for-description versus excluded
processes. `pack.py` records archive construction; its original cache paths and
no-overwrite checks require adaptation for independent replay.
