"""Preserve complete, excluded and failed evidence without changing runtime code."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent


def main():
    for name, receipt in (
        ('qualification-failed', 'run-1788662708-282195919-2612597'),
        ('qualification-passed', 'run-1788663017-196073715-2617934'),
    ):
        shutil.copytree(Path('/root/.cache/zcheck') / receipt, OUT / name)
    result = subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=ROOT)
    (OUT / 'qualification.patch').write_bytes(result)
    completed = sorted(path.stem for path in OUT.glob('control-*.csv'))
    excluded = [name for name in completed if any(
        not (OUT / f'{name}.{stage}.guard').exists()
        or (OUT / f'{name}.{stage}.guard').read_text().strip()
        for stage in ('before', 'after'))]
    summary = {'planned_processes': 30, 'completed_processes': len(completed),
               'guard_clean_processes': [name for name in completed if name not in excluded],
               'excluded_processes': excluded, 'may_comparison': False,
               'optimization_acceptance': False}
    (OUT / 'control-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    paths = sorted(path for path in OUT.rglob('*') if path.is_file()
                   and path.name not in {'baseline-benchmark', 'SHA256SUMS'}
                   and '__pycache__' not in path.parts)
    (OUT / 'SHA256SUMS').write_text(''.join(
        f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(OUT)}\n'
        for path in paths))
    archive = ROOT / 'benchmarks/evidence/native-qualification-f57b1db1.tar.gz'
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as bundle:
        for path in [*paths, OUT / 'SHA256SUMS']:
            bundle.add(path, arcname=str(path.relative_to(OUT)))
    print(json.dumps(summary, indent=2))
    print(hashlib.sha256(archive.read_bytes()).hexdigest(), archive)


if __name__ == '__main__':
    main()
