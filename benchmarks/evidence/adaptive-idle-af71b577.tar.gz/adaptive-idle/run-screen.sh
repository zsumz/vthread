#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/adaptive-idle

run_case() {
    local kind=$1 label=$2 mask=$3
    shift 3
    if [[ ${VTHREAD_CONTROL_CASES:-all} != all && " ${VTHREAD_CONTROL_CASES:-} " != *" $label "* ]]; then return; fi
    for round in ${VTHREAD_CONTROL_ROUNDS:-1 2 3 4}; do
        local engines='baseline candidate'
        if (( round % 2 == 0 )); then engines='candidate baseline'; fi
        for engine in $engines; do
            local binary=$evidence_dir/candidate-benchmark
            if [[ $kind == cpu ]]; then binary=$evidence_dir/candidate-control; fi
            if [[ $engine == baseline && $kind == cpu ]]; then binary=target/finish-line/idle-budget/baseline-control; fi
            if [[ $engine == baseline && $kind == benchmark ]]; then binary=target/finish-line/channel-latency/baseline-benchmark; fi
            local prefix=$evidence_dir/$kind/control-$round-$engine-$label
            if [[ -e $prefix.log ]]; then
                printf 'refusing to overwrite earlier output: %s\n' "$prefix" >&2
                return 126
            fi
            if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
                printf 'control deferred before %s\n' "$prefix" >&2
                return 125
            fi
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            sed -n '1,9p' /proc/stat > "$prefix.before.cpu"
            local arguments=("$@")
            if [[ $kind == benchmark ]]; then arguments=(vthread "${arguments[@]}"); fi
            printf '%q ' timeout 120s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c "$mask" "$binary" "${arguments[@]}" >> "$evidence_dir/screen-commands.log"
            printf '\n' >> "$evidence_dir/screen-commands.log"
            timeout 120s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c "$mask" "$binary" "${arguments[@]}" > "$prefix.log" 2>&1
            sed -n '1,9p' /proc/stat > "$prefix.after.cpu"
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'screen round=%s engine=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

mkdir -p "$evidence_dir/benchmark" "$evidence_dir/cpu"
run_case cpu burst4-1ms 0-3 4 8 8 1000 2000
run_case cpu burst4-100us 0-3 4 8 8 100 5000
run_case benchmark mpmc-4c8 0-3 channel-mpmc 20000 1 4 8 5 --pin-carriers
run_case benchmark mpmc-4c64 0-3 channel-mpmc 10000 1 4 64 5 --pin-carriers
run_case benchmark tail-4c8 0-3 channel-mpmc 20000 1 4 8 5 --pin-carriers --sample-channel-latency
