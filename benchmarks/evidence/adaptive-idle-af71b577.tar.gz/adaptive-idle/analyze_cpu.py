"""Retain all four independent process pairs; require exact wave/drain accounting."""

import json
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parent / "cpu"
rows = []
for path in sorted(ROOT.glob("control-*-*.log")):
    match = re.fullmatch(r"control-(\d+)-(baseline|candidate)-(.+)\.log", path.name)
    row = {"round": int(match[1]), "arm": match[2], "case": match[3], "log": path.name}
    for line in path.read_text().splitlines():
        fields = dict(re.findall(r"(\w+)=(\S+)", line))
        if fields.get("phase") in ("interval", "drained"):
            row.update({key: int(value) for key, value in fields.items() if key != "phase"})
    for line in path.with_suffix(".csv").read_text().splitlines():
        fields = line.split(",")
        if len(fields) >= 3:
            try:
                row[fields[2]] = float(fields[0])
            except ValueError:
                pass
    assert row["active"] == 0
    assert row["selected_wakes"] + row["stored_permits"] == row["acknowledgements"]
    rows.append(row)

summary = {}
for case in sorted({row["case"] for row in rows}):
    groups = {arm: [row for row in rows if row["case"] == case and row["arm"] == arm]
              for arm in ("baseline", "candidate")}
    if not all(sorted(row["round"] for row in group) == [1, 2, 3, 4] for group in groups.values()):
        summary[case] = {"status": "incomplete_not_compared"}
        continue
    entry = {"status": "screening_not_acceptance"}
    for metric in ("task-clock", "cycles", "instructions", "elapsed_ns", "context-switches", "stored_permits"):
        values = {arm: [row[metric] for row in group] for arm, group in groups.items()}
        medians = {arm: statistics.median(group) for arm, group in values.items()}
        change = None if medians["baseline"] == 0 else 100 * (medians["candidate"] / medians["baseline"] - 1)
        entry[metric] = {"values": values, "medians": medians, "change_percent": change}
    summary[case] = entry
print(json.dumps({"summary": summary, "raw": rows}, indent=2))
