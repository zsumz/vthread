# Adaptive parked-idle screen

Baseline benchmark/runtime is qualified checkpoint 070c11f, source 30bb4869.
Candidate source af71b5774299e3fcb07c649ac73072d706f619b15092dfa43e70fbd35fa87ec2
is captured in source.json and candidate.patch; immutable executable/library hashes
are in binaries.sha256. The post-build zrail refresh changes analysis counts only.
A repeated release build after that refresh produces a byte-identical executable.

Only parked, untimed, multi-carrier idle intervals are timed. Sixteen consecutive
complete idle intervals at most 50 us earn 4096 probes; a longer interval resets
the policy to the original 640. Clock timing includes polling and native sleep.
No clock is added to repeated yield/task paths, admission-only, single-carrier or
timed waits. This is an experimental owner-local pacing policy, not new signaling
atomics or evidence that these thresholds are optimal.

The old fixed policy fails the first-park budget regression (4096 versus 640),
captured after task cleanup. The new policy passes all 65536 sixteen-interval
short/long histories, saturation and native parked-budget/no-clock exclusions.
An initial syntax error and invalid test-only stack-cache configuration are
preserved alongside the final three passing idle tests and 18 channel tests.
No final canonical, long stress, May comparison or acceptance is claimed here.

```sh
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib kernel_idle -- --test-threads=1
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib channel:: -- --test-threads=1
zrail check --format json
zrail update --format json
zrail update --accept-grants --format json
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
rustc --edition=2024 -C opt-level=3 -D warnings --crate-name idle_budget target/finish-line/idle-budget/control.rs --extern vthread=benchmarks/target/release/deps/libvthread-d6eb8953727b0829.rlib -L dependency=benchmarks/target/release/deps -o target/finish-line/adaptive-idle/candidate-control
bash target/finish-line/adaptive-idle/run-screen.sh
python3 target/finish-line/adaptive-idle/analyze_cpu.py
python3 target/finish-line/channel-tail/analyze.py target/finish-line/adaptive-idle/benchmark
```

The planned screen has four balanced pairs for two burst-CPU cases, two untimed
shared-channel cases and one sampled endpoint-tail case. The burst diagnostic
source/contract is the same as the archived fixed-policy control in channel-tail-
c6a2bd0a.tar.gz. Main harness pinning and closed-loop/whole-process limitations
also remain unchanged. Every command, raw result and endpoint host/CPU snapshot
is retained. Own builds/tests do not overlap timing.

The first run stopped when zrail activity appeared before the 100-us burst case.
The immediately preceding round-4 baseline 1-ms case also records zrail in its
after.host observation. Both arms of that pair and the deferral guard are kept
in excluded-build-overlap, not discarded. That complete pair must be rerun before
the four-pair CPU comparison can be reported. Endpoint quiet is not proof of
exclusive access to the physical host or absence of all intervening activity.

The complete 40-process screen, after replacing the separately retained two-run
overlap pair, does not qualify the policy. Shared MPMC 4c8/4c64 cycles fall 36.53%/
31.86%; sampled 4c8 cycles fall 42.07%, with lower endpoint medians. However,
median-across-process receive/send p99.9 worsen from 31.52/35.36 us to 46.98/46.89 us.
The individual tails vary widely; this is not a trace establishing their cause.

Burst whole-process CPU rises 3.01% at 1-ms gaps and 26.10% at 100-us gaps. The
100-us cycles/instructions rise only 5.28%/0.77%, respectively. Do not ascribe the
entire CPU-time increase to additional instructions or extend this screen into a
platform-independent cause claim. All unexcluded endpoint host observations are
free of the guarded build processes, but physical-host interference is unproven.

This candidate is shelved, not accepted. The policy does not change a shared atomic
protocol; exhaustive owner-local state histories are targeted coverage, not proof
of full wake/sleep/lifecycle composition. Final canonical and soak qualification
would not override failed performance/tail acceptance and were not run for it.

After shelving the candidate in stash 997c3299edc645d947202aeea64d9cdc996dfe32,
the exact qualified baseline source 30bb4869 was restored. All 11 canonical gates
pass again before the evidence-only commit, under receipt
/root/.cache/zcheck/run-1788649966-389538660-2506468/receipt.json.
The full receipt/log directory and restored source manifest are preserved in
baseline-checkpoint. This canonical receipt covers the restored baseline, NOT the
adaptive candidate. The candidate's Rust files and lock are absent from the commit.
