"""Preserve a stopped measurement without manufacturing a completed panel."""

import hashlib
from pathlib import Path
import subprocess
import tarfile
import tempfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
assert (OUT / 'resumed-default2-1-local-1000.before.guard').read_text().strip() == '3195527'
assert not list(OUT.glob('*.result.json'))
paths = sorted(path for path in OUT.iterdir() if path.is_file() and not path.name.endswith('-binary')
               and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n')
destination = ROOT / 'benchmarks/evidence/mutex-final-guard-f0ce5246.tar.gz'
with tarfile.open(destination, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=path.name, recursive=False)
verify = Path(tempfile.mkdtemp(prefix='mutex-final-guard-verify.', dir=ROOT / 'target/finish-line'))
with tarfile.open(destination) as archive:
    members = archive.getmembers()
    assert all(member.isfile() and Path(member.name).name == member.name for member in members)
    archive.extractall(verify, members=members)
subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=verify, check=True)
print('archive', destination, 'sha256', hashlib.sha256(destination.read_bytes()).hexdigest())
print('verified', len(paths), 'files', verify)
