| Case | Baseline ns/op | Repair ns/op | Cycles change | Instructions change |
| --- | ---: | ---: | ---: | ---: |
| mutex1c8 | 196.31 | 205.93 | +3.07% | +10.34% |
| park1c8 | 120.29 | 137.40 | +12.17% | +13.31% |
| spawn1000 | 444.83 | 437.91 | -1.83% | -6.66% |
| spawn10000 | 323.55 | 337.47 | +3.75% | +2.27% |
| yield4 | 14.19 | 15.32 | +5.53% | +0.03% |
Validated 40 guarded processes; raw process samples in cost2-analysis.json
