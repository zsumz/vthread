"""Default-build correctness-repair cost screen; reuse the pristine control capture."""

import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
CONTROL = ROOT / 'target/finish-line/native-control.R84U9h'
spec = importlib.util.spec_from_file_location('control', CONTROL / 'control.py')
control = importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
control.OUT = OUT
evidence = control.evidence
CASES = (
    ('park1c8', '7', ['park', '10000', '1', '8', '7', '--pin-carriers']),
    ('mutex1c8', '7', ['mutex', '2000', '1', '8', '7', '--pin-carriers']),
    *control.CASES,
    ('spawn-spare', '0-3', ['spawn', '4', '1000', '63', '--max-vthreads', '65536']),
)
BINARY = {
    'A': CONTROL / 'baseline-benchmark',
    'B': OUT / 'candidate-benchmark',
}


def prepare():
    assert not BINARY['B'].exists(), 'never overwrite measured binaries'
    shutil.copy2(control.BUILD / 'release/vthread-benchmarks', BINARY['B'])
    manifest = evidence.metadata('default native release; paused-publication progress repair cost; no handoff profiling')
    manifest['binaries'] = {name: evidence.digest(path) for name, path in BINARY.items()}
    manifest['baseline_source'] = json.loads((CONTROL / 'source.json').read_text())
    manifest['features'] = 'default'
    manifest['build_command'] = 'CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI cargo build --locked --release --manifest-path benchmarks/Cargo.toml'
    with (OUT / 'benchmark-source.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)


def run(cohort, labels):
    manifest = json.loads((OUT / 'benchmark-source.json').read_text())
    assert manifest['source_sha256'] == evidence.source_digest()
    assert manifest['binaries'] == {name: evidence.digest(path) for name, path in BINARY.items()}
    cases = [case for case in CASES if not labels or case[0] in labels]
    assert not labels or set(labels) == {case[0] for case in cases}
    for label, mask, arguments in cases:
        for round_number, order in enumerate(('AB', 'BA', 'BA', 'AB'), 1):
            for arm in order:
                prefix = f'{cohort}-{round_number}-{label}-{arm}'
                assert not (OUT / f'{prefix}.command.json').exists(), 'never overwrite a process run'
                control.observe(prefix, 'before')
                command = ['timeout', '120s', 'perf', 'stat', '-x,', '-e',
                           'task-clock,cycles,instructions,context-switches,cpu-migrations',
                           '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', mask,
                           str(BINARY[arm]), 'vthread', *arguments]
                with (OUT / f'{prefix}.command.json').open('x') as stream:
                    json.dump(command, stream)
                with (OUT / f'{prefix}.log').open('x') as stream:
                    result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
                control.observe(prefix, 'after')
                assert result.returncode == 0, (prefix, result.returncode)
                print(f'completed {prefix}', flush=True)
    assert manifest['source_sha256'] == evidence.source_digest()
    print('completed balanced baseline/candidate process runs; no May comparison', flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    else:
        run(sys.argv[1], sys.argv[2:])
