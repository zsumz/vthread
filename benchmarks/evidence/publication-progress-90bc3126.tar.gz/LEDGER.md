# Native paused-publication progress evidence

Base commit: 060ba6c86488bcaa0cab369a9429a04722be5c35.
Frozen source: 90bc31261224939e4e1f15fbecd09ca29784d348ce2175dbe901a6f22541511d.
`candidate.patch` includes every new/changed runtime/model file, the reviewed
inventory-only lock refresh, and the report as captured before this bundle link.
Apply it to the base commit in a separate checkout. Markdown archive links/index
added after packaging do not change the source digest used by scripts/evidence.py.

## Correctness

- `old-runtime-progress.log`: two ordered old-runtime failures; matching fixture
  delta is `ordered-progress-negative.patch`.
- `old-runtime-cleanup.log`: four old-runtime cleanup failures; both tracked and
  new fixture sources are preserved in the ordered-cleanup patches. The earlier
  ambiguous-Result compile failure is separate and is not negative-control proof.
- Targeted dispatch, cleanup, sleeping owner, shutdown/fault and original-hub
  rebinding logs preserve intermediate and final passing tests.
- `native-missing-completion.patch` deliberately omits the completion signal.
  Its native sleeping-owner failure is in `native-missing-completion-negative.log`.
  `native-completion-restored.log` passes after the identical good implementation
  (`wait-hub-completion-good.rs`) was restored and compared byte-for-byte.
- `production-model-final.log`: 17 passing tests with production wait word,
  publication/retirement and MPSC queue code. Earlier fixture/compiler/coverage
  failures remain separate. Two-route/reuse coverage is 54/23 modeled schedules.
  The Signal adapter's SC fences and the factored losing-selector assumption are
  explicit limits; this is not an exhaustive native runtime/OS proof.
- `canonical/`: all 14 zcheck gates passed with repository state preserved,
  including all-features, native default debug and native default release.
- `replay.sh`: exact native replay and soak commands. Thirty repetitions/profile
  of 15 kernel and four owner/protocol tests pass on one CPU: 1,140 executions in
  120 processes. No randomized schedule coverage is inferred from repetition.
- Two sequential default optimized 60-second soaks, one/four carriers and 64
  tasks/batch, complete all 778,182 lifetimes with balanced parks/wakes, exact mutex
  updates, drained services and checked shutdown. Not ten-million release burn-in.
- `benchmark-tests.log`: 47 default harness tests pass.

## Default-build cost, not optimization acceptance

`benchmark-source.json` records actual source and executable identities and the
exact build command. Binaries are represented by hashes, not shipped in this
archive. `control.py` and `control-source.json` preserve the pristine baseline
capture helper/manifest used by compare.py; replay paths must be adapted to the
new checkout and verified binaries. Each measured invocation has a command JSON,
perf CSV, full output and before/after host/CPU/build-guard observations.

- Cohort 1: 74 invocations completed. The final baseline spare-channel process
  caught cargo/clippy at its after-guard. Exclude that pair. This whole preliminary
  cohort is preserved but not pooled into the report.
- Cohort 2: case-sized AB/BA/BA/AB groups. Forty invocations complete the first five
  cases (local park/mutex, yield, lifecycle 1k/10k). Three additional park invocations
  precede the second caught build; the incomplete park group is excluded.
- Cohort 3: all 64 invocations complete the eight remaining case groups.
- The report therefore uses 104 selected invocations, four pairs per 13 cases.
  `cost2-analysis.json` and `cost3-analysis.json` retain all selected per-process
  metrics, paired changes and medians; the companion Markdown tables summarize.
  `analyze.py` requires four complete clean pairs for each explicitly selected case.
- No candidate code changed between cohorts. Neither binary enables handoff timing
  or profiling. No own build, test or soak overlapped measured invocations. Endpoint
  host guards cannot prove continuous exclusivity, physical topology or frequency.

Replay the analyses with:

```
python3 analyze.py cost2 park1c8 mutex1c8 yield4 spawn1000 spawn10000
python3 analyze.py cost3
```

They deliberately refuse overwriting existing analysis JSON; use a fresh extraction
with output paths adjusted if recomputing. Ns/op is throughput-derived. Perf totals
include setup/warm-up/teardown. The repair has a repeatable park cycle cost and no
qualified tail improvement; it is retained for demonstrated recipient progress.
No engine, affinity, fairness, checkpoint, mutex ownership, polling, channel or
readiness policy optimization is hidden in this patch. The May panel is historical.

Six loaded findings and architecture/sanitizer/large-population/offered-load release
qualification remain open. Subsequent quiet passes do not close those findings.
