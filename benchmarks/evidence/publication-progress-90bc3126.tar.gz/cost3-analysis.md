| Case | Baseline ns/op | Repair ns/op | Cycles change | Instructions change |
| --- | ---: | ---: | ---: | ---: |
| channel-spare | 17651.36 | 20827.01 | +8.46% | +6.96% |
| channel1c8 | 429.46 | 444.92 | +3.94% | +14.56% |
| channel4c64 | 1451.78 | 1462.99 | +1.91% | +11.18% |
| channel4c8 | 1414.39 | 1485.63 | -0.09% | +12.03% |
| mutex4 | 428.76 | 461.94 | -9.52% | +1.69% |
| park4 | 107.00 | 117.07 | +15.55% | +12.51% |
| spawn-spare | 1679.14 | 1617.53 | +10.09% | -2.08% |
| wake4 | 83.64 | 94.13 | +9.03% | +9.14% |
Validated 64 guarded processes; raw process samples in cost3-analysis.json
