#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR=/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI
replay_out=target/finish-line/native-deferral.jBIgJM

for profile in debug release; do
    flags=()
    if [[ "$profile" == release ]]; then flags=(--release); fi
    cargo test --locked -p vthread --lib --no-run "${flags[@]}" --message-format=json > "$replay_out/$profile-artifacts.jsonl" 2> "$replay_out/$profile-replay-build.log"
    test_binary=$(jq -r 'select(.reason == "compiler-artifact" and .target.name == "vthread" and .profile.test and .executable != null) | .executable' "$replay_out/$profile-artifacts.jsonl")
    test -x "$test_binary"
    sha256sum "$test_binary" > "$replay_out/$profile-test-binary.sha256"
    for ((iteration=1; iteration<=30; iteration++)); do
        timeout 45s taskset -c 7 "$test_binary" kernel_publication --test-threads=1 > "$replay_out/replay-$profile-$iteration-kernel.log" 2>&1
        timeout 45s taskset -c 7 "$test_binary" wait::wait_owner --test-threads=1 > "$replay_out/replay-$profile-$iteration-owner.log" 2>&1
    done
done

cargo build --locked --release -p vthread-lab --bin vthread-lab > "$replay_out/lab-build.log" 2>&1
sha256sum "$CARGO_TARGET_DIR/release/vthread-lab" > "$replay_out/lab-binary.sha256"
for carriers in 1 4; do
    timeout 100s "$CARGO_TARGET_DIR/release/vthread-lab" soak 60 "$carriers" 64 > "$replay_out/soak-$carriers.log" 2>&1
done
