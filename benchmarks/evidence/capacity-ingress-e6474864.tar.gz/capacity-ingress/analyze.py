"""Four-way diagnostic comparison; no sample exclusion or headline claims."""

import json
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parent
ENGINES = ("baseline", "observer", "repair", "combined")
CASES = ("spawn10000", "spawn-cap65536", "park-cap65536")


def record(engine, case, round_number):
    path = ROOT / f"profile-{round_number}-{engine}-{case}.log"
    result = {"log": path.name, "engine": engine, "case": case, "round": round_number}
    profiles = []
    for line in path.read_text().splitlines():
        data = dict(re.findall(r"(\w+)=(\[[^\]]*\]|\S+)", line))
        if "ns_per_operation" in data:
            result["ns_per_operation"] = float(data["ns_per_operation"])
        if data.get("phase") in ("scheduler-admission", "scheduler-idle"):
            profiles.append(data)
    assert len(profiles) == 8, f"incomplete final profile: {path}"
    totals, histogram = {}, [0] * 8
    for data in profiles:
        if "batch_histogram" in data:
            histogram = [a + b for a, b in zip(histogram, json.loads(data["batch_histogram"]))]
        for key, value in data.items():
            if key in ("engine", "phase", "carrier", "batch_histogram", "maximum_idle_dispatches"):
                continue
            totals[key] = totals.get(key, 0) + int(value)
    totals["batch_histogram"] = histogram
    totals["mean_nonempty_batch"] = totals["remote_packets"] / sum(histogram[1:])
    totals["probes_per_admitted_task"] = totals["poll_probes"] / totals["remote_packets"]
    totals["dispatches_per_idle_entry"] = totals["idle_dispatches"] / totals["idle_entries"]
    result["profile"] = totals
    result["perf"] = {}
    for line in path.with_suffix(".csv").read_text().splitlines():
        columns = line.split(",")
        if len(columns) >= 3 and columns[0].isdigit():
            result["perf"][columns[2]] = int(columns[0])
    assert "cycles" in result["perf"] and "instructions" in result["perf"]
    return result


records = [record(engine, case, round_number) for case in CASES
           for round_number in range(1, 5) for engine in ENGINES]
summary = {}
for case in CASES:
    summary[case] = {}
    for engine in ENGINES:
        rows = [row for row in records if row["case"] == case and row["engine"] == engine]
        metrics = {"ns_per_operation": [row["ns_per_operation"] for row in rows]}
        for key in ("cycles", "instructions", "context-switches", "cpu-migrations"):
            metrics[key] = [row["perf"][key] for row in rows]
        for key in ("mean_nonempty_batch", "probes_per_admitted_task", "empty_idle_entries",
                    "early_work_returns", "wait_calls", "dispatches_per_idle_entry"):
            metrics[key] = [row["profile"][key] for row in rows]
        summary[case][engine] = {key: {"values": values, "median": statistics.median(values)}
                                for key, values in metrics.items()}
    summary[case]["cycle_changes_percent"] = {
        f"{candidate}_vs_{baseline}": 100 * (
            summary[case][candidate]["cycles"]["median"] /
            summary[case][baseline]["cycles"]["median"] - 1)
        for candidate, baseline in (("observer", "baseline"), ("combined", "repair"),
                                    ("combined", "observer"), ("repair", "baseline"))
    }

print(json.dumps({"headline": False, "processes_per_arm_case": 4,
                  "summary": summary, "raw": records}, indent=2))
