#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/capacity-ingress

run_case() {
    local label=$1
    shift
    for round in 1 2 3 4; do
        local engines
        case $round in
            1) engines='baseline observer repair combined' ;;
            2) engines='observer combined baseline repair' ;;
            3) engines='repair baseline combined observer' ;;
            4) engines='combined repair observer baseline' ;;
        esac
        for engine in $engines; do
            local binary
            case $engine in
                baseline) binary=target/finish-line/scheduler-profile/profile-benchmark ;;
                observer) binary=target/finish-line/capacity-pacing/observer-profile-benchmark ;;
                repair) binary=target/finish-line/ingress-visibility/profile-benchmark ;;
                combined) binary=$evidence_dir/profile-benchmark ;;
            esac
            local prefix=$evidence_dir/profile-$round-$engine-$label
            if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
                printf 'profile deferred: other build activity before %s\n' "$prefix" >&2
                return 125
            fi
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            printf '%q ' timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c 0-3 "$binary" vthread "$@" >> "$evidence_dir/profile-commands.log"
            printf '\n' >> "$evidence_dir/profile-commands.log"
            timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c 0-3 "$binary" vthread "$@" > "$prefix.log" 2>&1
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'profile round=%s engine=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

run_case spawn10000 spawn 4 10000 501
run_case spawn-cap65536 spawn 4 10000 101 --max-vthreads 65536
run_case park-cap65536 park 10000 4 64 5 --max-vthreads 65536
