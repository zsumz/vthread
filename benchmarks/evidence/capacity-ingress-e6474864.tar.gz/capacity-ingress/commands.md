# Four-way scan and ingress attribution

The combined candidate applies observer.patch to a4b5a96740ae426de4fbff43c00e9bf385c03472.
source.json identifies it; the other three source manifests and binaries.sha256
identify the original, observer-only and ingress-repair diagnostic binaries.
No canonical or final performance acceptance is claimed for this rejected candidate.

```sh
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib kernel_snapshot -- --test-threads=1
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib carrier_ingress -- --test-threads=1
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml --features scheduler-profiling
bash target/finish-line/capacity-ingress/run-profiles.sh
python3 target/finish-line/capacity-ingress/analyze.py
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
perf record -F 199 -e cycles -g -o target/finish-line/capacity-ingress/combined-cycles.data -- taskset -c 0-3 target/finish-line/capacity-ingress/default-benchmark vthread spawn 4 10000 501
perf report --stdio --no-children --percent-limit 1 -i target/finish-line/capacity-ingress/combined-cycles.data
perf annotate --stdio --symbol=std::sys::backtrace::__rust_begin_short_backtrace -i target/finish-line/capacity-ingress/combined-cycles.data
```

run-profiles.sh and profile-commands.log preserve all 48 actual diagnostic commands.
Each of four binary orders places each arm in each position once. Counter builds
observe only the final shutdown snapshot. The 96 start/end host observations caught
no compiler or process above 10% lifetime-average CPU, which is not proof of a
dedicated host. No samples are excluded from analysis.json.

The separate cycle sample uses an uninstrumented executable identified in
default-binaries.sha256. It is attribution, not an independent accepted timing panel.
Only flat samples and assembly are used; its incomplete call chains do not establish
caller attribution. The initial vthread::carrier::drive annotation found no matching
sampled symbol because that loop was inlined; the carrier-entry symbol contains it.

Executables are omitted from the archive. Source patches, raw reports, perf data,
sample annotation, checks, commands and binary hashes are preserved.
