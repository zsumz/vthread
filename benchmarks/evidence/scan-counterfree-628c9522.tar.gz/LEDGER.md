# Scan-only counter-free recovery: stopped at the early screen

Base `2ee55ed` / retained source e344a60e. Candidate source 628c9522.
The exact production scan-only B expressions are restored; polling and publication
ordering are unchanged. The candidate is preserved at stash object
`baa7aa284043eddda593402a3f1c154190dcefad`, not promoted to the perf branch.

- Baseline default build/benchmark tests/clippy pass and its binary is identical
  to the previous quiet-window binary. Candidate passes the same build steps.
- Ordered snapshot negative control: three intended failures, one positive remote
  refresh control passes. Candidate: all four pass. No full candidate canonical
  gate is claimed because the optional candidate fails its first timing screen.
- First analysis-test invocation exposed an import-path collision with the reused
  archived parser. Corrected before any performance process. Seven tests pass.
- All 32 predeclared screen processes complete with clear endpoint build guards:
  16 bare, 16 perf; default and individually pinned placement remain separate.
- Both bare cells cross the predeclared gross-regression stop. No protected/scaling
  confirmation panel is run and no unfavorable process is replaced.
- Sixteen separate scheduler-profiling processes complete and validate their task,
  batch and idle accounting. These are attribution, never acceptance timings.
- Post-exit resource accounting includes timeout/perf wrappers; RSS is a process-
  tree high-water observation, not a measured runtime-only footprint.
- Existing ARM64/sanitizer/population/release obligations remain open. No May
  result or lost-wake finding is inferred from these lifecycle controls.

The bundle includes complete source bytes for both arms, commands, binary hashes,
raw attempts and scripts. Historical parser dependencies and its sample fixture
are included under replay-dependencies; adjust the recorded absolute paths when
replaying in another checkout. Do not run diagnostics concurrently with acceptance.
