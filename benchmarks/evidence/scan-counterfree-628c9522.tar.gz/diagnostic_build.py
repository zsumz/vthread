"""Existing scheduler counters only; these executables cannot supply acceptance timings."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

arm = sys.argv[1]
assert arm in ['A', 'B']
manifest = evidence.metadata('scheduler counter attribution only; not performance acceptance')
assert manifest['source_sha256'] == json.loads((OUT / f'{arm}-source.json').read_text())['source_sha256']
command = ['cargo', 'build', '--locked', '--release', '--manifest-path', 'benchmarks/Cargo.toml',
           '--features', 'scheduler-profiling']
environment = dict(os.environ, CARGO_TARGET_DIR=str(BUILD), CARGO_INCREMENTAL='0')
with (OUT / f'{arm}-diagnostic-build.command.json').open('x') as stream:
    json.dump(dict(command=command, source=manifest), stream, indent=2)
with (OUT / f'{arm}-diagnostic-build.log').open('x') as stream:
    result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT, timeout=600)
with (OUT / f'{arm}-diagnostic-build.result.json').open('x') as stream:
    json.dump(dict(returncode=result.returncode), stream)
assert result.returncode == 0
assert manifest['source_sha256'] == evidence.source_digest()
binary = OUT / f'benchmark-{arm}-diagnostic'
assert not binary.exists()
shutil.copy2(BUILD / 'release/vthread-benchmarks', binary)
manifest.update(binary_sha256=evidence.digest(binary), features='scheduler-profiling', headline=False)
with (OUT / f'{arm}-diagnostic-source.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
print('frozen diagnostic', arm, manifest['binary_sha256'], flush=True)
