"""Small scheduler-counter attribution: never promote based on these timings."""

import ast
import json
import os
import re
import statistics
import subprocess
import time

from acceptance import fields, parse
from panel import OUT, ROOT, evidence, observe, screen_plan


def main():
    # Four paired default and four paired pinned processes; no perf collector.
    jobs = [dict(job, prefix=job['prefix'].replace('screen-', 'diagnostic-'))
            for job in screen_plan() if job['collector'] == 'bare']
    manifests = {arm: json.loads((OUT / f'{arm}-diagnostic-source.json').read_text()) for arm in ['A', 'B']}
    for arm, manifest in manifests.items():
        assert manifest['features'] == 'scheduler-profiling' and not manifest['headline']
        assert manifest['binary_sha256'] == evidence.digest(OUT / f'benchmark-{arm}-diagnostic')
    with (OUT / 'diagnostic-plan.json').open('x') as stream:
        json.dump(jobs, stream, indent=2)
    groups = {}
    for index, job in enumerate(jobs):
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '180s', 'taskset', '-c', job['case']['mask'],
                   str(OUT / f'benchmark-{job["arm"]}-diagnostic'), 'vthread', *job['case']['args']]
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, started_unix=time.time(), job=job,
                           source=manifests[job['arm']], headline=False), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            process = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            _, status, usage = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(dict(returncode=process.returncode, finished_unix=time.time(),
                           cpu_seconds=usage.ru_utime + usage.ru_stime, headline=False), stream, indent=2)
        observe(prefix, 'after')
        assert process.returncode == 0, prefix
        text = (OUT / f'{prefix}.log').read_text()
        row = parse(text, job)
        totals, bins = {}, [0] * 8
        for phase in ['scheduler-admission', 'scheduler-idle']:
            lines = [line for line in text.splitlines() if f'phase={phase} ' in line]
            assert len(lines) == 4
            for line in lines:
                for key, value in fields(line).items():
                    if value.isdigit() and key != 'carrier':
                        totals[key] = totals.get(key, 0) + int(value)
                if phase == 'scheduler-admission':
                    histogram = ast.literal_eval(re.search(r'batch_histogram=(\[.*\])', line)[1])
                    assert len(histogram) == 8
                    bins = [left + right for left, right in zip(bins, histogram)]
        assert totals['remote_packets'] == row['process_operations'] == 502000
        assert totals['receive_calls'] == totals['window_deferrals'] + sum(bins)
        totals['packets_per_nonempty_batch'] = totals['remote_packets'] / sum(bins[1:])
        totals['batch_histogram'] = bins
        totals['instrumented_ns_per_task'] = row['ns_per_operation']
        totals['cpu_seconds'] = usage.ru_utime + usage.ru_stime
        key = f'{job["case"]["name"]}-{job["arm"]}'
        groups.setdefault(key, []).append(totals)
        print(f'{index + 1}/{len(jobs)} {prefix}: batches={sum(bins[1:])}, '
              f'packets/batch={totals["packets_per_nonempty_batch"]:.2f}, waits={totals["wait_calls"]}', flush=True)
    report = {key: dict(processes=rows, median={field: statistics.median(row[field] for row in rows)
                                               for field in rows[0] if field != 'batch_histogram'})
              for key, rows in groups.items()}
    with (OUT / 'diagnostic-analysis.json').open('x') as stream:
        json.dump(report, stream, indent=2)
    print('16 diagnostic processes completed; no acceptance timings', flush=True)


if __name__ == '__main__':
    main()
