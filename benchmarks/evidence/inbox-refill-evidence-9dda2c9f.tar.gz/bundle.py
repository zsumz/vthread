"""Archive inbox pre-cleanup evidence without waiving historical findings."""

import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

manifest = evidence.metadata('pre-cleanup inbox evidence; production runtime unchanged')
assert manifest['source_sha256'] == json.loads(
    (OUT / 'canonical.command.json').read_text())['source']['source_sha256']
assert json.loads((OUT / 'canonical.result.json').read_text())['returncode'] == 0
for profile in ('debug', 'release'):
    for index in range(20):
        assert json.loads((OUT / f'repeat-{profile}-{index:02}.result.json').read_text())['returncode'] == 0
for index in range(4):
    assert json.loads((OUT / f'loaded-{index:02}.result.json').read_text())['returncode'] == 0
with (OUT / 'source.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
binary_paths = sorted({name for log in (OUT / 'canonical').glob('*.log')
    for name in re.findall(r'Running (?:unittests|tests) \S+ \(([^)\s]+)\)', log.read_text())})
with (OUT / 'canonical-binaries.json').open('x') as stream:
    json.dump([{'path': name, 'sha256': evidence.digest(Path(name))}
               for name in binary_paths], stream, indent=2)
with (OUT / 'candidate.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--',
        'crates/vthread/src/carrier.rs', 'crates/vthread/src/carrier_refill_test.rs',
        'crates/vthread/src/carrier_test.rs', 'zrail.lock'], cwd=ROOT))
archive_path = ROOT / f'benchmarks/evidence/inbox-refill-evidence-{manifest["source_sha256"][:8]}.tar.gz'
paths = sorted(path for path in OUT.rglob('*') if path.is_file()
               and '__pycache__' not in path.parts and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(archive_path, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
verify = Path(tempfile.mkdtemp(prefix='inbox-refill-evidence-verify.', dir=ROOT / 'target/finish-line'))
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    assert all(member.isfile() and not Path(member.name).is_absolute()
               and '..' not in Path(member.name).parts for member in members)
    archive.extractall(verify, members=members)
with (verify / 'verification.log').open('x') as stream:
    subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=verify, stdout=stream,
                   stderr=subprocess.STDOUT, check=True)
print('archive', archive_path)
print('sha256', evidence.digest(archive_path))
print('verified', len(paths), 'internal hashes', verify)
