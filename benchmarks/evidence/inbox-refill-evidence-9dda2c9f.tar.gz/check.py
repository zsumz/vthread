"""Capture continuous-inbox evidence before test cleanup requests stop."""

import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
ENV = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_TARGET_DIR='/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def run(label, command, expected=0):
    with (OUT / f'{label}.command.json').open('x') as stream:
        json.dump({'argv': command, 'environment': {key: ENV[key] for key in ('CARGO_INCREMENTAL', 'CARGO_TARGET_DIR')},
                   'source': evidence.metadata(label)}, stream, indent=2)
    with (OUT / f'{label}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    with (OUT / f'{label}.result.json').open('x') as stream:
        json.dump({'returncode': result.returncode, 'expected': expected}, stream)
    print(label, result.returncode, flush=True)
    assert result.returncode == expected


mode = sys.argv[1]
if mode in ('initial', 'negative-notify', 'negative-order', 'restored'):
    run(mode, ['cargo', 'test', '--locked', '-p', 'vthread', 'carrier_refill_test', '--', '--nocapture'],
        101 if mode.startswith('negative') else 0)
    log = (OUT / f'{mode}.log').read_text()
    if mode == 'negative-order':
        assert 'progress evidence captured after cleanup' in log
    elif mode == 'negative-notify':
        assert 'refill-primary admission=Err(Timeout) drained=None' in log
        assert 'started: 0, body_returns: 0, completed_credits: 0' in log
        assert 'refill-before-stop' in log and 'accepting=true' in log
        assert 'late_admission=Some(Ok(Err(RuntimeStopped)))' in log
    else:
        assert 'test result: ok. 1 passed;' in log
        assert 'refill-primary admission=Ok(Ok(())) drained=Some(Ok(true))' in log
elif mode == 'canonical':
    run(mode, ['zcheck', 'run', 'check', '--logs-dir', str(OUT / mode),
               '--receipt', str(OUT / f'{mode}-receipt.json')])
elif mode == 'repeat':
    profile = sys.argv[2]
    log = OUT / f'canonical/{"0007-test-native.log" if profile == "debug" else "0008-test-native-release.log"}'
    binaries = re.findall(r'Running unittests src/lib.rs \(([^)\s]*/deps/vthread-[0-9a-f]+)\)', log.read_text())
    assert len(binaries) == 1, binaries
    binary = binaries[0]
    with (OUT / f'repeat-{profile}-binary.json').open('x') as stream:
        json.dump({'path': binary, 'sha256': evidence.digest(Path(binary))}, stream)
    for index in range(20):
        label = f'repeat-{profile}-{index:02}'
        run(label, ['taskset', '-c', '6', binary, 'carrier_refill_test', '--nocapture'])
        log = (OUT / f'{label}.log').read_text()
        assert 'test result: ok. 1 passed;' in log
        assert 'started: 4096, body_returns: 4096, completed_credits: 4096, active: 0' in log
elif mode == 'loaded':
    log = OUT / 'canonical/0007-test-native.log'
    binaries = re.findall(r'Running unittests src/lib.rs \(([^)\s]*/deps/vthread-[0-9a-f]+)\)', log.read_text())
    assert len(binaries) == 1, binaries
    binary = binaries[0]
    with (OUT / 'loaded-binary.json').open('x') as stream:
        json.dump({'path': binary, 'sha256': evidence.digest(Path(binary))}, stream)
    for index in range(4):
        label = f'loaded-{index:02}'
        run(label, ['taskset', '-c', '0-3', binary, '--test-threads=32', '--nocapture'])
        assert '545 passed; 0 failed; 2 ignored;' in (OUT / f'{label}.log').read_text()
else:
    raise SystemExit(f'unknown mode {mode}')
