# Inbox refill: preserve the primary observation before cleanup

Base 2b21d0f. This is a test/evidence repair, not an inbox, scheduling, polling,
capacity or notification change. The original 4,096 tasks and default runtime
configuration remain: 65,536 task capacity and 256 queued remote starts.
The five-second admission watchdog is unchanged; completion-credit drainage now
also has an explicit five-second failure bound.

The historical loaded-2.log captures admission Timeout followed by a producer
panic after test cleanup stops admission. It does not record the pre-cleanup
accepted/queued/started/completed counts. The historical cause remains unresolved
and continues to block release; neither passing reruns nor this fixture change
can reconstruct its missing state.

## What is observed

The real carrier first registers its signal wait, ordering producer startup after
the sleeping-owner boundary. The bounded producer records accepted submissions;
each body records start and end-of-body markers. These are explicitly distinct
from completed scope credits. The final-task body signal is no longer treated as
proof that every task was reclaimed or every completion credit was published.

Before any test cleanup stop, the observer records admission outcome, bounded
drain outcome, accepted begin/end, queued starts, started bodies, end-of-body
markers, completed scope credits, active tasks, scope failures, carrier snapshots,
signal epoch and waiter count. Concurrent diagnostics describe an observation
window, not a single atomic snapshot; published carrier counters can lag.

Only then does cleanup request stop. Producer/carrier panic reports and any late
RuntimeStopped admission result are retained separately, never substituted for
the original timeout. Scoped thread guards request stop on observer failure before
implicit joins. Successful runs also verify zero cleanup failures/aborts/panics
and actual carrier reclamation.

## Attempts and negative controls

- initial: all 4,096 bodies and completion credits observed before cleanup.
- negative-notify: suppress Inbox::push's empty-to-nonempty notification. Exact
  pre-cleanup evidence is accepted=queued=active=256, started/body_returns/credits=0,
  accepting=true, epoch=0, one registered signal waiter. Primary admission is
  Timeout. Only after cleanup does the producer return RuntimeStopped. The test
  fails as intended and all native threads recover.
- Add final cleanup/reclamation assertions; keep the earlier source separately
  as ordered-source.txt and this final variant as final-source.txt.
- negative-order: deliberately drop the cleanup guard before observing progress;
  the capture guard rejects evidence after cleanup. The native threads recover.
- restored: mutations removed, production inbox diff empty, test byte-compared
  with final-source.txt; the complete positive regression passes.
- zrail: one test-file inventory change, no grants/revokes/debt.
- canonical/repeat/loaded: retain every command, full source/binary identity,
  log and outcome. Expected-failure controls are distinct from positive runs.

All fourteen canonical gates pass (run-1788700201-426769387-3127326), including
545 default-native tests in debug and release and 574 all-feature runtime tests;
two intentional ignored tests remain separate. Twenty default-native debug and
twenty release targeted invocations pass on CPU 6 (163,840 task lifetimes).
All four further default-native full-library runs pass using 32 test threads on
CPU mask 0-3, matching the earlier oversubscribed setting: 2,180 runtime test
executions, each refill observing all 4,096 completion credits before cleanup.
These are correctness stress, not performance acceptance, native ARM64, sanitizer
or the large simultaneous-population lifetime qualification.

Even a passing loaded panel does not close the missing historical stall evidence.
It establishes current execution coverage; it is not permission to relabel an
unexplained historical failure as host noise or a proved production defect.
