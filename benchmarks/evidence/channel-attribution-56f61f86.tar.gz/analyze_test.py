"""Negative controls for counter eligibility and sample parsing."""

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import analyze
import profiles


class EvidenceTests(unittest.TestCase):
    def fixture(self, root):
        for stage in ('before', 'after'):
            (root / f'case.{stage}.guard').write_text('')
        (root / 'case.result.json').write_text(json.dumps({'returncode': 0}))
        (root / 'case.log').write_text('ns_per_operation=10.5\n')
        (root / 'case.csv').write_text('\n'.join(
            f'100,,{metric},1000,100.00' for metric in analyze.METRICS))

    def test_rejects_failed_contaminated_or_multiplexed_counter_process(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.object(analyze, 'OUT', root):
                self.fixture(root)
                self.assertEqual(analyze.sample('case')['cycles'], 100)
                (root / 'case.result.json').write_text(json.dumps({'returncode': 124}))
                with self.assertRaises(AssertionError):
                    analyze.sample('case')
                self.fixture(root)
                (root / 'case.after.guard').write_text('123\n')
                with self.assertRaises(AssertionError):
                    analyze.sample('case')
                self.fixture(root)
                (root / 'case.csv').write_text('100,,cycles,1000,50.0\n')
                with self.assertRaises(AssertionError):
                    analyze.sample('case')

    def test_five_events_are_supported_without_inventing_branch_counts(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.object(analyze, 'OUT', root):
                self.fixture(root)
                (root / 'case.csv').write_text('\n'.join(
                    f'100,,{metric},1000,100.00' for metric in analyze.METRICS[:2]
                    + analyze.METRICS[4:]))
                result = analyze.sample('case')
                self.assertNotIn('branches', result)
                self.assertEqual(result['instructions'], 100)

    def test_sample_parser_preserves_period_not_rounded_share(self):
        row = profiles.ROW.match('     0.00%  2  92  [.] clock_gettime       -      -    ')
        self.assertEqual(row.groups(), ('0.00', '2', '92', '.', 'clock_gettime'))
        self.assertIsNone(profiles.ROW.match('# Total Lost Samples: 1'))


if __name__ == '__main__':
    unittest.main()
