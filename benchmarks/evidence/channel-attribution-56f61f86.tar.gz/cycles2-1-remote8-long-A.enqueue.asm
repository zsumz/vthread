 Percent |	Source code & Disassembly of baseline-benchmark for cycles:u (43 samples, percent: global period)
-----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3      Disassembly of section .text:
         :
         : 5      0000000000175bf0 <vthread::channel::wait::Ticket<T>::enqueue>:
         : 6      vthread::channel::wait::Ticket<T>::enqueue:
    0.00 :   175bf0: push   %r15
    0.00 :   175bf2: push   %r14
    0.00 :   175bf4: push   %r12
    0.00 :   175bf6: push   %rbx
    0.00 :   175bf7: sub    $0x18,%rsp
    0.00 :   175bfb: mov    %rdi,%rbx
    0.00 :   175bfe: cmpb   $0x0,0x19(%rsi)
    0.00 :   175c02: jne    175cbf <vthread::channel::wait::Ticket<T>::enqueue+0xcf>
    0.00 :   175c08: mov    %rcx,%r14
    0.00 :   175c0b: mov    %rsi,%r15
    0.00 :   175c0e: mov    0x30(%rcx),%rax
    0.00 :   175c12: mov    %rax,(%rsp)
    0.00 :   175c16: cmpb   $0x0,(%rsi)
    0.00 :   175c19: je     175cd8 <vthread::channel::wait::Ticket<T>::enqueue+0xe8>
    0.00 :   175c1f: mov    0x8(%r15),%rcx
    0.00 :   175c23: mov    %rcx,0x8(%rsp)
    0.00 :   175c28: cmp    %rcx,%rax
    0.00 :   175c2b: jne    175cf1 <vthread::channel::wait::Ticket<T>::enqueue+0x101>
    0.00 :   175c31: movzbl 0x18(%r15),%ecx
    0.00 :   175c36: shl    $0x5,%ecx
    0.00 :   175c39: mov    0x38(%rcx,%rdx,1),%rax
    0.00 :   175c3e: mov    0x10(%r15),%rsi
    0.00 :   175c42: cmp    0x88(%rsi),%rax
    5.71 :   175c49: jne    175c66 <vthread::channel::wait::Ticket<T>::enqueue+0x76>
    0.00 :   175c4b: movabs $0x8000000000000022,%rcx
    0.00 :   175c55: add    $0xffffffffffffffeb,%rcx
    0.00 :   175c59: mov    %rcx,(%rbx)
    0.00 :   175c5c: mov    %rax,0x8(%rbx)
    0.00 :   175c60: movb   $0x5,0x10(%rbx)
    0.00 :   175c64: jmp    175ccc <vthread::channel::wait::Ticket<T>::enqueue+0xdc>
    0.00 :   175c66: lock incq (%r14)
   94.29 :   175c6a: jle    175d15 <vthread::channel::wait::Ticket<T>::enqueue+0x125>
    0.00 :   175c70: lea    (%rcx,%rdx,1),%r12
    0.00 :   175c74: add    $0x20,%r12
    0.00 :   175c78: mov    %r14,0x10(%rsp)
    0.00 :   175c7d: mov    (%r12),%rcx
    0.00 :   175c81: cmp    %rcx,%rax
    0.00 :   175c84: jne    175c97 <vthread::channel::wait::Ticket<T>::enqueue+0xa7>
    0.00 :   175c86: mov    %r12,%rdi
    0.00 :   175c89: call   170a00 <alloc::collections::vec_deque::VecDeque<T,A>::grow>
    0.00 :   175c8e: mov    (%r12),%rcx
    0.00 :   175c92: mov    0x18(%r12),%rax
    0.00 :   175c97: lea    0x1(%rax),%rdx
    0.00 :   175c9b: mov    %rdx,0x18(%r12)
    0.00 :   175ca0: add    0x10(%r12),%rax
    0.00 :   175ca5: xor    %edx,%edx
    0.00 :   175ca7: cmp    %rcx,%rax
    0.00 :   175caa: cmovae %rcx,%rdx
    0.00 :   175cae: sub    %rdx,%rax
    0.00 :   175cb1: mov    0x8(%r12),%rcx
    0.00 :   175cb6: mov    %r14,(%rcx,%rax,8)
    0.00 :   175cba: movb   $0x1,0x19(%r15)
    0.00 :   175cbf: movabs $0x8000000000000022,%rax
    0.00 :   175cc9: mov    %rax,(%rbx)
    0.00 :   175ccc: add    $0x18,%rsp
    0.00 :   175cd0: pop    %rbx
    0.00 :   175cd1: pop    %r12
    0.00 :   175cd3: pop    %r14
    0.00 :   175cd5: pop    %r15
    0.00 :   175cd7: ret
    0.00 :   175cd8: lea    -0x15423c(%rip),%rdi        # 21aa3 <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058+0x2f2e>
    0.00 :   175cdf: lea    0x19ed2(%rip),%rdx        # 18fbb8 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x1cc8>
    0.00 :   175ce6: mov    $0x15,%esi
    0.00 :   175ceb: call   *0x1b4f7(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   175cf1: lea    -0x154240(%rip),%rcx        # 21ab8 <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058+0x2f43>
    0.00 :   175cf8: lea    0x19ed1(%rip),%r9        # 18fbd0 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x1ce0>
    0.00 :   175cff: mov    %rsp,%rsi
    0.00 :   175d02: lea    0x8(%rsp),%rdx
    0.00 :   175d07: mov    $0x29,%r8d
    0.00 :   175d0d: xor    %edi,%edi
    0.00 :   175d0f: call   *0x1b3ab(%rip)        # 1910c0 <_DYNAMIC+0x300>
    0.00 :   175d15: ud2
    0.00 :   175d17: mov    %rax,%rbx
    0.00 :   175d1a: lock decq (%r14)
    0.00 :   175d1e: jne    175d2b <vthread::channel::wait::Ticket<T>::enqueue+0x13b>
    0.00 :   175d20: lea    0x10(%rsp),%rdi
    0.00 :   175d25: call   *0x1c1d5(%rip)        # 191f00 <_DYNAMIC+0x1140>
    0.00 :   175d2b: mov    %rbx,%rdi
    0.00 :   175d2e: call   186a90 <_Unwind_Resume@plt>
    0.00 :   175d33: call   *0x1b4c7(%rip)        # 191200 <_DYNAMIC+0x440>
