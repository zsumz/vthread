The first generated archive could not run its extraction self-check on this host:
Python 3.11.0rc1 does not support `TarFile.extractall(filter=...)`. The initial,
unverified archive is retained at the task-local packaging directory, and its
hash list is `packaging-initial-SHA256SUMS`. No raw measurement changed.

The corrected packager first validates that every member is a relative regular
file with no parent traversal, then extracts into a fresh directory and verifies
all internal hashes. Only that regenerated, verified archive is committed.
