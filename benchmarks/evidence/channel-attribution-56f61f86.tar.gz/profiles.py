"""Validate sampling quality and retain symbol/assembly evidence, not a new profiler."""

import json
from pathlib import Path
import re
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROW = re.compile(r'^\s*([\d.]+)%\s+(\d+)\s+(\d+)\s+\[([.k])\]\s+(.+?)\s+-\s+-\s*$')
GROUPS = {
    'channel_core': ('vthread::channel::core::',),
    'ticket_enqueue': ('vthread::channel::wait::Ticket<T>::enqueue',),
    'ticket_turn': ('vthread::channel::wait::Ticket<T>::take_turn',),
    'publication': ('NotificationPublication', 'vthread::wait::wait_select::enqueue_selected::'),
    'park_notification': ('vthread::sync::wait::Wait::park_notification',),
    'wait_begin': ('::begin_resident',),
    'wait_finish': ('::finish_slow',),
    'subscription': ('::register_resident',),
    'carrier_loop': ('std::sys::backtrace::__rust_begin_short_backtrace',),
    'kernel': ('vthread::kernel::',),
    'hub': ('vthread::wait_hub::',),
}


def inspect(cohort):
    results = {}
    for report in sorted(OUT.glob(f'{cohort}-*.report')):
        prefix = report.stem
        for stage in ('before', 'after'):
            assert (OUT / f'{prefix}.{stage}.guard').read_text() == ''
        rows = [match.groups() for line in report.read_text().splitlines()
                if (match := ROW.match(line))]
        assert rows, prefix
        total = sum(int(row[2]) for row in rows)
        command = ['perf', 'script', '--show-lost-events', '-D', '-i', str(OUT / f'{prefix}.data')]
        raw = subprocess.run(command, capture_output=True, text=True, check=True)
        transitions = [line for line in raw.stdout.splitlines()
                       if re.search(r'PERF_RECORD_(THROTTLE|UNTHROTTLE|LOST)', line)]
        groups = {label: sum(int(row[2]) for row in rows if any(part in row[4] for part in parts))
                  for label, parts in GROUPS.items()}
        results[prefix] = {
            'samples': sum(int(row[1]) for row in rows), 'period': total,
            'groups_period': groups,
            'groups_percent': {label: 100 * value / total for label, value in groups.items()},
            'throttle': sum('PERF_RECORD_THROTTLE' in line for line in transitions),
            'unthrottle': sum('PERF_RECORD_UNTHROTTLE' in line for line in transitions),
            'lost': sum('PERF_RECORD_LOST' in line for line in transitions),
            'raw_command': command, 'raw_stderr': raw.stderr,
        }
        with (OUT / f'{prefix}.sampling-events').open('x') as stream:
            stream.write('\n'.join(transitions) + '\n')
        print(prefix, 'samples', results[prefix]['samples'],
              'throttle/lost', results[prefix]['throttle'], results[prefix]['lost'])
    with (OUT / f'{cohort}-profiles.json').open('x') as stream:
        json.dump(results, stream, indent=2)


def annotate():
    symbols = {
        'enqueue': 'vthread::channel::wait::Ticket<T>::enqueue',
        'send': 'vthread::channel::core::<impl vthread::channel::Core<T>>::send',
        'recv': 'vthread::channel::core::<impl vthread::channel::Core<T>>::recv',
        'loop': 'std::sys::backtrace::__rust_begin_short_backtrace',
        'publish': 'core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>',
    }
    for case in ('local-profile', 'remote8-long'):
        for arm in 'AE':
            for label, symbol in symbols.items():
                if label == 'publish' and arm == 'A':
                    continue
                prefix = f'cycles2-1-{case}-{arm}'
                command = ['perf', 'annotate', '--stdio', '--stdio-color', 'never',
                           '--no-source', '--percent-type', 'global-period',
                           '-i', str(OUT / f'{prefix}.data'), '-s', symbol]
                with (OUT / f'{prefix}.{label}.asm-command.json').open('x') as stream:
                    json.dump(command, stream)
                with (OUT / f'{prefix}.{label}.asm').open('x') as stream:
                    result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
                assert result.returncode == 0, (prefix, label, result.returncode)


if __name__ == '__main__':
    if sys.argv[1] == 'annotate':
        annotate()
    else:
        inspect(sys.argv[1])
