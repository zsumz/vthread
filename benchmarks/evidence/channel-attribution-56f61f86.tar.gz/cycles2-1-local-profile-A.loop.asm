 Percent |	Source code & Disassembly of baseline-benchmark for cycles:u (5 samples, percent: global period)
----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000ca890 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   ca890:  push   %rbp
    0.00 :   ca891:  push   %r15
    0.00 :   ca893:  push   %r14
    0.00 :   ca895:  push   %r13
    0.00 :   ca897:  push   %r12
    0.00 :   ca899:  push   %rbx
    0.00 :   ca89a:  sub    $0x558,%rsp
    0.00 :   ca8a1:  mov    %rdi,%r12
    0.00 :   ca8a4:  mov    %rdi,0xc0(%rsp)
    0.00 :   ca8ac:  mov    %rsi,0x28(%rsp)
    0.00 :   ca8b1:  mov    %rsi,0xc8(%rsp)
    0.00 :   ca8b9:  jmp    ca8c2 <std::sys::backtrace::__rust_begin_short_backtrace+0x32>
    0.00 :   ca8bb:  nopl   0x0(%rax,%rax,1)
    0.00 :   ca8c0:  pause
    0.00 :   ca8c2:  mov    0x8(%r12),%rax
    0.00 :   ca8c7:  nopw   0x0(%rax,%rax,1)
    0.00 :   ca8d0:  cmp    $0xffffffffffffffff,%rax
    0.00 :   ca8d4:  je     ca8c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x30>
    0.00 :   ca8d6:  test   %rax,%rax
    0.00 :   ca8d9:  js     cae52 <std::sys::backtrace::__rust_begin_short_backtrace+0x5c2>
    0.00 :   ca8df:  lea    0x1(%rax),%rcx
    0.00 :   ca8e3:  lock cmpxchg %rcx,0x8(%r12)
    0.00 :   ca8ea:  jne    ca8d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x40>
    0.00 :   ca8ec:  mov    %r12,%rdi
    0.00 :   ca8ef:  xor    %esi,%esi
    0.00 :   ca8f1:  call   102ae0 <vthread::worker_context::attach>
    0.00 :   ca8f6:  lock incq (%r12)
    0.00 :   ca8fb:  jle    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   ca901:  mov    %r12,0x98(%rsp)
    0.00 :   ca909:  lock incq (%r12)
    0.00 :   ca90e:  jle    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   ca914:  mov    %r12,0xd0(%rsp)
    0.00 :   ca91c:  mov    0xa0(%r12),%rsi
    0.00 :   ca924:  mov    0x28(%rsp),%rdi
    0.00 :   ca929:  cmp    %rsi,%rdi
    0.00 :   ca92c:  jae    cbea1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1611>
    0.00 :   ca932:  movups 0x50(%r12),%xmm0
    0.00 :   ca938:  mov    0x70(%r12),%rax
    0.00 :   ca93d:  mov    0x98(%r12),%rcx
    0.00 :   ca945:  mov    (%rcx,%rdi,8),%rbx
    0.00 :   ca949:  lock incq (%rbx)
    0.00 :   ca94d:  jle    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   ca953:  mov    %rbx,0xd8(%rsp)
    0.00 :   ca95b:  mov    %r12,0x40(%rsp)
    0.00 :   ca960:  movq   $0x0,0x3a8(%rsp)
    0.00 :   ca96c:  movq   $0x8,0x3b0(%rsp)
    0.00 :   ca978:  xorps  %xmm1,%xmm1
    0.00 :   ca97b:  movups %xmm1,0x3b8(%rsp)
    0.00 :   ca983:  movq   $0x8,0x3c8(%rsp)
    0.00 :   ca98f:  movups %xmm1,0x3d0(%rsp)
    0.00 :   ca997:  movq   $0x8,0x3e0(%rsp)
    0.00 :   ca9a3:  movups %xmm1,0x3e8(%rsp)
    0.00 :   ca9ab:  movq   $0x8,0x3f8(%rsp)
    0.00 :   ca9b7:  movq   $0x0,0x400(%rsp)
    0.00 :   ca9c3:  movq   $0x0,0x480(%rsp)
    0.00 :   ca9cf:  movq   $0x8,0x488(%rsp)
    0.00 :   ca9db:  movups %xmm1,0x490(%rsp)
    0.00 :   ca9e3:  movq   $0x0,0x4a0(%rsp)
    0.00 :   ca9ef:  movq   $0x8,0x4a8(%rsp)
    0.00 :   ca9fb:  movups %xmm1,0x4b0(%rsp)
    0.00 :   caa03:  movb   $0x0,0x4c0(%rsp)
    0.00 :   caa0b:  movq   $0x0,0x58(%rsp)
    0.00 :   caa14:  movq   $0x8,0x60(%rsp)
    0.00 :   caa1d:  movups %xmm1,0x68(%rsp)
    0.00 :   caa22:  movq   $0x8,0x78(%rsp)
    0.00 :   caa2b:  movups %xmm1,0x80(%rsp)
    0.00 :   caa33:  movq   $0x2,0x100(%rsp)
    0.00 :   caa3f:  movq   $0x0,0xe0(%rsp)
    0.00 :   caa4b:  movups %xmm1,0xf0(%rsp)
    0.00 :   caa53:  movq   $0x8,0xe8(%rsp)
    0.00 :   caa5f:  movq   $0x0,0xa0(%rsp)
    0.00 :   caa6b:  movq   $0x8,0xa8(%rsp)
    0.00 :   caa77:  movq   $0x0,0xb0(%rsp)
    0.00 :   caa83:  movq   $0x1,0x120(%rsp)
    0.00 :   caa8f:  movq   $0x1,0x128(%rsp)
    0.00 :   caa9b:  movups %xmm1,0x130(%rsp)
    0.00 :   caaa3:  movq   $0x8,0x140(%rsp)
    0.00 :   caaaf:  movq   $0x0,0x148(%rsp)
    0.00 :   caabb:  movups %xmm0,0x150(%rsp)
    0.00 :   caac3:  movq   $0x1,0x160(%rsp)
    0.00 :   caacf:  movups %xmm1,0x168(%rsp)
    0.00 :   caad7:  movups %xmm1,0x178(%rsp)
    0.00 :   caadf:  movups %xmm1,0x188(%rsp)
    0.00 :   caae7:  movq   $0x0,0x198(%rsp)
    0.00 :   caaf3:  movq   $0x8,0x1a0(%rsp)
    0.00 :   caaff:  movups %xmm1,0x1a8(%rsp)
    0.00 :   cab07:  movups %xmm1,0x1b8(%rsp)
    0.00 :   cab0f:  movq   $0x0,0x1c8(%rsp)
    0.00 :   cab1b:  movq   $0x8,0x1d0(%rsp)
    0.00 :   cab27:  movups %xmm1,0x1d8(%rsp)
    0.00 :   cab2f:  movups %xmm1,0x1e8(%rsp)
    0.00 :   cab37:  mov    %rax,0x1f8(%rsp)
    0.00 :   cab3f:  mov    $0xe0,%edi
    0.00 :   cab44:  call   *0xc64be(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   cab4a:  test   %rax,%rax
    0.00 :   cab4d:  je     cae91 <std::sys::backtrace::__rust_begin_short_backtrace+0x601>
    0.00 :   cab53:  mov    %rax,%r14
    0.00 :   cab56:  lea    0x120(%rsp),%rsi
    0.00 :   cab5e:  mov    $0xe0,%edx
    0.00 :   cab63:  mov    %rax,%rdi
    0.00 :   cab66:  call   *0xc646c(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   cab6c:  mov    %r12,0x2b8(%rsp)
    0.00 :   cab74:  mov    %rbx,0x2c0(%rsp)
    0.00 :   cab7c:  mov    0x28(%rsp),%rax
    0.00 :   cab81:  mov    %rax,0x2d0(%rsp)
    0.00 :   cab89:  movups 0x3a8(%rsp),%xmm0
    0.00 :   cab91:  movups 0x3b8(%rsp),%xmm1
    0.00 :   cab99:  movups 0x3c8(%rsp),%xmm2
    0.00 :   caba1:  movups 0x3d8(%rsp),%xmm3
    0.00 :   caba9:  movaps %xmm0,0x1a0(%rsp)
    0.00 :   cabb1:  movaps %xmm1,0x1b0(%rsp)
    0.00 :   cabb9:  movaps %xmm2,0x1c0(%rsp)
    0.00 :   cabc1:  movaps %xmm3,0x1d0(%rsp)
    0.00 :   cabc9:  movups 0x3e8(%rsp),%xmm0
    0.00 :   cabd1:  movaps %xmm0,0x1e0(%rsp)
    0.00 :   cabd9:  movups 0x3f8(%rsp),%xmm0
    0.00 :   cabe1:  movaps %xmm0,0x1f0(%rsp)
    0.00 :   cabe9:  movups 0x480(%rsp),%xmm0
    0.00 :   cabf1:  movups 0x490(%rsp),%xmm1
    0.00 :   cabf9:  movups 0x4a0(%rsp),%xmm2
    0.00 :   cac01:  movups 0x4b0(%rsp),%xmm3
    0.00 :   cac09:  movaps %xmm0,0x200(%rsp)
    0.00 :   cac11:  movaps %xmm1,0x210(%rsp)
    0.00 :   cac19:  movaps %xmm2,0x220(%rsp)
    0.00 :   cac21:  movaps %xmm3,0x230(%rsp)
    0.00 :   cac29:  mov    0x4c0(%rsp),%rax
    0.00 :   cac31:  mov    %rax,0x240(%rsp)
    0.00 :   cac39:  mov    0x88(%rsp),%rax
    0.00 :   cac41:  mov    %rax,0x278(%rsp)
    0.00 :   cac49:  movups 0x58(%rsp),%xmm0
    0.00 :   cac4e:  movups 0x68(%rsp),%xmm1
    0.00 :   cac53:  movups 0x78(%rsp),%xmm2
    0.00 :   cac58:  movups %xmm2,0x268(%rsp)
    0.00 :   cac60:  movups %xmm1,0x258(%rsp)
    0.00 :   cac68:  movups %xmm0,0x248(%rsp)
    0.00 :   cac70:  movq   $0x0,0x2d8(%rsp)
    0.00 :   cac7c:  movups 0x100(%rsp),%xmm0
    0.00 :   cac84:  movups 0x110(%rsp),%xmm1
    0.00 :   cac8c:  movaps %xmm0,0x120(%rsp)
    0.00 :   cac94:  movaps %xmm1,0x130(%rsp)
    0.00 :   cac9c:  movups 0xe0(%rsp),%xmm0
    0.00 :   caca4:  movups 0xf0(%rsp),%xmm1
    0.00 :   cacac:  movaps %xmm0,0x280(%rsp)
    0.00 :   cacb4:  movaps %xmm1,0x290(%rsp)
    0.00 :   cacbc:  movb   $0x0,0x39c(%rsp)
    0.00 :   cacc4:  movq   $0x18,0x140(%rsp)
    0.00 :   cacd0:  movq   $0x0,0x168(%rsp)
    0.00 :   cacdc:  movq   $0x8,0x170(%rsp)
    0.00 :   cace8:  xorps  %xmm1,%xmm1
    0.00 :   caceb:  movups %xmm1,0x2e8(%rsp)
    0.00 :   cacf3:  movups %xmm1,0x178(%rsp)
    0.00 :   cacfb:  movups %xmm1,0x188(%rsp)
    0.00 :   cad03:  movq   $0x0,0x198(%rsp)
    0.00 :   cad0f:  mov    0xb0(%rsp),%rax
    0.00 :   cad17:  mov    %rax,0x2b0(%rsp)
    0.00 :   cad1f:  movups 0xa0(%rsp),%xmm0
    0.00 :   cad27:  movaps %xmm0,0x2a0(%rsp)
    0.00 :   cad2f:  mov    %r14,0x2c8(%rsp)
    0.00 :   cad37:  movw   $0x0,0x39d(%rsp)
    0.00 :   cad41:  movaps %xmm1,0x300(%rsp)
    0.00 :   cad49:  movups %xmm1,0x388(%rsp)
    0.00 :   cad51:  movups %xmm1,0x378(%rsp)
    0.00 :   cad59:  movups %xmm1,0x368(%rsp)
    0.00 :   cad61:  movups %xmm1,0x358(%rsp)
    0.00 :   cad69:  movups %xmm1,0x348(%rsp)
    0.00 :   cad71:  movups %xmm1,0x338(%rsp)
    0.00 :   cad79:  movups %xmm1,0x328(%rsp)
    0.00 :   cad81:  movups %xmm1,0x318(%rsp)
    0.00 :   cad89:  movl   $0x0,0x398(%rsp)
    0.00 :   cad94:  mov    $0x280,%edi
    0.00 :   cad99:  call   *0xc6269(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   cad9f:  test   %rax,%rax
    0.00 :   cada2:  je     caea6 <std::sys::backtrace::__rust_begin_short_backtrace+0x616>
    0.00 :   cada8:  mov    %rax,%rbx
    0.00 :   cadab:  lea    0x120(%rsp),%rsi
    0.00 :   cadb3:  mov    $0x280,%edx
    0.00 :   cadb8:  mov    %rax,%rdi
    0.00 :   cadbb:  call   *0xc6217(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   cadc1:  mov    0x1a0(%rbx),%rax
    0.00 :   cadc8:  mov    %rbx,0x8(%rsp)
    0.00 :   cadcd:  mov    0x1a8(%rbx),%rbx
    0.00 :   cadd4:  mov    0xe0(%rax),%r14
    0.00 :   caddb:  lock incq (%r14)
    0.00 :   caddf:  jle    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cade5:  incq   (%rbx)
    0.00 :   cade8:  je     cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cadee:  mov    %r14,0x3a8(%rsp)
    0.00 :   cadf6:  mov    %rbx,0x3b0(%rsp)
    0.00 :   cadfe:  movzbl %fs:0xffffffffffffffd8,%eax
    0.00 :   cae07:  cmp    $0x1,%eax
    0.00 :   cae0a:  je     caee1 <std::sys::backtrace::__rust_begin_short_backtrace+0x651>
    0.00 :   cae10:  cmp    $0x2,%eax
    0.00 :   cae13:  jne    caebb <std::sys::backtrace::__rust_begin_short_backtrace+0x62b>
    0.00 :   cae19:  lock decq (%r14)
    0.00 :   cae1d:  jne    cae2d <std::sys::backtrace::__rust_begin_short_backtrace+0x59d>
    0.00 :   cae1f:  lea    0x3a8(%rsp),%rdi
    0.00 :   cae27:  call   *0xc70fb(%rip)        # 191f28 <_DYNAMIC+0x1168>
    0.00 :   cae2d:  decq   (%rbx)
    0.00 :   cae30:  jne    cae40 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b0>
    0.00 :   cae32:  lea    0x3b0(%rsp),%rdi
    0.00 :   cae3a:  call   *0xc70f0(%rip)        # 191f30 <_DYNAMIC+0x1170>
    0.00 :   cae40:  lea    0xc16a9(%rip),%rdi        # 18c4f0 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058>
    0.00 :   cae47:  call   *0xc678b(%rip)        # 1915d8 <_DYNAMIC+0x818>
    0.00 :   cae4d:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae52:  lea    0xc10e7(%rip),%rax        # 18bf40 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x210>
    0.00 :   cae59:  mov    %rax,0x120(%rsp)
    0.00 :   cae61:  lea    0x8778(%rip),%rax        # d35e0 <_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hb2a2ab9295a6d20aE.llvm.10013882635303053058>
    0.00 :   cae68:  mov    %rax,0x128(%rsp)
    0.00 :   cae70:  lea    -0xb8702(%rip),%rdi        # 12775 <anon.48996dcd35f4b7aad43cb5fc1472ecbf.144.llvm.7041895458470441471>
    0.00 :   cae77:  lea    0xc1e92(%rip),%rdx        # 18cd10 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x6b0>
    0.00 :   cae7e:  lea    0x120(%rsp),%rsi
    0.00 :   cae86:  call   *0xc61bc(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   cae8c:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae91:  mov    $0x8,%edi
    0.00 :   cae96:  mov    $0xe0,%esi
    0.00 :   cae9b:  call   *0xc618f(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   caea1:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   caea6:  mov    $0x8,%edi
    0.00 :   caeab:  mov    $0x280,%esi
    0.00 :   caeb0:  call   *0xc617a(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   caeb6:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   caebb:  mov    %fs:0x0,%rax
    0.00 :   caec4:  lea    -0x40(%rax),%rdi
    0.00 :   caecb:  lea    -0x4db2(%rip),%rsi        # c6120 <std::sys::thread_local::native::eager::destroy>
    0.00 :   caed2:  call   *0xc6850(%rip)        # 191728 <_DYNAMIC+0x968>
    0.00 :   caed8:  movb   $0x1,%fs:0xffffffffffffffd8
    0.00 :   caee1:  mov    %r14,0x120(%rsp)
    0.00 :   caee9:  mov    %rbx,0x128(%rsp)
    0.00 :   caef1:  cmpq   $0x0,%fs:0xffffffffffffffc0
    0.00 :   caefb:  jne    cbd80 <std::sys::backtrace::__rust_begin_short_backtrace+0x14f0>
    0.00 :   caf01:  movups %fs:0xffffffffffffffc8,%xmm0
    0.00 :   caf0a:  mov    %r14,%fs:0xffffffffffffffc8
    0.00 :   caf13:  mov    %rbx,%fs:0xffffffffffffffd0
    0.00 :   caf1c:  movaps %xmm0,0x40(%rsp)
    0.00 :   caf21:  mov    %r12,0x18(%rsp)
    0.00 :   caf26:  lea    0x10(%r12),%rax
    0.00 :   caf2b:  mov    %rax,0x20(%rsp)
    0.00 :   caf30:  mov    0x8(%rsp),%rdi
    0.00 :   caf35:  lea    0x20(%rdi),%rax
    0.00 :   caf39:  mov    %rax,0x90(%rsp)
    0.00 :   caf41:  mov    %rdi,%rax
    0.00 :   caf44:  add    $0x58,%rax
    0.00 :   caf48:  mov    %rax,0xb8(%rsp)
    0.00 :   caf50:  mov    $0x1,%al
    0.00 :   caf52:  jmp    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   caf54:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   caf60:  mov    0x1a0(%rdi),%rax
    0.00 :   caf67:  mov    0xd0(%rax),%rax
    0.00 :   caf6e:  test   %rax,%rax
    0.00 :   caf71:  je     cb450 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc0>
    0.00 :   caf77:  movb   $0x1,0x27c(%rdi)
    0.00 :   caf7e:  xor    %eax,%eax
    0.00 :   caf80:  mov    0x1a0(%rdi),%rcx
    0.00 :   caf87:  mov    0xd8(%rcx),%rcx
    0.00 :   caf8e:  mov    0x10(%rcx),%rcx
   20.99 :   caf92:  mov    %rcx,0x38(%rsp)
    0.00 :   caf97:  cmp    %rcx,%r15
    0.00 :   caf9a:  setne  %bl
    0.00 :   caf9d:  or     %al,%bl
    0.00 :   caf9f:  test   $0x1,%bl
    0.00 :   cafa2:  je     cb200 <std::sys::backtrace::__rust_begin_short_backtrace+0x970>
    0.00 :   cafa8:  mov    0x1a0(%rdi),%rax
    0.00 :   cafaf:  movzbl 0xeb(%rax),%eax
    0.00 :   cafb6:  test   %al,%al
    0.00 :   cafb8:  jne    cbaef <std::sys::backtrace::__rust_begin_short_backtrace+0x125f>
    0.00 :   cafbe:  mov    %bl,0x14(%rsp)
    0.00 :   cafc2:  mov    0x1a0(%rdi),%r12
    0.00 :   cafc9:  movzbl 0xec(%r12),%eax
    0.00 :   cafd2:  test   %al,%al
    0.00 :   cafd4:  je     cb210 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cafda:  lea    0xec(%r12),%rbx
    0.00 :   cafe2:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   caff0:  lea    0x88(%r12),%r13
    0.00 :   caff8:  xor    %eax,%eax
    0.00 :   caffa:  mov    $0x1,%ecx
    0.00 :   cafff:  lock cmpxchg %ecx,0x88(%r12)
    0.00 :   cb009:  jne    cb195 <std::sys::backtrace::__rust_begin_short_backtrace+0x905>
    0.00 :   cb00f:  mov    0xc633a(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cb016:  mov    (%rax),%rax
    0.00 :   cb019:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb023:  test   %rcx,%rax
    0.00 :   cb026:  jne    cb1a3 <std::sys::backtrace::__rust_begin_short_backtrace+0x913>
    0.00 :   cb02c:  xor    %ebp,%ebp
    0.00 :   cb02e:  movzbl 0x8c(%r12),%eax
    0.00 :   cb037:  mov    0xb0(%r12),%rax
    0.00 :   cb03f:  mov    $0x6,%r14b
    0.00 :   cb042:  test   %rax,%rax
    0.00 :   cb045:  je     cb100 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb04b:  mov    0xb8(%r12),%rcx
    0.00 :   cb053:  test   %rcx,%rcx
    0.00 :   cb056:  je     cb0b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb058:  mov    %rcx,%rdx
    0.00 :   cb05b:  and    $0x7,%rdx
    0.00 :   cb05f:  je     cb183 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f3>
    0.00 :   cb065:  xor    %esi,%esi
    0.00 :   cb067:  nopw   0x0(%rax,%rax,1)
    0.00 :   cb070:  mov    0x70(%rax),%rax
    0.00 :   cb074:  inc    %rsi
    0.00 :   cb077:  cmp    %rsi,%rdx
    0.00 :   cb07a:  jne    cb070 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e0>
    0.00 :   cb07c:  mov    %rcx,%rdx
    0.00 :   cb07f:  sub    %rsi,%rdx
    0.00 :   cb082:  cmp    $0x8,%rcx
    0.00 :   cb086:  jb     cb0b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb088:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb090:  mov    0x70(%rax),%rax
    0.00 :   cb094:  mov    0x70(%rax),%rax
    0.00 :   cb098:  mov    0x70(%rax),%rax
    0.00 :   cb09c:  mov    0x70(%rax),%rax
    0.00 :   cb0a0:  mov    0x70(%rax),%rax
    0.00 :   cb0a4:  mov    0x70(%rax),%rax
    0.00 :   cb0a8:  mov    0x70(%rax),%rax
    0.00 :   cb0ac:  mov    0x70(%rax),%rax
    0.00 :   cb0b0:  add    $0xfffffffffffffff8,%rdx
    0.00 :   cb0b4:  jne    cb090 <std::sys::backtrace::__rust_begin_short_backtrace+0x800>
    0.00 :   cb0b6:  cmpw   $0x0,0x62(%rax)
    0.00 :   cb0bb:  je     cb100 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb0bd:  lea    0xb0(%r12),%rcx
    0.00 :   cb0c5:  lea    0x128(%rsp),%rdx
    0.00 :   cb0cd:  xorps  %xmm0,%xmm0
    0.00 :   cb0d0:  movups %xmm0,(%rdx)
    0.00 :   cb0d3:  mov    %rax,0x120(%rsp)
    0.00 :   cb0db:  mov    %rcx,0x138(%rsp)
    0.00 :   cb0e3:  lea    0x120(%rsp),%rdi
    0.00 :   cb0eb:  call   e44f0 <alloc::collections::btree::map::entry::OccupiedEntry<K,V,A>::remove_kv>
    0.00 :   cb0f0:  mov    %rax,%r15
    0.00 :   cb0f3:  mov    %edx,%r14d
    0.00 :   cb0f6:  jmp    cb100 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb0f8:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb100:  cmpq   $0x0,0xc0(%r12)
    0.00 :   cb109:  setne  %al
    0.00 :   cb10c:  mov    %al,(%rbx)
    0.00 :   cb10e:  test   %bpl,%bpl
    0.00 :   cb111:  jne    cb130 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb113:  mov    0xc6236(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cb11a:  mov    (%rax),%rax
    0.00 :   cb11d:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb127:  test   %rcx,%rax
    0.00 :   cb12a:  jne    cb1da <std::sys::backtrace::__rust_begin_short_backtrace+0x94a>
    0.00 :   cb130:  xor    %eax,%eax
    0.00 :   cb132:  xchg   %eax,0x0(%r13)
    0.00 :   cb136:  cmp    $0x2,%eax
    0.00 :   cb139:  je     cb1b4 <std::sys::backtrace::__rust_begin_short_backtrace+0x924>
    0.00 :   cb13b:  cmp    $0x6,%r14b
    0.00 :   cb13f:  je     cb210 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb145:  movzbl %r14b,%ecx
    0.00 :   cb149:  mov    $0x1,%esi
    0.00 :   cb14e:  mov    0x8(%rsp),%rbx
    0.00 :   cb153:  mov    %rbx,%rdi
    0.00 :   cb156:  mov    %r15,%rdx
    0.00 :   cb159:  call   1131f0 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cb15e:  mov    0x1a0(%rbx),%r12
    0.00 :   cb165:  lea    0xec(%r12),%rbx
    0.00 :   cb16d:  movzbl 0xec(%r12),%eax
    0.00 :   cb176:  test   %al,%al
    0.00 :   cb178:  jne    caff0 <std::sys::backtrace::__rust_begin_short_backtrace+0x760>
    0.00 :   cb17e:  jmp    cb210 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb183:  mov    %rcx,%rdx
    0.00 :   cb186:  cmp    $0x8,%rcx
    0.00 :   cb18a:  jae    cb090 <std::sys::backtrace::__rust_begin_short_backtrace+0x800>
    0.00 :   cb190:  jmp    cb0b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb195:  mov    %r13,%rdi
    0.00 :   cb198:  call   *0xc622a(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cb19e:  jmp    cb00f <std::sys::backtrace::__rust_begin_short_backtrace+0x77f>
    0.00 :   cb1a3:  call   *0xc61c7(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cb1a9:  mov    %eax,%ebp
    0.00 :   cb1ab:  xor    $0x1,%bpl
    0.00 :   cb1af:  jmp    cb02e <std::sys::backtrace::__rust_begin_short_backtrace+0x79e>
    0.00 :   cb1b4:  mov    $0xca,%edi
    0.00 :   cb1b9:  mov    %r13,%rsi
    0.00 :   cb1bc:  mov    $0x81,%edx
    0.00 :   cb1c1:  mov    $0x1,%ecx
    0.00 :   cb1c6:  xor    %eax,%eax
    0.00 :   cb1c8:  call   *0xc61b2(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cb1ce:  cmp    $0x6,%r14b
    0.00 :   cb1d2:  jne    cb145 <std::sys::backtrace::__rust_begin_short_backtrace+0x8b5>
    0.00 :   cb1d8:  jmp    cb210 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb1da:  call   *0xc6190(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cb1e0:  test   %al,%al
    0.00 :   cb1e2:  jne    cb130 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb1e8:  movb   $0x1,0x8c(%r12)
    0.00 :   cb1f1:  jmp    cb130 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb1f6:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb200:  cmpb   $0x0,0x27c(%rdi)
    0.00 :   cb207:  je     cb230 <std::sys::backtrace::__rust_begin_short_backtrace+0x9a0>
    0.00 :   cb209:  call   1154c0 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive>
    0.00 :   cb20e:  jmp    cb280 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb210:  mov    0x8(%rsp),%rdi
    0.00 :   cb215:  call   1154c0 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive>
    0.00 :   cb21a:  mov    0x38(%rsp),%r15
    0.00 :   cb21f:  movzbl 0x14(%rsp),%ebx
    0.00 :   cb224:  jmp    cb280 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb226:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb230:  call   114f00 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive_local_tasks>
    0.00 :   cb235:  test   %al,%al
    0.00 :   cb237:  je     cb280 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb239:  mov    0x8(%rsp),%rsi
    0.00 :   cb23e:  movb   $0x0,0x27e(%rsi)
    0.00 :   cb245:  mov    0x198(%rsi),%r14
    0.00 :   cb24c:  lea    0x120(%rsp),%rdi
    0.00 :   cb254:  mov    $0x1,%edx
    0.00 :   cb259:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cb25e:  add    $0x10,%r14
    0.00 :   cb262:  mov    %r14,%rdi
    0.00 :   cb265:  lea    0x120(%rsp),%rsi
    0.00 :   cb26d:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cb272:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb280:  movzbl %bl,%edx
   20.55 :   cb283:  and    $0x1,%edx
    0.00 :   cb286:  lea    0x120(%rsp),%rdi
    0.00 :   cb28e:  mov    0x8(%rsp),%rsi
   38.90 :   cb293:  call   10da40 <vthread::kernel::kernel_drive::<impl vthread::kernel::Kernel>::tick>
    0.00 :   cb298:  mov    0x120(%rsp),%rax
    0.00 :   cb2a0:  movabs $0x7fffffffffffffff,%rcx
   19.57 :   cb2aa:  add    $0x23,%rcx
    0.00 :   cb2ae:  cmp    %rcx,%rax
    0.00 :   cb2b1:  jne    cb8f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1060>
    0.00 :   cb2b7:  xor    %eax,%eax
    0.00 :   cb2b9:  cmpb   $0x0,0x128(%rsp)
    0.00 :   cb2c1:  mov    0x8(%rsp),%rdi
    0.00 :   cb2c6:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb2cc:  cmpq   $0x0,0x60(%rdi)
    0.00 :   cb2d1:  je     cb32d <std::sys::backtrace::__rust_begin_short_backtrace+0xa9d>
    0.00 :   cb2d3:  mov    0x1c8(%rdi),%rdx
    0.00 :   cb2da:  test   %rdx,%rdx
    0.00 :   cb2dd:  je     cbd5d <std::sys::backtrace::__rust_begin_short_backtrace+0x14cd>
    0.00 :   cb2e3:  mov    0x198(%rdi),%rdi
    0.00 :   cb2ea:  add    $0x10,%rdi
    0.00 :   cb2ee:  add    $0x40,%rdx
    0.00 :   cb2f2:  mov    0x90(%rsp),%rsi
    0.00 :   cb2fa:  call   120a50 <vthread::control::control_completion::<impl vthread::control::Shared>::publish_completions>
    0.00 :   cb2ff:  mov    0x90(%rsp),%rax
    0.00 :   cb307:  movq   $0x18,(%rax)
    0.00 :   cb30e:  mov    0xb8(%rsp),%rax
    0.00 :   cb316:  xorps  %xmm0,%xmm0
    0.00 :   cb319:  movups %xmm0,0x10(%rax)
    0.00 :   cb31d:  movups %xmm0,(%rax)
    0.00 :   cb320:  movq   $0x0,0x20(%rax)
    0.00 :   cb328:  mov    0x8(%rsp),%rdi
    0.00 :   cb32d:  mov    0x1d0(%rdi),%rax
    0.00 :   cb334:  test   %rax,%rax
    0.00 :   cb337:  je     caf60 <std::sys::backtrace::__rust_begin_short_backtrace+0x6d0>
    0.00 :   cb33d:  mov    0x1d8(%rdi),%rcx
    0.00 :   cb344:  test   %rcx,%rcx
    0.00 :   cb347:  je     cb3be <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb349:  mov    %rcx,%rdx
    0.00 :   cb34c:  and    $0x7,%rdx
    0.00 :   cb350:  je     cb55e <std::sys::backtrace::__rust_begin_short_backtrace+0xcce>
    0.00 :   cb356:  xor    %esi,%esi
    0.00 :   cb358:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb360:  mov    0x170(%rax),%rax
    0.00 :   cb367:  inc    %rsi
    0.00 :   cb36a:  cmp    %rsi,%rdx
    0.00 :   cb36d:  jne    cb360 <std::sys::backtrace::__rust_begin_short_backtrace+0xad0>
    0.00 :   cb36f:  mov    %rcx,%rdx
    0.00 :   cb372:  sub    %rsi,%rdx
    0.00 :   cb375:  cmp    $0x8,%rcx
    0.00 :   cb379:  jb     cb3be <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb37b:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb380:  mov    0x170(%rax),%rax
    0.00 :   cb387:  mov    0x170(%rax),%rax
    0.00 :   cb38e:  mov    0x170(%rax),%rax
    0.00 :   cb395:  mov    0x170(%rax),%rax
    0.00 :   cb39c:  mov    0x170(%rax),%rax
    0.00 :   cb3a3:  mov    0x170(%rax),%rax
    0.00 :   cb3aa:  mov    0x170(%rax),%rax
    0.00 :   cb3b1:  mov    0x170(%rax),%rax
    0.00 :   cb3b8:  add    $0xfffffffffffffff8,%rdx
    0.00 :   cb3bc:  jne    cb380 <std::sys::backtrace::__rust_begin_short_backtrace+0xaf0>
    0.00 :   cb3be:  cmpw   $0x0,0x16a(%rax)
    0.00 :   cb3c6:  mov    0x8(%rsp),%rdi
    0.00 :   cb3cb:  je     caf60 <std::sys::backtrace::__rust_begin_short_backtrace+0x6d0>
    0.00 :   cb3d1:  mov    (%rax),%r13
    0.00 :   cb3d4:  mov    0x8(%rax),%ebp
    0.00 :   cb3d7:  incq   0x250(%rdi)
    0.00 :   cb3de:  mov    0x1a0(%rdi),%rax
    0.00 :   cb3e5:  mov    0xd0(%rax),%rax
    0.00 :   cb3ec:  test   %rax,%rax
    0.00 :   cb3ef:  jne    caf77 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e7>
    0.00 :   cb3f5:  mov    0x1a8(%rdi),%rcx
    0.00 :   cb3fc:  xor    %eax,%eax
    0.00 :   cb3fe:  cmpq   $0x0,0xc8(%rcx)
    0.00 :   cb406:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb40c:  mov    0x1a0(%rdi),%rax
    0.00 :   cb413:  mov    0xe0(%rax),%rcx
    0.00 :   cb41a:  mov    0x80(%rcx),%rdx
    0.00 :   cb421:  xor    %eax,%eax
    0.00 :   cb423:  test   %rdx,%rdx
    0.00 :   cb426:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb42c:  mov    0x40(%rcx),%rcx
    0.00 :   cb430:  xor    %eax,%eax
    0.00 :   cb432:  mov    $0x0,%r12d
    0.00 :   cb438:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb442:  test   %rdx,%rcx
    0.00 :   cb445:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb44b:  jmp    cb575 <std::sys::backtrace::__rust_begin_short_backtrace+0xce5>
    0.00 :   cb450:  mov    0x1a8(%rdi),%rcx
    0.00 :   cb457:  xor    %eax,%eax
    0.00 :   cb459:  cmpq   $0x0,0xc8(%rcx)
    0.00 :   cb461:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb467:  mov    0x1a0(%rdi),%rax
    0.00 :   cb46e:  mov    0xe0(%rax),%rcx
    0.00 :   cb475:  mov    0x80(%rcx),%rdx
    0.00 :   cb47c:  xor    %eax,%eax
    0.00 :   cb47e:  test   %rdx,%rdx
    0.00 :   cb481:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb487:  mov    0x40(%rcx),%rcx
    0.00 :   cb48b:  xor    %eax,%eax
    0.00 :   cb48d:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb497:  test   %rdx,%rcx
    0.00 :   cb49a:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb4a0:  mov    0x198(%rdi),%rax
    0.00 :   cb4a7:  mov    $0x3b9aca00,%ebp
    0.00 :   cb4ac:  mov    $0x1,%r12b
    0.00 :   cb4af:  cmpq   $0x2,0x60(%rax)
    0.00 :   cb4b4:  jb     cb570 <std::sys::backtrace::__rust_begin_short_backtrace+0xce0>
    0.00 :   cb4ba:  mov    $0x281,%ecx
    0.00 :   cb4bf:  dec    %rcx
    0.00 :   cb4c2:  je     cb570 <std::sys::backtrace::__rust_begin_short_backtrace+0xce0>
    0.00 :   cb4c8:  pause
    0.00 :   cb4ca:  mov    0x8(%rsp),%rdi
    0.00 :   cb4cf:  mov    0x1a0(%rdi),%rax
    0.00 :   cb4d6:  mov    0xd0(%rax),%rax
    0.00 :   cb4dd:  test   %rax,%rax
    0.00 :   cb4e0:  jne    caf77 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e7>
    0.00 :   cb4e6:  mov    0x1a8(%rdi),%rax
    0.00 :   cb4ed:  cmpq   $0x0,0xc8(%rax)
    0.00 :   cb4f5:  jne    cb894 <std::sys::backtrace::__rust_begin_short_backtrace+0x1004>
    0.00 :   cb4fb:  mov    0x1a0(%rdi),%rax
    0.00 :   cb502:  mov    0xe0(%rax),%rax
    0.00 :   cb509:  mov    0x80(%rax),%rdx
    0.00 :   cb510:  test   %rdx,%rdx
    0.00 :   cb513:  jne    cb888 <std::sys::backtrace::__rust_begin_short_backtrace+0xff8>
    0.00 :   cb519:  mov    0x40(%rax),%rax
    0.00 :   cb51d:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb527:  test   %rdx,%rax
    0.00 :   cb52a:  jne    cb888 <std::sys::backtrace::__rust_begin_short_backtrace+0xff8>
    0.00 :   cb530:  mov    0x8(%rsp),%rax
    0.00 :   cb535:  mov    0x1a0(%rax),%rax
    0.00 :   cb53c:  mov    0xd8(%rax),%rax
    0.00 :   cb543:  mov    0x10(%rax),%rdx
    0.00 :   cb547:  xor    %eax,%eax
    0.00 :   cb549:  cmp    0x38(%rsp),%rdx
    0.00 :   cb54e:  je     cb4bf <std::sys::backtrace::__rust_begin_short_backtrace+0xc2f>
    0.00 :   cb554:  mov    0x8(%rsp),%rdi
    0.00 :   cb559:  jmp    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb55e:  mov    %rcx,%rdx
    0.00 :   cb561:  cmp    $0x8,%rcx
    0.00 :   cb565:  jae    cb380 <std::sys::backtrace::__rust_begin_short_backtrace+0xaf0>
    0.00 :   cb56b:  jmp    cb3be <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb570:  mov    0x8(%rsp),%rdi
    0.00 :   cb575:  movb   $0x0,0x27e(%rdi)
    0.00 :   cb57c:  mov    0x198(%rdi),%r14
    0.00 :   cb583:  mov    %rdi,%rsi
    0.00 :   cb586:  lea    0x120(%rsp),%rdi
    0.00 :   cb58e:  xor    %edx,%edx
    0.00 :   cb590:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cb595:  add    $0x10,%r14
    0.00 :   cb599:  mov    %r14,%rdi
    0.00 :   cb59c:  lea    0x120(%rsp),%rsi
    0.00 :   cb5a4:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cb5a9:  mov    0x8(%rsp),%rax
    0.00 :   cb5ae:  mov    0x1a0(%rax),%rax
    0.00 :   cb5b5:  mov    0xe0(%rax),%rbx
    0.00 :   cb5bc:  mov    0x110(%rbx),%r14
    0.00 :   cb5c3:  lea    0x20(%r14),%rax
    0.00 :   cb5c7:  mov    %rax,0x50(%rsp)
    0.00 :   cb5cc:  xor    %eax,%eax
    0.00 :   cb5ce:  mov    $0x1,%ecx
    0.00 :   cb5d3:  lock cmpxchg %ecx,0x20(%r14)
    0.00 :   cb5d9:  jne    cb89b <std::sys::backtrace::__rust_begin_short_backtrace+0x100b>
    0.00 :   cb5df:  mov    0xc5d6a(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cb5e6:  mov    (%rax),%rax
    0.00 :   cb5e9:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb5f3:  test   %rcx,%rax
    0.00 :   cb5f6:  jne    cb8aa <std::sys::backtrace::__rust_begin_short_backtrace+0x101a>
    0.00 :   cb5fc:  movl   $0x0,0x14(%rsp)
    0.00 :   cb604:  movzbl 0x24(%r14),%eax
    0.00 :   cb609:  lock incq 0x18(%r14)
    0.00 :   cb60e:  mov    0x10(%r14),%rax
    0.00 :   cb612:  cmp    0x38(%rsp),%rax
    0.00 :   cb617:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb61d:  test   %r12b,%r12b
    0.00 :   cb620:  je     cb75d <std::sys::backtrace::__rust_begin_short_backtrace+0xecd>
    0.00 :   cb626:  mov    0x80(%rbx),%rax
    0.00 :   cb62d:  test   %rax,%rax
    0.00 :   cb630:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb636:  mov    0x40(%rbx),%rax
    0.00 :   cb63a:  nopw   0x0(%rax,%rax,1)
    0.00 :   cb640:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb64a:  test   %rcx,%rax
    0.00 :   cb64d:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb653:  test   %rax,%rax
    0.00 :   cb656:  jne    cb66c <std::sys::backtrace::__rust_begin_short_backtrace+0xddc>
    0.00 :   cb658:  xor    %eax,%eax
    0.00 :   cb65a:  movabs $0x8000000000000000,%rcx
    0.00 :   cb664:  lock cmpxchg %rcx,0x40(%rbx)
    0.00 :   cb66a:  jne    cb640 <std::sys::backtrace::__rust_begin_short_backtrace+0xdb0>
    0.00 :   cb66c:  lea    0x28(%r14),%rax
    0.00 :   cb670:  mov    (%rax),%ebp
    0.00 :   cb672:  xor    %eax,%eax
    0.00 :   cb674:  lea    0x20(%r14),%r13
    0.00 :   cb678:  xchg   %eax,0x0(%r13)
    0.00 :   cb67c:  cmp    $0x2,%eax
    0.00 :   cb67f:  je     cb71b <std::sys::backtrace::__rust_begin_short_backtrace+0xe8b>
    0.00 :   cb685:  movq   $0x0,0x120(%rsp)
    0.00 :   cb691:  mov    0xc5d88(%rip),%r12        # 191420 <__errno_location@GLIBC_2.2.5>
    0.00 :   cb698:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb6a0:  lea    0x28(%r14),%rax
    0.00 :   cb6a4:  mov    (%rax),%eax
    0.00 :   cb6a6:  cmp    %ebp,%eax
    0.00 :   cb6a8:  jne    cb6f3 <std::sys::backtrace::__rust_begin_short_backtrace+0xe63>
    0.00 :   cb6aa:  cmpb   $0x0,0x120(%rsp)
    0.00 :   cb6b2:  mov    $0x0,%r8d
    0.00 :   cb6b8:  lea    0x128(%rsp),%rax
    0.00 :   cb6c0:  cmovne %rax,%r8
    0.00 :   cb6c4:  movl   $0xffffffff,(%rsp)
    0.00 :   cb6cb:  mov    $0xca,%edi
    0.00 :   cb6d0:  lea    0x28(%r14),%rsi
    0.00 :   cb6d4:  mov    $0x89,%edx
    0.00 :   cb6d9:  mov    %ebp,%ecx
    0.00 :   cb6db:  xor    %r9d,%r9d
    0.00 :   cb6de:  xor    %eax,%eax
    0.00 :   cb6e0:  call   *0xc5c9a(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cb6e6:  test   %rax,%rax
    0.00 :   cb6e9:  jns    cb6f3 <std::sys::backtrace::__rust_begin_short_backtrace+0xe63>
    0.00 :   cb6eb:  call   *%r12
    0.00 :   cb6ee:  cmpl   $0x4,(%rax)
    0.00 :   cb6f1:  je     cb6a0 <std::sys::backtrace::__rust_begin_short_backtrace+0xe10>
    0.00 :   cb6f3:  xor    %eax,%eax
    0.00 :   cb6f5:  mov    $0x1,%ecx
    0.00 :   cb6fa:  lock cmpxchg %ecx,0x0(%r13)
    0.00 :   cb700:  jne    cb73a <std::sys::backtrace::__rust_begin_short_backtrace+0xeaa>
    0.00 :   cb702:  movzbl 0x24(%r14),%eax
    0.00 :   cb707:  mov    0x10(%r14),%rax
    0.00 :   cb70b:  cmp    0x38(%rsp),%rax
    0.00 :   cb710:  je     cb626 <std::sys::backtrace::__rust_begin_short_backtrace+0xd96>
    0.00 :   cb716:  jmp    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb71b:  mov    $0xca,%edi
    0.00 :   cb720:  mov    %r13,%rsi
    0.00 :   cb723:  mov    $0x81,%edx
    0.00 :   cb728:  mov    $0x1,%ecx
    0.00 :   cb72d:  xor    %eax,%eax
    0.00 :   cb72f:  call   *0xc5c4b(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cb735:  jmp    cb685 <std::sys::backtrace::__rust_begin_short_backtrace+0xdf5>
    0.00 :   cb73a:  lea    0x20(%r14),%rdi
    0.00 :   cb73e:  call   *0xc5c84(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cb744:  movzbl 0x24(%r14),%eax
    0.00 :   cb749:  mov    0x10(%r14),%rax
    0.00 :   cb74d:  cmp    0x38(%rsp),%rax
    0.00 :   cb752:  je     cb626 <std::sys::backtrace::__rust_begin_short_backtrace+0xd96>
    0.00 :   cb758:  jmp    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb75d:  mov    0x80(%rbx),%rax
    0.00 :   cb764:  test   %rax,%rax
    0.00 :   cb767:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb76d:  mov    0x40(%rbx),%rax
    0.00 :   cb771:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb780:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb78a:  test   %rcx,%rax
    0.00 :   cb78d:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb793:  test   %rax,%rax
    0.00 :   cb796:  jne    cb7ac <std::sys::backtrace::__rust_begin_short_backtrace+0xf1c>
    0.00 :   cb798:  xor    %eax,%eax
    0.00 :   cb79a:  movabs $0x8000000000000000,%rcx
    0.00 :   cb7a4:  lock cmpxchg %rcx,0x40(%rbx)
    0.00 :   cb7aa:  jne    cb780 <std::sys::backtrace::__rust_begin_short_backtrace+0xef0>
    0.00 :   cb7ac:  mov    %r13,0xa0(%rsp)
    0.00 :   cb7b4:  mov    %ebp,0xa8(%rsp)
    0.00 :   cb7bb:  mov    $0x1,%edi
    0.00 :   cb7c0:  call   a12d0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   cb7c5:  mov    %rax,0x100(%rsp)
    0.00 :   cb7cd:  mov    %edx,0x108(%rsp)
    0.00 :   cb7d4:  lea    0x120(%rsp),%rdi
    0.00 :   cb7dc:  lea    0xa0(%rsp),%rsi
    0.00 :   cb7e4:  lea    0x100(%rsp),%rdx
    0.00 :   cb7ec:  call   a1200 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec.llvm.13342753452097612697>
    0.00 :   cb7f1:  cmpb   $0x0,0x120(%rsp)
    0.00 :   cb7f9:  mov    0x130(%rsp),%ecx
    0.00 :   cb800:  mov    $0x0,%eax
    0.00 :   cb805:  cmovne %eax,%ecx
    0.00 :   cb808:  mov    0x128(%rsp),%rdx
    0.00 :   cb810:  cmovne %rax,%rdx
    0.00 :   cb814:  test   %rdx,%rdx
    0.00 :   cb817:  sete   %al
    0.00 :   cb81a:  test   %ecx,%ecx
    0.00 :   cb81c:  sete   %sil
    0.00 :   cb820:  test   %sil,%al
    0.00 :   cb823:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb825:  lea    0x28(%r14),%rdi
    0.00 :   cb829:  lea    0x20(%r14),%rsi
    0.00 :   cb82d:  call   a1870 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys4sync7condvar5futexNtB2_7Condvar21wait_optional_timeout.llvm.13342753452097612697>
    0.00 :   cb832:  movzbl 0x24(%r14),%eax
    0.00 :   cb837:  mov    0x10(%r14),%rax
    0.00 :   cb83b:  cmp    0x38(%rsp),%rax
    0.00 :   cb840:  je     cb75d <std::sys::backtrace::__rust_begin_short_backtrace+0xecd>
    0.00 :   cb846:  lock decq 0x18(%r14)
    0.00 :   cb84b:  cmpb   $0x0,0x14(%rsp)
    0.00 :   cb850:  jne    cb86b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cb852:  mov    0xc5af7(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cb859:  mov    (%rax),%rax
    0.00 :   cb85c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb866:  test   %rcx,%rax
    0.00 :   cb869:  jne    cb8dc <std::sys::backtrace::__rust_begin_short_backtrace+0x104c>
    0.00 :   cb86b:  xor    %eax,%eax
    0.00 :   cb86d:  mov    0x50(%rsp),%rsi
    0.00 :   cb872:  xchg   %eax,(%rsi)
    0.00 :   cb874:  cmp    $0x2,%eax
    0.00 :   cb877:  je     cb8c3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1033>
    0.00 :   cb879:  movabs $0x7fffffffffffffff,%rax
    0.00 :   cb883:  lock and %rax,0x40(%rbx)
    0.00 :   cb888:  xor    %eax,%eax
    0.00 :   cb88a:  mov    0x8(%rsp),%rdi
    0.00 :   cb88f:  jmp    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb894:  xor    %eax,%eax
    0.00 :   cb896:  jmp    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb89b:  lea    0x20(%r14),%rdi
    0.00 :   cb89f:  call   *0xc5b23(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cb8a5:  jmp    cb5df <std::sys::backtrace::__rust_begin_short_backtrace+0xd4f>
    0.00 :   cb8aa:  call   *0xc5ac0(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cb8b0:  mov    %eax,0x14(%rsp)
    0.00 :   cb8b4:  mov    0x14(%rsp),%eax
    0.00 :   cb8b8:  xor    $0x1,%al
    0.00 :   cb8ba:  mov    %eax,0x14(%rsp)
    0.00 :   cb8be:  jmp    cb604 <std::sys::backtrace::__rust_begin_short_backtrace+0xd74>
    0.00 :   cb8c3:  mov    $0xca,%edi
    0.00 :   cb8c8:  mov    $0x81,%edx
    0.00 :   cb8cd:  mov    $0x1,%ecx
    0.00 :   cb8d2:  xor    %eax,%eax
    0.00 :   cb8d4:  call   *0xc5aa6(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cb8da:  jmp    cb879 <std::sys::backtrace::__rust_begin_short_backtrace+0xfe9>
    0.00 :   cb8dc:  call   *0xc5a8e(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cb8e2:  test   %al,%al
    0.00 :   cb8e4:  jne    cb86b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cb8e6:  movb   $0x1,0x24(%r14)
    0.00 :   cb8eb:  jmp    cb86b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cb8f0:  movups 0x128(%rsp),%xmm0
    0.00 :   cb8f8:  movups 0x138(%rsp),%xmm1
    0.00 :   cb900:  movups 0x148(%rsp),%xmm2
    0.00 :   cb908:  mov    0x158(%rsp),%rcx
    0.00 :   cb910:  mov    %rcx,0x3e0(%rsp)
    0.00 :   cb918:  movups %xmm2,0x3d0(%rsp)
    0.00 :   cb920:  movups %xmm1,0x3c0(%rsp)
    0.00 :   cb928:  mov    %rax,0x3a8(%rsp)
    0.00 :   cb930:  movups %xmm0,0x3b0(%rsp)
    0.00 :   cb938:  movq   $0x0,0x58(%rsp)
    0.00 :   cb941:  movq   $0x1,0x60(%rsp)
    0.00 :   cb94a:  movq   $0x0,0x68(%rsp)
    0.00 :   cb953:  movq   $0x60000020,0x130(%rsp)
    0.00 :   cb95f:  lea    0x58(%rsp),%rax
    0.00 :   cb964:  mov    %rax,0x120(%rsp)
    0.00 :   cb96c:  lea    0xc0c65(%rip),%rax        # 18c5d8 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0xe8>
    0.00 :   cb973:  mov    %rax,0x128(%rsp)
    0.00 :   cb97b:  lea    0x3a8(%rsp),%rdi
    0.00 :   cb983:  lea    0x120(%rsp),%rsi
    0.00 :   cb98b:  call   *0xc6647(%rip)        # 191fd8 <_DYNAMIC+0x1218>
    0.00 :   cb991:  test   %al,%al
    0.00 :   cb993:  jne    cbe13 <std::sys::backtrace::__rust_begin_short_backtrace+0x1583>
    0.00 :   cb999:  mov    0x58(%rsp),%rbx
    0.00 :   cb99e:  mov    0x60(%rsp),%r15
    0.00 :   cb9a3:  mov    0x68(%rsp),%r14
    0.00 :   cb9a8:  mov    $0x18,%edi
    0.00 :   cb9ad:  call   *0xc5655(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   cb9b3:  test   %rax,%rax
    0.00 :   cb9b6:  je     cbe3d <std::sys::backtrace::__rust_begin_short_backtrace+0x15ad>
    0.00 :   cb9bc:  mov    %rbx,(%rax)
    0.00 :   cb9bf:  mov    %r15,0x8(%rax)
    0.00 :   cb9c3:  mov    %r14,0x10(%rax)
    0.00 :   cb9c7:  lea    0xc236a(%rip),%rdx        # 18dd38 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x4c8>
    0.00 :   cb9ce:  lea    0x58(%rsp),%rdi
    0.00 :   cb9d3:  mov    %rax,%rsi
    0.00 :   cb9d6:  mov    0x18(%rsp),%r12
    0.00 :   cb9db:  mov    0x20(%rsp),%r13
    0.00 :   cb9e0:  call   *0xc6532(%rip)        # 191f18 <_DYNAMIC+0x1158>
    0.00 :   cb9e6:  lea    0x3a8(%rsp),%rdi
    0.00 :   cb9ee:  call   d75c0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10013882635303053058>
    0.00 :   cb9f3:  lea    0x58(%rsp),%rsi
    0.00 :   cb9f8:  mov    %r13,%rdi
    0.00 :   cb9fb:  call   118070 <vthread::carrier::record_failure>
    0.00 :   cba00:  mov    0x8(%rsp),%rax
    0.00 :   cba05:  mov    0x1a0(%rax),%rbx
    0.00 :   cba0c:  lea    0x88(%rbx),%r14
    0.00 :   cba13:  mov    $0x1,%ecx
    0.00 :   cba18:  xor    %eax,%eax
    0.00 :   cba1a:  lock cmpxchg %ecx,0x88(%rbx)
    0.00 :   cba22:  jne    cbda7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1517>
    0.00 :   cba28:  mov    0xc5921(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cba2f:  mov    (%rax),%rax
    0.00 :   cba32:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cba3c:  test   %rcx,%rax
    0.00 :   cba3f:  jne    cbdb5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1525>
    0.00 :   cba45:  lea    0x8c(%rbx),%r15
    0.00 :   cba4c:  movzbl 0x8c(%rbx),%eax
    0.00 :   cba53:  movb   $0x1,0xc8(%rbx)
    0.00 :   cba5a:  mov    0xc58ef(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cba61:  mov    (%rax),%rax
    0.00 :   cba64:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cba6e:  test   %rcx,%rax
    0.00 :   cba71:  jne    cbdfc <std::sys::backtrace::__rust_begin_short_backtrace+0x156c>
    0.00 :   cba77:  xor    %eax,%eax
    0.00 :   cba79:  xchg   %eax,(%r14)
    0.00 :   cba7c:  cmp    $0x2,%eax
    0.00 :   cba7f:  je     cbddd <std::sys::backtrace::__rust_begin_short_backtrace+0x154d>
    0.00 :   cba85:  movb   $0x1,0xeb(%rbx)
    0.00 :   cba8c:  mov    0xd8(%rbx),%rdi
    0.00 :   cba93:  add    $0x10,%rdi
    0.00 :   cba97:  call   117f50 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10013882635303053058>
    0.00 :   cba9c:  mov    0x8(%rsp),%rdi
    0.00 :   cbaa1:  xor    %esi,%esi
    0.00 :   cbaa3:  mov    $0x4,%ecx
    0.00 :   cbaa8:  call   1131f0 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cbaad:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbab5:  mov    0x8(%rsp),%rsi
    0.00 :   cbaba:  mov    $0x3,%edx
    0.00 :   cbabf:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbac4:  movq   $0x0,0x450(%rsp)
    0.00 :   cbad0:  mov    0x8(%rsp),%rax
    0.00 :   cbad5:  mov    0x198(%rax),%rdi
    0.00 :   cbadc:  add    $0x10,%rdi
    0.00 :   cbae0:  lea    0x3a8(%rsp),%rsi
    0.00 :   cbae8:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cbaed:  jmp    cbb46 <std::sys::backtrace::__rust_begin_short_backtrace+0x12b6>
    0.00 :   cbaef:  mov    %rdi,%rbx
    0.00 :   cbaf2:  xor    %esi,%esi
    0.00 :   cbaf4:  mov    $0x3,%ecx
    0.00 :   cbaf9:  mov    0x20(%rsp),%r13
    0.00 :   cbafe:  call   1131f0 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cbb03:  lea    0x120(%rsp),%rdi
    0.00 :   cbb0b:  mov    %rbx,%rsi
    0.00 :   cbb0e:  mov    $0x2,%edx
    0.00 :   cbb13:  mov    0x18(%rsp),%r12
    0.00 :   cbb18:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbb1d:  movq   $0x0,0x1c8(%rsp)
    0.00 :   cbb29:  mov    0x8(%rsp),%rax
    0.00 :   cbb2e:  mov    0x198(%rax),%rdi
    0.00 :   cbb35:  add    $0x10,%rdi
    0.00 :   cbb39:  lea    0x120(%rsp),%rsi
    0.00 :   cbb41:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cbb46:  mov    0xa0(%r12),%rsi
    0.00 :   cbb4e:  mov    0x28(%rsp),%rcx
    0.00 :   cbb53:  cmp    %rsi,%rcx
    0.00 :   cbb56:  jae    cbeb0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1620>
    0.00 :   cbb5c:  mov    0x98(%r12),%rax
    0.00 :   cbb64:  mov    (%rax,%rcx,8),%rax
    0.00 :   cbb68:  movb   $0x1,0xe9(%rax)
    0.00 :   cbb6f:  mov    0x8(%rsp),%rcx
    0.00 :   cbb74:  cmpl   $0x2,(%rcx)
    0.00 :   cbb77:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbb7d:  cmpq   $0x0,0x178(%rcx)
    0.00 :   cbb85:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbb8b:  cmpq   $0x0,0x1b8(%rcx)
    0.00 :   cbb93:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbb99:  cmpq   $0x0,0xf8(%rcx)
    0.00 :   cbba1:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbba7:  cmpq   $0x0,0x118(%rcx)
    0.00 :   cbbaf:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbb5:  cmpq   $0x0,0x158(%rcx)
    0.00 :   cbbbd:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbc3:  mov    0x90(%rcx),%rax
    0.00 :   cbbca:  cmp    0xa8(%rcx),%rax
    0.00 :   cbbd1:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbd7:  mov    0xc0(%rcx),%rax
    0.00 :   cbbde:  cmp    0xd8(%rcx),%rax
    0.00 :   cbbe5:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbe7:  cmpq   $0x0,0x60(%rcx)
    0.00 :   cbbec:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbee:  mov    0x198(%rcx),%rax
    0.00 :   cbbf5:  mov    0x1b0(%rcx),%rdi
    0.00 :   cbbfc:  mov    0x88(%rax),%rsi
    0.00 :   cbc03:  cmp    %rsi,%rdi
    0.00 :   cbc06:  jae    cbec7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1637>
    0.00 :   cbc0c:  mov    0x80(%rax),%rax
    0.00 :   cbc13:  shl    $0x6,%rdi
    0.00 :   cbc17:  mov    (%rax,%rdi,1),%rax
    0.00 :   cbc1b:  test   %rax,%rax
    0.00 :   cbc1e:  mov    0x8(%rsp),%rdi
    0.00 :   cbc23:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbc25:  mov    0x1a8(%rdi),%rax
    0.00 :   cbc2c:  cmpq   $0x0,0x98(%rax)
    0.00 :   cbc34:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbc36:  cmpq   $0x0,0xc8(%rax)
    0.00 :   cbc3e:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbc40:  mov    0x1a0(%rdi),%rax
    0.00 :   cbc47:  mov    0xd0(%rax),%rax
    0.00 :   cbc4e:  test   %rax,%rax
    0.00 :   cbc51:  je     cbe5c <std::sys::backtrace::__rust_begin_short_backtrace+0x15cc>
    0.00 :   cbc57:  mov    $0x10,%edi
    0.00 :   cbc5c:  call   *0xc53a6(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   cbc62:  test   %rax,%rax
    0.00 :   cbc65:  je     cbd92 <std::sys::backtrace::__rust_begin_short_backtrace+0x1502>
    0.00 :   cbc6b:  lea    -0xad227(%rip),%rcx        # 1ea4b <anon.cccb389264607a2d4c2b49e143c9c1b6.746.llvm.10013882635303053058+0x321>
    0.00 :   cbc72:  mov    %rcx,(%rax)
    0.00 :   cbc75:  movq   $0x1a,0x8(%rax)
    0.00 :   cbc7d:  lea    0xc1a34(%rip),%rdx        # 18d6b8 <anon.cccb389264607a2d4c2b49e143c9c1b6.433.llvm.10013882635303053058+0x858>
    0.00 :   cbc84:  lea    0xe0(%rsp),%rdi
    0.00 :   cbc8c:  mov    %rax,%rsi
    0.00 :   cbc8f:  call   *0xc6283(%rip)        # 191f18 <_DYNAMIC+0x1158>
    0.00 :   cbc95:  lea    0xe0(%rsp),%rsi
    0.00 :   cbc9d:  mov    %r13,%rdi
    0.00 :   cbca0:  call   118070 <vthread::carrier::record_failure>
    0.00 :   cbca5:  mov    0x8(%rsp),%rsi
    0.00 :   cbcaa:  movb   $0x0,0x27e(%rsi)
    0.00 :   cbcb1:  mov    0x198(%rsi),%r14
    0.00 :   cbcb8:  lea    0x480(%rsp),%rdi
    0.00 :   cbcc0:  mov    $0x3,%edx
    0.00 :   cbcc5:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbcca:  add    $0x10,%r14
    0.00 :   cbcce:  lea    0x480(%rsp),%rsi
    0.00 :   cbcd6:  mov    %r14,%rdi
    0.00 :   cbcd9:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cbcde:  mov    %r13,%rdi
    0.00 :   cbce1:  call   120fe0 <_ZN7vthread7control6Shared12request_stop17hb40bf47e89bed244E.llvm.10013882635303053058>
    0.00 :   cbce6:  lea    0x40(%rsp),%rdi
    0.00 :   cbceb:  call   *0xc62ef(%rip)        # 191fe0 <_DYNAMIC+0x1220>
    0.00 :   cbcf1:  mov    0x40(%rsp),%rax
    0.00 :   cbcf6:  test   %rax,%rax
    0.00 :   cbcf9:  je     cbd21 <std::sys::backtrace::__rust_begin_short_backtrace+0x1491>
    0.00 :   cbcfb:  lock decq (%rax)
    0.00 :   cbcff:  jne    cbd0c <std::sys::backtrace::__rust_begin_short_backtrace+0x147c>
    0.00 :   cbd01:  lea    0x40(%rsp),%rdi
    0.00 :   cbd06:  call   *0xc621c(%rip)        # 191f28 <_DYNAMIC+0x1168>
    0.00 :   cbd0c:  mov    0x48(%rsp),%rax
    0.00 :   cbd11:  decq   (%rax)
    0.00 :   cbd14:  jne    cbd21 <std::sys::backtrace::__rust_begin_short_backtrace+0x1491>
    0.00 :   cbd16:  lea    0x48(%rsp),%rdi
    0.00 :   cbd1b:  call   *0xc620f(%rip)        # 191f30 <_DYNAMIC+0x1170>
    0.00 :   cbd21:  lock decq (%r12)
    0.00 :   cbd26:  jne    cbd36 <std::sys::backtrace::__rust_begin_short_backtrace+0x14a6>
    0.00 :   cbd28:  lea    0x98(%rsp),%rdi
    0.00 :   cbd30:  call   *0xc6282(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cbd36:  lock decq (%r12)
    0.00 :   cbd3b:  jne    cbd4b <std::sys::backtrace::__rust_begin_short_backtrace+0x14bb>
    0.00 :   cbd3d:  lea    0xc0(%rsp),%rdi
    0.00 :   cbd45:  call   *0xc626d(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cbd4b:  add    $0x558,%rsp
    0.00 :   cbd52:  pop    %rbx
    0.00 :   cbd53:  pop    %r12
    0.00 :   cbd55:  pop    %r13
    0.00 :   cbd57:  pop    %r14
    0.00 :   cbd59:  pop    %r15
    0.00 :   cbd5b:  pop    %rbp
    0.00 :   cbd5c:  ret
    0.00 :   cbd5d:  lea    -0xad346(%rip),%rdi        # 1ea1e <anon.cccb389264607a2d4c2b49e143c9c1b6.746.llvm.10013882635303053058+0x2f4>
    0.00 :   cbd64:  lea    0xc1ef5(%rip),%rdx        # 18dc60 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x3f0>
    0.00 :   cbd6b:  mov    $0x19,%esi
    0.00 :   cbd70:  mov    0x20(%rsp),%r13
    0.00 :   cbd75:  call   *0xc546d(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   cbd7b:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbd80:  lea    0xc1fe9(%rip),%rdi        # 18dd70 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x500>
    0.00 :   cbd87:  call   *0xc543b(%rip)        # 1911c8 <_DYNAMIC+0x408>
    0.00 :   cbd8d:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbd92:  mov    $0x8,%edi
    0.00 :   cbd97:  mov    $0x10,%esi
    0.00 :   cbd9c:  call   *0xc528e(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   cbda2:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbda7:  mov    %r14,%rdi
    0.00 :   cbdaa:  call   *0xc5618(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cbdb0:  jmp    cba28 <std::sys::backtrace::__rust_begin_short_backtrace+0x1198>
    0.00 :   cbdb5:  call   *0xc55b5(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cbdbb:  movzbl 0x8c(%rbx),%ecx
    0.00 :   cbdc2:  movb   $0x1,0xc8(%rbx)
    0.00 :   cbdc9:  test   %al,%al
    0.00 :   cbdcb:  je     cba77 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cbdd1:  lea    0x8c(%rbx),%r15
    0.00 :   cbdd8:  jmp    cba5a <std::sys::backtrace::__rust_begin_short_backtrace+0x11ca>
    0.00 :   cbddd:  mov    $0xca,%edi
    0.00 :   cbde2:  mov    %r14,%rsi
    0.00 :   cbde5:  mov    $0x81,%edx
    0.00 :   cbdea:  mov    $0x1,%ecx
    0.00 :   cbdef:  xor    %eax,%eax
    0.00 :   cbdf1:  call   *0xc5589(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cbdf7:  jmp    cba85 <std::sys::backtrace::__rust_begin_short_backtrace+0x11f5>
    0.00 :   cbdfc:  call   *0xc556e(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cbe02:  test   %al,%al
    0.00 :   cbe04:  jne    cba77 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cbe0a:  movb   $0x1,(%r15)
    0.00 :   cbe0e:  jmp    cba77 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cbe13:  lea    -0xaea3f(%rip),%rdi        # 1d3db <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x73>
    0.00 :   cbe1a:  lea    0xc085f(%rip),%rcx        # 18c680 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x20>
    0.00 :   cbe21:  lea    0xc07e0(%rip),%r8        # 18c608 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0x118>
    0.00 :   cbe28:  lea    0x37(%rsp),%rdx
    0.00 :   cbe2d:  mov    $0x37,%esi
    0.00 :   cbe32:  call   *0xc51f0(%rip)        # 191028 <_DYNAMIC+0x268>
    0.00 :   cbe38:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbe3d:  mov    $0x8,%edi
    0.00 :   cbe42:  mov    $0x18,%esi
    0.00 :   cbe47:  mov    0x18(%rsp),%r12
    0.00 :   cbe4c:  mov    0x20(%rsp),%r13
    0.00 :   cbe51:  call   *0xc51d9(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   cbe57:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbe5c:  call   d7960 <core::ptr::drop_in_place<vthread::kernel::Kernel>>
    0.00 :   cbe61:  mov    0x8(%rsp),%rdi
    0.00 :   cbe66:  call   *0xc5184(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cbe6c:  mov    0x18(%rsp),%rax
    0.00 :   cbe71:  mov    0xa0(%rax),%rsi
    0.00 :   cbe78:  cmp    %rsi,0x28(%rsp)
    0.00 :   cbe7d:  jae    cbed9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1649>
    0.00 :   cbe7f:  mov    0x18(%rsp),%r12
    0.00 :   cbe84:  mov    0x98(%r12),%rax
    0.00 :   cbe8c:  mov    0x28(%rsp),%rcx
    0.00 :   cbe91:  mov    (%rax,%rcx,8),%rax
    0.00 :   cbe95:  movb   $0x1,0xea(%rax)
    0.00 :   cbe9c:  jmp    cbce6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1456>
    0.00 :   cbea1:  lea    0xc1dd0(%rip),%rdx        # 18dc78 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x408>
    0.00 :   cbea8:  call   *0xc511a(%rip)        # 190fc8 <_DYNAMIC+0x208>
    0.00 :   cbeae:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbeb0:  xor    %r15d,%r15d
    0.00 :   cbeb3:  lea    0xc1e4e(%rip),%rdx        # 18dd08 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x498>
    0.00 :   cbeba:  mov    0x28(%rsp),%rdi
    0.00 :   cbebf:  call   *0xc5103(%rip)        # 190fc8 <_DYNAMIC+0x208>
    0.00 :   cbec5:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbec7:  xor    %r15d,%r15d
    0.00 :   cbeca:  lea    0xc1e1f(%rip),%rdx        # 18dcf0 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x480>
    0.00 :   cbed1:  call   *0xc50f1(%rip)        # 190fc8 <_DYNAMIC+0x208>
    0.00 :   cbed7:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbed9:  xor    %r15d,%r15d
    0.00 :   cbedc:  lea    0xc1e3d(%rip),%rdx        # 18dd20 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x4b0>
    0.00 :   cbee3:  mov    0x28(%rsp),%rdi
    0.00 :   cbee8:  call   *0xc50da(%rip)        # 190fc8 <_DYNAMIC+0x208>
    0.00 :   cbeee:  ud2
    0.00 :   cbef0:  mov    %rax,%r14
    0.00 :   cbef3:  mov    0x8(%rsp),%rdi
    0.00 :   cbef8:  call   *0xc50f2(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cbefe:  xor    %r15d,%r15d
    0.00 :   cbf01:  jmp    cbf7d <std::sys::backtrace::__rust_begin_short_backtrace+0x16ed>
    0.00 :   cbf03:  mov    %rax,%r14
    0.00 :   cbf06:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbf0e:  call   dc4e0 <core::ptr::drop_in_place<vthread::context::wake::mount_carrier::{{closure}}>>
    0.00 :   cbf13:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cbf18:  call   *0xc52e2(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbf1e:  mov    %rax,%r14
    0.00 :   cbf21:  movzbl 0x14(%rsp),%esi
    0.00 :   cbf26:  mov    0x50(%rsp),%rdi
    0.00 :   cbf2b:  call   db660 <_ZN4core3ptr73drop_in_place$LT$std..sync..poison..mutex..MutexGuard$LT$$LP$$RP$$GT$$GT$17h714f23ec911ea948E.llvm.10013882635303053058>
    0.00 :   cbf30:  jmp    cbfc2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1732>
    0.00 :   cbf35:  call   *0xc52c5(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbf3b:  mov    %rax,%r14
    0.00 :   cbf3e:  movzbl 0x14(%rsp),%esi
    0.00 :   cbf43:  mov    0x50(%rsp),%rdi
    0.00 :   cbf48:  call   db660 <_ZN4core3ptr73drop_in_place$LT$std..sync..poison..mutex..MutexGuard$LT$$LP$$RP$$GT$$GT$17h714f23ec911ea948E.llvm.10013882635303053058>
    0.00 :   cbf4d:  jmp    cbfc2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1732>
    0.00 :   cbf4f:  call   *0xc52ab(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbf55:  mov    %rax,%r14
    0.00 :   cbf58:  jmp    cc014 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cbf5d:  mov    %rax,%r14
    0.00 :   cbf60:  lea    0x40(%rsp),%rdi
    0.00 :   cbf65:  call   dc420 <core::ptr::drop_in_place<core::option::Option<vthread::context::wake::CarrierRoute>>>
    0.00 :   cbf6a:  mov    0x18(%rsp),%r12
    0.00 :   cbf6f:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cbf74:  call   *0xc5286(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbf7a:  mov    %rax,%r14
    0.00 :   cbf7d:  mov    %r15,%rdi
    0.00 :   cbf80:  mov    %r12,%rsi
    0.00 :   cbf83:  call   d5c20 <core::ptr::drop_in_place<core::result::Result<(),alloc::boxed::Box<dyn core::any::Any+core::marker::Send>>>>
    0.00 :   cbf88:  mov    0x18(%rsp),%r12
    0.00 :   cbf8d:  jmp    cc0a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1810>
    0.00 :   cbf92:  mov    %rax,%r14
    0.00 :   cbf95:  lock decq (%r12)
    0.00 :   cbf9a:  jne    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cbfa0:  lea    0xd0(%rsp),%rdi
    0.00 :   cbfa8:  call   *0xc600a(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cbfae:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cbfb3:  mov    %rax,%r14
    0.00 :   cbfb6:  movzbl %bpl,%esi
    0.00 :   cbfba:  mov    %r13,%rdi
    0.00 :   cbfbd:  call   d4e30 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::thread_failure::ThreadFailures>>>
    0.00 :   cbfc2:  mov    %r14,%rdi
    0.00 :   cbfc5:  jmp    cbfd2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1742>
    0.00 :   cbfc7:  call   *0xc5233(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbfcd:  jmp    cbfcf <std::sys::backtrace::__rust_begin_short_backtrace+0x173f>
    0.00 :   cbfcf:  mov    %rax,%rdi
    0.00 :   cbfd2:  mov    0x18(%rsp),%r12
    0.00 :   cbfd7:  mov    0x20(%rsp),%r13
    0.00 :   cbfdc:  jmp    cc161 <std::sys::backtrace::__rust_begin_short_backtrace+0x18d1>
    0.00 :   cbfe1:  mov    %rax,%r14
    0.00 :   cbfe4:  test   %rbx,%rbx
    0.00 :   cbfe7:  je     cc014 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cbfe9:  mov    %r15,%rdi
    0.00 :   cbfec:  call   *0xc4ffe(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cbff2:  jmp    cc014 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cbff4:  mov    %rax,%r14
    0.00 :   cbff7:  cmpq   $0x0,0x58(%rsp)
    0.00 :   cbffd:  je     cc00a <std::sys::backtrace::__rust_begin_short_backtrace+0x177a>
    0.00 :   cbfff:  mov    0x60(%rsp),%rdi
    0.00 :   cc004:  call   *0xc4fe6(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cc00a:  mov    0x18(%rsp),%r12
    0.00 :   cc00f:  mov    0x20(%rsp),%r13
    0.00 :   cc014:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc01c:  call   d75c0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10013882635303053058>
    0.00 :   cc021:  mov    %r14,%rdi
    0.00 :   cc024:  call   *0xc57ae(%rip)        # 1917d8 <_DYNAMIC+0xa18>
    0.00 :   cc02a:  mov    0xc531f(%rip),%rcx        # 191350 <_DYNAMIC+0x590>
    0.00 :   cc031:  lock decq (%rcx)
    0.00 :   cc035:  decq   %fs:0xffffffffffffff70
    0.00 :   cc03e:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cc047:  mov    0xa0(%r12),%rsi
    0.00 :   cc04f:  mov    0x28(%rsp),%rdi
    0.00 :   cc054:  cmp    %rsi,%rdi
    0.00 :   cc057:  jae    cc071 <std::sys::backtrace::__rust_begin_short_backtrace+0x17e1>
    0.00 :   cc059:  mov    0x98(%r12),%rcx
    0.00 :   cc061:  mov    (%rcx,%rdi,8),%rcx
    0.00 :   cc065:  movb   $0x1,0xe9(%rcx)
    0.00 :   cc06c:  jmp    cbc84 <std::sys::backtrace::__rust_begin_short_backtrace+0x13f4>
    0.00 :   cc071:  mov    %rdx,%r12
    0.00 :   cc074:  mov    %rax,%r15
    0.00 :   cc077:  jmp    cbeb3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1623>
    0.00 :   cc07c:  call   *0xc517e(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc082:  mov    %rax,%r14
    0.00 :   cc085:  lea    0x120(%rsp),%rdi
    0.00 :   cc08d:  call   dc420 <core::ptr::drop_in_place<core::option::Option<vthread::context::wake::CarrierRoute>>>
    0.00 :   cc092:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc097:  call   *0xc5163(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc09d:  mov    %rax,%r14
    0.00 :   cc0a0:  lea    0x40(%rsp),%rdi
    0.00 :   cc0a5:  call   dac60 <core::ptr::drop_in_place<vthread::context::wake::CarrierRouteGuard>>
    0.00 :   cc0aa:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc0af:  mov    %rax,%r14
    0.00 :   cc0b2:  lea    0x120(%rsp),%rdi
    0.00 :   cc0ba:  call   d7960 <core::ptr::drop_in_place<vthread::kernel::Kernel>>
    0.00 :   cc0bf:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc0c4:  call   *0xc5136(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc0ca:  mov    %rax,%r14
    0.00 :   cc0cd:  lea    0x120(%rsp),%rdi
    0.00 :   cc0d5:  call   dc0b0 <core::ptr::drop_in_place<alloc::rc::RcInner<vthread::local_carrier::LocalCarrier>>>
    0.00 :   cc0da:  lea    0xa0(%rsp),%rdi
    0.00 :   cc0e2:  call   dcb90 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::rc::Rc<vthread::context::Execution>>>>
    0.00 :   cc0e7:  lea    0xe0(%rsp),%rdi
    0.00 :   cc0ef:  call   dce20 <core::ptr::drop_in_place<alloc::collections::vec_deque::VecDeque<vthread::inbox::SpawnPacket>>>
    0.00 :   cc0f4:  lea    0x100(%rsp),%rdi
    0.00 :   cc0fc:  call   dbb50 <core::ptr::drop_in_place<core::option::Option<vthread::inbox::SpawnPacket>>>
    0.00 :   cc101:  lea    0x58(%rsp),%rdi
    0.00 :   cc106:  call   dade0 <core::ptr::drop_in_place<vthread::kernel::parked_tasks::ParkedTasks>>
    0.00 :   cc10b:  lea    0x480(%rsp),%rdi
    0.00 :   cc113:  call   d9780 <core::ptr::drop_in_place<vthread::ready_queue::ReadyQueue>>
    0.00 :   cc118:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc120:  call   d9950 <core::ptr::drop_in_place<vthread::kernel_tasks::KernelTasks>>
    0.00 :   cc125:  lock decq (%r12)
    0.00 :   cc12a:  jne    cc137 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a7>
    0.00 :   cc12c:  lea    0x40(%rsp),%rdi
    0.00 :   cc131:  call   *0xc5e81(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cc137:  lock decq (%rbx)
    0.00 :   cc13b:  jne    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc13d:  lea    0xd8(%rsp),%rdi
    0.00 :   cc145:  call   *0xc5e9d(%rip)        # 191fe8 <_DYNAMIC+0x1228>
    0.00 :   cc14b:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc14d:  call   *0xc50ad(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc153:  call   *0xc50a7(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc159:  mov    %rax,%rdi
    0.00 :   cc15c:  mov    0x18(%rsp),%r12
    0.00 :   cc161:  call   *0xc5671(%rip)        # 1917d8 <_DYNAMIC+0xa18>
    0.00 :   cc167:  mov    0xc51e2(%rip),%rcx        # 191350 <_DYNAMIC+0x590>
    0.00 :   cc16e:  lock decq (%rcx)
    0.00 :   cc172:  decq   %fs:0xffffffffffffff70
    0.00 :   cc17b:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cc184:  lea    0x58(%rsp),%rdi
    0.00 :   cc189:  mov    %rax,%rsi
    0.00 :   cc18c:  call   *0xc5d86(%rip)        # 191f18 <_DYNAMIC+0x1158>
    0.00 :   cc192:  jmp    cb9f3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1163>
    0.00 :   cc197:  mov    %rax,%r14
    0.00 :   cc19a:  jmp    cc021 <std::sys::backtrace::__rust_begin_short_backtrace+0x1791>
    0.00 :   cc19f:  mov    %rax,%r14
    0.00 :   cc1a2:  jmp    cc1bc <std::sys::backtrace::__rust_begin_short_backtrace+0x192c>
    0.00 :   cc1a4:  mov    %rax,%r14
    0.00 :   cc1a7:  lock decq (%r12)
    0.00 :   cc1ac:  jne    cc1bc <std::sys::backtrace::__rust_begin_short_backtrace+0x192c>
    0.00 :   cc1ae:  lea    0x98(%rsp),%rdi
    0.00 :   cc1b6:  call   *0xc5dfc(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cc1bc:  lock decq (%r12)
    0.00 :   cc1c1:  jne    cc1d1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1941>
    0.00 :   cc1c3:  lea    0xc0(%rsp),%rdi
    0.00 :   cc1cb:  call   *0xc5de7(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cc1d1:  mov    %r14,%rdi
    0.00 :   cc1d4:  call   186a90 <_Unwind_Resume@plt>
    0.00 :   cc1d9:  call   *0xc5021(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc1df:  call   *0xc501b(%rip)        # 191200 <_DYNAMIC+0x440>
