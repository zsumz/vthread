"""Targeted diagnostic-only checks and feature-on builds, never timing acceptance."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, '/root/vthread/scripts')
import evidence

BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_TARGET_DIR=str(BUILD))


def run(arm, label, command, expected=0):
    prefix = f'probe-{arm}-{label}'
    with (OUT / f'{prefix}.command.json').open('x') as stream:
        json.dump(command, stream)
    with (OUT / f'{prefix}.log').open('x') as stream:
        result = subprocess.run(command, cwd=OUT / f'probe{arm}', env=env,
                                stdout=stream, stderr=subprocess.STDOUT)
    with (OUT / f'{prefix}.result.json').open('x') as stream:
        json.dump({'returncode': result.returncode, 'expected': expected}, stream)
    assert result.returncode == expected, (prefix, result.returncode, expected)
    print(f'completed {prefix}', flush=True)


def qualify(arm):
    root = OUT / f'probe{arm}'
    run(arm, 'fmt', ['cargo', 'fmt', '--all'])
    run(arm, 'fmt-bench', ['cargo', 'fmt', '--manifest-path', 'benchmarks/Cargo.toml', '--all'])
    run(arm, 'native', ['cargo', 'test', '--locked', '-p', 'vthread', '--features',
                       'handoff-profiling', 'handoff_channel_test', '--', '--nocapture'])
    run(arm, 'report', ['cargo', 'test', '--locked', '--manifest-path', 'benchmarks/Cargo.toml',
                       '--features', 'handoff-profiling', 'handoff_profile', '--', '--nocapture'])
    run(arm, 'build', ['cargo', 'build', '--locked', '--release', '--manifest-path',
                      'benchmarks/Cargo.toml', '--features', 'handoff-profiling'])
    binary = OUT / f'probe-{arm}-benchmark'
    assert not binary.exists()
    shutil.copy2(BUILD / 'release/vthread-benchmarks', binary)
    evidence.ROOT = root
    manifest = evidence.metadata('diagnostic attachment/rearm/retirement counts; timed handoff instrumentation enabled; no performance acceptance')
    manifest['binary_sha256'] = evidence.digest(binary)
    manifest['features'] = ['handoff-profiling']
    with (OUT / f'probe-{arm}-source.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)


if __name__ == '__main__':
    for arm in sys.argv[1:]:
        qualify(arm)
