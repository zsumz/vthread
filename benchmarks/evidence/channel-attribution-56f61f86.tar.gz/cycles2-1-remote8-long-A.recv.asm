 Percent |	Source code & Disassembly of baseline-benchmark for cycles:u (479 samples, percent: global period)
------------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3      Disassembly of section .text:
         :
         : 5      00000000001743a0 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv>:
         : 6      vthread::channel::core::<impl vthread::channel::Core<T>>::recv:
    0.00 :   1743a0: push   %rbp
    0.00 :   1743a1: push   %r15
    0.00 :   1743a3: push   %r14
    0.00 :   1743a5: push   %r13
    0.00 :   1743a7: push   %r12
    0.00 :   1743a9: push   %rbx
    0.00 :   1743aa: sub    $0xc8,%rsp
    0.00 :   1743b1: mov    %rsi,%r14
    0.00 :   1743b4: mov    %rdi,%r15
    0.00 :   1743b7: movabs $0x8000000000000022,%rbx
    0.00 :   1743c1: lea    0x48(%rsp),%rdi
    0.00 :   1743c6: call   175e70 <vthread::context::check_current>
    0.00 :   1743cb: cmp    %rbx,0x48(%rsp)
    0.00 :   1743d0: jne    17466c <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2cc>
    0.00 :   1743d6: mov    %r15,0x8(%rsp)
    0.00 :   1743db: movq   $0x11,0x10(%rsp)
    0.00 :   1743e4: mov    %r14,0x98(%rsp)
    0.00 :   1743ec: movw   $0x1,0xa0(%rsp)
    0.00 :   1743f6: movq   $0x0,0x88(%rsp)
    0.00 :   174402: lea    0x20(%rsp),%r12
    0.00 :   174407: lea    -0x7(%rbx),%r15
    0.00 :   17440b: lea    0x48(%rsp),%r13
    0.00 :   174410: lea    0x88(%rsp),%rbp
    0.00 :   174418: nopl   0x0(%rax,%rax,1)
    0.00 :   174420: xor    %eax,%eax
    0.00 :   174422: mov    $0x1,%cl
    0.00 :   174424: lock cmpxchg %cl,0x78(%r14)
    9.48 :   17442a: jne    1745b3 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x213>
    0.00 :   174430: cmpq   $0x0,0x18(%r14)
    0.22 :   174435: je     174451 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0xb1>
    0.00 :   174437: mov    %rbp,%rdi
    0.00 :   17443a: mov    %r14,%rsi
    0.00 :   17443d: call   175d40 <vthread::channel::wait::Ticket<T>::take_turn>
    0.00 :   174442: test   %al,%al
    0.00 :   174444: jne    174700 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x360>
    0.00 :   17444a: cmpq   $0x0,0x18(%r14)
    0.00 :   17444f: jne    174467 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0xc7>
    0.00 :   174451: cmpb   $0x0,0x70(%r14)
    0.71 :   174456: jne    174698 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2f8>
    0.00 :   17445c: cmpq   $0x0,0x60(%r14)
    0.00 :   174461: je     174698 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2f8>
    0.00 :   174467: cmpl   $0x11,0x10(%rsp)
    0.00 :   17446c: je     1744cd <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x12d>
    0.00 :   17446e: mov    0x20(%rsp),%rax
    0.00 :   174473: mov    0x18(%rax),%rax
    0.00 :   174477: mov    0x68(%rax),%ecx
    0.00 :   17447a: test   %ecx,%ecx
    0.00 :   17447c: jne    17494b <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5ab>
    0.00 :   174482: mov    0x60(%rax),%rcx
    0.00 :   174486: mov    %r13,%rdi
    0.00 :   174489: mov    %rbp,%rsi
    0.00 :   17448c: mov    %r14,%rdx
    0.00 :   17448f: call   175bf0 <vthread::channel::wait::Ticket<T>::enqueue>
    0.00 :   174494: cmp    %rbx,0x48(%rsp)
    0.00 :   174499: jne    1746a6 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x306>
    0.00 :   17449f: movb   $0x0,0x78(%r14)
    0.00 :   1744a4: cmpl   $0x11,0x10(%rsp)
    0.00 :   1744a9: je     174969 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5c9>
    0.00 :   1744af: mov    %r13,%rdi
    0.00 :   1744b2: lea    0x10(%rsp),%rsi
    0.00 :   1744b7: call   *0x1ddbb(%rip)        # 192278 <_DYNAMIC+0x14b8>
    0.00 :   1744bd: cmp    %rbx,0x48(%rsp)
    0.00 :   1744c2: je     174420 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x80>
    0.00 :   1744c8: jmp    1746d3 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x333>
    0.00 :   1744cd: mov    %r15,0xc0(%rsp)
    0.00 :   1744d5: movb   $0x0,0x78(%r14)
    0.00 :   1744da: call   *0x1dcc8(%rip)        # 1921a8 <_DYNAMIC+0x13e8>
    0.00 :   1744e0: mov    %rax,%r15
    0.00 :   1744e3: lea    -0x7(%rbx),%rax
    0.00 :   1744e7: mov    %rax,0x48(%rsp)
    0.00 :   1744ec: cmp    $0x2,%r15
    0.00 :   1744f0: je     1747ed <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x44d>
    0.00 :   1744f6: mov    %rdx,%r12
    0.00 :   1744f9: mov    %r13,%rdi
    0.00 :   1744fc: call   d75c0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10013882635303053058>
    0.00 :   174501: test   $0x1,%r15b
    0.00 :   174505: jne    1747ed <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x44d>
    0.00 :   17450b: mov    0x10(%r12),%rax
    0.00 :   174510: mov    0x38(%rax),%rax
    0.00 :   174514: mov    0x20(%rax),%rdx
    0.00 :   174518: mov    0x28(%rax),%rcx
    0.00 :   17451c: movq   $0x9,0x20(%rax)
    0.00 :   174524: mov    %rdx,0xa8(%rsp)
    0.00 :   17452c: mov    %rdx,0x30(%rsp)
    0.00 :   174531: mov    %rcx,0xb0(%rsp)
    0.00 :   174539: mov    %rcx,0x38(%rsp)
    0.00 :   17453e: mov    %r12,0x40(%rsp)
    0.00 :   174543: mov    %r12,0xb8(%rsp)
    0.00 :   17454b: mov    0x18(%r12),%r12
    0.00 :   174550: mov    0x68(%r12),%eax
    0.00 :   174555: add    $0x60,%r12
    0.00 :   174559: test   %eax,%eax
    0.00 :   17455b: lea    -0x7(%rbx),%r15
    0.21 :   17455f: jne    17465f <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2bf>
    0.00 :   174565: mov    (%r12),%rcx
    0.00 :   174569: mov    0x38(%rcx),%rax
    0.00 :   17456d: lea    0x40(%rsp),%rdi
    0.00 :   174572: data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   174580: mov    %eax,%edx
    0.00 :   174582: and    $0xf,%edx
    0.00 :   174585: cmp    $0xd,%edx
    0.00 :   174588: jae    174a17 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x677>
    0.00 :   17458e: test   $0xd0,%al
    0.00 :   174590: je     1745db <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x23b>
    0.00 :   174592: mov    %eax,%edx
    0.00 :   174594: and    $0x2f,%edx
    0.00 :   174597: jne    1745db <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x23b>
    0.00 :   174599: mov    %rax,%rdx
    0.00 :   17459c: and    $0xffffffffffffff00,%rdx
    0.00 :   1745a3: lock cmpxchg %rdx,0x38(%rcx)
    1.95 :   1745a9: jne    174580 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x1e0>
    0.00 :   1745ab: jmp    1745e3 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x243>
    0.00 :   1745ad: call   *0x1cf6d(%rip)        # 191520 <sched_yield@GLIBC_2.2.5>
    0.00 :   1745b3: xor    %ecx,%ecx
    0.00 :   1745b5: movzbl 0x78(%r14),%eax
   21.41 :   1745ba: test   %al,%al
    0.00 :   1745bc: jne    1745ce <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x22e>
    0.00 :   1745be: xor    %eax,%eax
    0.81 :   1745c0: mov    $0x1,%dl
    0.17 :   1745c2: lock cmpxchg %dl,0x78(%r14)
   19.13 :   1745c8: je     174430 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x90>
    0.00 :   1745ce: pause
   35.67 :   1745d0: inc    %rcx
    3.59 :   1745d3: cmp    $0x40,%rcx
    0.00 :   1745d7: jne    1745b5 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x215>
    0.00 :   1745d9: jmp    1745ad <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x20d>
    0.00 :   1745db: test   $0x2f,%al
    0.00 :   1745dd: jne    174987 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5e7>
    0.00 :   1745e3: mov    (%r12),%rax
    0.00 :   1745e7: mov    0x30(%rax),%rax
    0.00 :   1745eb: cmpq   $0x0,0x88(%rsp)
    0.00 :   1745f4: movq   $0x1,0x88(%rsp)
    0.00 :   174600: mov    %rax,0x90(%rsp)
    0.00 :   174608: jne    174a32 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x692>
    0.00 :   17460e: mov    0x10(%rsp),%rax
    0.00 :   174613: cmp    $0x11,%rax
    0.00 :   174617: lea    0x20(%rsp),%r12
    0.00 :   17461c: je     174646 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2a6>
    0.00 :   17461e: mov    0x18(%rsp),%rcx
    0.00 :   174623: mov    0x20(%rsp),%rdx
    0.00 :   174628: mov    0x10(%rdx),%rsi
    0.00 :   17462c: mov    0x38(%rsi),%rsi
    0.00 :   174630: mov    %rax,0x20(%rsi)
    0.00 :   174634: mov    %rcx,0x28(%rsi)
    0.00 :   174638: decq   (%rdx)
    0.00 :   17463b: jne    174646 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2a6>
    0.00 :   17463d: mov    %r12,%rdi
    0.00 :   174640: call   *0x1d8da(%rip)        # 191f20 <_DYNAMIC+0x1160>
    0.00 :   174646: mov    0x40(%rsp),%rax
    0.00 :   17464b: mov    %rax,0x20(%rsp)
    0.00 :   174650: movaps 0x30(%rsp),%xmm0
    0.24 :   174655: movaps %xmm0,0x10(%rsp)
    0.00 :   17465a: jmp    174420 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x80>
    0.00 :   17465f: mov    %r12,%rdi
    0.00 :   174662: call   d196a <_ZN3std4sync9once_lock17OnceLock$LT$T$GT$10initialize17hd31d093978ca14d7E.llvm.10013882635303053058>
    0.00 :   174667: jmp    174565 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x1c5>
    0.00 :   17466c: movups 0x48(%rsp),%xmm0
    0.00 :   174671: movups 0x58(%rsp),%xmm1
    0.00 :   174676: movups 0x68(%rsp),%xmm2
    0.00 :   17467b: movups 0x78(%rsp),%xmm3
    0.00 :   174680: movups %xmm3,0x30(%r15)
    0.00 :   174685: movups %xmm2,0x20(%r15)
    0.00 :   17468a: movups %xmm1,0x10(%r15)
    0.00 :   17468f: movups %xmm0,(%r15)
    0.00 :   174693: jmp    174939 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x599>
    0.00 :   174698: add    $0xffffffffffffffe3,%rbx
    0.00 :   17469c: mov    0x8(%rsp),%rax
    0.00 :   1746a1: jmp    1748f1 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x551>
    0.00 :   1746a6: movups 0x48(%rsp),%xmm0
    0.00 :   1746ab: movups 0x58(%rsp),%xmm1
    0.00 :   1746b0: movups 0x68(%rsp),%xmm2
    0.00 :   1746b5: movups 0x78(%rsp),%xmm3
    0.00 :   1746ba: mov    0x8(%rsp),%rax
    0.00 :   1746bf: movups %xmm3,0x30(%rax)
    0.00 :   1746c3: movups %xmm2,0x20(%rax)
    0.00 :   1746c7: movups %xmm1,0x10(%rax)
    0.00 :   1746cb: movups %xmm0,(%rax)
    0.00 :   1746ce: jmp    1748f4 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x554>
    0.00 :   1746d3: movups 0x48(%rsp),%xmm0
    0.00 :   1746d8: movups 0x58(%rsp),%xmm1
    0.00 :   1746dd: movups 0x68(%rsp),%xmm2
    0.00 :   1746e2: movups 0x78(%rsp),%xmm3
    0.00 :   1746e7: mov    0x8(%rsp),%rax
    0.00 :   1746ec: movups %xmm3,0x30(%rax)
    0.00 :   1746f0: movups %xmm2,0x20(%rax)
    0.00 :   1746f4: movups %xmm1,0x10(%rax)
    0.00 :   1746f8: movups %xmm0,(%rax)
    0.00 :   1746fb: jmp    1748f9 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x559>
    0.00 :   174700: mov    0x18(%r14),%rax
    0.00 :   174704: test   %rax,%rax
    0.00 :   174707: je     174a4d <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6ad>
    0.00 :   17470d: mov    0x10(%r14),%rcx
    0.00 :   174711: lea    0x1(%rcx),%rdx
    0.00 :   174715: mov    (%r14),%rsi
    0.00 :   174718: mov    0x8(%r14),%rdi
    0.00 :   17471c: xor    %r8d,%r8d
    0.00 :   17471f: cmp    %rsi,%rdx
    0.00 :   174722: cmovae %rsi,%r8
    0.00 :   174726: neg    %r8
    0.00 :   174729: lea    (%rcx,%r8,1),%rdx
    0.00 :   17472d: inc    %rdx
    0.00 :   174730: mov    %rdx,0x10(%r14)
    0.00 :   174734: dec    %rax
    0.00 :   174737: mov    %rax,0x18(%r14)
    0.00 :   17473b: mov    (%rdi,%rcx,8),%r15
    0.00 :   17473f: cmpq   $0x0,0x38(%r14)
    0.00 :   174744: je     17483a <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x49a>
    0.00 :   17474a: mov    0x30(%r14),%rax
    0.00 :   17474e: mov    0x20(%r14),%rcx
    0.00 :   174752: mov    0x28(%r14),%rdx
    0.00 :   174756: xor    %esi,%esi
    0.00 :   174758: cmp    %rcx,%rax
    0.00 :   17475b: cmovae %rcx,%rsi
    0.00 :   17475f: sub    %rsi,%rax
    0.00 :   174762: mov    (%rdx,%rax,8),%rcx
    0.00 :   174766: mov    0x38(%rcx),%rax
    0.00 :   17476a: mov    %eax,%esi
    0.00 :   17476c: and    $0xf,%esi
    0.00 :   17476f: cmp    $0xc,%rsi
    0.00 :   174773: ja     1749fc <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x65c>
    0.00 :   174779: lea    0x10(%rcx),%rdi
    0.00 :   17477d: mov    $0xaa8,%edx
    0.00 :   174782: jmp    1747a5 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x405>
    0.00 :   174784: data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   174790: pause
    0.00 :   174792: mov    0x38(%rcx),%rax
    0.00 :   174796: mov    %eax,%esi
    0.00 :   174798: and    $0xf,%esi
    0.00 :   17479b: cmp    $0xd,%rsi
    0.00 :   17479f: jae    1749fc <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x65c>
    0.00 :   1747a5: cmp    $0x1,%rsi
    0.00 :   1747a9: je     174790 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x3f0>
    0.00 :   1747ab: test   $0x20,%al
    0.00 :   1747ad: jne    17483a <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x49a>
    0.00 :   1747b3: cmp    $0xb,%sil
    0.00 :   1747b7: ja     1747dc <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x43c>
    0.00 :   1747b9: movzbl %sil,%esi
    0.00 :   1747bd: bt     %esi,%edx
    0.00 :   1747c0: jb     174790 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x3f0>
    0.00 :   1747c2: cmp    $0x2,%esi
    0.00 :   1747c5: jne    1747dc <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x43c>
    0.00 :   1747c7: mov    %rax,%rsi
    0.00 :   1747ca: and    $0xffffffffffffffd0,%rsi
    0.00 :   1747ce: or     $0x3,%rsi
    0.00 :   1747d2: lock cmpxchg %rsi,0x38(%rcx)
    1.19 :   1747d8: jne    174796 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x3f6>
    0.00 :   1747da: jmp    17482b <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x48b>
    0.00 :   1747dc: mov    %rax,%rsi
    0.00 :   1747df: or     $0x10,%rsi
    0.00 :   1747e3: lock cmpxchg %rsi,0x38(%rcx)
    1.24 :   1747e9: jne    174796 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x3f6>
    0.00 :   1747eb: jmp    17483a <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x49a>
    0.00 :   1747ed: mov    0x8(%rsp),%rax
    0.00 :   1747f2: mov    0xa8(%rsp),%rcx
    0.00 :   1747fa: mov    %rcx,0x8(%rax)
    0.00 :   1747fe: mov    0xb0(%rsp),%rcx
    0.00 :   174806: mov    %rcx,0x10(%rax)
    0.00 :   17480a: mov    0xb8(%rsp),%rcx
    0.00 :   174812: mov    %rcx,0x18(%rax)
    0.00 :   174816: mov    0xc0(%rsp),%rcx
    0.00 :   17481e: mov    %rcx,(%rax)
    0.00 :   174821: lea    0x20(%rsp),%r12
    0.00 :   174826: jmp    1748f9 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x559>
    0.00 :   17482b: xor    %edx,%edx
    0.00 :   17482d: xor    %ecx,%ecx
    0.00 :   17482f: mov    $0x1,%r8d
    0.00 :   174835: call   109e00 <_ZN7vthread4wait11wait_select16enqueue_selected17h5a35090e1549dd93E.llvm.10013882635303053058>
    0.00 :   17483a: cmpq   $0x0,0x58(%r14)
    0.00 :   17483f: je     1748e8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x548>
    0.00 :   174845: mov    0x50(%r14),%rax
    0.00 :   174849: mov    0x40(%r14),%rcx
    0.00 :   17484d: mov    0x48(%r14),%rdx
    0.00 :   174851: xor    %esi,%esi
    0.00 :   174853: cmp    %rcx,%rax
    0.00 :   174856: cmovae %rcx,%rsi
    0.00 :   17485a: sub    %rsi,%rax
    0.00 :   17485d: mov    (%rdx,%rax,8),%rcx
    0.00 :   174861: mov    0x38(%rcx),%rax
    0.23 :   174865: mov    %eax,%esi
    0.00 :   174867: and    $0xf,%esi
    0.00 :   17486a: cmp    $0xc,%rsi
    0.00 :   17486e: ja     1749fc <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x65c>
    0.00 :   174874: lea    0x10(%rcx),%rdi
    0.00 :   174878: mov    $0xaa8,%edx
    0.00 :   17487d: jmp    174895 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x4f5>
    0.00 :   17487f: nop
    0.00 :   174880: pause
    0.00 :   174882: mov    0x38(%rcx),%rax
    0.00 :   174886: mov    %eax,%esi
    0.00 :   174888: and    $0xf,%esi
    0.00 :   17488b: cmp    $0xd,%rsi
    0.00 :   17488f: jae    1749fc <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x65c>
    0.00 :   174895: cmp    $0x1,%rsi
    0.00 :   174899: je     174880 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x4e0>
    0.00 :   17489b: test   $0x20,%al
    0.00 :   17489d: jne    1748e8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x548>
    0.00 :   17489f: cmp    $0xb,%sil
    0.00 :   1748a3: ja     1748c8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x528>
    0.00 :   1748a5: movzbl %sil,%esi
    0.00 :   1748a9: bt     %esi,%edx
    0.00 :   1748ac: jb     174880 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x4e0>
    0.00 :   1748ae: cmp    $0x2,%esi
    0.00 :   1748b1: jne    1748c8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x528>
    0.00 :   1748b3: mov    %rax,%rsi
    0.00 :   1748b6: and    $0xffffffffffffffd0,%rsi
    0.00 :   1748ba: or     $0x3,%rsi
    0.00 :   1748be: lock cmpxchg %rsi,0x38(%rcx)
    3.77 :   1748c4: jne    174886 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x4e6>
    0.00 :   1748c6: jmp    1748d9 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x539>
    0.00 :   1748c8: mov    %rax,%rsi
    0.00 :   1748cb: or     $0x10,%rsi
    0.00 :   1748cf: lock cmpxchg %rsi,0x38(%rcx)
    0.00 :   1748d5: jne    174886 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x4e6>
    0.00 :   1748d7: jmp    1748e8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x548>
    0.00 :   1748d9: xor    %edx,%edx
    0.00 :   1748db: xor    %ecx,%ecx
    0.00 :   1748dd: mov    $0x1,%r8d
    0.00 :   1748e3: call   109e00 <_ZN7vthread4wait11wait_select16enqueue_selected17h5a35090e1549dd93E.llvm.10013882635303053058>
    0.00 :   1748e8: mov    0x8(%rsp),%rax
    0.00 :   1748ed: mov    %r15,0x8(%rax)
    0.00 :   1748f1: mov    %rbx,(%rax)
    0.00 :   1748f4: movb   $0x0,0x78(%r14)
    0.00 :   1748f9: lea    0x88(%rsp),%rdi
    0.00 :   174901: call   16af80 <core::ptr::drop_in_place<vthread::channel::wait::Ticket<i32>>>
    0.00 :   174906: mov    0x10(%rsp),%rax
    0.00 :   17490b: cmp    $0x11,%rax
    0.00 :   17490f: je     174939 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x599>
    0.00 :   174911: mov    0x18(%rsp),%rcx
    0.00 :   174916: mov    0x20(%rsp),%rdx
    0.00 :   17491b: mov    0x10(%rdx),%rsi
    0.00 :   17491f: mov    0x38(%rsi),%rsi
    0.00 :   174923: mov    %rax,0x20(%rsi)
    0.00 :   174927: mov    %rcx,0x28(%rsi)
    0.00 :   17492b: decq   (%rdx)
    0.00 :   17492e: jne    174939 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x599>
    0.00 :   174930: mov    %r12,%rdi
    0.00 :   174933: call   *0x1d5e7(%rip)        # 191f20 <_DYNAMIC+0x1160>
    0.00 :   174939: add    $0xc8,%rsp
    0.00 :   174940: pop    %rbx
    0.00 :   174941: pop    %r12
    0.00 :   174943: pop    %r13
    0.00 :   174945: pop    %r14
    0.00 :   174947: pop    %r15
    0.00 :   174949: pop    %rbp
    0.00 :   17494a: ret
    0.00 :   17494b: lea    -0x155ddd(%rip),%rdi        # 1eb75 <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058>
    0.00 :   174952: lea    0x1954f(%rip),%rdx        # 18dea8 <anon.cccb389264607a2d4c2b49e143c9c1b6.877.llvm.10013882635303053058>
    0.00 :   174959: mov    $0x1d,%esi
    0.00 :   17495e: call   *0x1c884(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   174964: jmp    174a96 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6f6>
    0.00 :   174969: lea    -0x15f1f0(%rip),%rdi        # 15780 <anon.3a58b439f571e0ec141896abec7fa7cc.106.llvm.7674982464417394995+0x80>
    0.00 :   174970: lea    0x1b1c9(%rip),%rdx        # 18fb40 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x1c50>
    0.00 :   174977: mov    $0x10,%esi
    0.00 :   17497c: call   *0x1c866(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   174982: jmp    174a96 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6f6>
    0.00 :   174987: mov    0x1f44a(%rip),%rax        # 193dd8 <_ZN7vthread5error13error_context12RuntimeFault3new4NEXT17haba27211dcb56122E.llvm.10013882635303053058>
    0.00 :   17498e: lea    0x20(%rsp),%r12
    0.00 :   174993: cmp    $0xffffffffffffffff,%rax
    0.00 :   174997: je     174a68 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6c8>
    0.00 :   17499d: lea    0x1(%rax),%rcx
    0.00 :   1749a1: lock cmpxchg %rcx,0x1f42e(%rip)        # 193dd8 <_ZN7vthread5error13error_context12RuntimeFault3new4NEXT17haba27211dcb56122E.llvm.10013882635303053058>
    0.00 :   1749aa: jne    174993 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5f3>
    0.00 :   1749ac: mov    0x8(%rsp),%rcx
    0.00 :   1749b1: movq   $0x2b,0x10(%rcx)
    0.00 :   1749b9: mov    %rax,0x18(%rcx)
    0.00 :   1749bd: movb   $0x0,0x20(%rcx)
    0.00 :   1749c1: dec    %rbx
    0.00 :   1749c4: mov    %rbx,(%rcx)
    0.00 :   1749c7: lea    -0x155e84(%rip),%rax        # 1eb4a <anon.cccb389264607a2d4c2b49e143c9c1b6.875.llvm.10013882635303053058>
    0.00 :   1749ce: mov    %rax,0x8(%rcx)
    0.00 :   1749d2: mov    0x40(%rsp),%rax
    0.00 :   1749d7: mov    0x10(%rax),%rcx
    0.00 :   1749db: mov    0x38(%rcx),%rcx
    0.00 :   1749df: movaps 0x30(%rsp),%xmm0
    0.00 :   1749e4: movups %xmm0,0x20(%rcx)
    0.00 :   1749e8: decq   (%rax)
    0.00 :   1749eb: jne    1748f9 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x559>
    0.00 :   1749f1: call   *0x1d529(%rip)        # 191f20 <_DYNAMIC+0x1160>
    0.00 :   1749f7: jmp    1748f9 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x559>
    0.00 :   1749fc: lea    -0x1566d7(%rip),%rdi        # 1e32c <anon.cccb389264607a2d4c2b49e143c9c1b6.694.llvm.10013882635303053058>
    0.00 :   174a03: lea    0x18dbe(%rip),%rdx        # 18d7c8 <anon.cccb389264607a2d4c2b49e143c9c1b6.695.llvm.10013882635303053058>
    0.00 :   174a0a: mov    $0x79,%esi
    0.00 :   174a0f: call   *0x1c633(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   174a15: jmp    174a96 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6f6>
    0.00 :   174a17: lea    -0x1566f2(%rip),%rdi        # 1e32c <anon.cccb389264607a2d4c2b49e143c9c1b6.694.llvm.10013882635303053058>
    0.00 :   174a1e: lea    0x18da3(%rip),%rdx        # 18d7c8 <anon.cccb389264607a2d4c2b49e143c9c1b6.695.llvm.10013882635303053058>
    0.00 :   174a25: mov    $0x79,%esi
    0.00 :   174a2a: call   *0x1c618(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   174a30: jmp    174a96 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6f6>
    0.00 :   174a32: lea    -0x152fc6(%rip),%rdi        # 21a73 <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058+0x2efe>
    0.00 :   174a39: lea    0x1b148(%rip),%rdx        # 18fb88 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x1c98>
    0.00 :   174a40: mov    $0x37,%esi
    0.00 :   174a45: call   *0x1c5fd(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   174a4b: jmp    174a96 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6f6>
    0.00 :   174a4d: lea    -0x15eea4(%rip),%rdi        # 15bb0 <anon.cccb389264607a2d4c2b49e143c9c1b6.882.llvm.10013882635303053058+0x3e0>
    0.00 :   174a54: lea    0x1b0fd(%rip),%rdx        # 18fb58 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x1c68>
    0.00 :   174a5b: mov    $0x10,%esi
    0.00 :   174a60: call   *0x1c782(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   174a66: jmp    174a96 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6f6>
    0.00 :   174a68: movq   $0xffffffffffffffff,0x48(%rsp)
    0.00 :   174a71: lea    -0x15661f(%rip),%rdi        # 1e459 <anon.cccb389264607a2d4c2b49e143c9c1b6.711.llvm.10013882635303053058>
    0.00 :   174a78: lea    0x17ba1(%rip),%rcx        # 18c620 <anon.cccb389264607a2d4c2b49e143c9c1b6.179.llvm.10013882635303053058>
    0.00 :   174a7f: lea    0x18dd2(%rip),%r8        # 18d858 <anon.cccb389264607a2d4c2b49e143c9c1b6.713.llvm.10013882635303053058>
    0.00 :   174a86: lea    0x48(%rsp),%rdx
    0.00 :   174a8b: mov    $0x1e,%esi
    0.00 :   174a90: call   *0x1c592(%rip)        # 191028 <_DYNAMIC+0x268>
    0.00 :   174a96: ud2
    0.00 :   174a98: jmp    174ac4 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x724>
    0.00 :   174a9a: jmp    174ad5 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x735>
    0.00 :   174a9c: mov    %rax,%rbx
    0.00 :   174a9f: mov    0x40(%rsp),%rax
    0.00 :   174aa4: mov    %rax,0x20(%rsp)
    0.00 :   174aa9: movaps 0x30(%rsp),%xmm0
    0.00 :   174aae: movaps %xmm0,0x10(%rsp)
    0.00 :   174ab3: jmp    174ae2 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x742>
    0.00 :   174ab5: jmp    174ada <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x73a>
    0.00 :   174ab7: jmp    174ad5 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x735>
    0.00 :   174ab9: mov    %rax,%rbx
    0.00 :   174abc: jmp    174aef <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x74f>
    0.00 :   174abe: jmp    174ad5 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x735>
    0.00 :   174ac0: jmp    174ada <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x73a>
    0.00 :   174ac2: jmp    174ac4 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x724>
    0.00 :   174ac4: mov    %rax,%rbx
    0.00 :   174ac7: lea    0x30(%rsp),%rdi
    0.00 :   174acc: call   1691d0 <core::ptr::drop_in_place<vthread::sync::wait::Wait>>
    0.00 :   174ad1: jmp    174ae2 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x742>
    0.00 :   174ad3: jmp    174ada <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x73a>
    0.00 :   174ad5: mov    %rax,%rbx
    0.00 :   174ad8: jmp    174ae2 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x742>
    0.00 :   174ada: mov    %rax,%rbx
    0.00 :   174add: movb   $0x0,0x78(%r14)
    0.00 :   174ae2: lea    0x88(%rsp),%rdi
    0.00 :   174aea: call   16af80 <core::ptr::drop_in_place<vthread::channel::wait::Ticket<i32>>>
    0.00 :   174aef: lea    0x10(%rsp),%rdi
    0.00 :   174af4: call   16b9c0 <core::ptr::drop_in_place<core::option::Option<vthread::sync::wait::Wait>>>
    0.00 :   174af9: mov    %rbx,%rdi
    0.00 :   174afc: call   186a90 <_Unwind_Resume@plt>
    0.00 :   174b01: call   *0x1c6f9(%rip)        # 191200 <_DYNAMIC+0x440>
