 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (433 samples, percent: global period)
-----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000cada0 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   cada0:  push   %rbp
    0.00 :   cada1:  push   %r15
    0.00 :   cada3:  push   %r14
    0.00 :   cada5:  push   %r13
    0.00 :   cada7:  push   %r12
    0.00 :   cada9:  push   %rbx
    0.00 :   cadaa:  sub    $0x558,%rsp
    0.00 :   cadb1:  mov    %rdi,%r12
    0.00 :   cadb4:  mov    %rdi,0xc0(%rsp)
    0.00 :   cadbc:  mov    %rsi,0x28(%rsp)
    0.00 :   cadc1:  mov    %rsi,0xc8(%rsp)
    0.00 :   cadc9:  jmp    cadd2 <std::sys::backtrace::__rust_begin_short_backtrace+0x32>
    0.00 :   cadcb:  nopl   0x0(%rax,%rax,1)
    0.00 :   cadd0:  pause
    0.00 :   cadd2:  mov    0x8(%r12),%rax
    0.00 :   cadd7:  nopw   0x0(%rax,%rax,1)
    0.00 :   cade0:  cmp    $0xffffffffffffffff,%rax
    0.00 :   cade4:  je     cadd0 <std::sys::backtrace::__rust_begin_short_backtrace+0x30>
    0.00 :   cade6:  test   %rax,%rax
    0.00 :   cade9:  js     cb362 <std::sys::backtrace::__rust_begin_short_backtrace+0x5c2>
    0.00 :   cadef:  lea    0x1(%rax),%rcx
    0.00 :   cadf3:  lock cmpxchg %rcx,0x8(%r12)
    0.00 :   cadfa:  jne    cade0 <std::sys::backtrace::__rust_begin_short_backtrace+0x40>
    0.00 :   cadfc:  mov    %r12,%rdi
    0.00 :   cadff:  xor    %esi,%esi
    0.00 :   cae01:  call   102ff0 <vthread::worker_context::attach>
    0.00 :   cae06:  lock incq (%r12)
    0.00 :   cae0b:  jle    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae11:  mov    %r12,0x98(%rsp)
    0.00 :   cae19:  lock incq (%r12)
    0.00 :   cae1e:  jle    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae24:  mov    %r12,0xd0(%rsp)
    0.00 :   cae2c:  mov    0xa0(%r12),%rsi
    0.00 :   cae34:  mov    0x28(%rsp),%rdi
    0.00 :   cae39:  cmp    %rsi,%rdi
    0.00 :   cae3c:  jae    cc3b1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1611>
    0.00 :   cae42:  movups 0x50(%r12),%xmm0
    0.00 :   cae48:  mov    0x70(%r12),%rax
    0.00 :   cae4d:  mov    0x98(%r12),%rcx
    0.00 :   cae55:  mov    (%rcx,%rdi,8),%rbx
    0.00 :   cae59:  lock incq (%rbx)
    0.00 :   cae5d:  jle    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae63:  mov    %rbx,0xd8(%rsp)
    0.00 :   cae6b:  mov    %r12,0x40(%rsp)
    0.00 :   cae70:  movq   $0x0,0x3a8(%rsp)
    0.00 :   cae7c:  movq   $0x8,0x3b0(%rsp)
    0.00 :   cae88:  xorps  %xmm1,%xmm1
    0.00 :   cae8b:  movups %xmm1,0x3b8(%rsp)
    0.00 :   cae93:  movq   $0x8,0x3c8(%rsp)
    0.00 :   cae9f:  movups %xmm1,0x3d0(%rsp)
    0.00 :   caea7:  movq   $0x8,0x3e0(%rsp)
    0.00 :   caeb3:  movups %xmm1,0x3e8(%rsp)
    0.00 :   caebb:  movq   $0x8,0x3f8(%rsp)
    0.00 :   caec7:  movq   $0x0,0x400(%rsp)
    0.00 :   caed3:  movq   $0x0,0x480(%rsp)
    0.00 :   caedf:  movq   $0x8,0x488(%rsp)
    0.00 :   caeeb:  movups %xmm1,0x490(%rsp)
    0.00 :   caef3:  movq   $0x0,0x4a0(%rsp)
    0.00 :   caeff:  movq   $0x8,0x4a8(%rsp)
    0.00 :   caf0b:  movups %xmm1,0x4b0(%rsp)
    0.00 :   caf13:  movb   $0x0,0x4c0(%rsp)
    0.00 :   caf1b:  movq   $0x0,0x58(%rsp)
    0.00 :   caf24:  movq   $0x8,0x60(%rsp)
    0.00 :   caf2d:  movups %xmm1,0x68(%rsp)
    0.00 :   caf32:  movq   $0x8,0x78(%rsp)
    0.00 :   caf3b:  movups %xmm1,0x80(%rsp)
    0.00 :   caf43:  movq   $0x2,0x100(%rsp)
    0.00 :   caf4f:  movq   $0x0,0xe0(%rsp)
    0.00 :   caf5b:  movups %xmm1,0xf0(%rsp)
    0.00 :   caf63:  movq   $0x8,0xe8(%rsp)
    0.00 :   caf6f:  movq   $0x0,0xa0(%rsp)
    0.00 :   caf7b:  movq   $0x8,0xa8(%rsp)
    0.00 :   caf87:  movq   $0x0,0xb0(%rsp)
    0.00 :   caf93:  movq   $0x1,0x120(%rsp)
    0.00 :   caf9f:  movq   $0x1,0x128(%rsp)
    0.00 :   cafab:  movups %xmm1,0x130(%rsp)
    0.00 :   cafb3:  movq   $0x8,0x140(%rsp)
    0.00 :   cafbf:  movq   $0x0,0x148(%rsp)
    0.00 :   cafcb:  movups %xmm0,0x150(%rsp)
    0.00 :   cafd3:  movq   $0x1,0x160(%rsp)
    0.00 :   cafdf:  movups %xmm1,0x168(%rsp)
    0.00 :   cafe7:  movups %xmm1,0x178(%rsp)
    0.00 :   cafef:  movups %xmm1,0x188(%rsp)
    0.00 :   caff7:  movq   $0x0,0x198(%rsp)
    0.00 :   cb003:  movq   $0x8,0x1a0(%rsp)
    0.00 :   cb00f:  movups %xmm1,0x1a8(%rsp)
    0.00 :   cb017:  movups %xmm1,0x1b8(%rsp)
    0.00 :   cb01f:  movq   $0x0,0x1c8(%rsp)
    0.00 :   cb02b:  movq   $0x8,0x1d0(%rsp)
    0.00 :   cb037:  movups %xmm1,0x1d8(%rsp)
    0.00 :   cb03f:  movups %xmm1,0x1e8(%rsp)
    0.00 :   cb047:  mov    %rax,0x1f8(%rsp)
    0.00 :   cb04f:  mov    $0xe0,%edi
    0.00 :   cb054:  call   *0xc7206(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cb05a:  test   %rax,%rax
    0.00 :   cb05d:  je     cb3a1 <std::sys::backtrace::__rust_begin_short_backtrace+0x601>
    0.00 :   cb063:  mov    %rax,%r14
    0.00 :   cb066:  lea    0x120(%rsp),%rsi
    0.00 :   cb06e:  mov    $0xe0,%edx
    0.00 :   cb073:  mov    %rax,%rdi
    0.00 :   cb076:  call   *0xc71b4(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   cb07c:  mov    %r12,0x2b8(%rsp)
    0.00 :   cb084:  mov    %rbx,0x2c0(%rsp)
    0.00 :   cb08c:  mov    0x28(%rsp),%rax
    0.00 :   cb091:  mov    %rax,0x2d0(%rsp)
    0.00 :   cb099:  movups 0x3a8(%rsp),%xmm0
    0.00 :   cb0a1:  movups 0x3b8(%rsp),%xmm1
    0.00 :   cb0a9:  movups 0x3c8(%rsp),%xmm2
    0.00 :   cb0b1:  movups 0x3d8(%rsp),%xmm3
    0.00 :   cb0b9:  movaps %xmm0,0x1a0(%rsp)
    0.00 :   cb0c1:  movaps %xmm1,0x1b0(%rsp)
    0.00 :   cb0c9:  movaps %xmm2,0x1c0(%rsp)
    0.00 :   cb0d1:  movaps %xmm3,0x1d0(%rsp)
    0.00 :   cb0d9:  movups 0x3e8(%rsp),%xmm0
    0.00 :   cb0e1:  movaps %xmm0,0x1e0(%rsp)
    0.00 :   cb0e9:  movups 0x3f8(%rsp),%xmm0
    0.00 :   cb0f1:  movaps %xmm0,0x1f0(%rsp)
    0.00 :   cb0f9:  movups 0x480(%rsp),%xmm0
    0.00 :   cb101:  movups 0x490(%rsp),%xmm1
    0.00 :   cb109:  movups 0x4a0(%rsp),%xmm2
    0.00 :   cb111:  movups 0x4b0(%rsp),%xmm3
    0.00 :   cb119:  movaps %xmm0,0x200(%rsp)
    0.00 :   cb121:  movaps %xmm1,0x210(%rsp)
    0.00 :   cb129:  movaps %xmm2,0x220(%rsp)
    0.00 :   cb131:  movaps %xmm3,0x230(%rsp)
    0.00 :   cb139:  mov    0x4c0(%rsp),%rax
    0.00 :   cb141:  mov    %rax,0x240(%rsp)
    0.00 :   cb149:  mov    0x88(%rsp),%rax
    0.00 :   cb151:  mov    %rax,0x278(%rsp)
    0.00 :   cb159:  movups 0x58(%rsp),%xmm0
    0.00 :   cb15e:  movups 0x68(%rsp),%xmm1
    0.00 :   cb163:  movups 0x78(%rsp),%xmm2
    0.00 :   cb168:  movups %xmm2,0x268(%rsp)
    0.00 :   cb170:  movups %xmm1,0x258(%rsp)
    0.00 :   cb178:  movups %xmm0,0x248(%rsp)
    0.00 :   cb180:  movq   $0x0,0x2d8(%rsp)
    0.00 :   cb18c:  movups 0x100(%rsp),%xmm0
    0.00 :   cb194:  movups 0x110(%rsp),%xmm1
    0.00 :   cb19c:  movaps %xmm0,0x120(%rsp)
    0.00 :   cb1a4:  movaps %xmm1,0x130(%rsp)
    0.00 :   cb1ac:  movups 0xe0(%rsp),%xmm0
    0.00 :   cb1b4:  movups 0xf0(%rsp),%xmm1
    0.00 :   cb1bc:  movaps %xmm0,0x280(%rsp)
    0.00 :   cb1c4:  movaps %xmm1,0x290(%rsp)
    0.00 :   cb1cc:  movb   $0x0,0x39c(%rsp)
    0.00 :   cb1d4:  movq   $0x18,0x140(%rsp)
    0.00 :   cb1e0:  movq   $0x0,0x168(%rsp)
    0.00 :   cb1ec:  movq   $0x8,0x170(%rsp)
    0.00 :   cb1f8:  xorps  %xmm1,%xmm1
    0.00 :   cb1fb:  movups %xmm1,0x2e8(%rsp)
    0.00 :   cb203:  movups %xmm1,0x178(%rsp)
    0.00 :   cb20b:  movups %xmm1,0x188(%rsp)
    0.00 :   cb213:  movq   $0x0,0x198(%rsp)
    0.00 :   cb21f:  mov    0xb0(%rsp),%rax
    0.00 :   cb227:  mov    %rax,0x2b0(%rsp)
    0.00 :   cb22f:  movups 0xa0(%rsp),%xmm0
    0.00 :   cb237:  movaps %xmm0,0x2a0(%rsp)
    0.00 :   cb23f:  mov    %r14,0x2c8(%rsp)
    0.00 :   cb247:  movw   $0x0,0x39d(%rsp)
    0.00 :   cb251:  movaps %xmm1,0x300(%rsp)
    0.00 :   cb259:  movups %xmm1,0x388(%rsp)
    0.00 :   cb261:  movups %xmm1,0x378(%rsp)
    0.00 :   cb269:  movups %xmm1,0x368(%rsp)
    0.00 :   cb271:  movups %xmm1,0x358(%rsp)
    0.00 :   cb279:  movups %xmm1,0x348(%rsp)
    0.00 :   cb281:  movups %xmm1,0x338(%rsp)
    0.00 :   cb289:  movups %xmm1,0x328(%rsp)
    0.00 :   cb291:  movups %xmm1,0x318(%rsp)
    0.00 :   cb299:  movl   $0x0,0x398(%rsp)
    0.00 :   cb2a4:  mov    $0x280,%edi
    0.00 :   cb2a9:  call   *0xc6fb1(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cb2af:  test   %rax,%rax
    0.00 :   cb2b2:  je     cb3b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x616>
    0.00 :   cb2b8:  mov    %rax,%rbx
    0.00 :   cb2bb:  lea    0x120(%rsp),%rsi
    0.00 :   cb2c3:  mov    $0x280,%edx
    0.00 :   cb2c8:  mov    %rax,%rdi
    0.00 :   cb2cb:  call   *0xc6f5f(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   cb2d1:  mov    0x1a0(%rbx),%rax
    0.00 :   cb2d8:  mov    %rbx,0x8(%rsp)
    0.00 :   cb2dd:  mov    0x1a8(%rbx),%rbx
    0.00 :   cb2e4:  mov    0xe0(%rax),%r14
    0.00 :   cb2eb:  lock incq (%r14)
    0.00 :   cb2ef:  jle    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb2f5:  incq   (%rbx)
    0.00 :   cb2f8:  je     cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb2fe:  mov    %r14,0x3a8(%rsp)
    0.00 :   cb306:  mov    %rbx,0x3b0(%rsp)
    0.00 :   cb30e:  movzbl %fs:0xffffffffffffffd8,%eax
    0.00 :   cb317:  cmp    $0x1,%eax
    0.00 :   cb31a:  je     cb3f1 <std::sys::backtrace::__rust_begin_short_backtrace+0x651>
    0.00 :   cb320:  cmp    $0x2,%eax
    0.00 :   cb323:  jne    cb3cb <std::sys::backtrace::__rust_begin_short_backtrace+0x62b>
    0.00 :   cb329:  lock decq (%r14)
    0.00 :   cb32d:  jne    cb33d <std::sys::backtrace::__rust_begin_short_backtrace+0x59d>
    0.00 :   cb32f:  lea    0x3a8(%rsp),%rdi
    0.00 :   cb337:  call   *0xc7e43(%rip)        # 193180 <_DYNAMIC+0x1168>
    0.00 :   cb33d:  decq   (%rbx)
    0.00 :   cb340:  jne    cb350 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b0>
    0.00 :   cb342:  lea    0x3b0(%rsp),%rdi
    0.00 :   cb34a:  call   *0xc7e38(%rip)        # 193188 <_DYNAMIC+0x1170>
    0.00 :   cb350:  lea    0xc23a9(%rip),%rdi        # 18d700 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962>
    0.00 :   cb357:  call   *0xc74d3(%rip)        # 192830 <_DYNAMIC+0x818>
    0.00 :   cb35d:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb362:  lea    0xc1de7(%rip),%rax        # 18d150 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x210>
    0.00 :   cb369:  mov    %rax,0x120(%rsp)
    0.00 :   cb371:  lea    0x8778(%rip),%rax        # d3af0 <_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hb2a2ab9295a6d20aE.llvm.10657235172099788962>
    0.00 :   cb378:  mov    %rax,0x128(%rsp)
    0.00 :   cb380:  lea    -0xb8b8c(%rip),%rdi        # 127fb <anon.48996dcd35f4b7aad43cb5fc1472ecbf.144.llvm.7041895458470441471>
    0.00 :   cb387:  lea    0xc2b92(%rip),%rdx        # 18df20 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x6b0>
    0.00 :   cb38e:  lea    0x120(%rsp),%rsi
    0.00 :   cb396:  call   *0xc6f04(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   cb39c:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb3a1:  mov    $0x8,%edi
    0.00 :   cb3a6:  mov    $0xe0,%esi
    0.00 :   cb3ab:  call   *0xc6ed7(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   cb3b1:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb3b6:  mov    $0x8,%edi
    0.00 :   cb3bb:  mov    $0x280,%esi
    0.00 :   cb3c0:  call   *0xc6ec2(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   cb3c6:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb3cb:  mov    %fs:0x0,%rax
    0.00 :   cb3d4:  lea    -0x40(%rax),%rdi
    0.00 :   cb3db:  lea    -0x4db2(%rip),%rsi        # c6630 <std::sys::thread_local::native::eager::destroy>
    0.00 :   cb3e2:  call   *0xc7598(%rip)        # 192980 <_DYNAMIC+0x968>
    0.00 :   cb3e8:  movb   $0x1,%fs:0xffffffffffffffd8
    0.00 :   cb3f1:  mov    %r14,0x120(%rsp)
    0.00 :   cb3f9:  mov    %rbx,0x128(%rsp)
    0.00 :   cb401:  cmpq   $0x0,%fs:0xffffffffffffffc0
    0.00 :   cb40b:  jne    cc290 <std::sys::backtrace::__rust_begin_short_backtrace+0x14f0>
    0.00 :   cb411:  movups %fs:0xffffffffffffffc8,%xmm0
    0.00 :   cb41a:  mov    %r14,%fs:0xffffffffffffffc8
    0.00 :   cb423:  mov    %rbx,%fs:0xffffffffffffffd0
    0.00 :   cb42c:  movaps %xmm0,0x40(%rsp)
    0.00 :   cb431:  mov    %r12,0x18(%rsp)
    0.00 :   cb436:  lea    0x10(%r12),%rax
    0.00 :   cb43b:  mov    %rax,0x20(%rsp)
    0.00 :   cb440:  mov    0x8(%rsp),%rdi
    0.00 :   cb445:  lea    0x20(%rdi),%rax
    0.00 :   cb449:  mov    %rax,0x90(%rsp)
    0.00 :   cb451:  mov    %rdi,%rax
    0.00 :   cb454:  add    $0x58,%rax
    0.00 :   cb458:  mov    %rax,0xb8(%rsp)
    0.00 :   cb460:  mov    $0x1,%al
    0.00 :   cb462:  jmp    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb464:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb470:  mov    0x1a0(%rdi),%rax
    0.00 :   cb477:  mov    0xd0(%rax),%rax
    0.00 :   cb47e:  test   %rax,%rax
    0.00 :   cb481:  je     cb960 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc0>
    0.00 :   cb487:  movb   $0x1,0x27c(%rdi)
    0.00 :   cb48e:  xor    %eax,%eax
    0.00 :   cb490:  mov    0x1a0(%rdi),%rcx
    0.00 :   cb497:  mov    0xd8(%rcx),%rcx
    0.22 :   cb49e:  mov    0x10(%rcx),%rcx
    0.00 :   cb4a2:  mov    %rcx,0x38(%rsp)
    0.00 :   cb4a7:  cmp    %rcx,%r15
    0.00 :   cb4aa:  setne  %bl
    0.50 :   cb4ad:  or     %al,%bl
    0.00 :   cb4af:  test   $0x1,%bl
    0.00 :   cb4b2:  je     cb710 <std::sys::backtrace::__rust_begin_short_backtrace+0x970>
    0.00 :   cb4b8:  mov    0x1a0(%rdi),%rax
    0.00 :   cb4bf:  movzbl 0xeb(%rax),%eax
    0.00 :   cb4c6:  test   %al,%al
    0.00 :   cb4c8:  jne    cbfff <std::sys::backtrace::__rust_begin_short_backtrace+0x125f>
    0.00 :   cb4ce:  mov    %bl,0x14(%rsp)
    0.00 :   cb4d2:  mov    0x1a0(%rdi),%r12
    0.00 :   cb4d9:  movzbl 0xec(%r12),%eax
    0.00 :   cb4e2:  test   %al,%al
    0.00 :   cb4e4:  je     cb720 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb4ea:  lea    0xec(%r12),%rbx
    0.00 :   cb4f2:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb500:  lea    0x88(%r12),%r13
    0.00 :   cb508:  xor    %eax,%eax
    0.00 :   cb50a:  mov    $0x1,%ecx
    0.00 :   cb50f:  lock cmpxchg %ecx,0x88(%r12)
    0.00 :   cb519:  jne    cb6a5 <std::sys::backtrace::__rust_begin_short_backtrace+0x905>
    0.00 :   cb51f:  mov    0xc7082(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cb526:  mov    (%rax),%rax
    0.00 :   cb529:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb533:  test   %rcx,%rax
    0.00 :   cb536:  jne    cb6b3 <std::sys::backtrace::__rust_begin_short_backtrace+0x913>
    0.00 :   cb53c:  xor    %ebp,%ebp
    0.00 :   cb53e:  movzbl 0x8c(%r12),%eax
    0.00 :   cb547:  mov    0xb0(%r12),%rax
    0.00 :   cb54f:  mov    $0x6,%r14b
    0.00 :   cb552:  test   %rax,%rax
    0.00 :   cb555:  je     cb610 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb55b:  mov    0xb8(%r12),%rcx
    0.00 :   cb563:  test   %rcx,%rcx
    0.00 :   cb566:  je     cb5c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb568:  mov    %rcx,%rdx
    0.00 :   cb56b:  and    $0x7,%rdx
    0.00 :   cb56f:  je     cb693 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f3>
    0.00 :   cb575:  xor    %esi,%esi
    0.00 :   cb577:  nopw   0x0(%rax,%rax,1)
    0.00 :   cb580:  mov    0x70(%rax),%rax
    0.00 :   cb584:  inc    %rsi
    0.00 :   cb587:  cmp    %rsi,%rdx
    0.00 :   cb58a:  jne    cb580 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e0>
    0.00 :   cb58c:  mov    %rcx,%rdx
    0.00 :   cb58f:  sub    %rsi,%rdx
    0.00 :   cb592:  cmp    $0x8,%rcx
    0.00 :   cb596:  jb     cb5c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb598:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb5a0:  mov    0x70(%rax),%rax
    0.00 :   cb5a4:  mov    0x70(%rax),%rax
    0.00 :   cb5a8:  mov    0x70(%rax),%rax
    0.00 :   cb5ac:  mov    0x70(%rax),%rax
    0.00 :   cb5b0:  mov    0x70(%rax),%rax
    0.00 :   cb5b4:  mov    0x70(%rax),%rax
    0.00 :   cb5b8:  mov    0x70(%rax),%rax
    0.00 :   cb5bc:  mov    0x70(%rax),%rax
    0.00 :   cb5c0:  add    $0xfffffffffffffff8,%rdx
    0.00 :   cb5c4:  jne    cb5a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x800>
    0.00 :   cb5c6:  cmpw   $0x0,0x62(%rax)
    0.00 :   cb5cb:  je     cb610 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb5cd:  lea    0xb0(%r12),%rcx
    0.00 :   cb5d5:  lea    0x128(%rsp),%rdx
    0.00 :   cb5dd:  xorps  %xmm0,%xmm0
    0.00 :   cb5e0:  movups %xmm0,(%rdx)
    0.00 :   cb5e3:  mov    %rax,0x120(%rsp)
    0.00 :   cb5eb:  mov    %rcx,0x138(%rsp)
    0.00 :   cb5f3:  lea    0x120(%rsp),%rdi
    0.00 :   cb5fb:  call   e4a00 <alloc::collections::btree::map::entry::OccupiedEntry<K,V,A>::remove_kv>
    0.00 :   cb600:  mov    %rax,%r15
    0.00 :   cb603:  mov    %edx,%r14d
    0.00 :   cb606:  jmp    cb610 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb608:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb610:  cmpq   $0x0,0xc0(%r12)
    0.00 :   cb619:  setne  %al
    0.00 :   cb61c:  mov    %al,(%rbx)
    0.00 :   cb61e:  test   %bpl,%bpl
    0.00 :   cb621:  jne    cb640 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb623:  mov    0xc6f7e(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cb62a:  mov    (%rax),%rax
    0.00 :   cb62d:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb637:  test   %rcx,%rax
    0.00 :   cb63a:  jne    cb6ea <std::sys::backtrace::__rust_begin_short_backtrace+0x94a>
    0.00 :   cb640:  xor    %eax,%eax
    0.00 :   cb642:  xchg   %eax,0x0(%r13)
    0.00 :   cb646:  cmp    $0x2,%eax
    0.00 :   cb649:  je     cb6c4 <std::sys::backtrace::__rust_begin_short_backtrace+0x924>
    0.00 :   cb64b:  cmp    $0x6,%r14b
    0.00 :   cb64f:  je     cb720 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb655:  movzbl %r14b,%ecx
    0.00 :   cb659:  mov    $0x1,%esi
    0.00 :   cb65e:  mov    0x8(%rsp),%rbx
    0.00 :   cb663:  mov    %rbx,%rdi
    0.00 :   cb666:  mov    %r15,%rdx
    0.00 :   cb669:  call   113700 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cb66e:  mov    0x1a0(%rbx),%r12
    0.00 :   cb675:  lea    0xec(%r12),%rbx
    0.00 :   cb67d:  movzbl 0xec(%r12),%eax
    0.00 :   cb686:  test   %al,%al
    0.00 :   cb688:  jne    cb500 <std::sys::backtrace::__rust_begin_short_backtrace+0x760>
    0.00 :   cb68e:  jmp    cb720 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb693:  mov    %rcx,%rdx
    0.00 :   cb696:  cmp    $0x8,%rcx
    0.00 :   cb69a:  jae    cb5a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x800>
    0.00 :   cb6a0:  jmp    cb5c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb6a5:  mov    %r13,%rdi
    0.00 :   cb6a8:  call   *0xc6f72(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cb6ae:  jmp    cb51f <std::sys::backtrace::__rust_begin_short_backtrace+0x77f>
    0.00 :   cb6b3:  call   *0xc6f0f(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cb6b9:  mov    %eax,%ebp
    0.00 :   cb6bb:  xor    $0x1,%bpl
    0.00 :   cb6bf:  jmp    cb53e <std::sys::backtrace::__rust_begin_short_backtrace+0x79e>
    0.00 :   cb6c4:  mov    $0xca,%edi
    0.00 :   cb6c9:  mov    %r13,%rsi
    0.00 :   cb6cc:  mov    $0x81,%edx
    0.00 :   cb6d1:  mov    $0x1,%ecx
    0.00 :   cb6d6:  xor    %eax,%eax
    0.00 :   cb6d8:  call   *0xc6efa(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cb6de:  cmp    $0x6,%r14b
    0.00 :   cb6e2:  jne    cb655 <std::sys::backtrace::__rust_begin_short_backtrace+0x8b5>
    0.00 :   cb6e8:  jmp    cb720 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb6ea:  call   *0xc6ed8(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cb6f0:  test   %al,%al
    0.00 :   cb6f2:  jne    cb640 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb6f8:  movb   $0x1,0x8c(%r12)
    0.00 :   cb701:  jmp    cb640 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb706:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb710:  cmpb   $0x0,0x27c(%rdi)
    0.93 :   cb717:  je     cb740 <std::sys::backtrace::__rust_begin_short_backtrace+0x9a0>
    0.00 :   cb719:  call   1159d0 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive>
    0.00 :   cb71e:  jmp    cb790 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb720:  mov    0x8(%rsp),%rdi
    0.00 :   cb725:  call   1159d0 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive>
    0.00 :   cb72a:  mov    0x38(%rsp),%r15
    0.00 :   cb72f:  movzbl 0x14(%rsp),%ebx
    0.00 :   cb734:  jmp    cb790 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb736:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb740:  call   115410 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive_local_tasks>
    0.00 :   cb745:  test   %al,%al
    0.00 :   cb747:  je     cb790 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb749:  mov    0x8(%rsp),%rsi
    0.00 :   cb74e:  movb   $0x0,0x27e(%rsi)
    0.00 :   cb755:  mov    0x198(%rsi),%r14
    0.00 :   cb75c:  lea    0x120(%rsp),%rdi
    0.00 :   cb764:  mov    $0x1,%edx
    0.00 :   cb769:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cb76e:  add    $0x10,%r14
    0.00 :   cb772:  mov    %r14,%rdi
    0.00 :   cb775:  lea    0x120(%rsp),%rsi
    0.00 :   cb77d:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cb782:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb790:  movzbl %bl,%edx
    0.00 :   cb793:  and    $0x1,%edx
    0.00 :   cb796:  lea    0x120(%rsp),%rdi
    0.00 :   cb79e:  mov    0x8(%rsp),%rsi
    0.00 :   cb7a3:  call   10df50 <vthread::kernel::kernel_drive::<impl vthread::kernel::Kernel>::tick>
    0.00 :   cb7a8:  mov    0x120(%rsp),%rax
    0.00 :   cb7b0:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb7ba:  add    $0x23,%rcx
    0.00 :   cb7be:  cmp    %rcx,%rax
    0.00 :   cb7c1:  jne    cbe00 <std::sys::backtrace::__rust_begin_short_backtrace+0x1060>
    0.00 :   cb7c7:  xor    %eax,%eax
    0.00 :   cb7c9:  cmpb   $0x0,0x128(%rsp)
    0.00 :   cb7d1:  mov    0x8(%rsp),%rdi
    0.00 :   cb7d6:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb7dc:  cmpq   $0x0,0x60(%rdi)
    0.00 :   cb7e1:  je     cb83d <std::sys::backtrace::__rust_begin_short_backtrace+0xa9d>
    0.00 :   cb7e3:  mov    0x1c8(%rdi),%rdx
    0.00 :   cb7ea:  test   %rdx,%rdx
    0.00 :   cb7ed:  je     cc26d <std::sys::backtrace::__rust_begin_short_backtrace+0x14cd>
    0.00 :   cb7f3:  mov    0x198(%rdi),%rdi
    0.00 :   cb7fa:  add    $0x10,%rdi
    0.00 :   cb7fe:  add    $0x40,%rdx
    0.00 :   cb802:  mov    0x90(%rsp),%rsi
    0.00 :   cb80a:  call   120f60 <vthread::control::control_completion::<impl vthread::control::Shared>::publish_completions>
    0.00 :   cb80f:  mov    0x90(%rsp),%rax
    0.00 :   cb817:  movq   $0x18,(%rax)
    0.00 :   cb81e:  mov    0xb8(%rsp),%rax
    0.00 :   cb826:  xorps  %xmm0,%xmm0
    0.00 :   cb829:  movups %xmm0,0x10(%rax)
    0.00 :   cb82d:  movups %xmm0,(%rax)
    0.00 :   cb830:  movq   $0x0,0x20(%rax)
    0.00 :   cb838:  mov    0x8(%rsp),%rdi
    0.00 :   cb83d:  mov    0x1d0(%rdi),%rax
    0.25 :   cb844:  test   %rax,%rax
    0.00 :   cb847:  je     cb470 <std::sys::backtrace::__rust_begin_short_backtrace+0x6d0>
    0.00 :   cb84d:  mov    0x1d8(%rdi),%rcx
    0.00 :   cb854:  test   %rcx,%rcx
    0.00 :   cb857:  je     cb8ce <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb859:  mov    %rcx,%rdx
    0.00 :   cb85c:  and    $0x7,%rdx
    0.00 :   cb860:  je     cba6e <std::sys::backtrace::__rust_begin_short_backtrace+0xcce>
    0.00 :   cb866:  xor    %esi,%esi
    0.00 :   cb868:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb870:  mov    0x170(%rax),%rax
    0.00 :   cb877:  inc    %rsi
    0.00 :   cb87a:  cmp    %rsi,%rdx
    0.00 :   cb87d:  jne    cb870 <std::sys::backtrace::__rust_begin_short_backtrace+0xad0>
    0.00 :   cb87f:  mov    %rcx,%rdx
    0.00 :   cb882:  sub    %rsi,%rdx
    0.00 :   cb885:  cmp    $0x8,%rcx
    0.00 :   cb889:  jb     cb8ce <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb88b:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb890:  mov    0x170(%rax),%rax
    0.00 :   cb897:  mov    0x170(%rax),%rax
    0.00 :   cb89e:  mov    0x170(%rax),%rax
    0.00 :   cb8a5:  mov    0x170(%rax),%rax
    0.00 :   cb8ac:  mov    0x170(%rax),%rax
    0.00 :   cb8b3:  mov    0x170(%rax),%rax
    0.00 :   cb8ba:  mov    0x170(%rax),%rax
    0.00 :   cb8c1:  mov    0x170(%rax),%rax
    0.00 :   cb8c8:  add    $0xfffffffffffffff8,%rdx
    0.00 :   cb8cc:  jne    cb890 <std::sys::backtrace::__rust_begin_short_backtrace+0xaf0>
    0.00 :   cb8ce:  cmpw   $0x0,0x16a(%rax)
    0.00 :   cb8d6:  mov    0x8(%rsp),%rdi
    0.00 :   cb8db:  je     cb470 <std::sys::backtrace::__rust_begin_short_backtrace+0x6d0>
    0.00 :   cb8e1:  mov    (%rax),%r13
    0.00 :   cb8e4:  mov    0x8(%rax),%ebp
    0.00 :   cb8e7:  incq   0x250(%rdi)
    0.00 :   cb8ee:  mov    0x1a0(%rdi),%rax
    0.00 :   cb8f5:  mov    0xd0(%rax),%rax
    0.00 :   cb8fc:  test   %rax,%rax
    0.00 :   cb8ff:  jne    cb487 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e7>
    0.00 :   cb905:  mov    0x1a8(%rdi),%rcx
    0.00 :   cb90c:  xor    %eax,%eax
    0.00 :   cb90e:  cmpq   $0x0,0xc8(%rcx)
    0.00 :   cb916:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb91c:  mov    0x1a0(%rdi),%rax
    0.00 :   cb923:  mov    0xe0(%rax),%rcx
    0.00 :   cb92a:  mov    0x80(%rcx),%rdx
    0.00 :   cb931:  xor    %eax,%eax
    0.00 :   cb933:  test   %rdx,%rdx
    0.00 :   cb936:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb93c:  mov    0x40(%rcx),%rcx
    0.00 :   cb940:  xor    %eax,%eax
    0.00 :   cb942:  mov    $0x0,%r12d
    0.00 :   cb948:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb952:  test   %rdx,%rcx
    0.00 :   cb955:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb95b:  jmp    cba85 <std::sys::backtrace::__rust_begin_short_backtrace+0xce5>
    0.00 :   cb960:  mov    0x1a8(%rdi),%rcx
    0.00 :   cb967:  xor    %eax,%eax
    0.00 :   cb969:  cmpq   $0x0,0xc8(%rcx)
    0.00 :   cb971:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb977:  mov    0x1a0(%rdi),%rax
    0.00 :   cb97e:  mov    0xe0(%rax),%rcx
    0.00 :   cb985:  mov    0x80(%rcx),%rdx
    0.00 :   cb98c:  xor    %eax,%eax
    0.00 :   cb98e:  test   %rdx,%rdx
    0.00 :   cb991:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb997:  mov    0x40(%rcx),%rcx
    0.36 :   cb99b:  xor    %eax,%eax
    0.00 :   cb99d:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb9a7:  test   %rdx,%rcx
    0.00 :   cb9aa:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb9b0:  mov    0x198(%rdi),%rax
    0.00 :   cb9b7:  mov    $0x3b9aca00,%ebp
    0.00 :   cb9bc:  mov    $0x1,%r12b
    0.00 :   cb9bf:  cmpq   $0x2,0x60(%rax)
    0.00 :   cb9c4:  jb     cba80 <std::sys::backtrace::__rust_begin_short_backtrace+0xce0>
    0.00 :   cb9ca:  mov    $0x281,%ecx
    0.74 :   cb9cf:  dec    %rcx
    0.00 :   cb9d2:  je     cba80 <std::sys::backtrace::__rust_begin_short_backtrace+0xce0>
    0.00 :   cb9d8:  pause
   84.30 :   cb9da:  mov    0x8(%rsp),%rdi
    7.72 :   cb9df:  mov    0x1a0(%rdi),%rax
    0.00 :   cb9e6:  mov    0xd0(%rax),%rax
    0.00 :   cb9ed:  test   %rax,%rax
    0.00 :   cb9f0:  jne    cb487 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e7>
    0.52 :   cb9f6:  mov    0x1a8(%rdi),%rax
    0.00 :   cb9fd:  cmpq   $0x0,0xc8(%rax)
    0.00 :   cba05:  jne    cbda4 <std::sys::backtrace::__rust_begin_short_backtrace+0x1004>
    0.00 :   cba0b:  mov    0x1a0(%rdi),%rax
    0.00 :   cba12:  mov    0xe0(%rax),%rax
    0.00 :   cba19:  mov    0x80(%rax),%rdx
    0.26 :   cba20:  test   %rdx,%rdx
    0.22 :   cba23:  jne    cbd98 <std::sys::backtrace::__rust_begin_short_backtrace+0xff8>
    0.00 :   cba29:  mov    0x40(%rax),%rax
    0.80 :   cba2d:  movabs $0x7fffffffffffffff,%rdx
    1.18 :   cba37:  test   %rdx,%rax
    0.00 :   cba3a:  jne    cbd98 <std::sys::backtrace::__rust_begin_short_backtrace+0xff8>
    0.00 :   cba40:  mov    0x8(%rsp),%rax
    0.23 :   cba45:  mov    0x1a0(%rax),%rax
    0.76 :   cba4c:  mov    0xd8(%rax),%rax
    0.26 :   cba53:  mov    0x10(%rax),%rdx
    0.49 :   cba57:  xor    %eax,%eax
    0.00 :   cba59:  cmp    0x38(%rsp),%rdx
    0.00 :   cba5e:  je     cb9cf <std::sys::backtrace::__rust_begin_short_backtrace+0xc2f>
    0.00 :   cba64:  mov    0x8(%rsp),%rdi
    0.00 :   cba69:  jmp    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cba6e:  mov    %rcx,%rdx
    0.00 :   cba71:  cmp    $0x8,%rcx
    0.00 :   cba75:  jae    cb890 <std::sys::backtrace::__rust_begin_short_backtrace+0xaf0>
    0.00 :   cba7b:  jmp    cb8ce <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cba80:  mov    0x8(%rsp),%rdi
    0.00 :   cba85:  movb   $0x0,0x27e(%rdi)
    0.00 :   cba8c:  mov    0x198(%rdi),%r14
    0.00 :   cba93:  mov    %rdi,%rsi
    0.00 :   cba96:  lea    0x120(%rsp),%rdi
    0.00 :   cba9e:  xor    %edx,%edx
    0.00 :   cbaa0:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbaa5:  add    $0x10,%r14
    0.00 :   cbaa9:  mov    %r14,%rdi
    0.00 :   cbaac:  lea    0x120(%rsp),%rsi
    0.00 :   cbab4:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cbab9:  mov    0x8(%rsp),%rax
    0.00 :   cbabe:  mov    0x1a0(%rax),%rax
    0.00 :   cbac5:  mov    0xe0(%rax),%rbx
    0.00 :   cbacc:  mov    0x110(%rbx),%r14
    0.00 :   cbad3:  lea    0x20(%r14),%rax
    0.00 :   cbad7:  mov    %rax,0x50(%rsp)
    0.00 :   cbadc:  xor    %eax,%eax
    0.00 :   cbade:  mov    $0x1,%ecx
    0.00 :   cbae3:  lock cmpxchg %ecx,0x20(%r14)
    0.00 :   cbae9:  jne    cbdab <std::sys::backtrace::__rust_begin_short_backtrace+0x100b>
    0.00 :   cbaef:  mov    0xc6ab2(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cbaf6:  mov    (%rax),%rax
    0.00 :   cbaf9:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbb03:  test   %rcx,%rax
    0.00 :   cbb06:  jne    cbdba <std::sys::backtrace::__rust_begin_short_backtrace+0x101a>
    0.00 :   cbb0c:  movl   $0x0,0x14(%rsp)
    0.00 :   cbb14:  movzbl 0x24(%r14),%eax
    0.00 :   cbb19:  lock incq 0x18(%r14)
    0.00 :   cbb1e:  mov    0x10(%r14),%rax
    0.00 :   cbb22:  cmp    0x38(%rsp),%rax
    0.00 :   cbb27:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbb2d:  test   %r12b,%r12b
    0.00 :   cbb30:  je     cbc6d <std::sys::backtrace::__rust_begin_short_backtrace+0xecd>
    0.00 :   cbb36:  mov    0x80(%rbx),%rax
    0.00 :   cbb3d:  test   %rax,%rax
    0.00 :   cbb40:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbb46:  mov    0x40(%rbx),%rax
    0.00 :   cbb4a:  nopw   0x0(%rax,%rax,1)
    0.00 :   cbb50:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbb5a:  test   %rcx,%rax
    0.00 :   cbb5d:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbb63:  test   %rax,%rax
    0.00 :   cbb66:  jne    cbb7c <std::sys::backtrace::__rust_begin_short_backtrace+0xddc>
    0.00 :   cbb68:  xor    %eax,%eax
    0.00 :   cbb6a:  movabs $0x8000000000000000,%rcx
    0.00 :   cbb74:  lock cmpxchg %rcx,0x40(%rbx)
    0.00 :   cbb7a:  jne    cbb50 <std::sys::backtrace::__rust_begin_short_backtrace+0xdb0>
    0.00 :   cbb7c:  lea    0x28(%r14),%rax
    0.00 :   cbb80:  mov    (%rax),%ebp
    0.00 :   cbb82:  xor    %eax,%eax
    0.00 :   cbb84:  lea    0x20(%r14),%r13
    0.00 :   cbb88:  xchg   %eax,0x0(%r13)
    0.00 :   cbb8c:  cmp    $0x2,%eax
    0.00 :   cbb8f:  je     cbc2b <std::sys::backtrace::__rust_begin_short_backtrace+0xe8b>
    0.00 :   cbb95:  movq   $0x0,0x120(%rsp)
    0.00 :   cbba1:  mov    0xc6ad0(%rip),%r12        # 192678 <__errno_location@GLIBC_2.2.5>
    0.00 :   cbba8:  nopl   0x0(%rax,%rax,1)
    0.00 :   cbbb0:  lea    0x28(%r14),%rax
    0.00 :   cbbb4:  mov    (%rax),%eax
    0.00 :   cbbb6:  cmp    %ebp,%eax
    0.00 :   cbbb8:  jne    cbc03 <std::sys::backtrace::__rust_begin_short_backtrace+0xe63>
    0.00 :   cbbba:  cmpb   $0x0,0x120(%rsp)
    0.00 :   cbbc2:  mov    $0x0,%r8d
    0.00 :   cbbc8:  lea    0x128(%rsp),%rax
    0.00 :   cbbd0:  cmovne %rax,%r8
    0.00 :   cbbd4:  movl   $0xffffffff,(%rsp)
    0.00 :   cbbdb:  mov    $0xca,%edi
    0.00 :   cbbe0:  lea    0x28(%r14),%rsi
    0.00 :   cbbe4:  mov    $0x89,%edx
    0.00 :   cbbe9:  mov    %ebp,%ecx
    0.00 :   cbbeb:  xor    %r9d,%r9d
    0.00 :   cbbee:  xor    %eax,%eax
    0.00 :   cbbf0:  call   *0xc69e2(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cbbf6:  test   %rax,%rax
    0.00 :   cbbf9:  jns    cbc03 <std::sys::backtrace::__rust_begin_short_backtrace+0xe63>
    0.00 :   cbbfb:  call   *%r12
    0.00 :   cbbfe:  cmpl   $0x4,(%rax)
    0.00 :   cbc01:  je     cbbb0 <std::sys::backtrace::__rust_begin_short_backtrace+0xe10>
    0.00 :   cbc03:  xor    %eax,%eax
    0.00 :   cbc05:  mov    $0x1,%ecx
    0.00 :   cbc0a:  lock cmpxchg %ecx,0x0(%r13)
    0.00 :   cbc10:  jne    cbc4a <std::sys::backtrace::__rust_begin_short_backtrace+0xeaa>
    0.00 :   cbc12:  movzbl 0x24(%r14),%eax
    0.00 :   cbc17:  mov    0x10(%r14),%rax
    0.00 :   cbc1b:  cmp    0x38(%rsp),%rax
    0.00 :   cbc20:  je     cbb36 <std::sys::backtrace::__rust_begin_short_backtrace+0xd96>
    0.00 :   cbc26:  jmp    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbc2b:  mov    $0xca,%edi
    0.00 :   cbc30:  mov    %r13,%rsi
    0.00 :   cbc33:  mov    $0x81,%edx
    0.00 :   cbc38:  mov    $0x1,%ecx
    0.00 :   cbc3d:  xor    %eax,%eax
    0.00 :   cbc3f:  call   *0xc6993(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cbc45:  jmp    cbb95 <std::sys::backtrace::__rust_begin_short_backtrace+0xdf5>
    0.00 :   cbc4a:  lea    0x20(%r14),%rdi
    0.00 :   cbc4e:  call   *0xc69cc(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cbc54:  movzbl 0x24(%r14),%eax
    0.00 :   cbc59:  mov    0x10(%r14),%rax
    0.00 :   cbc5d:  cmp    0x38(%rsp),%rax
    0.00 :   cbc62:  je     cbb36 <std::sys::backtrace::__rust_begin_short_backtrace+0xd96>
    0.00 :   cbc68:  jmp    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbc6d:  mov    0x80(%rbx),%rax
    0.00 :   cbc74:  test   %rax,%rax
    0.00 :   cbc77:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbc7d:  mov    0x40(%rbx),%rax
    0.00 :   cbc81:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cbc90:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbc9a:  test   %rcx,%rax
    0.00 :   cbc9d:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbca3:  test   %rax,%rax
    0.00 :   cbca6:  jne    cbcbc <std::sys::backtrace::__rust_begin_short_backtrace+0xf1c>
    0.00 :   cbca8:  xor    %eax,%eax
    0.00 :   cbcaa:  movabs $0x8000000000000000,%rcx
    0.00 :   cbcb4:  lock cmpxchg %rcx,0x40(%rbx)
    0.00 :   cbcba:  jne    cbc90 <std::sys::backtrace::__rust_begin_short_backtrace+0xef0>
    0.00 :   cbcbc:  mov    %r13,0xa0(%rsp)
    0.00 :   cbcc4:  mov    %ebp,0xa8(%rsp)
    0.00 :   cbccb:  mov    $0x1,%edi
    0.00 :   cbcd0:  call   a17e0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   cbcd5:  mov    %rax,0x100(%rsp)
    0.00 :   cbcdd:  mov    %edx,0x108(%rsp)
    0.00 :   cbce4:  lea    0x120(%rsp),%rdi
    0.00 :   cbcec:  lea    0xa0(%rsp),%rsi
    0.00 :   cbcf4:  lea    0x100(%rsp),%rdx
    0.00 :   cbcfc:  call   a1710 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec.llvm.13342753452097612697>
    0.00 :   cbd01:  cmpb   $0x0,0x120(%rsp)
    0.00 :   cbd09:  mov    0x130(%rsp),%ecx
    0.00 :   cbd10:  mov    $0x0,%eax
    0.00 :   cbd15:  cmovne %eax,%ecx
    0.00 :   cbd18:  mov    0x128(%rsp),%rdx
    0.00 :   cbd20:  cmovne %rax,%rdx
    0.00 :   cbd24:  test   %rdx,%rdx
    0.00 :   cbd27:  sete   %al
    0.00 :   cbd2a:  test   %ecx,%ecx
    0.00 :   cbd2c:  sete   %sil
    0.00 :   cbd30:  test   %sil,%al
    0.00 :   cbd33:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbd35:  lea    0x28(%r14),%rdi
    0.00 :   cbd39:  lea    0x20(%r14),%rsi
    0.00 :   cbd3d:  call   a1d80 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys4sync7condvar5futexNtB2_7Condvar21wait_optional_timeout.llvm.13342753452097612697>
    0.00 :   cbd42:  movzbl 0x24(%r14),%eax
    0.00 :   cbd47:  mov    0x10(%r14),%rax
    0.00 :   cbd4b:  cmp    0x38(%rsp),%rax
    0.00 :   cbd50:  je     cbc6d <std::sys::backtrace::__rust_begin_short_backtrace+0xecd>
    0.00 :   cbd56:  lock decq 0x18(%r14)
    0.00 :   cbd5b:  cmpb   $0x0,0x14(%rsp)
    0.00 :   cbd60:  jne    cbd7b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cbd62:  mov    0xc683f(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cbd69:  mov    (%rax),%rax
    0.00 :   cbd6c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbd76:  test   %rcx,%rax
    0.00 :   cbd79:  jne    cbdec <std::sys::backtrace::__rust_begin_short_backtrace+0x104c>
    0.00 :   cbd7b:  xor    %eax,%eax
    0.00 :   cbd7d:  mov    0x50(%rsp),%rsi
    0.00 :   cbd82:  xchg   %eax,(%rsi)
    0.00 :   cbd84:  cmp    $0x2,%eax
    0.00 :   cbd87:  je     cbdd3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1033>
    0.00 :   cbd89:  movabs $0x7fffffffffffffff,%rax
    0.00 :   cbd93:  lock and %rax,0x40(%rbx)
    0.00 :   cbd98:  xor    %eax,%eax
    0.00 :   cbd9a:  mov    0x8(%rsp),%rdi
    0.25 :   cbd9f:  jmp    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cbda4:  xor    %eax,%eax
    0.00 :   cbda6:  jmp    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cbdab:  lea    0x20(%r14),%rdi
    0.00 :   cbdaf:  call   *0xc686b(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cbdb5:  jmp    cbaef <std::sys::backtrace::__rust_begin_short_backtrace+0xd4f>
    0.00 :   cbdba:  call   *0xc6808(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cbdc0:  mov    %eax,0x14(%rsp)
    0.00 :   cbdc4:  mov    0x14(%rsp),%eax
    0.00 :   cbdc8:  xor    $0x1,%al
    0.00 :   cbdca:  mov    %eax,0x14(%rsp)
    0.00 :   cbdce:  jmp    cbb14 <std::sys::backtrace::__rust_begin_short_backtrace+0xd74>
    0.00 :   cbdd3:  mov    $0xca,%edi
    0.00 :   cbdd8:  mov    $0x81,%edx
    0.00 :   cbddd:  mov    $0x1,%ecx
    0.00 :   cbde2:  xor    %eax,%eax
    0.00 :   cbde4:  call   *0xc67ee(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cbdea:  jmp    cbd89 <std::sys::backtrace::__rust_begin_short_backtrace+0xfe9>
    0.00 :   cbdec:  call   *0xc67d6(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cbdf2:  test   %al,%al
    0.00 :   cbdf4:  jne    cbd7b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cbdf6:  movb   $0x1,0x24(%r14)
    0.00 :   cbdfb:  jmp    cbd7b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cbe00:  movups 0x128(%rsp),%xmm0
    0.00 :   cbe08:  movups 0x138(%rsp),%xmm1
    0.00 :   cbe10:  movups 0x148(%rsp),%xmm2
    0.00 :   cbe18:  mov    0x158(%rsp),%rcx
    0.00 :   cbe20:  mov    %rcx,0x3e0(%rsp)
    0.00 :   cbe28:  movups %xmm2,0x3d0(%rsp)
    0.00 :   cbe30:  movups %xmm1,0x3c0(%rsp)
    0.00 :   cbe38:  mov    %rax,0x3a8(%rsp)
    0.00 :   cbe40:  movups %xmm0,0x3b0(%rsp)
    0.00 :   cbe48:  movq   $0x0,0x58(%rsp)
    0.00 :   cbe51:  movq   $0x1,0x60(%rsp)
    0.00 :   cbe5a:  movq   $0x0,0x68(%rsp)
    0.00 :   cbe63:  movq   $0x60000020,0x130(%rsp)
    0.00 :   cbe6f:  lea    0x58(%rsp),%rax
    0.00 :   cbe74:  mov    %rax,0x120(%rsp)
    0.00 :   cbe7c:  lea    0xc1965(%rip),%rax        # 18d7e8 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0xe8>
    0.00 :   cbe83:  mov    %rax,0x128(%rsp)
    0.00 :   cbe8b:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbe93:  lea    0x120(%rsp),%rsi
    0.00 :   cbe9b:  call   *0xc738f(%rip)        # 193230 <_DYNAMIC+0x1218>
    0.00 :   cbea1:  test   %al,%al
    0.00 :   cbea3:  jne    cc323 <std::sys::backtrace::__rust_begin_short_backtrace+0x1583>
    0.00 :   cbea9:  mov    0x58(%rsp),%rbx
    0.00 :   cbeae:  mov    0x60(%rsp),%r15
    0.00 :   cbeb3:  mov    0x68(%rsp),%r14
    0.00 :   cbeb8:  mov    $0x18,%edi
    0.00 :   cbebd:  call   *0xc639d(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cbec3:  test   %rax,%rax
    0.00 :   cbec6:  je     cc34d <std::sys::backtrace::__rust_begin_short_backtrace+0x15ad>
    0.00 :   cbecc:  mov    %rbx,(%rax)
    0.00 :   cbecf:  mov    %r15,0x8(%rax)
    0.00 :   cbed3:  mov    %r14,0x10(%rax)
    0.00 :   cbed7:  lea    0xc3082(%rip),%rdx        # 18ef60 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x4c8>
    0.00 :   cbede:  lea    0x58(%rsp),%rdi
    0.00 :   cbee3:  mov    %rax,%rsi
    0.00 :   cbee6:  mov    0x18(%rsp),%r12
    0.00 :   cbeeb:  mov    0x20(%rsp),%r13
    0.00 :   cbef0:  call   *0xc727a(%rip)        # 193170 <_DYNAMIC+0x1158>
    0.00 :   cbef6:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbefe:  call   d7ad0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10657235172099788962>
    0.00 :   cbf03:  lea    0x58(%rsp),%rsi
    0.00 :   cbf08:  mov    %r13,%rdi
    0.00 :   cbf0b:  call   118580 <vthread::carrier::record_failure>
    0.00 :   cbf10:  mov    0x8(%rsp),%rax
    0.00 :   cbf15:  mov    0x1a0(%rax),%rbx
    0.00 :   cbf1c:  lea    0x88(%rbx),%r14
    0.00 :   cbf23:  mov    $0x1,%ecx
    0.00 :   cbf28:  xor    %eax,%eax
    0.00 :   cbf2a:  lock cmpxchg %ecx,0x88(%rbx)
    0.00 :   cbf32:  jne    cc2b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1517>
    0.00 :   cbf38:  mov    0xc6669(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cbf3f:  mov    (%rax),%rax
    0.00 :   cbf42:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbf4c:  test   %rcx,%rax
    0.00 :   cbf4f:  jne    cc2c5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1525>
    0.00 :   cbf55:  lea    0x8c(%rbx),%r15
    0.00 :   cbf5c:  movzbl 0x8c(%rbx),%eax
    0.00 :   cbf63:  movb   $0x1,0xc8(%rbx)
    0.00 :   cbf6a:  mov    0xc6637(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cbf71:  mov    (%rax),%rax
    0.00 :   cbf74:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbf7e:  test   %rcx,%rax
    0.00 :   cbf81:  jne    cc30c <std::sys::backtrace::__rust_begin_short_backtrace+0x156c>
    0.00 :   cbf87:  xor    %eax,%eax
    0.00 :   cbf89:  xchg   %eax,(%r14)
    0.00 :   cbf8c:  cmp    $0x2,%eax
    0.00 :   cbf8f:  je     cc2ed <std::sys::backtrace::__rust_begin_short_backtrace+0x154d>
    0.00 :   cbf95:  movb   $0x1,0xeb(%rbx)
    0.00 :   cbf9c:  mov    0xd8(%rbx),%rdi
    0.00 :   cbfa3:  add    $0x10,%rdi
    0.00 :   cbfa7:  call   118460 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10657235172099788962>
    0.00 :   cbfac:  mov    0x8(%rsp),%rdi
    0.00 :   cbfb1:  xor    %esi,%esi
    0.00 :   cbfb3:  mov    $0x4,%ecx
    0.00 :   cbfb8:  call   113700 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cbfbd:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbfc5:  mov    0x8(%rsp),%rsi
    0.00 :   cbfca:  mov    $0x3,%edx
    0.00 :   cbfcf:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbfd4:  movq   $0x0,0x450(%rsp)
    0.00 :   cbfe0:  mov    0x8(%rsp),%rax
    0.00 :   cbfe5:  mov    0x198(%rax),%rdi
    0.00 :   cbfec:  add    $0x10,%rdi
    0.00 :   cbff0:  lea    0x3a8(%rsp),%rsi
    0.00 :   cbff8:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cbffd:  jmp    cc056 <std::sys::backtrace::__rust_begin_short_backtrace+0x12b6>
    0.00 :   cbfff:  mov    %rdi,%rbx
    0.00 :   cc002:  xor    %esi,%esi
    0.00 :   cc004:  mov    $0x3,%ecx
    0.00 :   cc009:  mov    0x20(%rsp),%r13
    0.00 :   cc00e:  call   113700 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cc013:  lea    0x120(%rsp),%rdi
    0.00 :   cc01b:  mov    %rbx,%rsi
    0.00 :   cc01e:  mov    $0x2,%edx
    0.00 :   cc023:  mov    0x18(%rsp),%r12
    0.00 :   cc028:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cc02d:  movq   $0x0,0x1c8(%rsp)
    0.00 :   cc039:  mov    0x8(%rsp),%rax
    0.00 :   cc03e:  mov    0x198(%rax),%rdi
    0.00 :   cc045:  add    $0x10,%rdi
    0.00 :   cc049:  lea    0x120(%rsp),%rsi
    0.00 :   cc051:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cc056:  mov    0xa0(%r12),%rsi
    0.00 :   cc05e:  mov    0x28(%rsp),%rcx
    0.00 :   cc063:  cmp    %rsi,%rcx
    0.00 :   cc066:  jae    cc3c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1620>
    0.00 :   cc06c:  mov    0x98(%r12),%rax
    0.00 :   cc074:  mov    (%rax,%rcx,8),%rax
    0.00 :   cc078:  movb   $0x1,0xe9(%rax)
    0.00 :   cc07f:  mov    0x8(%rsp),%rcx
    0.00 :   cc084:  cmpl   $0x2,(%rcx)
    0.00 :   cc087:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc08d:  cmpq   $0x0,0x178(%rcx)
    0.00 :   cc095:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc09b:  cmpq   $0x0,0x1b8(%rcx)
    0.00 :   cc0a3:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0a9:  cmpq   $0x0,0xf8(%rcx)
    0.00 :   cc0b1:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0b7:  cmpq   $0x0,0x118(%rcx)
    0.00 :   cc0bf:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0c5:  cmpq   $0x0,0x158(%rcx)
    0.00 :   cc0cd:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0d3:  mov    0x90(%rcx),%rax
    0.00 :   cc0da:  cmp    0xa8(%rcx),%rax
    0.00 :   cc0e1:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0e7:  mov    0xc0(%rcx),%rax
    0.00 :   cc0ee:  cmp    0xd8(%rcx),%rax
    0.00 :   cc0f5:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0f7:  cmpq   $0x0,0x60(%rcx)
    0.00 :   cc0fc:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0fe:  mov    0x198(%rcx),%rax
    0.00 :   cc105:  mov    0x1b0(%rcx),%rdi
    0.00 :   cc10c:  mov    0x88(%rax),%rsi
    0.00 :   cc113:  cmp    %rsi,%rdi
    0.00 :   cc116:  jae    cc3d7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1637>
    0.00 :   cc11c:  mov    0x80(%rax),%rax
    0.00 :   cc123:  shl    $0x6,%rdi
    0.00 :   cc127:  mov    (%rax,%rdi,1),%rax
    0.00 :   cc12b:  test   %rax,%rax
    0.00 :   cc12e:  mov    0x8(%rsp),%rdi
    0.00 :   cc133:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc135:  mov    0x1a8(%rdi),%rax
    0.00 :   cc13c:  cmpq   $0x0,0x98(%rax)
    0.00 :   cc144:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc146:  cmpq   $0x0,0xc8(%rax)
    0.00 :   cc14e:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc150:  mov    0x1a0(%rdi),%rax
    0.00 :   cc157:  mov    0xd0(%rax),%rax
    0.00 :   cc15e:  test   %rax,%rax
    0.00 :   cc161:  je     cc36c <std::sys::backtrace::__rust_begin_short_backtrace+0x15cc>
    0.00 :   cc167:  mov    $0x10,%edi
    0.00 :   cc16c:  call   *0xc60ee(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cc172:  test   %rax,%rax
    0.00 :   cc175:  je     cc2a2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1502>
    0.00 :   cc17b:  lea    -0xad66d(%rip),%rcx        # 1eb15 <anon.de2471ab41e489a293ba001b839d8fc3.749.llvm.10657235172099788962+0x321>
    0.00 :   cc182:  mov    %rcx,(%rax)
    0.00 :   cc185:  movq   $0x1a,0x8(%rax)
    0.00 :   cc18d:  lea    0xc2734(%rip),%rdx        # 18e8c8 <anon.de2471ab41e489a293ba001b839d8fc3.433.llvm.10657235172099788962+0x858>
    0.00 :   cc194:  lea    0xe0(%rsp),%rdi
    0.00 :   cc19c:  mov    %rax,%rsi
    0.00 :   cc19f:  call   *0xc6fcb(%rip)        # 193170 <_DYNAMIC+0x1158>
    0.00 :   cc1a5:  lea    0xe0(%rsp),%rsi
    0.00 :   cc1ad:  mov    %r13,%rdi
    0.00 :   cc1b0:  call   118580 <vthread::carrier::record_failure>
    0.00 :   cc1b5:  mov    0x8(%rsp),%rsi
    0.00 :   cc1ba:  movb   $0x0,0x27e(%rsi)
    0.00 :   cc1c1:  mov    0x198(%rsi),%r14
    0.00 :   cc1c8:  lea    0x480(%rsp),%rdi
    0.00 :   cc1d0:  mov    $0x3,%edx
    0.00 :   cc1d5:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cc1da:  add    $0x10,%r14
    0.00 :   cc1de:  lea    0x480(%rsp),%rsi
    0.00 :   cc1e6:  mov    %r14,%rdi
    0.00 :   cc1e9:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cc1ee:  mov    %r13,%rdi
    0.00 :   cc1f1:  call   1214f0 <_ZN7vthread7control6Shared12request_stop17hb40bf47e89bed244E.llvm.10657235172099788962>
    0.00 :   cc1f6:  lea    0x40(%rsp),%rdi
    0.00 :   cc1fb:  call   *0xc7037(%rip)        # 193238 <_DYNAMIC+0x1220>
    0.00 :   cc201:  mov    0x40(%rsp),%rax
    0.00 :   cc206:  test   %rax,%rax
    0.00 :   cc209:  je     cc231 <std::sys::backtrace::__rust_begin_short_backtrace+0x1491>
    0.00 :   cc20b:  lock decq (%rax)
    0.00 :   cc20f:  jne    cc21c <std::sys::backtrace::__rust_begin_short_backtrace+0x147c>
    0.00 :   cc211:  lea    0x40(%rsp),%rdi
    0.00 :   cc216:  call   *0xc6f64(%rip)        # 193180 <_DYNAMIC+0x1168>
    0.00 :   cc21c:  mov    0x48(%rsp),%rax
    0.00 :   cc221:  decq   (%rax)
    0.00 :   cc224:  jne    cc231 <std::sys::backtrace::__rust_begin_short_backtrace+0x1491>
    0.00 :   cc226:  lea    0x48(%rsp),%rdi
    0.00 :   cc22b:  call   *0xc6f57(%rip)        # 193188 <_DYNAMIC+0x1170>
    0.00 :   cc231:  lock decq (%r12)
    0.00 :   cc236:  jne    cc246 <std::sys::backtrace::__rust_begin_short_backtrace+0x14a6>
    0.00 :   cc238:  lea    0x98(%rsp),%rdi
    0.00 :   cc240:  call   *0xc6fca(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc246:  lock decq (%r12)
    0.00 :   cc24b:  jne    cc25b <std::sys::backtrace::__rust_begin_short_backtrace+0x14bb>
    0.00 :   cc24d:  lea    0xc0(%rsp),%rdi
    0.00 :   cc255:  call   *0xc6fb5(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc25b:  add    $0x558,%rsp
    0.00 :   cc262:  pop    %rbx
    0.00 :   cc263:  pop    %r12
    0.00 :   cc265:  pop    %r13
    0.00 :   cc267:  pop    %r14
    0.00 :   cc269:  pop    %r15
    0.00 :   cc26b:  pop    %rbp
    0.00 :   cc26c:  ret
    0.00 :   cc26d:  lea    -0xad78c(%rip),%rdi        # 1eae8 <anon.de2471ab41e489a293ba001b839d8fc3.749.llvm.10657235172099788962+0x2f4>
    0.00 :   cc274:  lea    0xc2c0d(%rip),%rdx        # 18ee88 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x3f0>
    0.00 :   cc27b:  mov    $0x19,%esi
    0.00 :   cc280:  mov    0x20(%rsp),%r13
    0.00 :   cc285:  call   *0xc61b5(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   cc28b:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc290:  lea    0xc2d19(%rip),%rdi        # 18efb0 <anon.de2471ab41e489a293ba001b839d8fc3.857.llvm.10657235172099788962+0x30>
    0.00 :   cc297:  call   *0xc6183(%rip)        # 192420 <_DYNAMIC+0x408>
    0.00 :   cc29d:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc2a2:  mov    $0x8,%edi
    0.00 :   cc2a7:  mov    $0x10,%esi
    0.00 :   cc2ac:  call   *0xc5fd6(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   cc2b2:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc2b7:  mov    %r14,%rdi
    0.00 :   cc2ba:  call   *0xc6360(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cc2c0:  jmp    cbf38 <std::sys::backtrace::__rust_begin_short_backtrace+0x1198>
    0.00 :   cc2c5:  call   *0xc62fd(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cc2cb:  movzbl 0x8c(%rbx),%ecx
    0.00 :   cc2d2:  movb   $0x1,0xc8(%rbx)
    0.00 :   cc2d9:  test   %al,%al
    0.00 :   cc2db:  je     cbf87 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cc2e1:  lea    0x8c(%rbx),%r15
    0.00 :   cc2e8:  jmp    cbf6a <std::sys::backtrace::__rust_begin_short_backtrace+0x11ca>
    0.00 :   cc2ed:  mov    $0xca,%edi
    0.00 :   cc2f2:  mov    %r14,%rsi
    0.00 :   cc2f5:  mov    $0x81,%edx
    0.00 :   cc2fa:  mov    $0x1,%ecx
    0.00 :   cc2ff:  xor    %eax,%eax
    0.00 :   cc301:  call   *0xc62d1(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cc307:  jmp    cbf95 <std::sys::backtrace::__rust_begin_short_backtrace+0x11f5>
    0.00 :   cc30c:  call   *0xc62b6(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cc312:  test   %al,%al
    0.00 :   cc314:  jne    cbf87 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cc31a:  movb   $0x1,(%r15)
    0.00 :   cc31e:  jmp    cbf87 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cc323:  lea    -0xaee9f(%rip),%rdi        # 1d48b <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x73>
    0.00 :   cc32a:  lea    0xc155f(%rip),%rcx        # 18d890 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x20>
    0.00 :   cc331:  lea    0xc14e0(%rip),%r8        # 18d818 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0x118>
    0.00 :   cc338:  lea    0x37(%rsp),%rdx
    0.00 :   cc33d:  mov    $0x37,%esi
    0.00 :   cc342:  call   *0xc5f38(%rip)        # 192280 <_DYNAMIC+0x268>
    0.00 :   cc348:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc34d:  mov    $0x8,%edi
    0.00 :   cc352:  mov    $0x18,%esi
    0.00 :   cc357:  mov    0x18(%rsp),%r12
    0.00 :   cc35c:  mov    0x20(%rsp),%r13
    0.00 :   cc361:  call   *0xc5f21(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   cc367:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc36c:  call   d7e70 <core::ptr::drop_in_place<vthread::kernel::Kernel>>
    0.00 :   cc371:  mov    0x8(%rsp),%rdi
    0.00 :   cc376:  call   *0xc5ecc(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cc37c:  mov    0x18(%rsp),%rax
    0.00 :   cc381:  mov    0xa0(%rax),%rsi
    0.00 :   cc388:  cmp    %rsi,0x28(%rsp)
    0.00 :   cc38d:  jae    cc3e9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1649>
    0.00 :   cc38f:  mov    0x18(%rsp),%r12
    0.00 :   cc394:  mov    0x98(%r12),%rax
    0.00 :   cc39c:  mov    0x28(%rsp),%rcx
    0.00 :   cc3a1:  mov    (%rax,%rcx,8),%rax
    0.00 :   cc3a5:  movb   $0x1,0xea(%rax)
    0.00 :   cc3ac:  jmp    cc1f6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1456>
    0.00 :   cc3b1:  lea    0xc2ae8(%rip),%rdx        # 18eea0 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x408>
    0.00 :   cc3b8:  call   *0xc5e62(%rip)        # 192220 <_DYNAMIC+0x208>
    0.00 :   cc3be:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc3c0:  xor    %r15d,%r15d
    0.00 :   cc3c3:  lea    0xc2b66(%rip),%rdx        # 18ef30 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x498>
    0.00 :   cc3ca:  mov    0x28(%rsp),%rdi
    0.00 :   cc3cf:  call   *0xc5e4b(%rip)        # 192220 <_DYNAMIC+0x208>
    0.00 :   cc3d5:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc3d7:  xor    %r15d,%r15d
    0.00 :   cc3da:  lea    0xc2b37(%rip),%rdx        # 18ef18 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x480>
    0.00 :   cc3e1:  call   *0xc5e39(%rip)        # 192220 <_DYNAMIC+0x208>
    0.00 :   cc3e7:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc3e9:  xor    %r15d,%r15d
    0.00 :   cc3ec:  lea    0xc2b55(%rip),%rdx        # 18ef48 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x4b0>
    0.00 :   cc3f3:  mov    0x28(%rsp),%rdi
    0.00 :   cc3f8:  call   *0xc5e22(%rip)        # 192220 <_DYNAMIC+0x208>
    0.00 :   cc3fe:  ud2
    0.00 :   cc400:  mov    %rax,%r14
    0.00 :   cc403:  mov    0x8(%rsp),%rdi
    0.00 :   cc408:  call   *0xc5e3a(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cc40e:  xor    %r15d,%r15d
    0.00 :   cc411:  jmp    cc48d <std::sys::backtrace::__rust_begin_short_backtrace+0x16ed>
    0.00 :   cc413:  mov    %rax,%r14
    0.00 :   cc416:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc41e:  call   dc9f0 <core::ptr::drop_in_place<vthread::context::wake::mount_carrier::{{closure}}>>
    0.00 :   cc423:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc428:  call   *0xc602a(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc42e:  mov    %rax,%r14
    0.00 :   cc431:  movzbl 0x14(%rsp),%esi
    0.00 :   cc436:  mov    0x50(%rsp),%rdi
    0.00 :   cc43b:  call   dbb70 <_ZN4core3ptr73drop_in_place$LT$std..sync..poison..mutex..MutexGuard$LT$$LP$$RP$$GT$$GT$17h714f23ec911ea948E.llvm.10657235172099788962>
    0.00 :   cc440:  jmp    cc4d2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1732>
    0.00 :   cc445:  call   *0xc600d(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc44b:  mov    %rax,%r14
    0.00 :   cc44e:  movzbl 0x14(%rsp),%esi
    0.00 :   cc453:  mov    0x50(%rsp),%rdi
    0.00 :   cc458:  call   dbb70 <_ZN4core3ptr73drop_in_place$LT$std..sync..poison..mutex..MutexGuard$LT$$LP$$RP$$GT$$GT$17h714f23ec911ea948E.llvm.10657235172099788962>
    0.00 :   cc45d:  jmp    cc4d2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1732>
    0.00 :   cc45f:  call   *0xc5ff3(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc465:  mov    %rax,%r14
    0.00 :   cc468:  jmp    cc524 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cc46d:  mov    %rax,%r14
    0.00 :   cc470:  lea    0x40(%rsp),%rdi
    0.00 :   cc475:  call   dc930 <core::ptr::drop_in_place<core::option::Option<vthread::context::wake::CarrierRoute>>>
    0.00 :   cc47a:  mov    0x18(%rsp),%r12
    0.00 :   cc47f:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc484:  call   *0xc5fce(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc48a:  mov    %rax,%r14
    0.00 :   cc48d:  mov    %r15,%rdi
    0.00 :   cc490:  mov    %r12,%rsi
    0.00 :   cc493:  call   d6130 <core::ptr::drop_in_place<core::result::Result<(),alloc::boxed::Box<dyn core::any::Any+core::marker::Send>>>>
    0.00 :   cc498:  mov    0x18(%rsp),%r12
    0.00 :   cc49d:  jmp    cc5b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1810>
    0.00 :   cc4a2:  mov    %rax,%r14
    0.00 :   cc4a5:  lock decq (%r12)
    0.00 :   cc4aa:  jne    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc4b0:  lea    0xd0(%rsp),%rdi
    0.00 :   cc4b8:  call   *0xc6d52(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc4be:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc4c3:  mov    %rax,%r14
    0.00 :   cc4c6:  movzbl %bpl,%esi
    0.00 :   cc4ca:  mov    %r13,%rdi
    0.00 :   cc4cd:  call   d5340 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::thread_failure::ThreadFailures>>>
    0.00 :   cc4d2:  mov    %r14,%rdi
    0.00 :   cc4d5:  jmp    cc4e2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1742>
    0.00 :   cc4d7:  call   *0xc5f7b(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc4dd:  jmp    cc4df <std::sys::backtrace::__rust_begin_short_backtrace+0x173f>
    0.00 :   cc4df:  mov    %rax,%rdi
    0.00 :   cc4e2:  mov    0x18(%rsp),%r12
    0.00 :   cc4e7:  mov    0x20(%rsp),%r13
    0.00 :   cc4ec:  jmp    cc671 <std::sys::backtrace::__rust_begin_short_backtrace+0x18d1>
    0.00 :   cc4f1:  mov    %rax,%r14
    0.00 :   cc4f4:  test   %rbx,%rbx
    0.00 :   cc4f7:  je     cc524 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cc4f9:  mov    %r15,%rdi
    0.00 :   cc4fc:  call   *0xc5d46(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cc502:  jmp    cc524 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cc504:  mov    %rax,%r14
    0.00 :   cc507:  cmpq   $0x0,0x58(%rsp)
    0.00 :   cc50d:  je     cc51a <std::sys::backtrace::__rust_begin_short_backtrace+0x177a>
    0.00 :   cc50f:  mov    0x60(%rsp),%rdi
    0.00 :   cc514:  call   *0xc5d2e(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cc51a:  mov    0x18(%rsp),%r12
    0.00 :   cc51f:  mov    0x20(%rsp),%r13
    0.00 :   cc524:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc52c:  call   d7ad0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10657235172099788962>
    0.00 :   cc531:  mov    %r14,%rdi
    0.00 :   cc534:  call   *0xc64f6(%rip)        # 192a30 <_DYNAMIC+0xa18>
    0.00 :   cc53a:  mov    0xc6067(%rip),%rcx        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cc541:  lock decq (%rcx)
    0.00 :   cc545:  decq   %fs:0xffffffffffffff70
    0.00 :   cc54e:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cc557:  mov    0xa0(%r12),%rsi
    0.00 :   cc55f:  mov    0x28(%rsp),%rdi
    0.00 :   cc564:  cmp    %rsi,%rdi
    0.00 :   cc567:  jae    cc581 <std::sys::backtrace::__rust_begin_short_backtrace+0x17e1>
    0.00 :   cc569:  mov    0x98(%r12),%rcx
    0.00 :   cc571:  mov    (%rcx,%rdi,8),%rcx
    0.00 :   cc575:  movb   $0x1,0xe9(%rcx)
    0.00 :   cc57c:  jmp    cc194 <std::sys::backtrace::__rust_begin_short_backtrace+0x13f4>
    0.00 :   cc581:  mov    %rdx,%r12
    0.00 :   cc584:  mov    %rax,%r15
    0.00 :   cc587:  jmp    cc3c3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1623>
    0.00 :   cc58c:  call   *0xc5ec6(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc592:  mov    %rax,%r14
    0.00 :   cc595:  lea    0x120(%rsp),%rdi
    0.00 :   cc59d:  call   dc930 <core::ptr::drop_in_place<core::option::Option<vthread::context::wake::CarrierRoute>>>
    0.00 :   cc5a2:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc5a7:  call   *0xc5eab(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc5ad:  mov    %rax,%r14
    0.00 :   cc5b0:  lea    0x40(%rsp),%rdi
    0.00 :   cc5b5:  call   db170 <core::ptr::drop_in_place<vthread::context::wake::CarrierRouteGuard>>
    0.00 :   cc5ba:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc5bf:  mov    %rax,%r14
    0.00 :   cc5c2:  lea    0x120(%rsp),%rdi
    0.00 :   cc5ca:  call   d7e70 <core::ptr::drop_in_place<vthread::kernel::Kernel>>
    0.00 :   cc5cf:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc5d4:  call   *0xc5e7e(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc5da:  mov    %rax,%r14
    0.00 :   cc5dd:  lea    0x120(%rsp),%rdi
    0.00 :   cc5e5:  call   dc5c0 <core::ptr::drop_in_place<alloc::rc::RcInner<vthread::local_carrier::LocalCarrier>>>
    0.00 :   cc5ea:  lea    0xa0(%rsp),%rdi
    0.00 :   cc5f2:  call   dd0a0 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::rc::Rc<vthread::context::Execution>>>>
    0.00 :   cc5f7:  lea    0xe0(%rsp),%rdi
    0.00 :   cc5ff:  call   dd330 <core::ptr::drop_in_place<alloc::collections::vec_deque::VecDeque<vthread::inbox::SpawnPacket>>>
    0.00 :   cc604:  lea    0x100(%rsp),%rdi
    0.00 :   cc60c:  call   dc060 <core::ptr::drop_in_place<core::option::Option<vthread::inbox::SpawnPacket>>>
    0.00 :   cc611:  lea    0x58(%rsp),%rdi
    0.00 :   cc616:  call   db2f0 <core::ptr::drop_in_place<vthread::kernel::parked_tasks::ParkedTasks>>
    0.00 :   cc61b:  lea    0x480(%rsp),%rdi
    0.00 :   cc623:  call   d9c90 <core::ptr::drop_in_place<vthread::ready_queue::ReadyQueue>>
    0.00 :   cc628:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc630:  call   d9e60 <core::ptr::drop_in_place<vthread::kernel_tasks::KernelTasks>>
    0.00 :   cc635:  lock decq (%r12)
    0.00 :   cc63a:  jne    cc647 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a7>
    0.00 :   cc63c:  lea    0x40(%rsp),%rdi
    0.00 :   cc641:  call   *0xc6bc9(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc647:  lock decq (%rbx)
    0.00 :   cc64b:  jne    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc64d:  lea    0xd8(%rsp),%rdi
    0.00 :   cc655:  call   *0xc6be5(%rip)        # 193240 <_DYNAMIC+0x1228>
    0.00 :   cc65b:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc65d:  call   *0xc5df5(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc663:  call   *0xc5def(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc669:  mov    %rax,%rdi
    0.00 :   cc66c:  mov    0x18(%rsp),%r12
    0.00 :   cc671:  call   *0xc63b9(%rip)        # 192a30 <_DYNAMIC+0xa18>
    0.00 :   cc677:  mov    0xc5f2a(%rip),%rcx        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cc67e:  lock decq (%rcx)
    0.00 :   cc682:  decq   %fs:0xffffffffffffff70
    0.00 :   cc68b:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cc694:  lea    0x58(%rsp),%rdi
    0.00 :   cc699:  mov    %rax,%rsi
    0.00 :   cc69c:  call   *0xc6ace(%rip)        # 193170 <_DYNAMIC+0x1158>
    0.00 :   cc6a2:  jmp    cbf03 <std::sys::backtrace::__rust_begin_short_backtrace+0x1163>
    0.00 :   cc6a7:  mov    %rax,%r14
    0.00 :   cc6aa:  jmp    cc531 <std::sys::backtrace::__rust_begin_short_backtrace+0x1791>
    0.00 :   cc6af:  mov    %rax,%r14
    0.00 :   cc6b2:  jmp    cc6cc <std::sys::backtrace::__rust_begin_short_backtrace+0x192c>
    0.00 :   cc6b4:  mov    %rax,%r14
    0.00 :   cc6b7:  lock decq (%r12)
    0.00 :   cc6bc:  jne    cc6cc <std::sys::backtrace::__rust_begin_short_backtrace+0x192c>
    0.00 :   cc6be:  lea    0x98(%rsp),%rdi
    0.00 :   cc6c6:  call   *0xc6b44(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc6cc:  lock decq (%r12)
    0.00 :   cc6d1:  jne    cc6e1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1941>
    0.00 :   cc6d3:  lea    0xc0(%rsp),%rdi
    0.00 :   cc6db:  call   *0xc6b2f(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc6e1:  mov    %r14,%rdi
    0.00 :   cc6e4:  call   187ca0 <_Unwind_Resume@plt>
    0.00 :   cc6e9:  call   *0xc5d69(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc6ef:  call   *0xc5d63(%rip)        # 192458 <_DYNAMIC+0x440>
 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (1 samples, percent: global period)
---------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000c9b30 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   c9b30:  push   %rbp
    0.00 :   c9b31:  push   %r15
    0.00 :   c9b33:  push   %r14
    0.00 :   c9b35:  push   %r13
    0.00 :   c9b37:  push   %r12
    0.00 :   c9b39:  push   %rbx
    0.00 :   c9b3a:  sub    $0x138,%rsp
    0.00 :   c9b41:  mov    %rdi,0xe8(%rsp)
    0.00 :   c9b49:  movb   $0x1,%fs:0xffffffffffffffb8
    0.00 :   c9b52:  lea    0x10(%rdi),%rbx
    0.00 :   c9b56:  mov    %rdi,(%rsp)
    0.00 :   c9b5a:  lea    0x30(%rdi),%r14
    0.00 :   c9b5e:  mov    %r14,0x28(%rsp)
    0.00 :   c9b63:  mov    %rbx,0xe0(%rsp)
    0.00 :   c9b6b:  jmp    c9b8e <std::sys::backtrace::__rust_begin_short_backtrace+0x5e>
    0.00 :   c9b6d:  add    $0x989680,%ecx
    0.00 :   c9b73:  mov    0xe0(%rsp),%rbx
    0.00 :   c9b7b:  mov    %rbx,%rdi
    0.00 :   c9b7e:  mov    0x110(%rsp),%rsi
    0.00 :   c9b86:  mov    %rax,%rdx
    0.00 :   c9b89:  call   118180 <vthread::signal::Signal::wait>
    0.00 :   c9b8e:  mov    (%rbx),%rax
    0.00 :   c9b91:  mov    %rax,0x110(%rsp)
    0.00 :   c9b99:  xor    %eax,%eax
    0.00 :   c9b9b:  mov    $0x1,%ecx
    0.00 :   c9ba0:  lock cmpxchg %ecx,(%r14)
    0.00 :   c9ba5:  jne    ca3cd <std::sys::backtrace::__rust_begin_short_backtrace+0x89d>
    0.00 :   c9bab:  mov    0xc89f6(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c9bb2:  mov    (%rax),%rax
    0.00 :   c9bb5:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9bbf:  test   %rcx,%rax
    0.00 :   c9bc2:  jne    ca3db <std::sys::backtrace::__rust_begin_short_backtrace+0x8ab>
    0.00 :   c9bc8:  movl   $0x0,0xc(%rsp)
    0.00 :   c9bd0:  mov    (%rsp),%rcx
    0.00 :   c9bd4:  movzbl 0x34(%rcx),%eax
    0.00 :   c9bd8:  mov    0x48(%rcx),%rax
    0.00 :   c9bdc:  test   %rax,%rax
    0.00 :   c9bdf:  je     ca6d0 <std::sys::backtrace::__rust_begin_short_backtrace+0xba0>
    0.00 :   c9be5:  mov    (%rsp),%rcx
    0.00 :   c9be9:  mov    0x40(%rcx),%rbp
    0.00 :   c9bed:  shl    $0x3,%rax
    0.00 :   c9bf1:  lea    (%rax,%rax,2),%rax
    0.00 :   c9bf5:  mov    %rax,0x118(%rsp)
    0.00 :   c9bfd:  xor    %ebx,%ebx
    0.00 :   c9bff:  xor    %r12d,%r12d
    0.00 :   c9c02:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   c9c10:  mov    0x0(%rbp,%rbx,1),%r15
    0.00 :   c9c15:  lea    0x10(%r15),%r14
    0.00 :   c9c19:  xor    %eax,%eax
    0.00 :   c9c1b:  mov    $0x1,%ecx
    0.00 :   c9c20:  lock cmpxchg %ecx,0x10(%r15)
    0.00 :   c9c26:  jne    c9c69 <std::sys::backtrace::__rust_begin_short_backtrace+0x139>
    0.00 :   c9c28:  mov    0xc8979(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c9c2f:  mov    (%rax),%rax
    0.00 :   c9c32:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9c3c:  test   %rcx,%rax
    0.00 :   c9c3f:  jne    c9c74 <std::sys::backtrace::__rust_begin_short_backtrace+0x144>
    0.00 :   c9c41:  xor    %eax,%eax
    0.00 :   c9c43:  movzbl 0x14(%r15),%ecx
    0.00 :   c9c48:  mov    0x18(%r15),%rcx
    0.00 :   c9c4c:  test   %rcx,%rcx
    0.00 :   c9c4f:  je     c9c90 <std::sys::backtrace::__rust_begin_short_backtrace+0x160>
    0.00 :   c9c51:  cmp    $0x1,%ecx
    0.00 :   c9c54:  jne    c9c60 <std::sys::backtrace::__rust_begin_short_backtrace+0x130>
    0.00 :   c9c56:  xor    %r13d,%r13d
    0.00 :   c9c59:  test   %al,%al
    0.00 :   c9c5b:  je     c9ca3 <std::sys::backtrace::__rust_begin_short_backtrace+0x173>
    0.00 :   c9c5d:  jmp    c9cbc <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9c5f:  nop
    0.00 :   c9c60:  mov    $0x1,%r13b
    0.00 :   c9c63:  test   %al,%al
    0.00 :   c9c65:  je     c9ca3 <std::sys::backtrace::__rust_begin_short_backtrace+0x173>
    0.00 :   c9c67:  jmp    c9cbc <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9c69:  mov    %r14,%rdi
    0.00 :   c9c6c:  call   *0xc89ae(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   c9c72:  jmp    c9c28 <std::sys::backtrace::__rust_begin_short_backtrace+0xf8>
    0.00 :   c9c74:  call   *0xc894e(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   c9c7a:  xor    $0x1,%al
    0.00 :   c9c7c:  movzbl 0x14(%r15),%ecx
    0.00 :   c9c81:  mov    0x18(%r15),%rcx
    0.00 :   c9c85:  test   %rcx,%rcx
    0.00 :   c9c88:  jne    c9c51 <std::sys::backtrace::__rust_begin_short_backtrace+0x121>
    0.00 :   c9c8a:  nopw   0x0(%rax,%rax,1)
    0.00 :   c9c90:  mov    0x28(%r15),%rcx
    0.00 :   c9c94:  mov    (%rcx),%rcx
    0.00 :   c9c97:  cmp    $0x1,%rcx
    0.00 :   c9c9b:  sete   %r13b
    0.00 :   c9c9f:  test   %al,%al
    0.00 :   c9ca1:  jne    c9cbc <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9ca3:  mov    0xc88fe(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c9caa:  mov    (%rax),%rax
    0.00 :   c9cad:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9cb7:  test   %rcx,%rax
    0.00 :   c9cba:  jne    c9d06 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d6>
    0.00 :   c9cbc:  xor    %eax,%eax
    0.00 :   c9cbe:  xchg   %eax,(%r14)
    0.00 :   c9cc1:  cmp    $0x2,%eax
    0.00 :   c9cc4:  je     c9ce5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b5>
    0.00 :   c9cc6:  test   %r13b,%r13b
    0.00 :   c9cc9:  jne    c9d20 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c9ccb:  inc    %r12
    0.00 :   c9cce:  add    $0x18,%rbx
    0.00 :   c9cd2:  cmp    %rbx,0x118(%rsp)
    0.00 :   c9cda:  jne    c9c10 <std::sys::backtrace::__rust_begin_short_backtrace+0xe0>
    0.00 :   c9ce0:  jmp    ca6d0 <std::sys::backtrace::__rust_begin_short_backtrace+0xba0>
    0.00 :   c9ce5:  mov    $0xca,%edi
    0.00 :   c9cea:  mov    %r14,%rsi
    0.00 :   c9ced:  mov    $0x81,%edx
    0.00 :   c9cf2:  mov    $0x1,%ecx
    0.00 :   c9cf7:  xor    %eax,%eax
    0.00 :   c9cf9:  call   *0xc88d9(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   c9cff:  test   %r13b,%r13b
    0.00 :   c9d02:  je     c9ccb <std::sys::backtrace::__rust_begin_short_backtrace+0x19b>
    0.00 :   c9d04:  jmp    c9d20 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c9d06:  call   *0xc88bc(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   c9d0c:  test   %al,%al
    0.00 :   c9d0e:  jne    c9cbc <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9d10:  movb   $0x1,0x14(%r15)
    0.00 :   c9d15:  jmp    c9cbc <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9d17:  nopw   0x0(%rax,%rax,1)
    0.00 :   c9d20:  mov    (%rsp),%rdi
    0.00 :   c9d24:  lock incq (%rdi)
    0.00 :   c9d28:  mov    0x28(%rsp),%r14
    0.00 :   c9d2d:  jle    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   c9d33:  mov    %rdi,0x30(%rsp)
    0.00 :   c9d38:  mov    0x48(%rdi),%rsi
    0.00 :   c9d3c:  cmp    %rsi,%r12
    0.00 :   c9d3f:  jae    ca89f <std::sys::backtrace::__rust_begin_short_backtrace+0xd6f>
    0.00 :   c9d45:  mov    0x40(%rdi),%rax
    0.00 :   c9d49:  mov    0x10(%rax,%rbx,1),%rcx
    0.00 :   c9d4e:  mov    %rcx,0x130(%rsp)
    0.00 :   c9d56:  movups (%rax,%rbx,1),%xmm0
    0.00 :   c9d5a:  movaps %xmm0,0x120(%rsp)
    0.00 :   c9d62:  dec    %rsi
    0.00 :   c9d65:  lea    (%rsi,%rsi,2),%rcx
    0.00 :   c9d69:  mov    0x10(%rax,%rcx,8),%rdx
    0.00 :   c9d6e:  movups (%rax,%rcx,8),%xmm0
    0.00 :   c9d72:  movups %xmm0,(%rax,%rbx,1)
    0.00 :   c9d76:  mov    %rdx,0x10(%rax,%rbx,1)
    0.00 :   c9d7b:  mov    %rsi,0x48(%rdi)
    0.00 :   c9d7f:  cmpb   $0x0,0xc(%rsp)
    0.00 :   c9d84:  jne    c9da3 <std::sys::backtrace::__rust_begin_short_backtrace+0x273>
    0.00 :   c9d86:  mov    0xc881b(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c9d8d:  mov    (%rax),%rax
    0.00 :   c9d90:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9d9a:  test   %rcx,%rax
    0.00 :   c9d9d:  jne    ca47b <std::sys::backtrace::__rust_begin_short_backtrace+0x94b>
    0.00 :   c9da3:  xor    %eax,%eax
    0.00 :   c9da5:  xchg   %eax,(%r14)
    0.00 :   c9da8:  cmp    $0x2,%eax
    0.00 :   c9dab:  je     ca3ec <std::sys::backtrace::__rust_begin_short_backtrace+0x8bc>
    0.00 :   c9db1:  mov    (%rsp),%rax
    0.00 :   c9db5:  mov    %rax,0x60(%rsp)
    0.00 :   c9dba:  mov    0x130(%rsp),%rax
    0.00 :   c9dc2:  lea    0x68(%rsp),%rcx
    0.00 :   c9dc7:  mov    %rax,0x10(%rcx)
    0.00 :   c9dcb:  movaps 0x120(%rsp),%xmm0
    0.00 :   c9dd3:  movups %xmm0,(%rcx)
    0.00 :   c9dd6:  cmpq   $0x0,0x68(%rsp)
    0.00 :   c9ddc:  je     ca8ad <std::sys::backtrace::__rust_begin_short_backtrace+0xd7d>
    0.00 :   c9de2:  mov    0x70(%rsp),%r14
    0.00 :   c9de7:  lea    0x8(%r14),%r15
    0.00 :   c9deb:  jmp    c9df2 <std::sys::backtrace::__rust_begin_short_backtrace+0x2c2>
    0.00 :   c9ded:  nopl   (%rax)
    0.00 :   c9df0:  pause
    0.00 :   c9df2:  mov    (%r15),%rax
    0.00 :   c9df5:  data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   c9e00:  cmp    $0xffffffffffffffff,%rax
    0.00 :   c9e04:  je     c9df0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2c0>
    0.00 :   c9e06:  test   %rax,%rax
    0.00 :   c9e09:  js     ca869 <std::sys::backtrace::__rust_begin_short_backtrace+0xd39>
    0.00 :   c9e0f:  lea    0x1(%rax),%rcx
    0.00 :   c9e13:  lock cmpxchg %rcx,(%r15)
    0.00 :   c9e18:  jne    c9e00 <std::sys::backtrace::__rust_begin_short_backtrace+0x2d0>
    0.00 :   c9e1a:  mov    %r14,0x10(%rsp)
    0.00 :   c9e1f:  mov    0x68(%rsp),%rsi
    0.00 :   c9e24:  lea    0x30(%rsp),%rdi
    0.00 :   c9e29:  call   12e5c0 <vthread::join_slot::JoinSlot::claim>
    0.00 :   c9e2e:  cmpq   $0x0,0x30(%rsp)
    0.00 :   c9e34:  je     c9e67 <std::sys::backtrace::__rust_begin_short_backtrace+0x337>
    0.00 :   c9e36:  movups 0x30(%rsp),%xmm0
    0.00 :   c9e3b:  movups 0x40(%rsp),%xmm1
    0.00 :   c9e40:  movaps %xmm1,0x100(%rsp)
    0.00 :   c9e48:  movaps %xmm0,0xf0(%rsp)
    0.00 :   c9e50:  lea    0xf0(%rsp),%rdi
    0.00 :   c9e58:  lea    0x10(%rsp),%rsi
    0.00 :   c9e5d:  mov    $0x4,%edx
    0.00 :   c9e62:  call   12db80 <vthread::join_slot::Claim::join>
    0.00 :   c9e67:  cmp    $0xffffffffffffffff,%r14
    0.00 :   c9e6b:  je     c9e7c <std::sys::backtrace::__rust_begin_short_backtrace+0x34c>
    0.00 :   c9e6d:  lock decq (%r15)
    0.00 :   c9e71:  jne    c9e7c <std::sys::backtrace::__rust_begin_short_backtrace+0x34c>
    0.00 :   c9e73:  mov    %r14,%rdi
    0.00 :   c9e76:  call   *0xc83cc(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c9e7c:  mov    0x78(%rsp),%r12
    0.00 :   c9e81:  mov    0x68(%rsp),%r15
    0.00 :   c9e86:  mov    0x70(%rsp),%r13
    0.00 :   c9e8b:  lea    0x10(%r15),%r14
    0.00 :   c9e8f:  xor    %eax,%eax
    0.00 :   c9e91:  mov    $0x1,%ecx
    0.00 :   c9e96:  lock cmpxchg %ecx,0x10(%r15)
    0.00 :   c9e9c:  jne    ca40b <std::sys::backtrace::__rust_begin_short_backtrace+0x8db>
    0.00 :   c9ea2:  mov    0xc86ff(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c9ea9:  mov    (%rax),%rax
    0.00 :   c9eac:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9eb6:  test   %rcx,%rax
    0.00 :   c9eb9:  jne    ca419 <std::sys::backtrace::__rust_begin_short_backtrace+0x8e9>
    0.00 :   c9ebf:  lea    0x14(%r15),%rbp
    0.00 :   c9ec3:  movzbl 0x14(%r15),%eax
    0.00 :   c9ec8:  mov    0x18(%r15),%rbx
    0.00 :   c9ecc:  mov    0xc86d5(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c9ed3:  mov    (%rax),%rax
    0.00 :   c9ed6:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9ee0:  test   %rcx,%rax
    0.00 :   c9ee3:  jne    ca464 <std::sys::backtrace::__rust_begin_short_backtrace+0x934>
    0.00 :   c9ee9:  xor    %eax,%eax
    0.00 :   c9eeb:  xchg   %eax,(%r14)
    0.00 :   c9eee:  cmp    $0x2,%eax
    0.00 :   c9ef1:  je     ca43c <std::sys::backtrace::__rust_begin_short_backtrace+0x90c>
    0.00 :   c9ef7:  cmp    $0x2,%ebx
    0.00 :   c9efa:  jne    ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9f00:  movzbl 0x38(%r12),%eax
    0.00 :   c9f06:  test   %al,%al
    0.00 :   c9f08:  je     ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9f0e:  mov    0x10(%r12),%rdi
    0.00 :   c9f13:  add    $0x10,%rdi
    0.00 :   c9f17:  call   12e8d0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9f1c:  test   %al,%al
    0.00 :   c9f1e:  je     ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9f24:  mov    0x98(%r13),%rax
    0.00 :   c9f2b:  mov    0xa0(%r13),%rcx
    0.00 :   c9f32:  shl    $0x3,%rcx
    0.00 :   c9f36:  xor    %edx,%edx
    0.00 :   c9f38:  jmp    c9f54 <std::sys::backtrace::__rust_begin_short_backtrace+0x424>
    0.00 :   c9f3a:  nopw   0x0(%rax,%rax,1)
    0.00 :   c9f40:  mov    0xd0(%rsi),%rsi
    0.00 :   c9f47:  add    $0x8,%rdx
    0.00 :   c9f4b:  test   %rsi,%rsi
    0.00 :   c9f4e:  jne    ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9f54:  cmp    %rdx,%rcx
    0.00 :   c9f57:  je     c9f8a <std::sys::backtrace::__rust_begin_short_backtrace+0x45a>
    0.00 :   c9f59:  mov    (%rax,%rdx,1),%rsi
    0.00 :   c9f5d:  movzbl 0xe8(%rsi),%edi
    0.00 :   c9f64:  test   %dil,%dil
    0.00 :   c9f67:  je     c9f40 <std::sys::backtrace::__rust_begin_short_backtrace+0x410>
    0.00 :   c9f69:  movzbl 0xe9(%rsi),%edi
    0.00 :   c9f70:  test   %dil,%dil
    0.00 :   c9f73:  je     ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9f79:  movzbl 0xea(%rsi),%edi
    0.00 :   c9f80:  test   %dil,%dil
    0.00 :   c9f83:  jne    c9f40 <std::sys::backtrace::__rust_begin_short_backtrace+0x410>
    0.00 :   c9f85:  jmp    ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9f8a:  mov    0x20(%r12),%eax
    0.00 :   c9f8f:  test   %eax,%eax
    0.00 :   c9f91:  jne    c9fa9 <std::sys::backtrace::__rust_begin_short_backtrace+0x479>
    0.00 :   c9f93:  mov    0x18(%r12),%rdi
    0.00 :   c9f98:  add    $0x10,%rdi
    0.00 :   c9f9c:  call   12e8d0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9fa1:  test   %al,%al
    0.00 :   c9fa3:  je     ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9fa9:  mov    0x30(%r12),%eax
    0.00 :   c9fae:  test   %eax,%eax
    0.00 :   c9fb0:  jne    c9fc8 <std::sys::backtrace::__rust_begin_short_backtrace+0x498>
    0.00 :   c9fb2:  mov    0x28(%r12),%rdi
    0.00 :   c9fb7:  add    $0x10,%rdi
    0.00 :   c9fbb:  call   12e8d0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9fc0:  test   %al,%al
    0.00 :   c9fc2:  je     ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9fc8:  mov    0x100(%r13),%eax
    0.00 :   c9fcf:  test   %eax,%eax
    0.00 :   c9fd1:  jne    ca11f <std::sys::backtrace::__rust_begin_short_backtrace+0x5ef>
    0.00 :   c9fd7:  mov    0xd8(%r13),%rbx
    0.00 :   c9fde:  mov    0xe0(%r13),%rdi
    0.00 :   c9fe5:  add    $0x10,%rdi
    0.00 :   c9fe9:  call   12e8d0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9fee:  test   %al,%al
    0.00 :   c9ff0:  je     ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9ff6:  lea    0x20(%rbx),%r12
    0.00 :   c9ffa:  xor    %eax,%eax
    0.00 :   c9ffc:  mov    $0x1,%ecx
    0.00 :   ca001:  lock cmpxchg %ecx,0x20(%rbx)
    0.00 :   ca006:  jne    ca5d4 <std::sys::backtrace::__rust_begin_short_backtrace+0xaa4>
    0.00 :   ca00c:  mov    0xc8595(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca013:  mov    (%rax),%rax
    0.00 :   ca016:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca020:  test   %rcx,%rax
    0.00 :   ca023:  jne    ca5e2 <std::sys::backtrace::__rust_begin_short_backtrace+0xab2>
    0.00 :   ca029:  lea    0x24(%rbx),%r14
    0.00 :   ca02d:  movzbl 0x24(%rbx),%eax
    0.00 :   ca031:  cmpq   $0x0,0x50(%rbx)
    0.00 :   ca036:  jne    ca8ed <std::sys::backtrace::__rust_begin_short_backtrace+0xdbd>
    0.00 :   ca03c:  mov    0xc8565(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca043:  mov    (%rax),%rax
    0.00 :   ca046:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca050:  test   %rcx,%rax
    0.00 :   ca053:  jne    ca634 <std::sys::backtrace::__rust_begin_short_backtrace+0xb04>
    0.00 :   ca059:  xor    %eax,%eax
    0.00 :   ca05b:  xchg   %eax,(%r12)
    0.00 :   ca05f:  cmp    $0x2,%eax
    0.00 :   ca062:  je     ca608 <std::sys::backtrace::__rust_begin_short_backtrace+0xad8>
    0.00 :   ca068:  mov    0x70(%rbx),%rax
    0.00 :   ca06c:  test   %rax,%rax
    0.00 :   ca06f:  jne    ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   ca075:  mov    0xe8(%r13),%rbx
    0.00 :   ca07c:  lea    0x10(%rbx),%r12
    0.00 :   ca080:  xor    %eax,%eax
    0.00 :   ca082:  mov    $0x1,%ecx
    0.00 :   ca087:  lock cmpxchg %ecx,0x10(%rbx)
    0.00 :   ca08c:  jne    ca64b <std::sys::backtrace::__rust_begin_short_backtrace+0xb1b>
    0.00 :   ca092:  mov    0xc850f(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca099:  mov    (%rax),%rax
    0.00 :   ca09c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca0a6:  test   %rcx,%rax
    0.00 :   ca0a9:  jne    ca659 <std::sys::backtrace::__rust_begin_short_backtrace+0xb29>
    0.00 :   ca0af:  xor    %r14d,%r14d
    0.00 :   ca0b2:  movzbl 0x14(%rbx),%eax
    0.00 :   ca0b6:  mov    0xf0(%r13),%rdi
    0.00 :   ca0bd:  add    $0x10,%rdi
    0.00 :   ca0c1:  call   12e8d0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   ca0c6:  test   %al,%al
    0.00 :   ca0c8:  je     ca0e3 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b3>
    0.00 :   ca0ca:  cmpq   $0x0,0x30(%rbx)
    0.00 :   ca0cf:  jne    ca0e3 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b3>
    0.00 :   ca0d1:  cmpq   $0x0,0x50(%rbx)
    0.00 :   ca0d6:  jne    ca0e3 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b3>
    0.00 :   ca0d8:  cmpq   $0x0,0x58(%rbx)
    0.00 :   ca0dd:  je     ca3b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x886>
    0.00 :   ca0e3:  xor    %ebp,%ebp
    0.00 :   ca0e5:  test   %r14b,%r14b
    0.00 :   ca0e8:  jne    ca107 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d7>
    0.00 :   ca0ea:  mov    0xc84b7(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca0f1:  mov    (%rax),%rax
    0.00 :   ca0f4:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca0fe:  test   %rcx,%rax
    0.00 :   ca101:  jne    ca693 <std::sys::backtrace::__rust_begin_short_backtrace+0xb63>
    0.00 :   ca107:  xor    %eax,%eax
    0.00 :   ca109:  xchg   %eax,(%r12)
    0.00 :   ca10d:  cmp    $0x2,%eax
    0.00 :   ca110:  je     ca66b <std::sys::backtrace::__rust_begin_short_backtrace+0xb3b>
    0.00 :   ca116:  test   %bpl,%bpl
    0.00 :   ca119:  je     ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   ca11f:  mov    0x70(%rsp),%rbx
    0.00 :   ca124:  lea    0x130(%rbx),%r12
    0.00 :   ca12b:  xor    %eax,%eax
    0.00 :   ca12d:  mov    $0x1,%ecx
    0.00 :   ca132:  lock cmpxchg %ecx,0x130(%rbx)
    0.00 :   ca13a:  jne    ca496 <std::sys::backtrace::__rust_begin_short_backtrace+0x966>
    0.00 :   ca140:  mov    0xc8461(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca147:  mov    (%rax),%rax
    0.00 :   ca14a:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca154:  test   %rcx,%rax
    0.00 :   ca157:  jne    ca4a4 <std::sys::backtrace::__rust_begin_short_backtrace+0x974>
    0.00 :   ca15d:  xor    %eax,%eax
    0.00 :   ca15f:  movzbl 0x134(%rbx),%ecx
    0.00 :   ca166:  cmpq   $0x0,0x148(%rbx)
    0.00 :   ca16e:  jne    ca17e <std::sys::backtrace::__rust_begin_short_backtrace+0x64e>
    0.00 :   ca170:  cmpq   $0x0,0x150(%rbx)
    0.00 :   ca178:  je     ca354 <std::sys::backtrace::__rust_begin_short_backtrace+0x824>
    0.00 :   ca17e:  test   %al,%al
    0.00 :   ca180:  jne    ca19f <std::sys::backtrace::__rust_begin_short_backtrace+0x66f>
    0.00 :   ca182:  mov    0xc841f(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca189:  mov    (%rax),%rax
    0.00 :   ca18c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca196:  test   %rcx,%rax
    0.00 :   ca199:  jne    ca5ba <std::sys::backtrace::__rust_begin_short_backtrace+0xa8a>
    0.00 :   ca19f:  xor    %eax,%eax
    0.00 :   ca1a1:  xchg   %eax,(%r12)
    0.00 :   ca1a5:  mov    $0x6,%r13b
    0.00 :   ca1a8:  cmp    $0x2,%eax
    0.00 :   ca1ab:  je     ca387 <std::sys::backtrace::__rust_begin_short_backtrace+0x857>
    0.00 :   ca1b1:  mov    0x70(%rsp),%r12
    0.00 :   ca1b6:  lock incq (%r12)
    0.00 :   ca1bb:  jle    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca1c1:  mov    %r12,0xf0(%rsp)
    0.00 :   ca1c9:  lea    0x68(%rsp),%rax
    0.00 :   ca1ce:  movups (%rax),%xmm0
    0.00 :   ca1d1:  movaps %xmm0,0x30(%rsp)
    0.00 :   ca1d6:  mov    0x10(%rax),%rax
    0.00 :   ca1da:  mov    %rax,0x40(%rsp)
    0.00 :   ca1df:  movq   $0x0,0x68(%rsp)
    0.00 :   ca1e8:  cmpq   $0x0,0x30(%rsp)
    0.00 :   ca1ee:  je     ca1fd <std::sys::backtrace::__rust_begin_short_backtrace+0x6cd>
    0.00 :   ca1f0:  mov    $0x1,%bpl
    0.00 :   ca1f3:  lea    0x30(%rsp),%rdi
    0.00 :   ca1f8:  call   d9900 <core::ptr::drop_in_place<vthread::lifecycle_owner::Entry>>
    0.00 :   ca1fd:  mov    0x60(%rsp),%rbx
    0.00 :   ca202:  lea    0x30(%rbx),%r14
    0.00 :   ca206:  xor    %eax,%eax
    0.00 :   ca208:  mov    $0x1,%ecx
    0.00 :   ca20d:  lock cmpxchg %ecx,0x30(%rbx)
    0.00 :   ca212:  jne    ca4c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x996>
    0.00 :   ca218:  mov    0xc8389(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca21f:  mov    (%rax),%rax
    0.00 :   ca222:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca22c:  test   %rcx,%rax
    0.00 :   ca22f:  jne    ca4d4 <std::sys::backtrace::__rust_begin_short_backtrace+0x9a4>
    0.00 :   ca235:  lea    0x34(%rbx),%r15
    0.00 :   ca239:  movzbl 0x34(%rbx),%eax
    0.00 :   ca23d:  decq   0x90(%rbx)
    0.00 :   ca244:  mov    0xc835d(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca24b:  mov    (%rax),%rax
    0.00 :   ca24e:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca258:  test   %rcx,%rax
    0.00 :   ca25b:  jne    ca588 <std::sys::backtrace::__rust_begin_short_backtrace+0xa58>
    0.00 :   ca261:  xor    %eax,%eax
    0.00 :   ca263:  xchg   %eax,(%r14)
    0.00 :   ca266:  cmp    $0x2,%eax
    0.00 :   ca269:  je     ca4fc <std::sys::backtrace::__rust_begin_short_backtrace+0x9cc>
    0.00 :   ca26f:  movups 0x60(%rsp),%xmm0
    0.00 :   ca274:  movups 0x70(%rsp),%xmm1
    0.00 :   ca279:  movaps %xmm1,0x40(%rsp)
    0.00 :   ca27e:  movaps %xmm0,0x30(%rsp)
    0.00 :   ca283:  xor    %ebp,%ebp
    0.00 :   ca285:  lea    0x30(%rsp),%rdi
    0.00 :   ca28a:  call   db8f0 <core::ptr::drop_in_place<vthread::lifecycle_owner::lifecycle_reaper::Claim>>
    0.00 :   ca28f:  lea    0x168(%r12),%r14
    0.00 :   ca297:  xor    %eax,%eax
    0.00 :   ca299:  mov    $0x1,%ecx
    0.00 :   ca29e:  lock cmpxchg %ecx,0x168(%r12)
    0.00 :   ca2a8:  jne    ca51b <std::sys::backtrace::__rust_begin_short_backtrace+0x9eb>
    0.00 :   ca2ae:  mov    0xc82f3(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca2b5:  mov    (%rax),%rax
    0.00 :   ca2b8:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca2c2:  test   %rcx,%rax
    0.00 :   ca2c5:  jne    ca529 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f9>
    0.00 :   ca2cb:  lea    0x16c(%r12),%rbx
    0.00 :   ca2d3:  movzbl 0x16c(%r12),%eax
    0.00 :   ca2dc:  movzbl 0x221(%r12),%eax
    0.00 :   ca2e5:  movzbl %r13b,%ecx
    0.00 :   ca2e9:  cmp    %al,%r13b
    0.00 :   ca2ec:  cmovbe %eax,%ecx
    0.00 :   ca2ef:  mov    %cl,0x221(%r12)
    0.00 :   ca2f7:  mov    0xc82aa(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca2fe:  mov    (%rax),%rax
    0.00 :   ca301:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca30b:  test   %rcx,%rax
    0.00 :   ca30e:  jne    ca5a2 <std::sys::backtrace::__rust_begin_short_backtrace+0xa72>
    0.00 :   ca314:  xor    %eax,%eax
    0.00 :   ca316:  xchg   %eax,(%r14)
    0.00 :   ca319:  cmp    $0x2,%eax
    0.00 :   ca31c:  je     ca569 <std::sys::backtrace::__rust_begin_short_backtrace+0xa39>
    0.00 :   ca322:  lea    0x108(%r12),%rdi
    0.00 :   ca32a:  xor    %ebp,%ebp
    0.00 :   ca32c:  call   118460 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10657235172099788962>
    0.00 :   ca331:  lock decq (%r12)
    0.00 :   ca336:  mov    0x28(%rsp),%r14
    0.00 :   ca33b:  jne    c9b99 <std::sys::backtrace::__rust_begin_short_backtrace+0x69>
    0.00 :   ca341:  lea    0xf0(%rsp),%rdi
    0.00 :   ca349:  call   *0xc8ec1(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   ca34f:  jmp    c9b99 <std::sys::backtrace::__rust_begin_short_backtrace+0x69>
    0.00 :   ca354:  test   %al,%al
    0.00 :   ca356:  jne    ca375 <std::sys::backtrace::__rust_begin_short_backtrace+0x845>
    0.00 :   ca358:  mov    0xc8249(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca35f:  mov    (%rax),%rax
    0.00 :   ca362:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca36c:  test   %rcx,%rax
    0.00 :   ca36f:  jne    ca6aa <std::sys::backtrace::__rust_begin_short_backtrace+0xb7a>
    0.00 :   ca375:  xor    %eax,%eax
    0.00 :   ca377:  xchg   %eax,(%r12)
    0.00 :   ca37b:  mov    $0x5,%r13b
    0.00 :   ca37e:  cmp    $0x2,%eax
    0.00 :   ca381:  jne    ca1b1 <std::sys::backtrace::__rust_begin_short_backtrace+0x681>
    0.00 :   ca387:  mov    $0xca,%edi
    0.00 :   ca38c:  mov    %r12,%rsi
    0.00 :   ca38f:  mov    $0x81,%edx
    0.00 :   ca394:  mov    $0x1,%ecx
    0.00 :   ca399:  xor    %eax,%eax
    0.00 :   ca39b:  call   *0xc8237(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca3a1:  mov    0x70(%rsp),%r12
    0.00 :   ca3a6:  lock incq (%r12)
    0.00 :   ca3ab:  jg     ca1c1 <std::sys::backtrace::__rust_begin_short_backtrace+0x691>
    0.00 :   ca3b1:  jmp    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca3b6:  cmpq   $0x0,0x60(%rbx)
    0.00 :   ca3bb:  sete   %bpl
    0.00 :   ca3bf:  test   %r14b,%r14b
    0.00 :   ca3c2:  jne    ca107 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d7>
    0.00 :   ca3c8:  jmp    ca0ea <std::sys::backtrace::__rust_begin_short_backtrace+0x5ba>
    0.00 :   ca3cd:  mov    %r14,%rdi
    0.00 :   ca3d0:  call   *0xc824a(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ca3d6:  jmp    c9bab <std::sys::backtrace::__rust_begin_short_backtrace+0x7b>
    0.00 :   ca3db:  call   *0xc81e7(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca3e1:  xor    $0x1,%al
    0.00 :   ca3e3:  mov    %eax,0xc(%rsp)
    0.00 :   ca3e7:  jmp    c9bd0 <std::sys::backtrace::__rust_begin_short_backtrace+0xa0>
    0.00 :   ca3ec:  mov    $0xca,%edi
    0.00 :   ca3f1:  mov    %r14,%rsi
    0.00 :   ca3f4:  mov    $0x81,%edx
    0.00 :   ca3f9:  mov    $0x1,%ecx
    0.00 :   ca3fe:  xor    %eax,%eax
    0.00 :   ca400:  call   *0xc81d2(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca406:  jmp    c9db1 <std::sys::backtrace::__rust_begin_short_backtrace+0x281>
    0.00 :   ca40b:  mov    %r14,%rdi
    0.00 :   ca40e:  call   *0xc820c(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ca414:  jmp    c9ea2 <std::sys::backtrace::__rust_begin_short_backtrace+0x372>
    0.00 :   ca419:  call   *0xc81a9(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca41f:  movzbl 0x14(%r15),%ecx
    0.00 :   ca424:  mov    0x18(%r15),%rbx
    0.00 :   ca428:  test   %al,%al
    0.00 :   ca42a:  je     c9ee9 <std::sys::backtrace::__rust_begin_short_backtrace+0x3b9>
    0.00 :   ca430:  add    $0x14,%r15
    0.00 :   ca434:  mov    %r15,%rbp
    0.00 :   ca437:  jmp    c9ecc <std::sys::backtrace::__rust_begin_short_backtrace+0x39c>
    0.00 :   ca43c:  mov    $0xca,%edi
    0.00 :   ca441:  mov    %r14,%rsi
    0.00 :   ca444:  mov    $0x81,%edx
    0.00 :   ca449:  mov    $0x1,%ecx
    0.00 :   ca44e:  xor    %eax,%eax
    0.00 :   ca450:  call   *0xc8182(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca456:  cmp    $0x2,%ebx
    0.00 :   ca459:  je     c9f00 <std::sys::backtrace::__rust_begin_short_backtrace+0x3d0>
    0.00 :   ca45f:  jmp    ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   ca464:  call   *0xc815e(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca46a:  test   %al,%al
    0.00 :   ca46c:  jne    c9ee9 <std::sys::backtrace::__rust_begin_short_backtrace+0x3b9>
    0.00 :   ca472:  movb   $0x1,0x0(%rbp)
    0.00 :   ca476:  jmp    c9ee9 <std::sys::backtrace::__rust_begin_short_backtrace+0x3b9>
    0.00 :   ca47b:  call   *0xc8147(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca481:  test   %al,%al
    0.00 :   ca483:  jne    c9da3 <std::sys::backtrace::__rust_begin_short_backtrace+0x273>
    0.00 :   ca489:  mov    (%rsp),%rax
    0.00 :   ca48d:  movb   $0x1,0x34(%rax)
    0.00 :   ca491:  jmp    c9da3 <std::sys::backtrace::__rust_begin_short_backtrace+0x273>
    0.00 :   ca496:  mov    %r12,%rdi
    0.00 :   ca499:  call   *0xc8181(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ca49f:  jmp    ca140 <std::sys::backtrace::__rust_begin_short_backtrace+0x610>
    0.00 :   ca4a4:  call   *0xc811e(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca4aa:  xor    $0x1,%al
    0.00 :   ca4ac:  movzbl 0x134(%rbx),%ecx
    0.00 :   ca4b3:  cmpq   $0x0,0x148(%rbx)
    0.00 :   ca4bb:  jne    ca17e <std::sys::backtrace::__rust_begin_short_backtrace+0x64e>
    0.00 :   ca4c1:  jmp    ca170 <std::sys::backtrace::__rust_begin_short_backtrace+0x640>
    0.00 :   ca4c6:  mov    %r14,%rdi
    0.00 :   ca4c9:  call   *0xc8151(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ca4cf:  jmp    ca218 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e8>
    0.00 :   ca4d4:  mov    $0x1,%bpl
    0.00 :   ca4d7:  call   *0xc80eb(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca4dd:  movzbl 0x34(%rbx),%ecx
    0.00 :   ca4e1:  decq   0x90(%rbx)
    0.00 :   ca4e8:  test   %al,%al
    0.00 :   ca4ea:  je     ca261 <std::sys::backtrace::__rust_begin_short_backtrace+0x731>
    0.00 :   ca4f0:  add    $0x34,%rbx
    0.00 :   ca4f4:  mov    %rbx,%r15
    0.00 :   ca4f7:  jmp    ca244 <std::sys::backtrace::__rust_begin_short_backtrace+0x714>
    0.00 :   ca4fc:  mov    $0xca,%edi
    0.00 :   ca501:  mov    %r14,%rsi
    0.00 :   ca504:  mov    $0x81,%edx
    0.00 :   ca509:  mov    $0x1,%ecx
    0.00 :   ca50e:  xor    %eax,%eax
    0.00 :   ca510:  call   *0xc80c2(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca516:  jmp    ca26f <std::sys::backtrace::__rust_begin_short_backtrace+0x73f>
    0.00 :   ca51b:  mov    %r14,%rdi
    0.00 :   ca51e:  call   *0xc80fc(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ca524:  jmp    ca2ae <std::sys::backtrace::__rust_begin_short_backtrace+0x77e>
    0.00 :   ca529:  xor    %ebp,%ebp
    0.00 :   ca52b:  call   *0xc8097(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca531:  movzbl 0x16c(%r12),%ecx
    0.00 :   ca53a:  movzbl 0x221(%r12),%ecx
    0.00 :   ca543:  movzbl %r13b,%edx
    0.00 :   ca547:  cmp    %cl,%dl
    0.00 :   ca549:  cmova  %edx,%ecx
    0.00 :   ca54c:  mov    %cl,0x221(%r12)
    0.00 :   ca554:  test   %al,%al
    0.00 :   ca556:  je     ca314 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e4>
    0.00 :   ca55c:  lea    0x16c(%r12),%rbx
    0.00 :   ca564:  jmp    ca2f7 <std::sys::backtrace::__rust_begin_short_backtrace+0x7c7>
    0.00 :   ca569:  mov    $0xca,%edi
    0.00 :   ca56e:  mov    %r14,%rsi
    0.00 :   ca571:  mov    $0x81,%edx
    0.00 :   ca576:  mov    $0x1,%ecx
    0.00 :   ca57b:  xor    %eax,%eax
    0.00 :   ca57d:  call   *0xc8055(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca583:  jmp    ca322 <std::sys::backtrace::__rust_begin_short_backtrace+0x7f2>
    0.00 :   ca588:  mov    $0x1,%bpl
    0.00 :   ca58b:  call   *0xc8037(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca591:  test   %al,%al
    0.00 :   ca593:  jne    ca261 <std::sys::backtrace::__rust_begin_short_backtrace+0x731>
    0.00 :   ca599:  movb   $0x1,(%r15)
    0.00 :   ca59d:  jmp    ca261 <std::sys::backtrace::__rust_begin_short_backtrace+0x731>
    0.00 :   ca5a2:  xor    %ebp,%ebp
    0.00 :   ca5a4:  call   *0xc801e(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca5aa:  test   %al,%al
    0.00 :   ca5ac:  jne    ca314 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e4>
    0.00 :   ca5b2:  movb   $0x1,(%rbx)
    0.00 :   ca5b5:  jmp    ca314 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e4>
    0.00 :   ca5ba:  call   *0xc8008(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca5c0:  test   %al,%al
    0.00 :   ca5c2:  jne    ca19f <std::sys::backtrace::__rust_begin_short_backtrace+0x66f>
    0.00 :   ca5c8:  movb   $0x1,0x134(%rbx)
    0.00 :   ca5cf:  jmp    ca19f <std::sys::backtrace::__rust_begin_short_backtrace+0x66f>
    0.00 :   ca5d4:  mov    %r12,%rdi
    0.00 :   ca5d7:  call   *0xc8043(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ca5dd:  jmp    ca00c <std::sys::backtrace::__rust_begin_short_backtrace+0x4dc>
    0.00 :   ca5e2:  call   *0xc7fe0(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca5e8:  lea    0x24(%rbx),%r14
    0.00 :   ca5ec:  movzbl 0x24(%rbx),%ecx
    0.00 :   ca5f0:  cmpq   $0x0,0x50(%rbx)
    0.00 :   ca5f5:  jne    ca8e9 <std::sys::backtrace::__rust_begin_short_backtrace+0xdb9>
    0.00 :   ca5fb:  test   %al,%al
    0.00 :   ca5fd:  jne    ca03c <std::sys::backtrace::__rust_begin_short_backtrace+0x50c>
    0.00 :   ca603:  jmp    ca059 <std::sys::backtrace::__rust_begin_short_backtrace+0x529>
    0.00 :   ca608:  mov    $0xca,%edi
    0.00 :   ca60d:  mov    %r12,%rsi
    0.00 :   ca610:  mov    $0x81,%edx
    0.00 :   ca615:  mov    $0x1,%ecx
    0.00 :   ca61a:  xor    %eax,%eax
    0.00 :   ca61c:  call   *0xc7fb6(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca622:  mov    0x70(%rbx),%rax
    0.00 :   ca626:  test   %rax,%rax
    0.00 :   ca629:  je     ca075 <std::sys::backtrace::__rust_begin_short_backtrace+0x545>
    0.00 :   ca62f:  jmp    ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   ca634:  call   *0xc7f8e(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca63a:  test   %al,%al
    0.00 :   ca63c:  jne    ca059 <std::sys::backtrace::__rust_begin_short_backtrace+0x529>
    0.00 :   ca642:  movb   $0x1,(%r14)
    0.00 :   ca646:  jmp    ca059 <std::sys::backtrace::__rust_begin_short_backtrace+0x529>
    0.00 :   ca64b:  mov    %r12,%rdi
    0.00 :   ca64e:  call   *0xc7fcc(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ca654:  jmp    ca092 <std::sys::backtrace::__rust_begin_short_backtrace+0x562>
    0.00 :   ca659:  call   *0xc7f69(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca65f:  mov    %eax,%r14d
    0.00 :   ca662:  xor    $0x1,%r14b
    0.00 :   ca666:  jmp    ca0b2 <std::sys::backtrace::__rust_begin_short_backtrace+0x582>
    0.00 :   ca66b:  mov    $0xca,%edi
    0.00 :   ca670:  mov    %r12,%rsi
    0.00 :   ca673:  mov    $0x81,%edx
    0.00 :   ca678:  mov    $0x1,%ecx
    0.00 :   ca67d:  xor    %eax,%eax
    0.00 :   ca67f:  call   *0xc7f53(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca685:  test   %bpl,%bpl
    0.00 :   ca688:  jne    ca11f <std::sys::backtrace::__rust_begin_short_backtrace+0x5ef>
    0.00 :   ca68e:  jmp    ca919 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   ca693:  call   *0xc7f2f(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca699:  test   %al,%al
    0.00 :   ca69b:  jne    ca107 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d7>
    0.00 :   ca6a1:  movb   $0x1,0x14(%rbx)
    0.00 :   ca6a5:  jmp    ca107 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d7>
    0.00 :   ca6aa:  call   *0xc7f18(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca6b0:  test   %al,%al
    0.00 :   ca6b2:  jne    ca375 <std::sys::backtrace::__rust_begin_short_backtrace+0x845>
    0.00 :   ca6b8:  movb   $0x1,0x134(%rbx)
    0.00 :   ca6bf:  jmp    ca375 <std::sys::backtrace::__rust_begin_short_backtrace+0x845>
    0.00 :   ca6c4:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   ca6d0:  cmpb   $0x0,0xc(%rsp)
    0.00 :   ca6d5:  mov    0x28(%rsp),%r14
    0.00 :   ca6da:  jne    ca6f9 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc9>
    0.00 :   ca6dc:  mov    0xc7ec5(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca6e3:  mov    (%rax),%rax
    0.00 :   ca6e6:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca6f0:  test   %rcx,%rax
    0.00 :   ca6f3:  jne    ca84e <std::sys::backtrace::__rust_begin_short_backtrace+0xd1e>
    0.00 :   ca6f9:  xor    %eax,%eax
    0.00 :   ca6fb:  xchg   %eax,(%r14)
    0.00 :   ca6fe:  cmp    $0x2,%eax
    0.00 :   ca701:  je     ca7aa <std::sys::backtrace::__rust_begin_short_backtrace+0xc7a>
    0.00 :   ca707:  xor    %eax,%eax
    0.00 :   ca709:  mov    $0x1,%ecx
    0.00 :   ca70e:  lock cmpxchg %ecx,(%r14)
    0.00 :   ca713:  jne    ca7d6 <std::sys::backtrace::__rust_begin_short_backtrace+0xca6>
    0.00 :   ca719:  mov    0xc7e88(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca720:  mov    (%rax),%rax
    0.00 :   ca723:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca72d:  test   %rcx,%rax
    0.00 :   ca730:  jne    ca7e4 <std::sys::backtrace::__rust_begin_short_backtrace+0xcb4>
    0.00 :   ca736:  mov    (%rsp),%rcx
    0.00 :   ca73a:  movzbl 0x34(%rcx),%eax
    0.00 :   ca73e:  cmpq   $0x0,0x48(%rcx)
    0.00 :   ca743:  sete   %bl
    0.00 :   ca746:  mov    0xc7e5b(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca74d:  mov    (%rax),%rax
    0.00 :   ca750:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca75a:  test   %rcx,%rax
    0.00 :   ca75d:  jne    ca833 <std::sys::backtrace::__rust_begin_short_backtrace+0xd03>
    0.00 :   ca763:  xor    %eax,%eax
    0.00 :   ca765:  xchg   %eax,(%r14)
    0.00 :   ca768:  cmp    $0x2,%eax
    0.00 :   ca76b:  je     ca807 <std::sys::backtrace::__rust_begin_short_backtrace+0xcd7>
    0.00 :   ca771:  mov    $0x3b9aca00,%ecx
    0.00 :   ca776:  test   %bl,%bl
    0.00 :   ca778:  jne    c9b73 <std::sys::backtrace::__rust_begin_short_backtrace+0x43>
    0.00 :   ca77e:  mov    $0x1,%edi
    0.00 :   ca783:  call   a17e0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   ca788:  mov    %edx,%ecx
    0.00 :   ca78a:  cmp    $0x3b023380,%edx
    0.00 :   ca790:  jb     c9b6d <std::sys::backtrace::__rust_begin_short_backtrace+0x3d>
    0.00 :   ca796:  inc    %rax
    0.00 :   ca799:  jo     ca8cb <std::sys::backtrace::__rust_begin_short_backtrace+0xd9b>
    0.00 :   ca79f:  add    $0xc4fdcc80,%ecx
    0.00 :   ca7a5:  jmp    c9b73 <std::sys::backtrace::__rust_begin_short_backtrace+0x43>
    0.00 :   ca7aa:  mov    $0xca,%edi
    0.00 :   ca7af:  mov    %r14,%rsi
    0.00 :   ca7b2:  mov    $0x81,%edx
    0.00 :   ca7b7:  mov    $0x1,%ecx
    0.00 :   ca7bc:  xor    %eax,%eax
    0.00 :   ca7be:  call   *0xc7e14(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca7c4:  xor    %eax,%eax
    0.00 :   ca7c6:  mov    $0x1,%ecx
    0.00 :   ca7cb:  lock cmpxchg %ecx,(%r14)
    0.00 :   ca7d0:  je     ca719 <std::sys::backtrace::__rust_begin_short_backtrace+0xbe9>
    0.00 :   ca7d6:  mov    %r14,%rdi
    0.00 :   ca7d9:  call   *0xc7e41(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ca7df:  jmp    ca719 <std::sys::backtrace::__rust_begin_short_backtrace+0xbe9>
    0.00 :   ca7e4:  call   *0xc7dde(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca7ea:  mov    (%rsp),%rdx
    0.00 :   ca7ee:  movzbl 0x34(%rdx),%ecx
    0.00 :   ca7f2:  cmpq   $0x0,0x48(%rdx)
    0.00 :   ca7f7:  sete   %bl
    0.00 :   ca7fa:  test   %al,%al
    0.00 :   ca7fc:  jne    ca746 <std::sys::backtrace::__rust_begin_short_backtrace+0xc16>
    0.00 :   ca802:  jmp    ca763 <std::sys::backtrace::__rust_begin_short_backtrace+0xc33>
    0.00 :   ca807:  mov    $0xca,%edi
    0.00 :   ca80c:  mov    %r14,%rsi
    0.00 :   ca80f:  mov    $0x81,%edx
    0.00 :   ca814:  mov    $0x1,%ecx
    0.00 :   ca819:  xor    %eax,%eax
    0.00 :   ca81b:  call   *0xc7db7(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ca821:  mov    $0x3b9aca00,%ecx
    0.00 :   ca826:  test   %bl,%bl
    0.00 :   ca828:  jne    c9b73 <std::sys::backtrace::__rust_begin_short_backtrace+0x43>
    0.00 :   ca82e:  jmp    ca77e <std::sys::backtrace::__rust_begin_short_backtrace+0xc4e>
    0.00 :   ca833:  call   *0xc7d8f(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca839:  test   %al,%al
    0.00 :   ca83b:  jne    ca763 <std::sys::backtrace::__rust_begin_short_backtrace+0xc33>
    0.00 :   ca841:  mov    (%rsp),%rax
    0.00 :   ca845:  movb   $0x1,0x34(%rax)
    0.00 :   ca849:  jmp    ca763 <std::sys::backtrace::__rust_begin_short_backtrace+0xc33>
    0.00 :   ca84e:  call   *0xc7d74(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ca854:  test   %al,%al
    0.00 :   ca856:  jne    ca6f9 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc9>
    0.00 :   ca85c:  mov    (%rsp),%rax
    0.00 :   ca860:  movb   $0x1,0x34(%rax)
    0.00 :   ca864:  jmp    ca6f9 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc9>
    0.00 :   ca869:  lea    0xc28e0(%rip),%rax        # 18d150 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x210>
    0.00 :   ca870:  mov    %rax,0x30(%rsp)
    0.00 :   ca875:  lea    0x9274(%rip),%rax        # d3af0 <_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hb2a2ab9295a6d20aE.llvm.10657235172099788962>
    0.00 :   ca87c:  mov    %rax,0x38(%rsp)
    0.00 :   ca881:  lea    -0xb808d(%rip),%rdi        # 127fb <anon.48996dcd35f4b7aad43cb5fc1472ecbf.144.llvm.7041895458470441471>
    0.00 :   ca888:  lea    0xc3691(%rip),%rdx        # 18df20 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x6b0>
    0.00 :   ca88f:  lea    0x30(%rsp),%rsi
    0.00 :   ca894:  call   *0xc7a06(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   ca89a:  jmp    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca89f:  mov    %r12,%rdi
    0.00 :   ca8a2:  call   *0xc7a00(%rip)        # 1922a8 <_DYNAMIC+0x290>
    0.00 :   ca8a8:  jmp    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca8ad:  lea    -0xac6fe(%rip),%rdi        # 1e1b6 <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0xd9e>
    0.00 :   ca8b4:  lea    0xc3ff5(%rip),%rdx        # 18e8b0 <anon.de2471ab41e489a293ba001b839d8fc3.433.llvm.10657235172099788962+0x840>
    0.00 :   ca8bb:  mov    $0xd,%esi
    0.00 :   ca8c0:  call   *0xc7b7a(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   ca8c6:  jmp    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca8cb:  lea    -0xae513(%rip),%rdi        # 1c3bf <anon.e19cb05173cfa9d2277c28e7a8ac702e.708.llvm.13342753452097612697>
    0.00 :   ca8d2:  lea    0xc2467(%rip),%rdx        # 18cd40 <anon.e19cb05173cfa9d2277c28e7a8ac702e.791.llvm.13342753452097612697>
    0.00 :   ca8d9:  mov    $0x28,%esi
    0.00 :   ca8de:  call   *0xc7b5c(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   ca8e4:  jmp    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca8e9:  test   %al,%al
    0.00 :   ca8eb:  je     ca90a <std::sys::backtrace::__rust_begin_short_backtrace+0xdda>
    0.00 :   ca8ed:  mov    0xc7cb4(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ca8f4:  mov    (%rax),%rax
    0.00 :   ca8f7:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca901:  test   %rcx,%rax
    0.00 :   ca904:  jne    caaf3 <std::sys::backtrace::__rust_begin_short_backtrace+0xfc3>
    0.00 :   ca90a:  xor    %eax,%eax
    0.00 :   ca90c:  xchg   %eax,(%r12)
    0.00 :   ca910:  cmp    $0x2,%eax
    0.00 :   ca913:  je     caab0 <std::sys::backtrace::__rust_begin_short_backtrace+0xf80>
    0.00 :   ca919:  mov    $0x10,%edi
    0.00 :   ca91e:  call   *0xc793c(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   ca924:  test   %rax,%rax
    0.00 :   ca927:  je     caade <std::sys::backtrace::__rust_begin_short_backtrace+0xfae>
    0.00 :   ca92d:  lea    -0xac771(%rip),%rcx        # 1e1c3 <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0xdab>
    0.00 :   ca934:  mov    %rcx,(%rax)
    0.00 :   ca937:  movq   $0x2f,0x8(%rax)
    0.00 :   ca93f:  lea    0xc3f82(%rip),%rdx        # 18e8c8 <anon.de2471ab41e489a293ba001b839d8fc3.433.llvm.10657235172099788962+0x858>
    0.00 :   ca946:  lea    0x30(%rsp),%rdi
    0.00 :   ca94b:  mov    %rax,%rsi
    0.00 :   ca94e:  call   *0xc88c4(%rip)        # 193218 <_DYNAMIC+0x1200>
    0.00 :   ca954:  mov    0x30(%rsp),%r12
    0.00 :   ca959:  mov    0x38(%rsp),%r14
    0.00 :   ca95e:  mov    0x40(%rsp),%rax
    0.00 :   ca963:  mov    %rax,0xf0(%rsp)
    0.00 :   ca96b:  movzbl 0x48(%rsp),%eax
    0.00 :   ca970:  mov    %al,0xf8(%rsp)
    0.00 :   ca977:  movzbl 0x49(%rsp),%ebx
    0.00 :   ca97c:  mov    0x4a(%rsp),%eax
    0.00 :   ca980:  mov    %eax,0x10(%rsp)
    0.00 :   ca984:  movzwl 0x4e(%rsp),%eax
    0.00 :   ca989:  mov    %ax,0x14(%rsp)
    0.00 :   ca98e:  mov    $0x17,%edi
    0.00 :   ca993:  call   *0xc78c7(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   ca999:  test   %rax,%rax
    0.00 :   ca99c:  je     cab0a <std::sys::backtrace::__rust_begin_short_backtrace+0xfda>
    0.00 :   ca9a2:  mov    %rax,%r15
    0.00 :   ca9a5:  movups -0xac80d(%rip),%xmm0        # 1e19f <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0xd87>
    0.00 :   ca9ac:  movups %xmm0,(%rax)
    0.00 :   ca9af:  movabs $0x72656e776f2d656c,%rax
    0.00 :   ca9b9:  mov    %rax,0xf(%r15)
    0.00 :   ca9bd:  mov    0xf0(%rsp),%rax
    0.00 :   ca9c5:  mov    %rax,0xd0(%rsp)
    0.00 :   ca9cd:  movzbl 0xf8(%rsp),%eax
    0.00 :   ca9d5:  mov    %al,0xd8(%rsp)
    0.00 :   ca9dc:  mov    0x10(%rsp),%eax
    0.00 :   ca9e0:  mov    %eax,0x20(%rsp)
    0.00 :   ca9e4:  movzwl 0x14(%rsp),%eax
    0.00 :   ca9e9:  mov    %ax,0x24(%rsp)
    0.00 :   ca9ee:  lea    0x60(%rsp),%rdi
    0.00 :   ca9f3:  call   db8f0 <core::ptr::drop_in_place<vthread::lifecycle_owner::lifecycle_reaper::Claim>>
    0.00 :   ca9f8:  mov    %r12,0x98(%rsp)
    0.00 :   caa00:  mov    %r14,0xa0(%rsp)
    0.00 :   caa08:  mov    0xd0(%rsp),%rax
    0.00 :   caa10:  mov    %rax,0xa8(%rsp)
    0.00 :   caa18:  movzbl 0xd8(%rsp),%eax
    0.00 :   caa20:  mov    %al,0xb0(%rsp)
    0.00 :   caa27:  mov    %bl,0xb1(%rsp)
    0.00 :   caa2e:  mov    0x20(%rsp),%eax
    0.00 :   caa32:  mov    %eax,0xb2(%rsp)
    0.00 :   caa39:  movzwl 0x24(%rsp),%eax
    0.00 :   caa3e:  mov    %ax,0xb6(%rsp)
    0.00 :   caa46:  movl   $0x10000,0xb8(%rsp)
    0.00 :   caa51:  movq   $0x17,0x80(%rsp)
    0.00 :   caa5d:  mov    %r15,0x88(%rsp)
    0.00 :   caa65:  movq   $0x17,0x90(%rsp)
    0.00 :   caa71:  lea    0x80(%rsp),%rsi
    0.00 :   caa79:  mov    0xe0(%rsp),%rdi
    0.00 :   caa81:  call   1038c0 <vthread::lifecycle_owner::State::fail>
    0.00 :   caa86:  mov    (%rsp),%rax
    0.00 :   caa8a:  lock decq (%rax)
    0.00 :   caa8e:  jne    caa9e <std::sys::backtrace::__rust_begin_short_backtrace+0xf6e>
    0.00 :   caa90:  lea    0xe8(%rsp),%rdi
    0.00 :   caa98:  call   *0xc8782(%rip)        # 193220 <_DYNAMIC+0x1208>
    0.00 :   caa9e:  add    $0x138,%rsp
    0.00 :   caaa5:  pop    %rbx
    0.00 :   caaa6:  pop    %r12
    0.00 :   caaa8:  pop    %r13
    0.00 :   caaaa:  pop    %r14
    0.00 :   caaac:  pop    %r15
    0.00 :   caaae:  pop    %rbp
    0.00 :   caaaf:  ret
    0.00 :   caab0:  mov    $0xca,%edi
    0.00 :   caab5:  mov    %r12,%rsi
    0.00 :   caab8:  mov    $0x81,%edx
    0.00 :   caabd:  mov    $0x1,%ecx
    0.00 :   caac2:  xor    %eax,%eax
    0.00 :   caac4:  call   *0xc7b0e(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   caaca:  mov    $0x10,%edi
    0.00 :   caacf:  call   *0xc778b(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   caad5:  test   %rax,%rax
    0.00 :   caad8:  jne    ca92d <std::sys::backtrace::__rust_begin_short_backtrace+0xdfd>
    0.00 :   caade:  mov    $0x8,%edi
    0.00 :   caae3:  mov    $0x10,%esi
    0.00 :   caae8:  call   *0xc779a(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   caaee:  jmp    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   caaf3:  call   *0xc7acf(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   caaf9:  test   %al,%al
    0.00 :   caafb:  jne    ca90a <std::sys::backtrace::__rust_begin_short_backtrace+0xdda>
    0.00 :   cab01:  movb   $0x1,(%r14)
    0.00 :   cab05:  jmp    ca90a <std::sys::backtrace::__rust_begin_short_backtrace+0xdda>
    0.00 :   cab0a:  mov    $0x1,%edi
    0.00 :   cab0f:  mov    $0x17,%esi
    0.00 :   cab14:  call   *0xc76f6(%rip)        # 192210 <_DYNAMIC+0x1f8>
    0.00 :   cab1a:  jmp    cad51 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   cab1f:  mov    %rax,%rbx
    0.00 :   cab22:  mov    0x28(%rsp),%r14
    0.00 :   cab27:  jmp    cabb0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1080>
    0.00 :   cab2c:  mov    %rax,%rbx
    0.00 :   cab2f:  movzbl %r14b,%esi
    0.00 :   cab33:  mov    %r12,%rdi
    0.00 :   cab36:  call   d5340 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::thread_failure::ThreadFailures>>>
    0.00 :   cab3b:  jmp    cabc8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   cab40:  call   *0xc7912(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cab46:  jmp    cab93 <std::sys::backtrace::__rust_begin_short_backtrace+0x1063>
    0.00 :   cab48:  mov    %rax,%rbx
    0.00 :   cab4b:  lock decq (%r12)
    0.00 :   cab50:  jne    cab60 <std::sys::backtrace::__rust_begin_short_backtrace+0x1030>
    0.00 :   cab52:  lea    0xf0(%rsp),%rdi
    0.00 :   cab5a:  call   *0xc86b0(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cab60:  test   %bpl,%bpl
    0.00 :   cab63:  jne    cabc8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   cab65:  jmp    cabd2 <std::sys::backtrace::__rust_begin_short_backtrace+0x10a2>
    0.00 :   cab67:  jmp    cab93 <std::sys::backtrace::__rust_begin_short_backtrace+0x1063>
    0.00 :   cab69:  mov    %rax,%rbx
    0.00 :   cab6c:  test   %r12,%r12
    0.00 :   cab6f:  jne    cab88 <std::sys::backtrace::__rust_begin_short_backtrace+0x1058>
    0.00 :   cab71:  jmp    cabc8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   cab73:  jmp    cabc5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1095>
    0.00 :   cab75:  jmp    cabc5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1095>
    0.00 :   cab77:  jmp    cab93 <std::sys::backtrace::__rust_begin_short_backtrace+0x1063>
    0.00 :   cab79:  mov    %rax,%rbx
    0.00 :   cab7c:  cmp    $0xffffffffffffffff,%r14
    0.00 :   cab80:  je     cabc8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   cab82:  lock decq (%r15)
    0.00 :   cab86:  jne    cabc8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   cab88:  mov    %r14,%rdi
    0.00 :   cab8b:  call   *0xc76b7(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cab91:  jmp    cabc8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   cab93:  mov    %rax,%rbx
    0.00 :   cab96:  jmp    cabd2 <std::sys::backtrace::__rust_begin_short_backtrace+0x10a2>
    0.00 :   cab98:  mov    %rax,%rbx
    0.00 :   cab9b:  mov    (%rsp),%rax
    0.00 :   cab9f:  lock decq (%rax)
    0.00 :   caba3:  jne    cabb0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1080>
    0.00 :   caba5:  lea    0x30(%rsp),%rdi
    0.00 :   cabaa:  call   *0xc8670(%rip)        # 193220 <_DYNAMIC+0x1208>
    0.00 :   cabb0:  movzbl 0xc(%rsp),%esi
    0.00 :   cabb5:  mov    %r14,%rdi
    0.00 :   cabb8:  call   dce00 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::control::State>>>
    0.00 :   cabbd:  jmp    cabd2 <std::sys::backtrace::__rust_begin_short_backtrace+0x10a2>
    0.00 :   cabbf:  call   *0xc7893(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cabc5:  mov    %rax,%rbx
    0.00 :   cabc8:  lea    0x60(%rsp),%rdi
    0.00 :   cabcd:  call   db8f0 <core::ptr::drop_in_place<vthread::lifecycle_owner::lifecycle_reaper::Claim>>
    0.00 :   cabd2:  movabs $0x54535552005a4f4d,%rax
    0.00 :   cabdc:  cmp    %rax,(%rbx)
    0.00 :   cabdf:  jne    cad32 <std::sys::backtrace::__rust_begin_short_backtrace+0x1202>
    0.00 :   cabe5:  lea    -0xb1a41(%rip),%rax        # 191ab <_RNvNtCsiPbkgJzcHgT_12panic_unwind3imp6CANARY.llvm.187188839016265319>
    0.00 :   cabec:  cmp    %rax,0x20(%rbx)
    0.00 :   cabf0:  jne    cad3b <std::sys::backtrace::__rust_begin_short_backtrace+0x120b>
    0.00 :   cabf6:  mov    0x28(%rbx),%r14
    0.00 :   cabfa:  mov    0x30(%rbx),%r15
    0.00 :   cabfe:  mov    %rbx,%rdi
    0.00 :   cac01:  call   *0xc7641(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cac07:  mov    0xc799a(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cac0e:  lock decq (%rax)
    0.00 :   cac12:  decq   %fs:0xffffffffffffff70
    0.00 :   cac1b:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cac24:  lea    0x80(%rsp),%rdi
    0.00 :   cac2c:  mov    %r14,%rsi
    0.00 :   cac2f:  mov    %r15,%rdx
    0.00 :   cac32:  call   *0xc85e0(%rip)        # 193218 <_DYNAMIC+0x1200>
    0.00 :   cac38:  mov    0x80(%rsp),%rbx
    0.00 :   cac40:  mov    0x88(%rsp),%r14
    0.00 :   cac48:  mov    0x90(%rsp),%rax
    0.00 :   cac50:  mov    %rax,0xc0(%rsp)
    0.00 :   cac58:  movzbl 0x98(%rsp),%eax
    0.00 :   cac60:  mov    %al,0xc8(%rsp)
    0.00 :   cac67:  movzbl 0x99(%rsp),%ebp
    0.00 :   cac6f:  mov    0x9a(%rsp),%eax
    0.00 :   cac76:  mov    %eax,0x18(%rsp)
    0.00 :   cac7a:  movzwl 0x9e(%rsp),%eax
    0.00 :   cac82:  mov    %ax,0x1c(%rsp)
    0.00 :   cac87:  mov    $0x17,%edi
    0.00 :   cac8c:  call   *0xc75ce(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cac92:  test   %rax,%rax
    0.00 :   cac95:  je     cad41 <std::sys::backtrace::__rust_begin_short_backtrace+0x1211>
    0.00 :   cac9b:  movups -0xacb03(%rip),%xmm0        # 1e19f <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0xd87>
    0.00 :   caca2:  movups %xmm0,(%rax)
    0.00 :   caca5:  movabs $0x72656e776f2d656c,%rcx
    0.00 :   cacaf:  mov    %rcx,0xf(%rax)
    0.00 :   cacb3:  movq   $0x17,0x80(%rsp)
    0.00 :   cacbf:  mov    %rax,0x88(%rsp)
    0.00 :   cacc7:  movq   $0x17,0x90(%rsp)
    0.00 :   cacd3:  mov    %rbx,0x98(%rsp)
    0.00 :   cacdb:  mov    %r14,0xa0(%rsp)
    0.00 :   cace3:  mov    0xc0(%rsp),%rax
    0.00 :   caceb:  mov    %rax,0xa8(%rsp)
    0.00 :   cacf3:  movzbl 0xc8(%rsp),%eax
    0.00 :   cacfb:  mov    %al,0xb0(%rsp)
    0.00 :   cad02:  mov    %bpl,0xb1(%rsp)
    0.00 :   cad0a:  mov    0x18(%rsp),%eax
    0.00 :   cad0e:  mov    %eax,0xb2(%rsp)
    0.00 :   cad15:  movzwl 0x1c(%rsp),%eax
    0.00 :   cad1a:  mov    %ax,0xb6(%rsp)
    0.00 :   cad22:  movl   $0x10000,0xb8(%rsp)
    0.00 :   cad2d:  jmp    caa71 <std::sys::backtrace::__rust_begin_short_backtrace+0xf41>
    0.00 :   cad32:  mov    %rbx,%rdi
    0.00 :   cad35:  call   *0xc7955(%rip)        # 192690 <_Unwind_DeleteException@GCC_3.0>
    0.00 :   cad3b:  call   *0xc7957(%rip)        # 192698 <_DYNAMIC+0x680>
    0.00 :   cad41:  mov    $0x1,%edi
    0.00 :   cad46:  mov    $0x17,%esi
    0.00 :   cad4b:  call   *0xc74bf(%rip)        # 192210 <_DYNAMIC+0x1f8>
    0.00 :   cad51:  ud2
    0.00 :   cad53:  call   *0xc76ff(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cad59:  mov    %rax,%r15
    0.00 :   cad5c:  test   %rbx,%rbx
    0.00 :   cad5f:  je     cad6f <std::sys::backtrace::__rust_begin_short_backtrace+0x123f>
    0.00 :   cad61:  mov    %r14,%rdi
    0.00 :   cad64:  call   *0xc74de(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cad6a:  jmp    cad6f <std::sys::backtrace::__rust_begin_short_backtrace+0x123f>
    0.00 :   cad6c:  mov    %rax,%r15
    0.00 :   cad6f:  mov    (%rsp),%rax
    0.00 :   cad73:  lock decq (%rax)
    0.00 :   cad77:  jne    cad87 <std::sys::backtrace::__rust_begin_short_backtrace+0x1257>
    0.00 :   cad79:  lea    0xe8(%rsp),%rdi
    0.00 :   cad81:  call   *0xc8499(%rip)        # 193220 <_DYNAMIC+0x1208>
    0.00 :   cad87:  mov    %r15,%rdi
    0.00 :   cad8a:  call   187ca0 <_Unwind_Resume@plt>
    0.00 :   cad8f:  call   *0xc76c3(%rip)        # 192458 <_DYNAMIC+0x440>
 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (1 samples, percent: global period)
---------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000c6680 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   c6680:  push   %rbp
    0.00 :   c6681:  push   %r15
    0.00 :   c6683:  push   %r14
    0.00 :   c6685:  push   %r13
    0.00 :   c6687:  push   %r12
    0.00 :   c6689:  push   %rbx
    0.00 :   c668a:  sub    $0x4b8,%rsp
    0.00 :   c6691:  mov    %rdi,%rbx
    0.00 :   c6694:  mov    0x10(%rdi),%r12
    0.00 :   c6698:  cmp    $0xffffffffffffffff,%r12
    0.00 :   c669c:  je     c66aa <std::sys::backtrace::__rust_begin_short_backtrace+0x2a>
    0.00 :   c669e:  lock incq 0x8(%r12)
    0.00 :   c66a4:  jle    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c66aa:  mov    %r12,%rdi
    0.00 :   c66ad:  mov    $0x3,%esi
    0.00 :   c66b2:  call   102ff0 <vthread::worker_context::attach>
    0.00 :   c66b7:  mov    0x18(%rbx),%rbp
    0.00 :   c66bb:  mov    (%rbx),%rax
    0.00 :   c66be:  mov    %rax,0x238(%rsp)
    0.00 :   c66c6:  mov    0x8(%rbx),%rax
    0.00 :   c66ca:  mov    %rax,0x240(%rsp)
    0.00 :   c66d2:  cmp    $0x3,%rbp
    0.00 :   c66d6:  mov    $0x2,%esi
    0.00 :   c66db:  cmovae %rbp,%rsi
    0.00 :   c66df:  lea    0x198(%rsp),%rdi
    0.00 :   c66e7:  mov    %rbp,%rdx
    0.00 :   c66ea:  call   *0xccaa8(%rip)        # 193198 <_DYNAMIC+0x1180>
    0.00 :   c66f0:  movabs $0x7fffffffffffffff,%rbx
    0.00 :   c66fa:  mov    0x198(%rsp),%rax
    0.00 :   c6702:  cmp    $0x2,%rax
    0.00 :   c6706:  jne    c6897 <std::sys::backtrace::__rust_begin_short_backtrace+0x217>
    0.00 :   c670c:  lea    0x1a0(%rsp),%rsi
    0.00 :   c6714:  lea    0x400(%rsp),%rdi
    0.00 :   c671c:  call   131e00 <vthread::readiness::io_error>
    0.00 :   c6721:  mov    0x400(%rsp),%rbx
    0.00 :   c6729:  mov    0x408(%rsp),%r14
    0.00 :   c6731:  mov    0x410(%rsp),%rbp
    0.00 :   c6739:  movups 0x418(%rsp),%xmm0
    0.00 :   c6741:  movups 0x428(%rsp),%xmm1
    0.00 :   c6749:  movaps %xmm1,0x350(%rsp)
    0.00 :   c6751:  mov    0x438(%rsp),%rax
    0.00 :   c6759:  movaps %xmm0,0x120(%rsp)
    0.00 :   c6761:  movaps %xmm1,0x3a0(%rsp)
    0.00 :   c6769:  mov    %rax,0x3b0(%rsp)
    0.00 :   c6771:  movaps %xmm0,0x2f0(%rsp)
    0.00 :   c6779:  mov    0x3b0(%rsp),%rax
    0.00 :   c6781:  mov    %rax,0x2e0(%rsp)
    0.00 :   c6789:  movdqa 0x3a0(%rsp),%xmm0
    0.00 :   c6792:  movdqa %xmm0,0x2d0(%rsp)
    0.00 :   c679b:  cmp    $0xffffffffffffffff,%r12
    0.00 :   c679f:  je     c67b2 <std::sys::backtrace::__rust_begin_short_backtrace+0x132>
    0.00 :   c67a1:  lock decq 0x8(%r12)
    0.00 :   c67a7:  jne    c67b2 <std::sys::backtrace::__rust_begin_short_backtrace+0x132>
    0.00 :   c67a9:  mov    %r12,%rdi
    0.00 :   c67ac:  call   *0xcba96(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c67b2:  movaps 0x2f0(%rsp),%xmm0
    0.00 :   c67ba:  movups %xmm0,0x1b0(%rsp)
    0.00 :   c67c2:  movdqa 0x2d0(%rsp),%xmm0
    0.00 :   c67cb:  movdqu %xmm0,0x1c0(%rsp)
    0.00 :   c67d4:  mov    0x2e0(%rsp),%rax
    0.00 :   c67dc:  mov    %rax,0x1d0(%rsp)
    0.00 :   c67e4:  mov    %rbx,0x198(%rsp)
    0.00 :   c67ec:  mov    %r14,0x1a0(%rsp)
    0.00 :   c67f4:  mov    %rbp,0x1a8(%rsp)
    0.00 :   c67fc:  lea    0x248(%rsp),%rdi
    0.00 :   c6804:  lea    0x198(%rsp),%rcx
    0.00 :   c680c:  mov    0x238(%rsp),%rsi
    0.00 :   c6814:  mov    0x240(%rsp),%rdx
    0.00 :   c681c:  call   ce7e0 <std::sync::mpmc::Sender<T>::send>
    0.00 :   c6821:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   c682b:  mov    0x248(%rsp),%rax
    0.00 :   c6833:  lea    0x24(%rdx),%rcx
    0.00 :   c6837:  cmp    %rcx,%rax
    0.00 :   c683a:  je     c6870 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c683c:  add    $0x23,%rdx
    0.00 :   c6840:  cmp    %rdx,%rax
    0.00 :   c6843:  jne    c6863 <std::sys::backtrace::__rust_begin_short_backtrace+0x1e3>
    0.00 :   c6845:  mov    0x250(%rsp),%rax
    0.00 :   c684d:  lock decq (%rax)
    0.00 :   c6851:  jne    c6870 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c6853:  lea    0x250(%rsp),%rdi
    0.00 :   c685b:  call   *0xcc93f(%rip)        # 1931a0 <_DYNAMIC+0x1188>
    0.00 :   c6861:  jmp    c6870 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c6863:  lea    0x248(%rsp),%rdi
    0.00 :   c686b:  call   d7ad0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10657235172099788962>
    0.00 :   c6870:  mov    0x238(%rsp),%rdi
    0.00 :   c6878:  mov    0x240(%rsp),%rsi
    0.00 :   c6880:  call   d65a0 <core::ptr::drop_in_place<std::sync::mpsc::SyncSender<core::result::Result<alloc::sync::Arc<vthread::readiness::Inner>,vthread::error::Error>>>>
    0.00 :   c6885:  add    $0x4b8,%rsp
    0.00 :   c688c:  pop    %rbx
    0.00 :   c688d:  pop    %r12
    0.00 :   c688f:  pop    %r13
    0.00 :   c6891:  pop    %r14
    0.00 :   c6893:  pop    %r15
    0.00 :   c6895:  pop    %rbp
    0.00 :   c6896:  ret
    0.00 :   c6897:  mov    0x1b0(%rsp),%rcx
    0.00 :   c689f:  movups 0x1b8(%rsp),%xmm0
    0.00 :   c68a7:  movaps %xmm0,0x50(%rsp)
    0.00 :   c68ac:  movups 0x1c8(%rsp),%xmm1
    0.00 :   c68b4:  movaps %xmm1,0x350(%rsp)
    0.00 :   c68bc:  mov    0x1d8(%rsp),%rdx
    0.00 :   c68c4:  mov    %rdx,0x360(%rsp)
    0.00 :   c68cc:  lea    0x290(%rsp),%r13
    0.00 :   c68d4:  movups 0x1e0(%rsp),%xmm1
    0.00 :   c68dc:  movups %xmm1,0x290(%rsp)
    0.00 :   c68e4:  movups 0x1f0(%rsp),%xmm1
    0.00 :   c68ec:  movups %xmm1,0x2a0(%rsp)
    0.00 :   c68f4:  movups 0x200(%rsp),%xmm1
    0.00 :   c68fc:  movups %xmm1,0x2b0(%rsp)
    0.00 :   c6904:  movups 0x210(%rsp),%xmm1
    0.00 :   c690c:  movups %xmm1,0x2c0(%rsp)
    0.00 :   c6914:  movups 0x1a0(%rsp),%xmm1
    0.00 :   c691c:  movaps %xmm0,0x120(%rsp)
    0.00 :   c6924:  mov    0x360(%rsp),%rdx
    0.00 :   c692c:  mov    %rdx,0x3b0(%rsp)
    0.00 :   c6934:  movaps 0x350(%rsp),%xmm0
    0.00 :   c693c:  movaps %xmm0,0x3a0(%rsp)
    0.00 :   c6944:  movups %xmm1,0x250(%rsp)
    0.00 :   c694c:  mov    %rcx,0x260(%rsp)
    0.00 :   c6954:  movaps 0x120(%rsp),%xmm0
    0.00 :   c695c:  movups %xmm0,0x268(%rsp)
    0.00 :   c6964:  mov    0x3b0(%rsp),%rcx
    0.00 :   c696c:  mov    %rcx,0x288(%rsp)
    0.00 :   c6974:  movdqa 0x3a0(%rsp),%xmm0
    0.00 :   c697d:  movdqu %xmm0,0x278(%rsp)
    0.00 :   c6986:  mov    %rax,0x248(%rsp)
    0.00 :   c698e:  mov    0x288(%rsp),%r15
    0.00 :   c6996:  lea    0x198(%rsp),%rdi
    0.00 :   c699e:  mov    $0x8,%edx
    0.00 :   c69a3:  mov    $0x10,%r8d
    0.00 :   c69a9:  xor    %esi,%esi
    0.00 :   c69ab:  mov    %r15,%rcx
    0.00 :   c69ae:  call   187880 <_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h4ed0753c4cf49bf8E.llvm.534919669303308328>
    0.00 :   c69b3:  cmpb   $0x0,0x198(%rsp)
    0.00 :   c69bb:  je     c6a41 <std::sys::backtrace::__rust_begin_short_backtrace+0x3c1>
    0.00 :   c69c1:  lea    0x408(%rsp),%rsi
    0.00 :   c69c9:  movb   $0x7,0x408(%rsp)
    0.00 :   c69d1:  mov    %r15,0x410(%rsp)
    0.00 :   c69d9:  lea    0x1(%rbx),%rax
    0.00 :   c69dd:  mov    %rax,0x400(%rsp)
    0.00 :   c69e5:  lea    0x198(%rsp),%rdi
    0.00 :   c69ed:  call   131e00 <vthread::readiness::io_error>
    0.00 :   c69f2:  mov    0x198(%rsp),%rbx
    0.00 :   c69fa:  mov    0x1a0(%rsp),%r14
    0.00 :   c6a02:  mov    0x1a8(%rsp),%rbp
    0.00 :   c6a0a:  movdqu 0x1b0(%rsp),%xmm0
    0.00 :   c6a13:  movups 0x1c0(%rsp),%xmm1
    0.00 :   c6a1b:  movaps %xmm1,0x2d0(%rsp)
    0.00 :   c6a23:  mov    0x1d0(%rsp),%rax
    0.00 :   c6a2b:  mov    %rax,0x2e0(%rsp)
    0.00 :   c6a33:  movdqa %xmm0,0x2f0(%rsp)
    0.00 :   c6a3c:  jmp    c6b21 <std::sys::backtrace::__rust_begin_short_backtrace+0x4a1>
    0.00 :   c6a41:  mov    0x1a0(%rsp),%rcx
    0.00 :   c6a49:  mov    %r15,0x418(%rsp)
    0.00 :   c6a51:  movq   $0x0,0x410(%rsp)
    0.00 :   c6a5d:  mov    0x410(%rsp),%rax
    0.00 :   c6a65:  mov    %rax,0x50(%rsp)
    0.00 :   c6a6a:  mov    0x418(%rsp),%rax
    0.00 :   c6a72:  mov    %rax,0x58(%rsp)
    0.00 :   c6a77:  cmpl   $0x1,0x248(%rsp)
    0.00 :   c6a7f:  mov    %rcx,0x20(%rsp)
    0.00 :   c6a84:  jne    c6bc3 <std::sys::backtrace::__rust_begin_short_backtrace+0x543>
    0.00 :   c6a8a:  mov    0x250(%rsp),%rax
    0.00 :   c6a92:  test   %rax,%rax
    0.00 :   c6a95:  je     c6bdb <std::sys::backtrace::__rust_begin_short_backtrace+0x55b>
    0.00 :   c6a9b:  movb   $0x2,0x90(%rsp)
    0.00 :   c6aa3:  mov    %rax,0x98(%rsp)
    0.00 :   c6aab:  movq   $0x0,0xa0(%rsp)
    0.00 :   c6ab7:  lea    0x198(%rsp),%rdi
    0.00 :   c6abf:  lea    0x90(%rsp),%rsi
    0.00 :   c6ac7:  call   131e00 <vthread::readiness::io_error>
    0.00 :   c6acc:  mov    0x198(%rsp),%rbx
    0.00 :   c6ad4:  mov    0x1a0(%rsp),%r14
    0.00 :   c6adc:  mov    0x1a8(%rsp),%rbp
    0.00 :   c6ae4:  movups 0x1b0(%rsp),%xmm0
    0.00 :   c6aec:  movaps %xmm0,0x2f0(%rsp)
    0.00 :   c6af4:  movdqu 0x1c0(%rsp),%xmm0
    0.00 :   c6afd:  movdqa %xmm0,0x2d0(%rsp)
    0.00 :   c6b06:  mov    0x1d0(%rsp),%rax
    0.00 :   c6b0e:  mov    %rax,0x2e0(%rsp)
    0.00 :   c6b16:  mov    0x20(%rsp),%rdi
    0.00 :   c6b1b:  call   *0xcb727(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c6b21:  mov    0x2c8(%rsp),%edi
    0.00 :   c6b28:  call   *0xcbd0a(%rip)        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c6b2e:  mov    0x260(%rsp),%rax
    0.00 :   c6b36:  mov    %rax,0x20(%rsp)
    0.00 :   c6b3b:  mov    0x268(%rsp),%r13
    0.00 :   c6b43:  test   %r13,%r13
    0.00 :   c6b46:  je     c6b88 <std::sys::backtrace::__rust_begin_short_backtrace+0x508>
    0.00 :   c6b48:  mov    0x20(%rsp),%rax
    0.00 :   c6b4d:  lea    0xe(%rax),%r15
    0.00 :   c6b51:  jmp    c6b69 <std::sys::backtrace::__rust_begin_short_backtrace+0x4e9>
    0.00 :   c6b53:  data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   c6b60:  add    $0x18,%r15
    0.00 :   c6b64:  dec    %r13
    0.00 :   c6b67:  je     c6b88 <std::sys::backtrace::__rust_begin_short_backtrace+0x508>
    0.00 :   c6b69:  mov    -0x6(%r15),%edi
    0.00 :   c6b6d:  cmpb   $0x2,(%r15)
    0.00 :   c6b71:  setne  %al
    0.00 :   c6b74:  test   %edi,%edi
    0.00 :   c6b76:  setns  %cl
    0.00 :   c6b79:  and    %al,%cl
    0.00 :   c6b7b:  cmp    $0x1,%cl
    0.00 :   c6b7e:  jne    c6b60 <std::sys::backtrace::__rust_begin_short_backtrace+0x4e0>
    0.00 :   c6b80:  call   *0xcbcb2(%rip)        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c6b86:  jmp    c6b60 <std::sys::backtrace::__rust_begin_short_backtrace+0x4e0>
    0.00 :   c6b88:  cmpq   $0x0,0x258(%rsp)
    0.00 :   c6b91:  je     c6b9e <std::sys::backtrace::__rust_begin_short_backtrace+0x51e>
    0.00 :   c6b93:  mov    0x20(%rsp),%rdi
    0.00 :   c6b98:  call   *0xcb6aa(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c6b9e:  mov    0x290(%rsp),%rax
    0.00 :   c6ba6:  lock decq (%rax)
    0.00 :   c6baa:  lea    0x290(%rsp),%rdi
    0.00 :   c6bb2:  jne    c679b <std::sys::backtrace::__rust_begin_short_backtrace+0x11b>
    0.00 :   c6bb8:  call   *0xcc5ea(%rip)        # 1931a8 <_DYNAMIC+0x1190>
    0.00 :   c6bbe:  jmp    c679b <std::sys::backtrace::__rust_begin_short_backtrace+0x11b>
    0.00 :   c6bc3:  movq   $0x1,0x248(%rsp)
    0.00 :   c6bcf:  movq   $0x0,0x250(%rsp)
    0.00 :   c6bdb:  mov    0x290(%rsp),%rax
    0.00 :   c6be3:  lock incq (%rax)
    0.00 :   c6be7:  jle    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c6bed:  movq   $0x1,0x198(%rsp)
    0.00 :   c6bf9:  movq   $0x1,0x1a0(%rsp)
    0.00 :   c6c05:  mov    %r12,0x1a8(%rsp)
    0.00 :   c6c0d:  mov    %rax,0x1b0(%rsp)
    0.00 :   c6c15:  movl   $0x0,0x1b8(%rsp)
    0.00 :   c6c20:  movb   $0x0,0x1bc(%rsp)
    0.00 :   c6c28:  lea    0x1(%rbx),%rax
    0.00 :   c6c2c:  mov    %rax,0x230(%rsp)
    0.00 :   c6c34:  mov    %rax,0x1c0(%rsp)
    0.00 :   c6c3c:  movq   $0x0,0x1d8(%rsp)
    0.00 :   c6c48:  movq   $0x0,0x1e8(%rsp)
    0.00 :   c6c54:  movq   $0x1,0x1f0(%rsp)
    0.00 :   c6c60:  movb   $0x0,0x1f8(%rsp)
    0.00 :   c6c68:  mov    %rbp,0x200(%rsp)
    0.00 :   c6c70:  movq   $0x0,0x208(%rsp)
    0.00 :   c6c7c:  mov    $0x78,%edi
    0.00 :   c6c81:  call   *0xcb5d9(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   c6c87:  test   %rax,%rax
    0.00 :   c6c8a:  je     c942a <std::sys::backtrace::__rust_begin_short_backtrace+0x2daa>
    0.00 :   c6c90:  lea    0x268(%rsp),%rcx
    0.00 :   c6c98:  lea    0x278(%rsp),%rdi
    0.00 :   c6ca0:  mov    0x208(%rsp),%rdx
    0.00 :   c6ca8:  mov    %rdx,0x70(%rax)
    0.00 :   c6cac:  movups 0x1f8(%rsp),%xmm0
    0.00 :   c6cb4:  movups %xmm0,0x60(%rax)
    0.00 :   c6cb8:  movups 0x1e8(%rsp),%xmm0
    0.00 :   c6cc0:  movups %xmm0,0x50(%rax)
    0.00 :   c6cc4:  movups 0x1d8(%rsp),%xmm0
    0.00 :   c6ccc:  movups %xmm0,0x40(%rax)
    0.00 :   c6cd0:  movups 0x198(%rsp),%xmm0
    0.00 :   c6cd8:  movups 0x1a8(%rsp),%xmm1
    0.00 :   c6ce0:  movups 0x1b8(%rsp),%xmm2
    0.00 :   c6ce8:  movups 0x1c8(%rsp),%xmm3
    0.00 :   c6cf0:  movups %xmm3,0x30(%rax)
    0.00 :   c6cf4:  movups %xmm2,0x20(%rax)
    0.00 :   c6cf8:  movups %xmm1,0x10(%rax)
    0.00 :   c6cfc:  movups %xmm0,(%rax)
    0.00 :   c6cff:  mov    0x248(%rsp),%rsi
    0.00 :   c6d07:  mov    0x250(%rsp),%rbx
    0.00 :   c6d0f:  mov    0x258(%rsp),%r14
    0.00 :   c6d17:  mov    0x260(%rsp),%rbp
    0.00 :   c6d1f:  movups (%rcx),%xmm0
    0.00 :   c6d22:  movaps %xmm0,0x2f0(%rsp)
    0.00 :   c6d2a:  mov    0x10(%rdi),%rcx
    0.00 :   c6d2e:  mov    %rcx,0x2e0(%rsp)
    0.00 :   c6d36:  movups (%rdi),%xmm0
    0.00 :   c6d39:  movaps %xmm0,0x2d0(%rsp)
    0.00 :   c6d41:  movups 0x0(%r13),%xmm0
    0.00 :   c6d46:  movups 0x10(%r13),%xmm1
    0.00 :   c6d4b:  movups 0x20(%r13),%xmm2
    0.00 :   c6d50:  movups 0x30(%r13),%xmm3
    0.00 :   c6d55:  movaps %xmm0,0x3a0(%rsp)
    0.00 :   c6d5d:  movaps %xmm1,0x3b0(%rsp)
    0.00 :   c6d65:  movaps %xmm2,0x3c0(%rsp)
    0.00 :   c6d6d:  movaps %xmm3,0x3d0(%rsp)
    0.00 :   c6d75:  movdqa 0x50(%rsp),%xmm0
    0.00 :   c6d7b:  movdqa %xmm0,0x4a0(%rsp)
    0.00 :   c6d84:  cmp    $0x2,%rsi
    0.00 :   c6d88:  je     c67b2 <std::sys::backtrace::__rust_begin_short_backtrace+0x132>
    0.00 :   c6d8e:  mov    %rax,%rdx
    0.00 :   c6d91:  mov    %rdi,0x228(%rsp)
    0.00 :   c6d99:  mov    %rax,0x320(%rsp)
    0.00 :   c6da1:  mov    %rsi,0x400(%rsp)
    0.00 :   c6da9:  mov    %rbx,0x408(%rsp)
    0.00 :   c6db1:  mov    %r14,0x410(%rsp)
    0.00 :   c6db9:  mov    %rbp,0x418(%rsp)
    0.00 :   c6dc1:  movaps 0x2f0(%rsp),%xmm0
    0.00 :   c6dc9:  movups %xmm0,0x420(%rsp)
    0.00 :   c6dd1:  movaps 0x2d0(%rsp),%xmm0
    0.00 :   c6dd9:  movups %xmm0,0x430(%rsp)
    0.00 :   c6de1:  mov    0x2e0(%rsp),%rax
    0.00 :   c6de9:  mov    %rax,0x440(%rsp)
    0.00 :   c6df1:  movdqa 0x3a0(%rsp),%xmm0
    0.00 :   c6dfa:  movaps 0x3b0(%rsp),%xmm1
    0.00 :   c6e02:  movaps 0x3c0(%rsp),%xmm2
    0.00 :   c6e0a:  movaps 0x3d0(%rsp),%xmm3
    0.00 :   c6e12:  movdqu %xmm0,0x448(%rsp)
    0.00 :   c6e1b:  movups %xmm1,0x458(%rsp)
    0.00 :   c6e23:  movups %xmm2,0x468(%rsp)
    0.00 :   c6e2b:  movups %xmm3,0x478(%rsp)
    0.00 :   c6e33:  lock incq (%rdx)
    0.00 :   c6e37:  jle    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c6e3d:  mov    %rdx,0x80(%rsp)
    0.00 :   c6e45:  mov    %rdx,0x1a0(%rsp)
    0.00 :   c6e4d:  movabs $0x7fffffffffffffff,%r14
    0.00 :   c6e57:  lea    0x23(%r14),%rbx
    0.00 :   c6e5b:  mov    %rbx,0x198(%rsp)
    0.00 :   c6e63:  lea    0x248(%rsp),%rdi
    0.00 :   c6e6b:  lea    0x198(%rsp),%rcx
    0.00 :   c6e73:  mov    0x238(%rsp),%rsi
    0.00 :   c6e7b:  mov    0x240(%rsp),%rdx
    0.00 :   c6e83:  call   ce7e0 <std::sync::mpmc::Sender<T>::send>
    0.00 :   c6e88:  mov    0x248(%rsp),%rax
    0.00 :   c6e90:  lea    0x24(%r14),%rcx
    0.00 :   c6e94:  mov    %rcx,0x3e0(%rsp)
    0.00 :   c6e9c:  cmp    %rcx,%rax
    0.00 :   c6e9f:  mov    %rax,0x3e8(%rsp)
    0.00 :   c6ea7:  jne    c8cc7 <std::sys::backtrace::__rust_begin_short_backtrace+0x2647>
    0.00 :   c6ead:  lea    0x248(%rsp),%rdi
    0.00 :   c6eb5:  lea    0x400(%rsp),%rsi
    0.00 :   c6ebd:  mov    $0x88,%edx
    0.00 :   c6ec2:  call   *0xcb368(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   c6ec8:  mov    %r15,0x330(%rsp)
    0.00 :   c6ed0:  mov    0x20(%rsp),%rax
    0.00 :   c6ed5:  mov    %rax,0x338(%rsp)
    0.00 :   c6edd:  movdqa 0x4a0(%rsp),%xmm0
    0.00 :   c6ee6:  movdqu %xmm0,0x340(%rsp)
    0.00 :   c6eef:  mov    0x80(%rsp),%rax
    0.00 :   c6ef7:  mov    %rax,0x328(%rsp)
    0.00 :   c6eff:  movq   $0x0,0x100(%rsp)
    0.00 :   c6f0b:  movq   $0x0,0x110(%rsp)
    0.00 :   c6f17:  lea    0x20(%rax),%rbp
    0.00 :   c6f1b:  lea    0x280(%rsp),%rcx
    0.00 :   c6f23:  mov    %rcx,0x220(%rsp)
    0.00 :   c6f2b:  lea    0x40(%rax),%rax
    0.00 :   c6f2f:  mov    %rax,0x3f8(%rsp)
    0.00 :   c6f37:  mov    $0x1,%r15d
    0.00 :   c6f3d:  mov    0xcb8f4(%rip),%rbx        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c6f44:  lea    0xc6dc5(%rip),%rax        # 18dd10 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x4a0>
    0.00 :   c6f4b:  mov    %rax,0x310(%rsp)
    0.00 :   c6f53:  lea    -0xa97a5(%rip),%rax        # 1d7b5 <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x39d>
    0.00 :   c6f5a:  mov    %rax,0x308(%rsp)
    0.00 :   c6f62:  mov    0x230(%rsp),%r14
    0.00 :   c6f6a:  mov    %rbp,0xe8(%rsp)
    0.00 :   c6f72:  xor    %eax,%eax
    0.00 :   c6f74:  lock cmpxchg %r15d,0x0(%rbp)
    0.00 :   c6f7a:  jne    c8c75 <std::sys::backtrace::__rust_begin_short_backtrace+0x25f5>
    0.00 :   c6f80:  mov    0xcb621(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c6f87:  mov    (%rax),%rax
    0.00 :   c6f8a:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c6f94:  test   %rcx,%rax
    0.00 :   c6f97:  jne    c8c83 <std::sys::backtrace::__rust_begin_short_backtrace+0x2603>
    0.00 :   c6f9d:  xor    %eax,%eax
    0.00 :   c6f9f:  mov    0x80(%rsp),%rdx
    0.00 :   c6fa7:  movzbl 0x24(%rdx),%ecx
    0.00 :   c6fab:  mov    %rbp,0x160(%rsp)
    0.00 :   c6fb3:  mov    %al,0x168(%rsp)
    0.00 :   c6fba:  cmpb   $0x0,0x60(%rdx)
    0.00 :   c6fbe:  jne    c926f <std::sys::backtrace::__rust_begin_short_backtrace+0x2bef>
    0.00 :   c6fc4:  mov    0x100(%rsp),%rax
    0.00 :   c6fcc:  xor    %ecx,%ecx
    0.00 :   c6fce:  mov    %rax,%rdx
    0.00 :   c6fd1:  test   %rax,%rax
    0.00 :   c6fd4:  setne  %sil
    0.00 :   c6fd8:  je     c6fe2 <std::sys::backtrace::__rust_begin_short_backtrace+0x962>
    0.00 :   c6fda:  mov    0x110(%rsp),%rdx
    0.00 :   c6fe2:  mov    0x108(%rsp),%rdi
    0.00 :   c6fea:  mov    %sil,%cl
    0.00 :   c6fed:  mov    %rcx,0x350(%rsp)
    0.00 :   c6ff5:  movq   $0x0,0x358(%rsp)
    0.00 :   c7001:  mov    %rax,0x360(%rsp)
    0.00 :   c7009:  mov    %rdi,0x368(%rsp)
    0.00 :   c7011:  mov    %rcx,0x370(%rsp)
    0.00 :   c7019:  movq   $0x0,0x378(%rsp)
    0.00 :   c7025:  mov    %rax,0x380(%rsp)
    0.00 :   c702d:  mov    %rdi,0x388(%rsp)
    0.00 :   c7035:  mov    %rdx,0x390(%rsp)
    0.00 :   c703d:  lea    0x160(%rsp),%rax
    0.00 :   c7045:  mov    %rax,0x398(%rsp)
    0.00 :   c704d:  lea    0x350(%rsp),%rdi
    0.00 :   c7055:  call   c5280 <<core::iter::adapters::copied::Copied<I> as core::iter::traits::iterator::Iterator>::next>
    0.00 :   c705a:  test   $0x1,%al
    0.00 :   c705c:  je     c759b <std::sys::backtrace::__rust_begin_short_backtrace+0xf1b>
    0.00 :   c7062:  mov    %rdx,%r12
    0.00 :   c7065:  mov    $0x20,%edi
    0.00 :   c706a:  call   *0xcb1f0(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   c7070:  test   %rax,%rax
    0.00 :   c7073:  je     c9690 <std::sys::backtrace::__rust_begin_short_backtrace+0x3010>
    0.00 :   c7079:  mov    %rax,%r15
    0.00 :   c707c:  mov    %r12,(%rax)
    0.00 :   c707f:  movq   $0x4,0x50(%rsp)
    0.00 :   c7088:  mov    %rax,0x58(%rsp)
    0.00 :   c708d:  movq   $0x1,0x60(%rsp)
    0.00 :   c7096:  movups 0x390(%rsp),%xmm0
    0.00 :   c709e:  movaps %xmm0,0xd0(%rsp)
    0.00 :   c70a6:  movdqu 0x350(%rsp),%xmm0
    0.00 :   c70af:  movups 0x360(%rsp),%xmm1
    0.00 :   c70b7:  movups 0x370(%rsp),%xmm2
    0.00 :   c70bf:  movups 0x380(%rsp),%xmm3
    0.00 :   c70c7:  movaps %xmm3,0xc0(%rsp)
    0.00 :   c70cf:  movaps %xmm2,0xb0(%rsp)
    0.00 :   c70d7:  movaps %xmm1,0xa0(%rsp)
    0.00 :   c70df:  movdqa %xmm0,0x90(%rsp)
    0.00 :   c70e8:  mov    $0x1,%r12d
    0.00 :   c70ee:  mov    $0xfffffffffffffff8,%r14
    0.00 :   c70f5:  lea    0x90(%rsp),%rbp
    0.00 :   c70fd:  jmp    c7114 <std::sys::backtrace::__rust_begin_short_backtrace+0xa94>
    0.00 :   c70ff:  mov    0x58(%rsp),%r15
    0.00 :   c7104:  mov    %r13,(%r15,%r12,8)
    0.00 :   c7108:  inc    %r12
    0.00 :   c710b:  mov    %r12,0x60(%rsp)
    0.00 :   c7110:  add    $0xfffffffffffffff8,%r14
    0.00 :   c7114:  mov    %rbp,%rdi
    0.00 :   c7117:  call   c5280 <<core::iter::adapters::copied::Copied<I> as core::iter::traits::iterator::Iterator>::next>
    0.00 :   c711c:  cmp    $0x1,%rax
    0.00 :   c7120:  jne    c714b <std::sys::backtrace::__rust_begin_short_backtrace+0xacb>
    0.00 :   c7122:  mov    %rdx,%r13
    0.00 :   c7125:  cmp    0x50(%rsp),%r12
    0.00 :   c712a:  jne    c7104 <std::sys::backtrace::__rust_begin_short_backtrace+0xa84>
    0.00 :   c712c:  mov    $0x1,%edx
    0.00 :   c7131:  mov    $0x8,%ecx
    0.00 :   c7136:  mov    $0x8,%r8d
    0.00 :   c713c:  lea    0x50(%rsp),%rdi
    0.00 :   c7141:  mov    %r12,%rsi
    0.00 :   c7144:  call   f29d0 <alloc::raw_vec::RawVecInner<A>::reserve::do_reserve_and_handle>
    0.00 :   c7149:  jmp    c70ff <std::sys::backtrace::__rust_begin_short_backtrace+0xa7f>
    0.00 :   c714b:  mov    0x50(%rsp),%rax
    0.00 :   c7150:  mov    %rax,0x8(%rsp)
    0.00 :   c7155:  mov    0x58(%rsp),%rax
    0.00 :   c715a:  mov    %rax,%rcx
    0.00 :   c715d:  sub    %r14,%rcx
    0.00 :   c7160:  mov    %rcx,0x20(%rsp)
    0.00 :   c7165:  mov    %rax,0x10(%rsp)
    0.00 :   c716a:  mov    %rax,%r14
    0.00 :   c716d:  jmp    c7190 <std::sys::backtrace::__rust_begin_short_backtrace+0xb10>
    0.00 :   c716f:  movb   $0x2,0xe(%rbp)
    0.00 :   c7173:  mov    0x280(%rsp),%eax
    0.00 :   c717a:  mov    %eax,0x14(%rbp)
    0.00 :   c717d:  mov    %r13d,0x280(%rsp)
    0.00 :   c7185:  cmp    %r14,0x20(%rsp)
    0.00 :   c718a:  je     c7578 <std::sys::backtrace::__rust_begin_short_backtrace+0xef8>
    0.00 :   c7190:  mov    0x100(%rsp),%r13
    0.00 :   c7198:  test   %r13,%r13
    0.00 :   c719b:  je     c95f1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2f71>
    0.00 :   c71a1:  mov    (%r14),%rdx
    0.00 :   c71a4:  add    $0x8,%r14
    0.00 :   c71a8:  mov    0x108(%rsp),%rbp
    0.00 :   c71b0:  lea    0x7(%rbp),%esi
    0.00 :   c71b3:  xor    %eax,%eax
    0.00 :   c71b5:  mov    %rbp,%rcx
    0.00 :   c71b8:  mov    %r13,%rdi
    0.00 :   c71bb:  movzwl 0x112(%rdi),%r9d
    0.00 :   c71c3:  mov    %r9d,%r10d
    0.00 :   c71c6:  shl    $0x3,%r10d
    0.00 :   c71ca:  mov    $0xffffffffffffffff,%r8
    0.00 :   c71d1:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   c71e0:  test   %r10,%r10
    0.00 :   c71e3:  je     c720d <std::sys::backtrace::__rust_begin_short_backtrace+0xb8d>
    0.00 :   c71e5:  cmp    0xc0(%rdi,%r8,8),%rdx
    0.00 :   c71ed:  seta   %r11b
    0.00 :   c71f1:  sbb    $0x0,%r11b
    0.00 :   c71f5:  inc    %r8
    0.00 :   c71f8:  add    $0xfffffffffffffff8,%r10
    0.00 :   c71fc:  cmp    $0x1,%r11b
    0.00 :   c7200:  je     c71e0 <std::sys::backtrace::__rust_begin_short_backtrace+0xb60>
    0.00 :   c7202:  movzbl %r11b,%r9d
    0.00 :   c7206:  test   %r9d,%r9d
    0.00 :   c7209:  jne    c7210 <std::sys::backtrace::__rust_begin_short_backtrace+0xb90>
    0.00 :   c720b:  jmp    c722d <std::sys::backtrace::__rust_begin_short_backtrace+0xbad>
    0.00 :   c720d:  mov    %r9,%r8
    0.00 :   c7210:  test   %rcx,%rcx
    0.00 :   c7213:  je     c95f1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2f71>
    0.00 :   c7219:  mov    0x118(%rdi,%r8,8),%rdi
    0.00 :   c7221:  dec    %rcx
    0.00 :   c7224:  inc    %rax
    0.00 :   c7227:  add    $0x7,%sil
    0.00 :   c722b:  jmp    c71bb <std::sys::backtrace::__rust_begin_short_backtrace+0xb3b>
    0.00 :   c722d:  movb   $0x0,0x120(%rsp)
    0.00 :   c7235:  test   %rcx,%rcx
    0.00 :   c7238:  je     c73c4 <std::sys::backtrace::__rust_begin_short_backtrace+0xd44>
    0.00 :   c723e:  mov    0x118(%rdi,%r8,8),%rdx
    0.00 :   c7246:  mov    %rcx,%rdi
    0.00 :   c7249:  dec    %rdi
    0.00 :   c724c:  je     c7324 <std::sys::backtrace::__rust_begin_short_backtrace+0xca4>
    0.00 :   c7252:  test   $0x7,%dil
    0.00 :   c7256:  je     c7296 <std::sys::backtrace::__rust_begin_short_backtrace+0xc16>
    0.00 :   c7258:  movzbl %sil,%esi
    0.00 :   c725c:  and    $0x7,%esi
    0.00 :   c725f:  neg    %rsi
    0.00 :   c7262:  mov    $0x1,%edi
    0.00 :   c7267:  nopw   0x0(%rax,%rax,1)
    0.00 :   c7270:  movzwl 0x112(%rdx),%r8d
    0.00 :   c7278:  mov    0x118(%rdx,%r8,8),%rdx
    0.00 :   c7280:  lea    (%rsi,%rdi,1),%r8
    0.00 :   c7284:  inc    %r8
    0.00 :   c7287:  inc    %rdi
    0.00 :   c728a:  cmp    $0x1,%r8
    0.00 :   c728e:  jne    c7270 <std::sys::backtrace::__rust_begin_short_backtrace+0xbf0>
    0.00 :   c7290:  sub    %rdi,%rcx
    0.00 :   c7293:  mov    %rcx,%rdi
    0.00 :   c7296:  mov    %rbp,%rcx
    0.00 :   c7299:  sub    %rax,%rcx
    0.00 :   c729c:  add    $0xfffffffffffffffe,%rcx
    0.00 :   c72a0:  cmp    $0x7,%rcx
    0.00 :   c72a4:  jb     c7324 <std::sys::backtrace::__rust_begin_short_backtrace+0xca4>
    0.00 :   c72a6:  movzwl 0x112(%rdx),%eax
    0.00 :   c72ad:  mov    0x118(%rdx,%rax,8),%rax
    0.00 :   c72b5:  movzwl 0x112(%rax),%ecx
    0.00 :   c72bc:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c72c4:  movzwl 0x112(%rax),%ecx
    0.00 :   c72cb:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c72d3:  movzwl 0x112(%rax),%ecx
    0.00 :   c72da:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c72e2:  movzwl 0x112(%rax),%ecx
    0.00 :   c72e9:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c72f1:  movzwl 0x112(%rax),%ecx
    0.00 :   c72f8:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c7300:  movzwl 0x112(%rax),%ecx
    0.00 :   c7307:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c730f:  movzwl 0x112(%rax),%ecx
    0.00 :   c7316:  mov    0x118(%rax,%rcx,8),%rdx
    0.00 :   c731e:  add    $0xfffffffffffffff8,%rdi
    0.00 :   c7322:  jne    c72a6 <std::sys::backtrace::__rust_begin_short_backtrace+0xc26>
    0.00 :   c7324:  movzwl 0x112(%rdx),%eax
    0.00 :   c732b:  dec    %rax
    0.00 :   c732e:  mov    %rdx,0x50(%rsp)
    0.00 :   c7333:  movq   $0x0,0x58(%rsp)
    0.00 :   c733c:  mov    %rax,0x60(%rsp)
    0.00 :   c7341:  lea    0x90(%rsp),%rdi
    0.00 :   c7349:  lea    0x50(%rsp),%rsi
    0.00 :   c734e:  lea    0x120(%rsp),%rdx
    0.00 :   c7356:  call   f0010 <alloc::collections::btree::remove::<impl alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut,K,V,alloc::collections::btree::node::marker::Leaf>,alloc::collections::btree::node::marker::KV>>::remove_leaf_kv>
    0.00 :   c735b:  mov    0xa8(%rsp),%rax
    0.00 :   c7363:  mov    0xb8(%rsp),%rcx
    0.00 :   c736b:  movzwl 0x112(%rax),%edx
    0.00 :   c7372:  cmp    %rdx,%rcx
    0.00 :   c7375:  jb     c7397 <std::sys::backtrace::__rust_begin_short_backtrace+0xd17>
    0.00 :   c7377:  nopw   0x0(%rax,%rax,1)
    0.00 :   c7380:  movzwl 0x110(%rax),%ecx
    0.00 :   c7387:  mov    0xb0(%rax),%rax
    0.00 :   c738e:  cmp    0x112(%rax),%cx
    0.00 :   c7395:  jae    c7380 <std::sys::backtrace::__rust_begin_short_backtrace+0xd00>
    0.00 :   c7397:  mov    0x90(%rsp),%rdx
    0.00 :   c739f:  movdqu 0x98(%rsp),%xmm0
    0.00 :   c73a8:  mov    %rdx,0xb8(%rax,%rcx,8)
    0.00 :   c73b0:  shl    $0x4,%rcx
    0.00 :   c73b4:  mov    (%rax,%rcx,1),%r12
    0.00 :   c73b8:  mov    0x8(%rax,%rcx,1),%r15
    0.00 :   c73bd:  movdqu %xmm0,(%rax,%rcx,1)
    0.00 :   c73c2:  jmp    c7401 <std::sys::backtrace::__rust_begin_short_backtrace+0xd81>
    0.00 :   c73c4:  mov    %rdi,0x50(%rsp)
    0.00 :   c73c9:  movq   $0x0,0x58(%rsp)
    0.00 :   c73d2:  mov    %r8,0x60(%rsp)
    0.00 :   c73d7:  lea    0x90(%rsp),%rdi
    0.00 :   c73df:  lea    0x50(%rsp),%rsi
    0.00 :   c73e4:  lea    0x120(%rsp),%rdx
    0.00 :   c73ec:  call   f0010 <alloc::collections::btree::remove::<impl alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut,K,V,alloc::collections::btree::node::marker::Leaf>,alloc::collections::btree::node::marker::KV>>::remove_leaf_kv>
    0.00 :   c73f1:  mov    0x98(%rsp),%r12
    0.00 :   c73f9:  mov    0xa0(%rsp),%r15
    0.00 :   c7401:  decq   0x110(%rsp)
    0.00 :   c7409:  cmpb   $0x1,0x120(%rsp)
    0.00 :   c7411:  jne    c744a <std::sys::backtrace::__rust_begin_short_backtrace+0xdca>
    0.00 :   c7413:  test   %rbp,%rbp
    0.00 :   c7416:  je     c9447 <std::sys::backtrace::__rust_begin_short_backtrace+0x2dc7>
    0.00 :   c741c:  mov    0x118(%r13),%rax
    0.00 :   c7423:  mov    %rax,0x100(%rsp)
    0.00 :   c742b:  dec    %rbp
    0.00 :   c742e:  mov    %rbp,0x108(%rsp)
    0.00 :   c7436:  movq   $0x0,0xb0(%rax)
    0.00 :   c7441:  mov    %r13,%rdi
    0.00 :   c7444:  call   *0xcadfe(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c744a:  mov    0x298(%rsp),%rax
    0.00 :   c7452:  mov    $0x3,%r13b
    0.00 :   c7455:  test   %rax,%rax
    0.00 :   c7458:  je     c8db5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2735>
    0.00 :   c745e:  cmp    %r12,%rax
    0.00 :   c7461:  jne    c8db5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2735>
    0.00 :   c7467:  lea    -0x1(%r15),%r13d
    0.00 :   c746b:  cmp    %r13,0x268(%rsp)
    0.00 :   c7473:  jbe    c8cea <std::sys::backtrace::__rust_begin_short_backtrace+0x266a>
    0.00 :   c7479:  mov    %r15,%r8
    0.00 :   c747c:  shr    $0x20,%r8
    0.00 :   c7480:  mov    0x260(%rsp),%rax
    0.00 :   c7488:  lea    0x0(,%r13,2),%rcx
    0.00 :   c7490:  add    %r13,%rcx
    0.00 :   c7493:  cmp    %r8d,0x10(%rax,%rcx,8)
    0.00 :   c7498:  jne    c8cea <std::sys::backtrace::__rust_begin_short_backtrace+0x266a>
    0.00 :   c749e:  lea    (%rax,%rcx,8),%rbp
    0.00 :   c74a2:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c74a6:  je     c8cea <std::sys::backtrace::__rust_begin_short_backtrace+0x266a>
    0.00 :   c74ac:  mov    0x8(%rbp),%edx
    0.00 :   c74af:  and    $0x7fffffff,%edx
    0.00 :   c74b5:  mov    0x2c8(%rsp),%edi
    0.00 :   c74bc:  mov    $0xe9,%eax
    0.00 :   c74c1:  mov    $0x2,%esi
    0.00 :   c74c6:  xor    %r10d,%r10d
    0.00 :   c74c9:  syscall
    0.00 :   c74cb:  test   %rax,%rax
    0.00 :   c74ce:  jne    c74f7 <std::sys::backtrace::__rust_begin_short_backtrace+0xe77>
    0.00 :   c74d0:  cmp    $0xffffffff,%r8d
    0.00 :   c74d4:  je     c7531 <std::sys::backtrace::__rust_begin_short_backtrace+0xeb1>
    0.00 :   c74d6:  mov    0x8(%rbp),%edi
    0.00 :   c74d9:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c74dd:  setne  %al
    0.00 :   c74e0:  test   %edi,%edi
    0.00 :   c74e2:  setns  %cl
    0.00 :   c74e5:  and    %al,%cl
    0.00 :   c74e7:  cmp    $0x1,%cl
    0.00 :   c74ea:  jne    c716f <std::sys::backtrace::__rust_begin_short_backtrace+0xaef>
    0.00 :   c74f0:  call   *%rbx
    0.00 :   c74f2:  jmp    c716f <std::sys::backtrace::__rust_begin_short_backtrace+0xaef>
    0.00 :   c74f7:  movswq %ax,%rdi
    0.00 :   c74fb:  movabs $0xffffffff00000000,%rax
    0.00 :   c7505:  imul   %rax,%rdi
    0.00 :   c7509:  or     $0x2,%rdi
    0.00 :   c750d:  call   *0xcbc9d(%rip)        # 1931b0 <_DYNAMIC+0x1198>
    0.00 :   c7513:  mov    %rax,0x38(%rsp)
    0.00 :   c7518:  mov    %edx,0x30(%rsp)
    0.00 :   c751c:  cmpb   $0x3,0x30(%rsp)
    0.00 :   c7521:  jne    c956b <std::sys::backtrace::__rust_begin_short_backtrace+0x2eeb>
    0.00 :   c7527:  mov    0x10(%rbp),%r8d
    0.00 :   c752b:  cmp    $0xffffffff,%r8d
    0.00 :   c752f:  jne    c74d6 <std::sys::backtrace::__rust_begin_short_backtrace+0xe56>
    0.00 :   c7531:  mov    0x278(%rsp),%r13
    0.00 :   c7539:  inc    %r13
    0.00 :   c753c:  je     c9465 <std::sys::backtrace::__rust_begin_short_backtrace+0x2de5>
    0.00 :   c7542:  mov    0x8(%rbp),%edi
    0.00 :   c7545:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c7549:  setne  %al
    0.00 :   c754c:  test   %edi,%edi
    0.00 :   c754e:  setns  %cl
    0.00 :   c7551:  and    %al,%cl
    0.00 :   c7553:  cmp    $0x1,%cl
    0.00 :   c7556:  jne    c755a <std::sys::backtrace::__rust_begin_short_backtrace+0xeda>
    0.00 :   c7558:  call   *%rbx
    0.00 :   c755a:  movb   $0x2,0xe(%rbp)
    0.00 :   c755e:  movl   $0xffffffff,0x14(%rbp)
    0.00 :   c7565:  mov    %r13,0x278(%rsp)
    0.00 :   c756d:  cmp    %r14,0x20(%rsp)
    0.00 :   c7572:  jne    c7190 <std::sys::backtrace::__rust_begin_short_backtrace+0xb10>
    0.00 :   c7578:  cmpq   $0x0,0x8(%rsp)
    0.00 :   c757e:  mov    0x230(%rsp),%r14
    0.00 :   c7586:  mov    0xe8(%rsp),%rbp
    0.00 :   c758e:  je     c759b <std::sys::backtrace::__rust_begin_short_backtrace+0xf1b>
    0.00 :   c7590:  mov    0x10(%rsp),%rdi
    0.00 :   c7595:  call   *0xcacad(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c759b:  mov    0x160(%rsp),%r15
    0.00 :   c75a3:  mov    0x20(%r15),%rdx
    0.00 :   c75a7:  test   %rdx,%rdx
    0.00 :   c75aa:  je     c897e <std::sys::backtrace::__rust_begin_short_backtrace+0x22fe>
    0.00 :   c75b0:  mov    0x30(%r15),%r12
    0.00 :   c75b4:  test   %r12,%r12
    0.00 :   c75b7:  je     c897e <std::sys::backtrace::__rust_begin_short_backtrace+0x22fe>
    0.00 :   c75bd:  mov    0x28(%r15),%r15
    0.00 :   c75c1:  xor    %r14d,%r14d
    0.00 :   c75c4:  jmp    c75f4 <std::sys::backtrace::__rust_begin_short_backtrace+0xf74>
    0.00 :   c75c6:  lea    0x100(%rsp),%rax
    0.00 :   c75ce:  mov    %rax,0xf8(%rsp)
    0.00 :   c75d6:  mov    %rsi,0x318(%rsp)
    0.00 :   c75de:  mov    0xe8(%rsp),%rbp
    0.00 :   c75e6:  mov    $0x0,%edx
    0.00 :   c75eb:  dec    %r12
    0.00 :   c75ee:  je     c896e <std::sys::backtrace::__rust_begin_short_backtrace+0x22ee>
    0.00 :   c75f4:  test   %r14,%r14
    0.00 :   c75f7:  jne    c7674 <std::sys::backtrace::__rust_begin_short_backtrace+0xff4>
    0.00 :   c75f9:  test   %r15,%r15
    0.00 :   c75fc:  je     c7623 <std::sys::backtrace::__rust_begin_short_backtrace+0xfa3>
    0.00 :   c75fe:  mov    %r15,%rax
    0.00 :   c7601:  mov    %rdx,%r14
    0.00 :   c7604:  and    $0x7,%rax
    0.00 :   c7608:  je     c7628 <std::sys::backtrace::__rust_begin_short_backtrace+0xfa8>
    0.00 :   c760a:  xor    %ecx,%ecx
    0.00 :   c760c:  mov    0x220(%r14),%r14
    0.00 :   c7613:  inc    %rcx
    0.00 :   c7616:  cmp    %rcx,%rax
    0.00 :   c7619:  jne    c760c <std::sys::backtrace::__rust_begin_short_backtrace+0xf8c>
    0.00 :   c761b:  mov    %r15,%rax
    0.00 :   c761e:  sub    %rcx,%rax
    0.00 :   c7621:  jmp    c762b <std::sys::backtrace::__rust_begin_short_backtrace+0xfab>
    0.00 :   c7623:  mov    %rdx,%r14
    0.00 :   c7626:  jmp    c766f <std::sys::backtrace::__rust_begin_short_backtrace+0xfef>
    0.00 :   c7628:  mov    %r15,%rax
    0.00 :   c762b:  cmp    $0x8,%r15
    0.00 :   c762f:  jb     c766f <std::sys::backtrace::__rust_begin_short_backtrace+0xfef>
    0.00 :   c7631:  mov    0x220(%r14),%rcx
    0.00 :   c7638:  mov    0x220(%rcx),%rcx
    0.00 :   c763f:  mov    0x220(%rcx),%rcx
    0.00 :   c7646:  mov    0x220(%rcx),%rcx
    0.00 :   c764d:  mov    0x220(%rcx),%rcx
    0.00 :   c7654:  mov    0x220(%rcx),%rcx
    0.00 :   c765b:  mov    0x220(%rcx),%rcx
    0.00 :   c7662:  mov    0x220(%rcx),%r14
    0.00 :   c7669:  add    $0xfffffffffffffff8,%rax
    0.00 :   c766d:  jne    c7631 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb1>
    0.00 :   c766f:  xor    %edx,%edx
    0.00 :   c7671:  xor    %r15d,%r15d
    0.00 :   c7674:  movzwl 0x21a(%r14),%eax
    0.00 :   c767c:  cmp    %rax,%r15
    0.00 :   c767f:  jae    c7690 <std::sys::backtrace::__rust_begin_short_backtrace+0x1010>
    0.00 :   c7681:  mov    %r14,%rax
    0.00 :   c7684:  mov    %r15,%rcx
    0.00 :   c7687:  jmp    c76b3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1033>
    0.00 :   c7689:  nopl   0x0(%rax)
    0.00 :   c7690:  mov    (%r14),%rax
    0.00 :   c7693:  test   %rax,%rax
    0.00 :   c7696:  je     c9559 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ed9>
    0.00 :   c769c:  inc    %rdx
    0.00 :   c769f:  movzwl 0x218(%r14),%ecx
    0.00 :   c76a7:  mov    %rax,%r14
    0.00 :   c76aa:  cmp    0x21a(%rax),%cx
    0.00 :   c76b1:  jae    c7690 <std::sys::backtrace::__rust_begin_short_backtrace+0x1010>
    0.00 :   c76b3:  test   %rdx,%rdx
    0.00 :   c76b6:  je     c76ea <std::sys::backtrace::__rust_begin_short_backtrace+0x106a>
    0.00 :   c76b8:  lea    (%rax,%rcx,8),%rsi
    0.00 :   c76bc:  add    $0x228,%rsi
    0.00 :   c76c3:  mov    %rdx,%rdi
    0.00 :   c76c6:  and    $0x7,%rdi
    0.00 :   c76ca:  je     c76f3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1073>
    0.00 :   c76cc:  xor    %r8d,%r8d
    0.00 :   c76cf:  nop
    0.00 :   c76d0:  mov    (%rsi),%r14
    0.00 :   c76d3:  lea    0x220(%r14),%rsi
    0.00 :   c76da:  inc    %r8
    0.00 :   c76dd:  cmp    %r8,%rdi
    0.00 :   c76e0:  jne    c76d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1050>
    0.00 :   c76e2:  mov    %rdx,%rdi
    0.00 :   c76e5:  sub    %r8,%rdi
    0.00 :   c76e8:  jmp    c76f6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1076>
    0.00 :   c76ea:  lea    0x1(%rcx),%r15
    0.00 :   c76ee:  mov    %rax,%r14
    0.00 :   c76f1:  jmp    c7744 <std::sys::backtrace::__rust_begin_short_backtrace+0x10c4>
    0.00 :   c76f3:  mov    %rdx,%rdi
    0.00 :   c76f6:  cmp    $0x8,%rdx
    0.00 :   c76fa:  jb     c7741 <std::sys::backtrace::__rust_begin_short_backtrace+0x10c1>
    0.00 :   c76fc:  nopl   0x0(%rax)
    0.00 :   c7700:  mov    (%rsi),%rdx
    0.00 :   c7703:  mov    0x220(%rdx),%rdx
    0.00 :   c770a:  mov    0x220(%rdx),%rdx
    0.00 :   c7711:  mov    0x220(%rdx),%rdx
    0.00 :   c7718:  mov    0x220(%rdx),%rdx
    0.00 :   c771f:  mov    0x220(%rdx),%rdx
    0.00 :   c7726:  mov    0x220(%rdx),%rdx
    0.00 :   c772d:  mov    0x220(%rdx),%r14
    0.00 :   c7734:  lea    0x220(%r14),%rsi
    0.00 :   c773b:  add    $0xfffffffffffffff8,%rdi
    0.00 :   c773f:  jne    c7700 <std::sys::backtrace::__rust_begin_short_backtrace+0x1080>
    0.00 :   c7741:  xor    %r15d,%r15d
    0.00 :   c7744:  mov    0x8(%rax,%rcx,8),%rbp
    0.00 :   c7749:  mov    0x100(%rsp),%rdx
    0.00 :   c7751:  test   %rdx,%rdx
    0.00 :   c7754:  je     c77c7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1147>
    0.00 :   c7756:  mov    %rdx,%rdi
    0.00 :   c7759:  mov    0x108(%rsp),%rdx
    0.00 :   c7761:  mov    %rdi,%r13
    0.00 :   c7764:  movzwl 0x112(%rdi),%edi
    0.00 :   c776b:  mov    %edi,%r8d
    0.00 :   c776e:  shl    $0x3,%r8d
    0.00 :   c7772:  mov    $0xffffffffffffffff,%rsi
    0.00 :   c7779:  nopl   0x0(%rax)
    0.00 :   c7780:  test   %r8,%r8
    0.00 :   c7783:  je     c77b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1130>
    0.00 :   c7785:  cmp    0xc0(%r13,%rsi,8),%rbp
    0.00 :   c778d:  seta   %r9b
    0.00 :   c7791:  sbb    $0x0,%r9b
    0.00 :   c7795:  inc    %rsi
    0.00 :   c7798:  add    $0xfffffffffffffff8,%r8
    0.00 :   c779c:  cmp    $0x1,%r9b
    0.00 :   c77a0:  je     c7780 <std::sys::backtrace::__rust_begin_short_backtrace+0x1100>
    0.00 :   c77a2:  movzbl %r9b,%edi
    0.00 :   c77a6:  test   %edi,%edi
    0.00 :   c77a8:  je     c75c6 <std::sys::backtrace::__rust_begin_short_backtrace+0xf46>
    0.00 :   c77ae:  jmp    c77b3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1133>
    0.00 :   c77b0:  mov    %rdi,%rsi
    0.00 :   c77b3:  sub    $0x1,%rdx
    0.00 :   c77b7:  jb     c79af <std::sys::backtrace::__rust_begin_short_backtrace+0x132f>
    0.00 :   c77bd:  mov    0x118(%r13,%rsi,8),%rdi
    0.00 :   c77c5:  jmp    c7761 <std::sys::backtrace::__rust_begin_short_backtrace+0x10e1>
    0.00 :   c77c7:  xor    %r13d,%r13d
    0.00 :   c77ca:  lea    (%rcx,%rcx,4),%rcx
    0.00 :   c77ce:  lea    (%rax,%rcx,8),%rax
    0.00 :   c77d2:  add    $0x60,%rax
    0.00 :   c77d6:  movzbl 0x20(%rax),%ecx
    0.00 :   c77da:  mov    %rcx,0x20(%rsp)
    0.00 :   c77df:  test   %ecx,%ecx
    0.00 :   c77e1:  je     c8fde <std::sys::backtrace::__rust_begin_short_backtrace+0x295e>
    0.00 :   c77e7:  mov    (%rax),%rax
    0.00 :   c77ea:  mov    0x10(%rax),%eax
    0.00 :   c77ed:  mov    %eax,0x90(%rsp)
    0.00 :   c77f4:  lea    0x198(%rsp),%rdi
    0.00 :   c77fc:  lea    0x90(%rsp),%rsi
    0.00 :   c7804:  call   *0xcb5fe(%rip)        # 192e08 <_DYNAMIC+0xdf0>
    0.00 :   c780a:  cmpl   $0x1,0x198(%rsp)
    0.00 :   c7812:  je     c8fee <std::sys::backtrace::__rust_begin_short_backtrace+0x296e>
    0.00 :   c7818:  mov    %r15,0x3f0(%rsp)
    0.00 :   c7820:  mov    %r12,0x148(%rsp)
    0.00 :   c7828:  mov    0x19c(%rsp),%r15d
    0.00 :   c7830:  mov    0x280(%rsp),%r12d
    0.00 :   c7838:  mov    0x2c8(%rsp),%eax
    0.00 :   c783f:  mov    %rax,0x8(%rsp)
    0.00 :   c7844:  mov    $0xffffffff,%eax
    0.00 :   c7849:  cmp    %rax,%r12
    0.00 :   c784c:  je     c7969 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e9>
    0.00 :   c7852:  cmp    %r12,0x268(%rsp)
    0.00 :   c785a:  jbe    c7945 <std::sys::backtrace::__rust_begin_short_backtrace+0x12c5>
    0.00 :   c7860:  mov    0x260(%rsp),%rax
    0.00 :   c7868:  lea    (%r12,%r12,2),%rcx
    0.00 :   c786c:  cmpb   $0x2,0xe(%rax,%rcx,8)
    0.00 :   c7871:  jne    c7945 <std::sys::backtrace::__rust_begin_short_backtrace+0x12c5>
    0.00 :   c7877:  lea    (%rax,%rcx,8),%r8
    0.00 :   c787b:  mov    0x10(%r8),%ecx
    0.00 :   c787f:  mov    $0xffffffff,%eax
    0.00 :   c7884:  cmp    %rax,%rcx
    0.00 :   c7887:  je     c7945 <std::sys::backtrace::__rust_begin_short_backtrace+0x12c5>
    0.00 :   c788d:  mov    %rcx,0x10(%rsp)
    0.00 :   c7892:  mov    0x14(%r8),%eax
    0.00 :   c7896:  mov    %eax,0x30(%rsp)
    0.00 :   c789a:  mov    0x298(%rsp),%r9
    0.00 :   c78a2:  test   %r9,%r9
    0.00 :   c78a5:  je     c869e <std::sys::backtrace::__rust_begin_short_backtrace+0x201e>
    0.00 :   c78ab:  mov    %rbp,(%r8)
    0.00 :   c78ae:  mov    %r15d,0x8(%r8)
    0.00 :   c78b2:  mov    0x20(%rsp),%rcx
    0.00 :   c78b7:  mov    %cl,0xc(%r8)
    0.00 :   c78bb:  movw   $0x0,0xd(%r8)
    0.00 :   c78c2:  mov    %r8,%rsi
    0.00 :   c78c5:  mov    0x10(%rsp),%rdx
    0.00 :   c78ca:  inc    %rdx
    0.00 :   c78cd:  mov    %rdx,%rax
    0.00 :   c78d0:  shl    $0x20,%rax
    0.00 :   c78d4:  lea    (%r12,%rax,1),%r15
    0.00 :   c78d8:  inc    %r15
    0.00 :   c78db:  mov    0x30(%rsp),%eax
    0.00 :   c78df:  mov    %eax,0x280(%rsp)
    0.00 :   c78e6:  mov    %edx,0x10(%r8)
    0.00 :   c78ea:  mov    0x8(%rsi),%edx
    0.00 :   c78ed:  and    $0x7fffffff,%edx
    0.00 :   c78f3:  mov    %ecx,%eax
    0.00 :   c78f5:  and    $0x1,%al
    0.00 :   c78f7:  movzbl %al,%eax
    0.00 :   c78fa:  and    $0x2,%ecx
    0.00 :   c78fd:  lea    (%rax,%rcx,2),%eax
    0.00 :   c7900:  add    $0x2000,%eax
    0.00 :   c7905:  mov    %eax,0x198(%rsp)
    0.00 :   c790c:  mov    %r15,0x19c(%rsp)
    0.00 :   c7914:  mov    $0xe9,%eax
    0.00 :   c7919:  mov    $0x1,%esi
    0.00 :   c791e:  mov    0x8(%rsp),%rdi
    0.00 :   c7923:  lea    0x198(%rsp),%r10
    0.00 :   c792b:  syscall
    0.00 :   c792d:  test   %rax,%rax
    0.00 :   c7930:  jne    c875e <std::sys::backtrace::__rust_begin_short_backtrace+0x20de>
    0.00 :   c7936:  mov    %r9,0x58(%rsp)
    0.00 :   c793b:  mov    %r15,0x60(%rsp)
    0.00 :   c7940:  jmp    c7b01 <std::sys::backtrace::__rust_begin_short_backtrace+0x1481>
    0.00 :   c7945:  movq   $0xb,0x90(%rsp)
    0.00 :   c7951:  lea    0x90(%rsp),%rsi
    0.00 :   c7959:  lea    0x50(%rsp),%rdi
    0.00 :   c795e:  call   *0xcb854(%rip)        # 1931b8 <_DYNAMIC+0x11a0>
    0.00 :   c7964:  jmp    c7b3b <std::sys::backtrace::__rust_begin_short_backtrace+0x14bb>
    0.00 :   c7969:  mov    0x268(%rsp),%r12
    0.00 :   c7971:  mov    0x270(%rsp),%rax
    0.00 :   c7979:  cmp    %rax,%r12
    0.00 :   c797c:  jae    c7994 <std::sys::backtrace::__rust_begin_short_backtrace+0x1314>
    0.00 :   c797e:  mov    %r12,%rax
    0.00 :   c7981:  shr    $0x20,%rax
    0.00 :   c7985:  je     c79c8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1348>
    0.00 :   c7987:  movb   $0xa,0x98(%rsp)
    0.00 :   c798f:  jmp    c7b1c <std::sys::backtrace::__rust_begin_short_backtrace+0x149c>
    0.00 :   c7994:  cmp    %rax,0x278(%rsp)
    0.00 :   c799c:  jne    c7b0c <std::sys::backtrace::__rust_begin_short_backtrace+0x148c>
    0.00 :   c79a2:  movb   $0x8,0x98(%rsp)
    0.00 :   c79aa:  jmp    c7b1c <std::sys::backtrace::__rust_begin_short_backtrace+0x149c>
    0.00 :   c79af:  movq   $0x0,0x318(%rsp)
    0.00 :   c79bb:  mov    %rsi,0xf8(%rsp)
    0.00 :   c79c3:  jmp    c77ca <std::sys::backtrace::__rust_begin_short_backtrace+0x114a>
    0.00 :   c79c8:  mov    $0xffffffff,%eax
    0.00 :   c79cd:  cmp    %rax,%r12
    0.00 :   c79d0:  je     c79a2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1322>
    0.00 :   c79d2:  mov    0x298(%rsp),%rdx
    0.00 :   c79da:  mov    %r12,0x10(%rsp)
    0.00 :   c79df:  mov    %rdx,0x30(%rsp)
    0.00 :   c79e4:  test   %rdx,%rdx
    0.00 :   c79e7:  je     c87b2 <std::sys::backtrace::__rust_begin_short_backtrace+0x2132>
    0.00 :   c79ed:  cmp    0x258(%rsp),%r12
    0.00 :   c79f5:  jne    c7a05 <std::sys::backtrace::__rust_begin_short_backtrace+0x1385>
    0.00 :   c79f7:  lea    0x258(%rsp),%rdi
    0.00 :   c79ff:  call   *0xcb74b(%rip)        # 193150 <_DYNAMIC+0x1138>
    0.00 :   c7a05:  mov    0x260(%rsp),%rax
    0.00 :   c7a0d:  lea    (%r12,%r12,2),%rcx
    0.00 :   c7a11:  movb   $0x2,0xe(%rax,%rcx,8)
    0.00 :   c7a16:  movabs $0xffffffff00000001,%rdx
    0.00 :   c7a20:  mov    %rdx,0x10(%rax,%rcx,8)
    0.00 :   c7a25:  inc    %r12
    0.00 :   c7a28:  mov    %r12,0x268(%rsp)
    0.00 :   c7a30:  mov    0x10(%rsp),%rax
    0.00 :   c7a35:  cmp    %r12,%rax
    0.00 :   c7a38:  jae    c8540 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ec0>
    0.00 :   c7a3e:  mov    0x260(%rsp),%r12
    0.00 :   c7a46:  lea    (%rax,%rax,2),%rdx
    0.00 :   c7a4a:  mov    0x8(%r12,%rdx,8),%edi
    0.00 :   c7a4f:  cmpb   $0x2,0xe(%r12,%rdx,8)
    0.00 :   c7a55:  setne  %al
    0.00 :   c7a58:  test   %edi,%edi
    0.00 :   c7a5a:  setns  %cl
    0.00 :   c7a5d:  and    %al,%cl
    0.00 :   c7a5f:  cmp    $0x1,%cl
    0.00 :   c7a62:  jne    c7a70 <std::sys::backtrace::__rust_begin_short_backtrace+0x13f0>
    0.00 :   c7a64:  mov    %rdx,0x38(%rsp)
    0.00 :   c7a69:  call   *%rbx
    0.00 :   c7a6b:  mov    0x38(%rsp),%rdx
    0.00 :   c7a70:  mov    0x10(%rsp),%rax
    0.00 :   c7a75:  lea    0x1(%rax),%r8
    0.00 :   c7a79:  movabs $0x100000000,%rax
    0.00 :   c7a83:  or     %rax,%r8
    0.00 :   c7a86:  lea    (%r12,%rdx,8),%r12
    0.00 :   c7a8a:  mov    %rbp,(%r12)
    0.00 :   c7a8e:  mov    %r15d,0x8(%r12)
    0.00 :   c7a93:  mov    0x20(%rsp),%rcx
    0.00 :   c7a98:  mov    %cl,0xc(%r12)
    0.00 :   c7a9d:  movw   $0x0,0xd(%r12)
    0.00 :   c7aa5:  and    $0x7fffffff,%r15d
    0.00 :   c7aac:  mov    %ecx,%eax
    0.00 :   c7aae:  and    $0x1,%al
    0.00 :   c7ab0:  movzbl %al,%eax
    0.00 :   c7ab3:  and    $0x2,%ecx
    0.00 :   c7ab6:  lea    (%rax,%rcx,2),%eax
    0.00 :   c7ab9:  add    $0x2000,%eax
    0.00 :   c7abe:  mov    %eax,0x198(%rsp)
    0.00 :   c7ac5:  mov    %r8,0x19c(%rsp)
    0.00 :   c7acd:  mov    $0xe9,%eax
    0.00 :   c7ad2:  mov    $0x1,%esi
    0.00 :   c7ad7:  mov    0x8(%rsp),%rdi
    0.00 :   c7adc:  mov    %r15,%rdx
    0.00 :   c7adf:  lea    0x198(%rsp),%r10
    0.00 :   c7ae7:  syscall
    0.00 :   c7ae9:  test   %rax,%rax
    0.00 :   c7aec:  jne    c88b5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2235>
    0.00 :   c7af2:  mov    0x30(%rsp),%rax
    0.00 :   c7af7:  mov    %rax,0x58(%rsp)
    0.00 :   c7afc:  mov    %r8,0x60(%rsp)
    0.00 :   c7b01:  movq   $0x2,0x50(%rsp)
    0.00 :   c7b0a:  jmp    c7b45 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c7b0c:  movb   $0x7,0x98(%rsp)
    0.00 :   c7b14:  mov    %rax,0xa0(%rsp)
    0.00 :   c7b1c:  movq   $0x0,0x90(%rsp)
    0.00 :   c7b28:  lea    0x50(%rsp),%rdi
    0.00 :   c7b2d:  lea    0x98(%rsp),%rsi
    0.00 :   c7b35:  call   *0xcb67d(%rip)        # 1931b8 <_DYNAMIC+0x11a0>
    0.00 :   c7b3b:  test   %r15d,%r15d
    0.00 :   c7b3e:  js     c7b45 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c7b40:  mov    %r15d,%edi
    0.00 :   c7b43:  call   *%rbx
    0.00 :   c7b45:  cmpq   $0x2,0x50(%rsp)
    0.00 :   c7b4b:  jne    c900b <std::sys::backtrace::__rust_begin_short_backtrace+0x298b>
    0.00 :   c7b51:  mov    0x58(%rsp),%rdx
    0.00 :   c7b56:  mov    0x60(%rsp),%rcx
    0.00 :   c7b5b:  test   %r13,%r13
    0.00 :   c7b5e:  je     c7ba0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1520>
    0.00 :   c7b60:  mov    %r13,%r15
    0.00 :   c7b63:  movzwl 0x112(%r13),%r12d
    0.00 :   c7b6b:  cmp    $0xb,%r12
    0.00 :   c7b6f:  jae    c7bfb <std::sys::backtrace::__rust_begin_short_backtrace+0x157b>
    0.00 :   c7b75:  mov    0xf8(%rsp),%r8
    0.00 :   c7b7d:  lea    0x1(%r8),%r13
    0.00 :   c7b81:  lea    (%r15,%r8,8),%rsi
    0.00 :   c7b85:  add    $0xb8,%rsi
    0.00 :   c7b8c:  cmp    %r12,%r13
    0.00 :   c7b8f:  jbe    c7c36 <std::sys::backtrace::__rust_begin_short_backtrace+0x15b6>
    0.00 :   c7b95:  mov    %rbp,(%rsi)
    0.00 :   c7b98:  mov    %r8,%rax
    0.00 :   c7b9b:  jmp    c7cb5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1635>
    0.00 :   c7ba0:  mov    %rdx,%r13
    0.00 :   c7ba3:  mov    %rcx,%r12
    0.00 :   c7ba6:  mov    $0x118,%r15d
    0.00 :   c7bac:  mov    $0x118,%edi
    0.00 :   c7bb1:  call   *0xca6a9(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   c7bb7:  test   %rax,%rax
    0.00 :   c7bba:  je     c93bb <std::sys::backtrace::__rust_begin_short_backtrace+0x2d3b>
    0.00 :   c7bc0:  movq   $0x0,0xb0(%rax)
    0.00 :   c7bcb:  mov    %rax,0x100(%rsp)
    0.00 :   c7bd3:  movq   $0x0,0x108(%rsp)
    0.00 :   c7bdf:  movw   $0x1,0x112(%rax)
    0.00 :   c7be8:  mov    %rbp,0xb8(%rax)
    0.00 :   c7bef:  mov    %r13,(%rax)
    0.00 :   c7bf2:  mov    %r12,0x8(%rax)
    0.00 :   c7bf6:  jmp    c8429 <std::sys::backtrace::__rust_begin_short_backtrace+0x1da9>
    0.00 :   c7bfb:  mov    0xf8(%rsp),%rax
    0.00 :   c7c03:  cmp    $0x5,%rax
    0.00 :   c7c07:  mov    %rcx,0x48(%rsp)
    0.00 :   c7c0c:  mov    %rdx,0x88(%rsp)
    0.00 :   c7c14:  jae    c7cd2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1652>
    0.00 :   c7c1a:  mov    $0x4,%ecx
    0.00 :   c7c1f:  mov    %rcx,0x8(%rsp)
    0.00 :   c7c24:  movl   $0x0,0x40(%rsp)
    0.00 :   c7c2c:  mov    %rax,0x10(%rsp)
    0.00 :   c7c31:  jmp    c7d32 <std::sys::backtrace::__rust_begin_short_backtrace+0x16b2>
    0.00 :   c7c36:  lea    0xb8(%r15),%rax
    0.00 :   c7c3d:  lea    (%rax,%r13,8),%rdi
    0.00 :   c7c41:  mov    %r12,%rax
    0.00 :   c7c44:  sub    %r8,%rax
    0.00 :   c7c47:  mov    %rax,0x20(%rsp)
    0.00 :   c7c4c:  mov    %rdx,0x88(%rsp)
    0.00 :   c7c54:  lea    0x0(,%rax,8),%rdx
    0.00 :   c7c5c:  mov    %rcx,0x48(%rsp)
    0.00 :   c7c61:  mov    %r8,0xf8(%rsp)
    0.00 :   c7c69:  call   *0xcaae9(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c7c6f:  mov    0xf8(%rsp),%rax
    0.00 :   c7c77:  mov    %rbp,0xb8(%r15,%rax,8)
    0.00 :   c7c7f:  mov    %rax,%rsi
    0.00 :   c7c82:  mov    %rax,%rbp
    0.00 :   c7c85:  shl    $0x4,%rsi
    0.00 :   c7c89:  add    %r15,%rsi
    0.00 :   c7c8c:  shl    $0x4,%r13
    0.00 :   c7c90:  add    %r15,%r13
    0.00 :   c7c93:  mov    0x20(%rsp),%rdx
    0.00 :   c7c98:  shl    $0x4,%rdx
    0.00 :   c7c9c:  mov    %r13,%rdi
    0.00 :   c7c9f:  call   *0xcaab3(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c7ca5:  mov    0x88(%rsp),%rdx
    0.00 :   c7cad:  mov    0x48(%rsp),%rcx
    0.00 :   c7cb2:  mov    %rbp,%rax
    0.00 :   c7cb5:  inc    %r12d
    0.00 :   c7cb8:  shl    $0x4,%rax
    0.00 :   c7cbc:  mov    %rdx,(%r15,%rax,1)
    0.00 :   c7cc0:  mov    %rcx,0x8(%r15,%rax,1)
    0.00 :   c7cc5:  mov    %r12w,0x112(%r15)
    0.00 :   c7ccd:  jmp    c8429 <std::sys::backtrace::__rust_begin_short_backtrace+0x1da9>
    0.00 :   c7cd2:  je     c7cfd <std::sys::backtrace::__rust_begin_short_backtrace+0x167d>
    0.00 :   c7cd4:  mov    0xf8(%rsp),%rax
    0.00 :   c7cdc:  cmp    $0x6,%rax
    0.00 :   c7ce0:  jne    c7d19 <std::sys::backtrace::__rust_begin_short_backtrace+0x1699>
    0.00 :   c7ce2:  mov    $0x5,%eax
    0.00 :   c7ce7:  mov    %rax,0x8(%rsp)
    0.00 :   c7cec:  mov    $0x1,%al
    0.00 :   c7cee:  mov    %eax,0x40(%rsp)
    0.00 :   c7cf2:  movq   $0x0,0x10(%rsp)
    0.00 :   c7cfb:  jmp    c7d32 <std::sys::backtrace::__rust_begin_short_backtrace+0x16b2>
    0.00 :   c7cfd:  movl   $0x0,0x40(%rsp)
    0.00 :   c7d05:  mov    0xf8(%rsp),%rax
    0.00 :   c7d0d:  mov    %rax,0x10(%rsp)
    0.00 :   c7d12:  mov    %rax,0x8(%rsp)
    0.00 :   c7d17:  jmp    c7d32 <std::sys::backtrace::__rust_begin_short_backtrace+0x16b2>
    0.00 :   c7d19:  add    $0xfffffffffffffff9,%rax
    0.00 :   c7d1d:  mov    %rax,0x10(%rsp)
    0.00 :   c7d22:  mov    $0x6,%eax
    0.00 :   c7d27:  mov    %rax,0x8(%rsp)
    0.00 :   c7d2c:  mov    $0x1,%al
    0.00 :   c7d2e:  mov    %eax,0x40(%rsp)
    0.00 :   c7d32:  mov    $0x118,%r15d
    0.00 :   c7d38:  mov    $0x118,%edi
    0.00 :   c7d3d:  call   *0xca51d(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   c7d43:  test   %rax,%rax
    0.00 :   c7d46:  je     c93bb <std::sys::backtrace::__rust_begin_short_backtrace+0x2d3b>
    0.00 :   c7d4c:  mov    %rax,%r12
    0.00 :   c7d4f:  movq   $0x0,0xb0(%rax)
    0.00 :   c7d5a:  movzwl 0x112(%r13),%eax
    0.00 :   c7d62:  mov    0x8(%rsp),%rcx
    0.00 :   c7d67:  mov    %rcx,%r15
    0.00 :   c7d6a:  not    %r15
    0.00 :   c7d6d:  add    %rax,%r15
    0.00 :   c7d70:  mov    %r15w,0x112(%r12)
    0.00 :   c7d79:  cmp    $0xc,%r15
    0.00 :   c7d7d:  jae    c946f <std::sys::backtrace::__rust_begin_short_backtrace+0x2def>
    0.00 :   c7d83:  mov    %rcx,%rax
    0.00 :   c7d86:  shl    $0x4,%rax
    0.00 :   c7d8a:  mov    %rcx,%rsi
    0.00 :   c7d8d:  mov    0x0(%r13,%rax,1),%rcx
    0.00 :   c7d92:  mov    %rcx,0x30(%rsp)
    0.00 :   c7d97:  mov    0x8(%r13,%rax,1),%rax
    0.00 :   c7d9c:  mov    %rax,0x38(%rsp)
    0.00 :   c7da1:  mov    %rsi,0x8(%rsp)
    0.00 :   c7da6:  mov    0xb8(%r13,%rsi,8),%rax
    0.00 :   c7dae:  mov    %rax,0xf0(%rsp)
    0.00 :   c7db6:  lea    0x1(%rsi),%rax
    0.00 :   c7dba:  mov    %rax,0x158(%rsp)
    0.00 :   c7dc2:  lea    0xc0(%r13,%rsi,8),%rsi
    0.00 :   c7dca:  lea    0xb8(%r12),%rdi
    0.00 :   c7dd2:  mov    %r13,0x20(%rsp)
    0.00 :   c7dd7:  lea    0x0(,%r15,8),%rdx
    0.00 :   c7ddf:  call   *0xca44b(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   c7de5:  mov    0x158(%rsp),%rsi
    0.00 :   c7ded:  shl    $0x4,%rsi
    0.00 :   c7df1:  add    0x20(%rsp),%rsi
    0.00 :   c7df6:  shl    $0x4,%r15
    0.00 :   c7dfa:  mov    %r12,%rdi
    0.00 :   c7dfd:  mov    %r15,%rdx
    0.00 :   c7e00:  call   *0xca42a(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   c7e06:  cmpb   $0x0,0x40(%rsp)
    0.00 :   c7e0b:  mov    %r12,%r15
    0.00 :   c7e0e:  mov    0x20(%rsp),%rcx
    0.00 :   c7e13:  cmove  %rcx,%r15
    0.00 :   c7e17:  mov    0x8(%rsp),%rax
    0.00 :   c7e1c:  mov    %ax,0x112(%rcx)
    0.00 :   c7e23:  movzwl 0x112(%r15),%r8d
    0.00 :   c7e2b:  mov    0x10(%rsp),%rdx
    0.00 :   c7e30:  lea    (%r15,%rdx,8),%rsi
    0.00 :   c7e34:  add    $0xb8,%rsi
    0.00 :   c7e3b:  cmp    %rdx,%r8
    0.00 :   c7e3e:  jbe    c7eb3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1833>
    0.00 :   c7e40:  lea    0xb8(%r15),%rax
    0.00 :   c7e47:  lea    0x1(%rdx),%rcx
    0.00 :   c7e4b:  mov    %rcx,0x8(%rsp)
    0.00 :   c7e50:  lea    (%rax,%rdx,8),%rdi
    0.00 :   c7e54:  add    $0x8,%rdi
    0.00 :   c7e58:  mov    %r8d,%eax
    0.00 :   c7e5b:  sub    %edx,%eax
    0.00 :   c7e5d:  mov    %rax,0x40(%rsp)
    0.00 :   c7e62:  lea    0x0(,%rax,8),%edx
    0.00 :   c7e69:  mov    %r8,0x20(%rsp)
    0.00 :   c7e6e:  call   *0xca8e4(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c7e74:  mov    0x10(%rsp),%rax
    0.00 :   c7e79:  mov    %rbp,0xb8(%r15,%rax,8)
    0.00 :   c7e81:  mov    0x10(%rsp),%rsi
    0.00 :   c7e86:  shl    $0x4,%rsi
    0.00 :   c7e8a:  add    %r15,%rsi
    0.00 :   c7e8d:  mov    0x8(%rsp),%rdi
    0.00 :   c7e92:  shl    $0x4,%rdi
    0.00 :   c7e96:  add    %r15,%rdi
    0.00 :   c7e99:  mov    0x40(%rsp),%rdx
    0.00 :   c7e9e:  shl    $0x4,%edx
    0.00 :   c7ea1:  call   *0xca8b1(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c7ea7:  mov    0x20(%rsp),%r8
    0.00 :   c7eac:  mov    0x10(%rsp),%rdx
    0.00 :   c7eb1:  jmp    c7eb6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1836>
    0.00 :   c7eb3:  mov    %rbp,(%rsi)
    0.00 :   c7eb6:  mov    0x48(%rsp),%rax
    0.00 :   c7ebb:  mov    0x88(%rsp),%rcx
    0.00 :   c7ec3:  inc    %r8d
    0.00 :   c7ec6:  shl    $0x4,%rdx
    0.00 :   c7eca:  mov    %rcx,(%r15,%rdx,1)
    0.00 :   c7ece:  mov    %rax,0x8(%r15,%rdx,1)
    0.00 :   c7ed3:  mov    %r8w,0x112(%r15)
    0.00 :   c7edb:  mov    0xb0(%r13),%r15
    0.00 :   c7ee2:  test   %r15,%r15
    0.00 :   c7ee5:  je     c8353 <std::sys::backtrace::__rust_begin_short_backtrace+0x1cd3>
    0.00 :   c7eeb:  mov    0x318(%rsp),%rdx
    0.00 :   c7ef3:  test   %rdx,%rdx
    0.00 :   c7ef6:  sete   %cl
    0.00 :   c7ef9:  mov    %rdx,0x2e8(%rsp)
    0.00 :   c7f01:  jmp    c7f1a <std::sys::backtrace::__rust_begin_short_backtrace+0x189a>
    0.00 :   c7f03:  mov    0x20(%rsp),%r13
    0.00 :   c7f08:  mov    0xb0(%r13),%r15
    0.00 :   c7f0f:  mov    $0x1,%cl
    0.00 :   c7f11:  test   %r15,%r15
    0.00 :   c7f14:  je     c835f <std::sys::backtrace::__rust_begin_short_backtrace+0x1cdf>
    0.00 :   c7f1a:  mov    0x38(%rsp),%rbp
    0.00 :   c7f1f:  mov    0x30(%rsp),%rdi
    0.00 :   c7f24:  mov    0xf0(%rsp),%r8
    0.00 :   c7f2c:  test   $0x1,%cl
    0.00 :   c7f2f:  je     c93ce <std::sys::backtrace::__rust_begin_short_backtrace+0x2d4e>
    0.00 :   c7f35:  mov    %r12,%rsi
    0.00 :   c7f38:  movzwl 0x110(%r13),%r10d
    0.00 :   c7f40:  movzwl 0x112(%r15),%r11d
    0.00 :   c7f48:  cmp    $0xb,%r11
    0.00 :   c7f4c:  mov    %r15,0x20(%rsp)
    0.00 :   c7f51:  mov    %r12,0x88(%rsp)
    0.00 :   c7f59:  mov    %rbp,0x40(%rsp)
    0.00 :   c7f5e:  mov    %rdi,0x158(%rsp)
    0.00 :   c7f66:  mov    %r11,0x48(%rsp)
    0.00 :   c7f6b:  mov    %r8,0x150(%rsp)
    0.00 :   c7f73:  jb     c845c <std::sys::backtrace::__rust_begin_short_backtrace+0x1ddc>
    0.00 :   c7f79:  cmp    $0x5,%r10w
    0.00 :   c7f7e:  jae    c7f9c <std::sys::backtrace::__rust_begin_short_backtrace+0x191c>
    0.00 :   c7f80:  mov    %r10,0x8(%rsp)
    0.00 :   c7f85:  mov    $0x4,%eax
    0.00 :   c7f8a:  mov    %rax,0x10(%rsp)
    0.00 :   c7f8f:  movl   $0x0,0x118(%rsp)
    0.00 :   c7f9a:  jmp    c7ff9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1979>
    0.00 :   c7f9c:  cmp    $0x5,%r10
    0.00 :   c7fa0:  je     c7fc6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1946>
    0.00 :   c7fa2:  cmp    $0x6,%r10d
    0.00 :   c7fa6:  jne    c7fdd <std::sys::backtrace::__rust_begin_short_backtrace+0x195d>
    0.00 :   c7fa8:  mov    $0x1,%al
    0.00 :   c7faa:  mov    %eax,0x118(%rsp)
    0.00 :   c7fb1:  mov    $0x5,%eax
    0.00 :   c7fb6:  mov    %rax,0x10(%rsp)
    0.00 :   c7fbb:  movq   $0x0,0x8(%rsp)
    0.00 :   c7fc4:  jmp    c7ff9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1979>
    0.00 :   c7fc6:  movl   $0x0,0x118(%rsp)
    0.00 :   c7fd1:  mov    %r10,0x8(%rsp)
    0.00 :   c7fd6:  mov    %r10,0x10(%rsp)
    0.00 :   c7fdb:  jmp    c7ff9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1979>
    0.00 :   c7fdd:  add    $0xfffffffffffffff9,%r10
    0.00 :   c7fe1:  mov    %r10,0x8(%rsp)
    0.00 :   c7fe6:  mov    $0x1,%al
    0.00 :   c7fe8:  mov    %eax,0x118(%rsp)
    0.00 :   c7fef:  mov    $0x6,%eax
    0.00 :   c7ff4:  mov    %rax,0x10(%rsp)
    0.00 :   c7ff9:  mov    $0x178,%r15d
    0.00 :   c7fff:  mov    $0x178,%edi
    0.00 :   c8004:  call   *0xca256(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   c800a:  test   %rax,%rax
    0.00 :   c800d:  je     c93bb <std::sys::backtrace::__rust_begin_short_backtrace+0x2d3b>
    0.00 :   c8013:  mov    %rax,%r13
    0.00 :   c8016:  mov    %rax,%r12
    0.00 :   c8019:  movq   $0x0,0xb0(%r13)
    0.00 :   c8024:  mov    0x20(%rsp),%rcx
    0.00 :   c8029:  movzwl 0x112(%rcx),%eax
    0.00 :   c8030:  mov    0x10(%rsp),%rsi
    0.00 :   c8035:  mov    %rsi,%r15
    0.00 :   c8038:  not    %r15
    0.00 :   c803b:  add    %rax,%r15
    0.00 :   c803e:  mov    %r15w,0x112(%r13)
    0.00 :   c8046:  cmp    $0xc,%r15
    0.00 :   c804a:  jae    c9383 <std::sys::backtrace::__rust_begin_short_backtrace+0x2d03>
    0.00 :   c8050:  mov    %esi,%eax
    0.00 :   c8052:  shl    $0x4,%eax
    0.00 :   c8055:  mov    (%rcx,%rax,1),%rdx
    0.00 :   c8059:  mov    %rdx,0x30(%rsp)
    0.00 :   c805e:  mov    0x8(%rcx,%rax,1),%rax
    0.00 :   c8063:  mov    %rax,0x38(%rsp)
    0.00 :   c8068:  mov    0xb8(%rcx,%rsi,8),%rax
    0.00 :   c8070:  mov    %rax,0xf0(%rsp)
    0.00 :   c8078:  lea    0x1(%rsi),%ebp
    0.00 :   c807b:  mov    0x20(%rsp),%rax
    0.00 :   c8080:  lea    (%rax,%rbp,8),%rsi
    0.00 :   c8084:  add    $0xb8,%rsi
    0.00 :   c808b:  lea    0xb8(%r13),%rdi
    0.00 :   c8092:  lea    0x0(,%r15,8),%rdx
    0.00 :   c809a:  call   *0xca190(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   c80a0:  shl    $0x4,%ebp
    0.00 :   c80a3:  add    0x20(%rsp),%rbp
    0.00 :   c80a8:  shl    $0x4,%r15
    0.00 :   c80ac:  mov    %r12,%rdi
    0.00 :   c80af:  mov    %rbp,%rsi
    0.00 :   c80b2:  mov    0x20(%rsp),%rbp
    0.00 :   c80b7:  mov    %r15,%rdx
    0.00 :   c80ba:  call   *0xca170(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   c80c0:  mov    0x10(%rsp),%rcx
    0.00 :   c80c5:  mov    %cx,0x112(%rbp)
    0.00 :   c80cc:  movzwl 0x112(%r12),%r15d
    0.00 :   c80d5:  lea    0x1(%r15),%rdx
    0.00 :   c80d9:  cmp    $0xc,%r15
    0.00 :   c80dd:  jae    c939f <std::sys::backtrace::__rust_begin_short_backtrace+0x2d1f>
    0.00 :   c80e3:  mov    0x48(%rsp),%rax
    0.00 :   c80e8:  sub    %ecx,%eax
    0.00 :   c80ea:  cmp    %edx,%eax
    0.00 :   c80ec:  jne    c940c <std::sys::backtrace::__rust_begin_short_backtrace+0x2d8c>
    0.00 :   c80f2:  incq   0x2e8(%rsp)
    0.00 :   c80fa:  lea    0x118(%r13),%rdi
    0.00 :   c8101:  lea    0x120(,%rcx,8),%rsi
    0.00 :   c8109:  add    %rbp,%rsi
    0.00 :   c810c:  shl    $0x3,%edx
    0.00 :   c810f:  call   *0xca11b(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   c8115:  xor    %eax,%eax
    0.00 :   c8117:  nopw   0x0(%rax,%rax,1)
    0.00 :   c8120:  mov    %rax,%rcx
    0.00 :   c8123:  cmp    %r15,%rax
    0.00 :   c8126:  adc    $0x0,%rax
    0.00 :   c812a:  mov    0x118(%r12,%rcx,8),%rdx
    0.00 :   c8132:  mov    %r12,0xb0(%rdx)
    0.00 :   c8139:  mov    %cx,0x110(%rdx)
    0.00 :   c8140:  cmp    %r15,%rcx
    0.00 :   c8143:  jae    c814a <std::sys::backtrace::__rust_begin_short_backtrace+0x1aca>
    0.00 :   c8145:  cmp    %r15,%rax
    0.00 :   c8148:  jbe    c8120 <std::sys::backtrace::__rust_begin_short_backtrace+0x1aa0>
    0.00 :   c814a:  cmpb   $0x0,0x118(%rsp)
    0.00 :   c8152:  cmove  %rbp,%r13
    0.00 :   c8156:  movzwl 0x112(%r13),%ebp
    0.00 :   c815e:  mov    0x8(%rsp),%rdx
    0.00 :   c8163:  lea    0x1(%rdx),%r15
    0.00 :   c8167:  mov    %rbp,%r8
    0.00 :   c816a:  sub    %rdx,%r8
    0.00 :   c816d:  jbe    c823f <std::sys::backtrace::__rust_begin_short_backtrace+0x1bbf>
    0.00 :   c8173:  lea    0xb8(%r13),%rax
    0.00 :   c817a:  lea    0xb8(,%rdx,8),%rsi
    0.00 :   c8182:  add    %r13,%rsi
    0.00 :   c8185:  lea    (%rax,%r15,8),%rdi
    0.00 :   c8189:  mov    %ebp,%eax
    0.00 :   c818b:  sub    %edx,%eax
    0.00 :   c818d:  mov    %rax,0x118(%rsp)
    0.00 :   c8195:  lea    0x0(,%rax,8),%edx
    0.00 :   c819c:  mov    %rdx,0x48(%rsp)
    0.00 :   c81a1:  mov    %r8,0x10(%rsp)
    0.00 :   c81a6:  call   *0xca5ac(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c81ac:  mov    0x8(%rsp),%rax
    0.00 :   c81b1:  mov    0x150(%rsp),%rcx
    0.00 :   c81b9:  mov    %rcx,0xb8(%r13,%rax,8)
    0.00 :   c81c1:  mov    0x8(%rsp),%rax
    0.00 :   c81c6:  shl    $0x4,%rax
    0.00 :   c81ca:  mov    %rax,0x150(%rsp)
    0.00 :   c81d2:  lea    (%rax,%r13,1),%rsi
    0.00 :   c81d6:  mov    %r15,%rdi
    0.00 :   c81d9:  shl    $0x4,%rdi
    0.00 :   c81dd:  add    %r13,%rdi
    0.00 :   c81e0:  mov    0x118(%rsp),%rdx
    0.00 :   c81e8:  shl    $0x4,%edx
    0.00 :   c81eb:  call   *0xca567(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c81f1:  mov    0x158(%rsp),%rax
    0.00 :   c81f9:  mov    0x150(%rsp),%rcx
    0.00 :   c8201:  mov    %rax,0x0(%r13,%rcx,1)
    0.00 :   c8206:  mov    0x40(%rsp),%rax
    0.00 :   c820b:  mov    %rax,0x8(%r13,%rcx,1)
    0.00 :   c8210:  lea    0x118(%r13,%r15,8),%rsi
    0.00 :   c8218:  mov    0x8(%rsp),%rax
    0.00 :   c821d:  lea    0x128(,%rax,8),%rdi
    0.00 :   c8225:  add    %r13,%rdi
    0.00 :   c8228:  mov    0x48(%rsp),%rdx
    0.00 :   c822d:  call   *0xca525(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c8233:  mov    0x10(%rsp),%r8
    0.00 :   c8238:  mov    0x8(%rsp),%rdx
    0.00 :   c823d:  jmp    c826d <std::sys::backtrace::__rust_begin_short_backtrace+0x1bed>
    0.00 :   c823f:  mov    0x150(%rsp),%rax
    0.00 :   c8247:  mov    %rax,0xb8(%r13,%rdx,8)
    0.00 :   c824f:  mov    %rdx,%rax
    0.00 :   c8252:  shl    $0x4,%rax
    0.00 :   c8256:  mov    0x158(%rsp),%rcx
    0.00 :   c825e:  mov    %rcx,0x0(%r13,%rax,1)
    0.00 :   c8263:  mov    0x40(%rsp),%rcx
    0.00 :   c8268:  mov    %rcx,0x8(%r13,%rax,1)
    0.00 :   c826d:  mov    0x88(%rsp),%rsi
    0.00 :   c8275:  lea    0x1(%rbp),%ecx
    0.00 :   c8278:  lea    0x2(%rbp),%rax
    0.00 :   c827c:  mov    %rsi,0x120(%r13,%rdx,8)
    0.00 :   c8284:  mov    %cx,0x112(%r13)
    0.00 :   c828c:  cmp    %eax,%r15d
    0.00 :   c828f:  jae    c7f03 <std::sys::backtrace::__rust_begin_short_backtrace+0x1883>
    0.00 :   c8295:  sub    %edx,%ebp
    0.00 :   c8297:  inc    %ebp
    0.00 :   c8299:  and    $0x3,%ebp
    0.00 :   c829c:  je     c82d1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c51>
    0.00 :   c829e:  lea    0x120(,%rdx,8),%rdx
    0.00 :   c82a6:  add    %r13,%rdx
    0.00 :   c82a9:  xor    %ecx,%ecx
    0.00 :   c82ab:  nopl   0x0(%rax,%rax,1)
    0.00 :   c82b0:  mov    (%rdx,%rcx,8),%rsi
    0.00 :   c82b4:  mov    %r13,0xb0(%rsi)
    0.00 :   c82bb:  lea    (%r15,%rcx,1),%edi
    0.00 :   c82bf:  mov    %di,0x110(%rsi)
    0.00 :   c82c6:  inc    %rcx
    0.00 :   c82c9:  cmp    %rcx,%rbp
    0.00 :   c82cc:  jne    c82b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c30>
    0.00 :   c82ce:  add    %rcx,%r15
    0.00 :   c82d1:  cmp    $0x3,%r8d
    0.00 :   c82d5:  jb     c7f03 <std::sys::backtrace::__rust_begin_short_backtrace+0x1883>
    0.00 :   c82db:  nopl   0x0(%rax,%rax,1)
    0.00 :   c82e0:  mov    0x118(%r13,%r15,8),%rcx
    0.00 :   c82e8:  mov    %r13,0xb0(%rcx)
    0.00 :   c82ef:  mov    %r15w,0x110(%rcx)
    0.00 :   c82f7:  mov    0x120(%r13,%r15,8),%rcx
    0.00 :   c82ff:  mov    %r13,0xb0(%rcx)
    0.00 :   c8306:  lea    0x1(%r15),%edx
    0.00 :   c830a:  mov    %dx,0x110(%rcx)
    0.00 :   c8311:  mov    0x128(%r13,%r15,8),%rcx
    0.00 :   c8319:  mov    %r13,0xb0(%rcx)
    0.00 :   c8320:  lea    0x2(%r15),%edx
    0.00 :   c8324:  mov    %dx,0x110(%rcx)
    0.00 :   c832b:  mov    0x130(%r13,%r15,8),%rcx
    0.00 :   c8333:  mov    %r13,0xb0(%rcx)
    0.00 :   c833a:  lea    0x3(%r15),%edx
    0.00 :   c833e:  mov    %dx,0x110(%rcx)
    0.00 :   c8345:  add    $0x4,%r15
    0.00 :   c8349:  cmp    %rax,%r15
    0.00 :   c834c:  jne    c82e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c60>
    0.00 :   c834e:  jmp    c7f03 <std::sys::backtrace::__rust_begin_short_backtrace+0x1883>
    0.00 :   c8353:  movq   $0x0,0x2e8(%rsp)
    0.00 :   c835f:  mov    0x100(%rsp),%r13
    0.00 :   c8367:  test   %r13,%r13
    0.00 :   c836a:  je     c94ec <std::sys::backtrace::__rust_begin_short_backtrace+0x2e6c>
    0.00 :   c8370:  mov    0x108(%rsp),%rbp
    0.00 :   c8378:  mov    $0x178,%edi
    0.00 :   c837d:  call   *0xc9edd(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   c8383:  test   %rax,%rax
    0.00 :   c8386:  je     c94fe <std::sys::backtrace::__rust_begin_short_backtrace+0x2e7e>
    0.00 :   c838c:  mov    %rax,%r15
    0.00 :   c838f:  movq   $0x0,0xb0(%rax)
    0.00 :   c839a:  movw   $0x0,0x112(%rax)
    0.00 :   c83a3:  mov    %r13,0x118(%rax)
    0.00 :   c83aa:  mov    %rbp,%rax
    0.00 :   c83ad:  inc    %rax
    0.00 :   c83b0:  je     c9513 <std::sys::backtrace::__rust_begin_short_backtrace+0x2e93>
    0.00 :   c83b6:  mov    %r15,0xb0(%r13)
    0.00 :   c83bd:  movw   $0x0,0x110(%r13)
    0.00 :   c83c7:  mov    %r15,0x100(%rsp)
    0.00 :   c83cf:  mov    %rax,0x108(%rsp)
    0.00 :   c83d7:  cmp    %rbp,0x2e8(%rsp)
    0.00 :   c83df:  jne    c9525 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ea5>
    0.00 :   c83e5:  movw   $0x1,0x112(%r15)
    0.00 :   c83ef:  mov    0xf0(%rsp),%rax
    0.00 :   c83f7:  mov    %rax,0xb8(%r15)
    0.00 :   c83fe:  mov    0x30(%rsp),%rax
    0.00 :   c8403:  mov    %rax,(%r15)
    0.00 :   c8406:  mov    0x38(%rsp),%rax
    0.00 :   c840b:  mov    %rax,0x8(%r15)
    0.00 :   c840f:  mov    %r12,0x120(%r15)
    0.00 :   c8416:  mov    %r15,0xb0(%r12)
    0.00 :   c841e:  movw   $0x1,0x110(%r12)
    0.00 :   c8429:  mov    0xe8(%rsp),%rbp
    0.00 :   c8431:  mov    0x148(%rsp),%r12
    0.00 :   c8439:  incq   0x110(%rsp)
    0.00 :   c8441:  mov    0x3f0(%rsp),%r15
    0.00 :   c8449:  mov    $0x0,%edx
    0.00 :   c844e:  dec    %r12
    0.00 :   c8451:  jne    c75f4 <std::sys::backtrace::__rust_begin_short_backtrace+0xf74>
    0.00 :   c8457:  jmp    c896e <std::sys::backtrace::__rust_begin_short_backtrace+0x22ee>
    0.00 :   c845c:  lea    0x1(%r10),%r13
    0.00 :   c8460:  cmp    %r11w,%r10w
    0.00 :   c8464:  jae    c8590 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f10>
    0.00 :   c846a:  lea    0xb8(%r15),%rdi
    0.00 :   c8471:  lea    (%r15,%r10,8),%rsi
    0.00 :   c8475:  add    $0xb8,%rsi
    0.00 :   c847c:  lea    0x0(,%r13,8),%eax
    0.00 :   c8484:  mov    %rax,0x10(%rsp)
    0.00 :   c8489:  add    %rax,%rdi
    0.00 :   c848c:  mov    %r11,%r12
    0.00 :   c848f:  sub    %r10,%r12
    0.00 :   c8492:  lea    0x0(,%r12,8),%rdx
    0.00 :   c849a:  mov    %rdx,0x30(%rsp)
    0.00 :   c849f:  mov    %r10,0x8(%rsp)
    0.00 :   c84a4:  call   *0xca2ae(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c84aa:  mov    0x8(%rsp),%rax
    0.00 :   c84af:  lea    0x0(,%rax,8),%eax
    0.00 :   c84b6:  mov    %rax,0x38(%rsp)
    0.00 :   c84bb:  mov    0x150(%rsp),%rcx
    0.00 :   c84c3:  mov    %rcx,0xb8(%r15,%rax,1)
    0.00 :   c84cb:  mov    0x8(%rsp),%rbp
    0.00 :   c84d0:  shl    $0x4,%ebp
    0.00 :   c84d3:  lea    (%r15,%rbp,1),%rsi
    0.00 :   c84d7:  mov    %r13d,%edi
    0.00 :   c84da:  shl    $0x4,%edi
    0.00 :   c84dd:  add    %r15,%rdi
    0.00 :   c84e0:  shl    $0x4,%r12
    0.00 :   c84e4:  mov    %r12,%rdx
    0.00 :   c84e7:  mov    0xca26a(%rip),%r12        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   c84ee:  call   *%r12
    0.00 :   c84f1:  mov    0x158(%rsp),%rax
    0.00 :   c84f9:  mov    %rax,(%r15,%rbp,1)
    0.00 :   c84fd:  mov    0x40(%rsp),%rax
    0.00 :   c8502:  mov    %rax,0x8(%r15,%rbp,1)
    0.00 :   c8507:  mov    0x10(%rsp),%rax
    0.00 :   c850c:  lea    0x118(%r15,%rax,1),%rsi
    0.00 :   c8514:  mov    0x38(%rsp),%rax
    0.00 :   c8519:  lea    (%r15,%rax,1),%rdi
    0.00 :   c851d:  add    $0x128,%rdi
    0.00 :   c8524:  mov    0x30(%rsp),%rdx
    0.00 :   c8529:  call   *%r12
    0.00 :   c852c:  mov    0x48(%rsp),%r11
    0.00 :   c8531:  mov    0x88(%rsp),%rsi
    0.00 :   c8539:  mov    0x8(%rsp),%r10
    0.00 :   c853e:  jmp    c85a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f27>
    0.00 :   c8540:  mov    $0xb,%r12d
    0.00 :   c8546:  test   %r15d,%r15d
    0.00 :   c8549:  js     c8550 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ed0>
    0.00 :   c854b:  mov    %r15d,%edi
    0.00 :   c854e:  call   *%rbx
    0.00 :   c8550:  mov    %r12,0x90(%rsp)
    0.00 :   c8558:  mov    0x220(%rsp),%rax
    0.00 :   c8560:  mov    %rax,0x98(%rsp)
    0.00 :   c8568:  mov    0x228(%rsp),%rax
    0.00 :   c8570:  mov    %rax,0xa0(%rsp)
    0.00 :   c8578:  lea    0x50(%rsp),%rdi
    0.00 :   c857d:  lea    0x90(%rsp),%rsi
    0.00 :   c8585:  call   *0xcac2d(%rip)        # 1931b8 <_DYNAMIC+0x11a0>
    0.00 :   c858b:  jmp    c7b45 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c8590:  mov    %r8,0xb8(%r15,%r10,8)
    0.00 :   c8598:  mov    %r10d,%eax
    0.00 :   c859b:  shl    $0x4,%eax
    0.00 :   c859e:  mov    %rdi,(%r15,%rax,1)
    0.00 :   c85a2:  mov    %rbp,0x8(%r15,%rax,1)
    0.00 :   c85a7:  mov    0xe8(%rsp),%rbp
    0.00 :   c85af:  mov    0x148(%rsp),%r12
    0.00 :   c85b7:  lea    0x1(%r11),%ecx
    0.00 :   c85bb:  lea    0x2(%r11),%rax
    0.00 :   c85bf:  mov    %rsi,0x120(%r15,%r10,8)
    0.00 :   c85c7:  mov    %cx,0x112(%r15)
    0.00 :   c85cf:  cmp    %eax,%r13d
    0.00 :   c85d2:  jae    c8439 <std::sys::backtrace::__rust_begin_short_backtrace+0x1db9>
    0.00 :   c85d8:  mov    %r11d,%ecx
    0.00 :   c85db:  sub    %r10d,%ecx
    0.00 :   c85de:  inc    %ecx
    0.00 :   c85e0:  and    $0x3,%ecx
    0.00 :   c85e3:  je     c8619 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f99>
    0.00 :   c85e5:  mov    0x20(%rsp),%r9
    0.00 :   c85ea:  lea    (%r9,%r10,8),%rsi
    0.00 :   c85ee:  add    $0x120,%rsi
    0.00 :   c85f5:  xor    %edx,%edx
    0.00 :   c85f7:  mov    (%rsi,%rdx,8),%rdi
    0.00 :   c85fb:  mov    %r9,0xb0(%rdi)
    0.00 :   c8602:  lea    (%rdx,%r13,1),%r8d
    0.00 :   c8606:  mov    %r8w,0x110(%rdi)
    0.00 :   c860e:  inc    %rdx
    0.00 :   c8611:  cmp    %rdx,%rcx
    0.00 :   c8614:  jne    c85f7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f77>
    0.00 :   c8616:  add    %rdx,%r13
    0.00 :   c8619:  sub    %r10,%r11
    0.00 :   c861c:  cmp    $0x3,%r11d
    0.00 :   c8620:  mov    0x20(%rsp),%rsi
    0.00 :   c8625:  jb     c8439 <std::sys::backtrace::__rust_begin_short_backtrace+0x1db9>
    0.00 :   c862b:  mov    0x118(%rsi,%r13,8),%rcx
    0.00 :   c8633:  mov    %rsi,0xb0(%rcx)
    0.00 :   c863a:  mov    %r13w,0x110(%rcx)
    0.00 :   c8642:  mov    0x120(%rsi,%r13,8),%rcx
    0.00 :   c864a:  mov    %rsi,0xb0(%rcx)
    0.00 :   c8651:  lea    0x1(%r13),%edx
    0.00 :   c8655:  mov    %dx,0x110(%rcx)
    0.00 :   c865c:  mov    0x128(%rsi,%r13,8),%rcx
    0.00 :   c8664:  mov    %rsi,0xb0(%rcx)
    0.00 :   c866b:  lea    0x2(%r13),%edx
    0.00 :   c866f:  mov    %dx,0x110(%rcx)
    0.00 :   c8676:  mov    0x130(%rsi,%r13,8),%rcx
    0.00 :   c867e:  mov    %rsi,0xb0(%rcx)
    0.00 :   c8685:  lea    0x3(%r13),%edx
    0.00 :   c8689:  mov    %dx,0x110(%rcx)
    0.00 :   c8690:  add    $0x4,%r13
    0.00 :   c8694:  cmp    %rax,%r13
    0.00 :   c8697:  jne    c862b <std::sys::backtrace::__rust_begin_short_backtrace+0x1fab>
    0.00 :   c8699:  jmp    c8439 <std::sys::backtrace::__rust_begin_short_backtrace+0x1db9>
    0.00 :   c869e:  mov    %r8,0x48(%rsp)
    0.00 :   c86a3:  lea    0x120(%rsp),%rdi
    0.00 :   c86ab:  lea    0x298(%rsp),%rsi
    0.00 :   c86b3:  mov    0xcab06(%rip),%rdx        # 1931c0 <_DYNAMIC+0x11a8>
    0.00 :   c86ba:  call   *0xcab08(%rip)        # 1931c8 <_DYNAMIC+0x11b0>
    0.00 :   c86c0:  cmpb   $0xd,0x120(%rsp)
    0.00 :   c86c8:  lea    0x120(%rsp),%rsi
    0.00 :   c86d0:  jne    c7959 <std::sys::backtrace::__rust_begin_short_backtrace+0x12d9>
    0.00 :   c86d6:  mov    0x128(%rsp),%rax
    0.00 :   c86de:  mov    %rax,0xf0(%rsp)
    0.00 :   c86e6:  mov    0x48(%rsp),%rax
    0.00 :   c86eb:  cmpb   $0x2,0xe(%rax)
    0.00 :   c86ef:  je     c895c <std::sys::backtrace::__rust_begin_short_backtrace+0x22dc>
    0.00 :   c86f5:  lea    0x90(%rsp),%rdi
    0.00 :   c86fd:  call   *0xcaacd(%rip)        # 1931d0 <_DYNAMIC+0x11b8>
    0.00 :   c8703:  mov    0x90(%rsp),%rax
    0.00 :   c870b:  mov    %rax,0x40(%rsp)
    0.00 :   c8710:  mov    0x98(%rsp),%rax
    0.00 :   c8718:  mov    %rax,0x38(%rsp)
    0.00 :   c871d:  mov    0xa0(%rsp),%rax
    0.00 :   c8725:  mov    %rax,0x88(%rsp)
    0.00 :   c872d:  test   %r15d,%r15d
    0.00 :   c8730:  js     c8737 <std::sys::backtrace::__rust_begin_short_backtrace+0x20b7>
    0.00 :   c8732:  mov    %r15d,%edi
    0.00 :   c8735:  call   *%rbx
    0.00 :   c8737:  cmpb   $0xd,0x40(%rsp)
    0.00 :   c873c:  jne    c8805 <std::sys::backtrace::__rust_begin_short_backtrace+0x2185>
    0.00 :   c8742:  mov    0x20(%rsp),%rcx
    0.00 :   c8747:  mov    0x48(%rsp),%r8
    0.00 :   c874c:  mov    0xf0(%rsp),%r9
    0.00 :   c8754:  mov    0x38(%rsp),%rsi
    0.00 :   c8759:  jmp    c78c5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1245>
    0.00 :   c875e:  mov    %r15,0x20(%rsp)
    0.00 :   c8763:  mov    %r9,0xf0(%rsp)
    0.00 :   c876b:  mov    %r8,%r15
    0.00 :   c876e:  movswq %ax,%rdi
    0.00 :   c8772:  movabs $0xffffffff00000000,%rax
    0.00 :   c877c:  imul   %rax,%rdi
    0.00 :   c8780:  or     $0x2,%rdi
    0.00 :   c8784:  call   *0xcaa26(%rip)        # 1931b0 <_DYNAMIC+0x1198>
    0.00 :   c878a:  cmp    $0x4,%dl
    0.00 :   c878d:  jne    c8847 <std::sys::backtrace::__rust_begin_short_backtrace+0x21c7>
    0.00 :   c8793:  mov    0x228(%rsp),%rax
    0.00 :   c879b:  mov    %rax,0x88(%rsp)
    0.00 :   c87a3:  mov    0x220(%rsp),%rax
    0.00 :   c87ab:  mov    %rax,0x38(%rsp)
    0.00 :   c87b0:  jmp    c880a <std::sys::backtrace::__rust_begin_short_backtrace+0x218a>
    0.00 :   c87b2:  lea    0x120(%rsp),%rdi
    0.00 :   c87ba:  lea    0x298(%rsp),%rsi
    0.00 :   c87c2:  mov    0xca9f7(%rip),%rdx        # 1931c0 <_DYNAMIC+0x11a8>
    0.00 :   c87c9:  call   *0xca9f9(%rip)        # 1931c8 <_DYNAMIC+0x11b0>
    0.00 :   c87cf:  cmpb   $0xd,0x120(%rsp)
    0.00 :   c87d7:  jne    c8944 <std::sys::backtrace::__rust_begin_short_backtrace+0x22c4>
    0.00 :   c87dd:  mov    0x128(%rsp),%rax
    0.00 :   c87e5:  mov    %rax,0x30(%rsp)
    0.00 :   c87ea:  mov    0x268(%rsp),%r12
    0.00 :   c87f2:  cmp    0x258(%rsp),%r12
    0.00 :   c87fa:  je     c79f7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1377>
    0.00 :   c8800:  jmp    c7a05 <std::sys::backtrace::__rust_begin_short_backtrace+0x1385>
    0.00 :   c8805:  mov    0x40(%rsp),%r15
    0.00 :   c880a:  mov    %r15,0x90(%rsp)
    0.00 :   c8812:  mov    0x38(%rsp),%rax
    0.00 :   c8817:  mov    %rax,0x98(%rsp)
    0.00 :   c881f:  mov    0x88(%rsp),%rax
    0.00 :   c8827:  mov    %rax,0xa0(%rsp)
    0.00 :   c882f:  lea    0x50(%rsp),%rdi
    0.00 :   c8834:  lea    0x90(%rsp),%rsi
    0.00 :   c883c:  call   *0xca976(%rip)        # 1931b8 <_DYNAMIC+0x11a0>
    0.00 :   c8842:  jmp    c7b45 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c8847:  mov    %r15,0x90(%rsp)
    0.00 :   c884f:  mov    0x220(%rsp),%rcx
    0.00 :   c8857:  mov    %rcx,0x98(%rsp)
    0.00 :   c885f:  mov    0x228(%rsp),%rcx
    0.00 :   c8867:  mov    %rcx,0xa0(%rsp)
    0.00 :   c886f:  mov    %r12d,0xa8(%rsp)
    0.00 :   c8877:  cmp    $0x3,%dl
    0.00 :   c887a:  mov    0xf0(%rsp),%r9
    0.00 :   c8882:  mov    0x20(%rsp),%r15
    0.00 :   c8887:  je     c7936 <std::sys::backtrace::__rust_begin_short_backtrace+0x12b6>
    0.00 :   c888d:  mov    %r9,%rcx
    0.00 :   c8890:  movzbl %dl,%r9d
    0.00 :   c8894:  lea    0x50(%rsp),%rdi
    0.00 :   c8899:  lea    0x90(%rsp),%rsi
    0.00 :   c88a1:  mov    %rcx,%rdx
    0.00 :   c88a4:  mov    %r15,%rcx
    0.00 :   c88a7:  mov    %rax,%r8
    0.00 :   c88aa:  call   *0xca928(%rip)        # 1931d8 <_DYNAMIC+0x11c0>
    0.00 :   c88b0:  jmp    c7b45 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c88b5:  mov    %r8,%r15
    0.00 :   c88b8:  movswq %ax,%rdi
    0.00 :   c88bc:  movabs $0xffffffff00000000,%rax
    0.00 :   c88c6:  imul   %rax,%rdi
    0.00 :   c88ca:  or     $0x2,%rdi
    0.00 :   c88ce:  call   *0xca8dc(%rip)        # 1931b0 <_DYNAMIC+0x1198>
    0.00 :   c88d4:  cmp    $0x4,%dl
    0.00 :   c88d7:  je     c8550 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ed0>
    0.00 :   c88dd:  mov    %r12,0x90(%rsp)
    0.00 :   c88e5:  mov    0x220(%rsp),%rcx
    0.00 :   c88ed:  mov    %rcx,0x98(%rsp)
    0.00 :   c88f5:  mov    0x228(%rsp),%rcx
    0.00 :   c88fd:  mov    %rcx,0xa0(%rsp)
    0.00 :   c8905:  mov    0x10(%rsp),%rcx
    0.00 :   c890a:  mov    %ecx,0xa8(%rsp)
    0.00 :   c8911:  cmp    $0x3,%dl
    0.00 :   c8914:  mov    %r15,%r8
    0.00 :   c8917:  je     c7af2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1472>
    0.00 :   c891d:  movzbl %dl,%r9d
    0.00 :   c8921:  lea    0x50(%rsp),%rdi
    0.00 :   c8926:  lea    0x90(%rsp),%rsi
    0.00 :   c892e:  mov    0x30(%rsp),%rdx
    0.00 :   c8933:  mov    %r8,%rcx
    0.00 :   c8936:  mov    %rax,%r8
    0.00 :   c8939:  call   *0xca899(%rip)        # 1931d8 <_DYNAMIC+0x11c0>
    0.00 :   c893f:  jmp    c7b45 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c8944:  lea    0x50(%rsp),%rdi
    0.00 :   c8949:  lea    0x120(%rsp),%rsi
    0.00 :   c8951:  call   *0xca861(%rip)        # 1931b8 <_DYNAMIC+0x11a0>
    0.00 :   c8957:  jmp    c7b3b <std::sys::backtrace::__rust_begin_short_backtrace+0x14bb>
    0.00 :   c895c:  mov    0x48(%rsp),%r8
    0.00 :   c8961:  mov    0xf0(%rsp),%r9
    0.00 :   c8969:  jmp    c78ab <std::sys::backtrace::__rust_begin_short_backtrace+0x122b>
    0.00 :   c896e:  mov    0x160(%rsp),%r15
    0.00 :   c8976:  mov    0x230(%rsp),%r14
    0.00 :   c897e:  mov    0x110(%rsp),%rax
    0.00 :   c8986:  mov    0x80(%rsp),%rcx
    0.00 :   c898e:  mov    %rax,0x70(%rcx)
    0.00 :   c8992:  cmpb   $0x0,0x168(%rsp)
    0.00 :   c899a:  jne    c89b9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2339>
    0.00 :   c899c:  mov    0xc9c05(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c89a3:  mov    (%rax),%rax
    0.00 :   c89a6:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c89b0:  test   %rcx,%rax
    0.00 :   c89b3:  jne    c8caf <std::sys::backtrace::__rust_begin_short_backtrace+0x262f>
    0.00 :   c89b9:  xor    %eax,%eax
    0.00 :   c89bb:  xchg   %eax,(%r15)
    0.00 :   c89be:  cmp    $0x2,%eax
    0.00 :   c89c1:  je     c8c90 <std::sys::backtrace::__rust_begin_short_backtrace+0x2610>
    0.00 :   c89c7:  lea    0x90(%rsp),%rdi
    0.00 :   c89cf:  lea    0x248(%rsp),%rsi
    0.00 :   c89d7:  lea    0x330(%rsp),%rdx
    0.00 :   c89df:  xor    %ecx,%ecx
    0.00 :   c89e1:  mov    $0x5f5e100,%r8d
    0.00 :   c89e7:  call   *0xca7f3(%rip)        # 1931e0 <_DYNAMIC+0x11c8>
    0.00 :   c89ed:  movabs $0x7fffffffffffffff,%rax
    0.00 :   c89f7:  add    $0x2,%rax
    0.00 :   c89fb:  cmp    %rax,0x90(%rsp)
    0.00 :   c8a03:  jne    c8a45 <std::sys::backtrace::__rust_begin_short_backtrace+0x23c5>
    0.00 :   c8a05:  cmpb   $0x0,0x98(%rsp)
    0.00 :   c8a0d:  jne    c9274 <std::sys::backtrace::__rust_begin_short_backtrace+0x2bf4>
    0.00 :   c8a13:  mov    0xa0(%rsp),%r15
    0.00 :   c8a1b:  mov    %r15,%rdi
    0.00 :   c8a1e:  call   c4900 <<std::io::error::Error>::kind>
    0.00 :   c8a23:  cmp    $0x23,%al
    0.00 :   c8a25:  jne    c9274 <std::sys::backtrace::__rust_begin_short_backtrace+0x2bf4>
    0.00 :   c8a2b:  mov    %r15,0x50(%rsp)
    0.00 :   c8a30:  lea    0x50(%rsp),%rdi
    0.00 :   c8a35:  call   d7a40 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10657235172099788962>
    0.00 :   c8a3a:  mov    $0x1,%r15d
    0.00 :   c8a40:  jmp    c6f72 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f2>
    0.00 :   c8a45:  mov    0xb0(%rsp),%rax
    0.00 :   c8a4d:  mov    %rax,0x140(%rsp)
    0.00 :   c8a55:  movdqu 0x90(%rsp),%xmm0
    0.00 :   c8a5e:  movups 0xa0(%rsp),%xmm1
    0.00 :   c8a66:  movaps %xmm1,0x130(%rsp)
    0.00 :   c8a6e:  movdqa %xmm0,0x120(%rsp)
    0.00 :   c8a77:  mov    0x340(%rsp),%r14
    0.00 :   c8a7f:  test   %r14,%r14
    0.00 :   c8a82:  mov    $0x1,%r15d
    0.00 :   c8a88:  je     c8c57 <std::sys::backtrace::__rust_begin_short_backtrace+0x25d7>
    0.00 :   c8a8e:  mov    0x338(%rsp),%r13
    0.00 :   c8a96:  shl    $0x4,%r14
    0.00 :   c8a9a:  add    %r13,%r14
    0.00 :   c8a9d:  jmp    c8aac <std::sys::backtrace::__rust_begin_short_backtrace+0x242c>
    0.00 :   c8a9f:  add    $0x10,%r13
    0.00 :   c8aa3:  cmp    %r14,%r13
    0.00 :   c8aa6:  je     c8c57 <std::sys::backtrace::__rust_begin_short_backtrace+0x25d7>
    0.00 :   c8aac:  testb  $0x1,0x0(%r13)
    0.00 :   c8ab1:  jne    c8a9f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c8ab3:  mov    $0x1,%ecx
    0.00 :   c8ab8:  mov    0x8(%r13),%r15
    0.00 :   c8abc:  xor    %eax,%eax
    0.00 :   c8abe:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   c8ac3:  jne    c8bd7 <std::sys::backtrace::__rust_begin_short_backtrace+0x2557>
    0.00 :   c8ac9:  mov    0xc9ad8(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c8ad0:  mov    (%rax),%rax
    0.00 :   c8ad3:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c8add:  test   %rcx,%rax
    0.00 :   c8ae0:  jne    c8be5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2565>
    0.00 :   c8ae6:  xor    %r12d,%r12d
    0.00 :   c8ae9:  mov    0x80(%rsp),%rax
    0.00 :   c8af1:  movzbl 0x24(%rax),%eax
    0.00 :   c8af5:  lea    0x50(%rsp),%rdi
    0.00 :   c8afa:  mov    0x3f8(%rsp),%rsi
    0.00 :   c8b02:  mov    %r15,%rdx
    0.00 :   c8b05:  call   e31a0 <alloc::collections::btree::map::BTreeMap<K,V,A>::remove>
    0.00 :   c8b0a:  test   %r12b,%r12b
    0.00 :   c8b0d:  mov    $0x1,%r15d
    0.00 :   c8b13:  jne    c8b32 <std::sys::backtrace::__rust_begin_short_backtrace+0x24b2>
    0.00 :   c8b15:  mov    0xc9a8c(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c8b1c:  mov    (%rax),%rax
    0.00 :   c8b1f:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c8b29:  test   %rcx,%rax
    0.00 :   c8b2c:  jne    c8c2a <std::sys::backtrace::__rust_begin_short_backtrace+0x25aa>
    0.00 :   c8b32:  xor    %eax,%eax
    0.00 :   c8b34:  xchg   %eax,0x0(%rbp)
    0.00 :   c8b37:  cmp    $0x2,%eax
    0.00 :   c8b3a:  je     c8bff <std::sys::backtrace::__rust_begin_short_backtrace+0x257f>
    0.00 :   c8b40:  cmpq   $0x0,0x50(%rsp)
    0.00 :   c8b46:  je     c8a9f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c8b4c:  movdqu 0x50(%rsp),%xmm0
    0.00 :   c8b52:  movups 0x60(%rsp),%xmm1
    0.00 :   c8b57:  movaps %xmm1,0xa0(%rsp)
    0.00 :   c8b5f:  mov    0x70(%rsp),%rax
    0.00 :   c8b64:  mov    %rax,0xb0(%rsp)
    0.00 :   c8b6c:  movdqa %xmm0,0x90(%rsp)
    0.00 :   c8b75:  mov    0xa0(%rsp),%rsi
    0.00 :   c8b7d:  mov    0xa8(%rsp),%rdx
    0.00 :   c8b85:  lea    0x98(%rsp),%rdi
    0.00 :   c8b8d:  call   *0xca655(%rip)        # 1931e8 <_DYNAMIC+0x11d0>
    0.00 :   c8b93:  mov    0x90(%rsp),%rax
    0.00 :   c8b9b:  lock decq (%rax)
    0.00 :   c8b9f:  jne    c8baf <std::sys::backtrace::__rust_begin_short_backtrace+0x252f>
    0.00 :   c8ba1:  lea    0x90(%rsp),%rdi
    0.00 :   c8ba9:  call   *0xca641(%rip)        # 1931f0 <_DYNAMIC+0x11d8>
    0.00 :   c8baf:  mov    0x98(%rsp),%rdi
    0.00 :   c8bb7:  cmp    $0xffffffffffffffff,%rdi
    0.00 :   c8bbb:  je     c8a9f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c8bc1:  lock decq 0x8(%rdi)
    0.00 :   c8bc6:  jne    c8a9f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c8bcc:  call   *0xc9676(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c8bd2:  jmp    c8a9f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c8bd7:  mov    %rbp,%rdi
    0.00 :   c8bda:  call   *0xc9a40(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   c8be0:  jmp    c8ac9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2449>
    0.00 :   c8be5:  call   *0xc99dd(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   c8beb:  mov    %eax,%r12d
    0.00 :   c8bee:  xor    $0x1,%r12b
    0.00 :   c8bf2:  mov    0xe8(%rsp),%rbp
    0.00 :   c8bfa:  jmp    c8ae9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2469>
    0.00 :   c8bff:  mov    $0xca,%edi
    0.00 :   c8c04:  mov    %rbp,%rsi
    0.00 :   c8c07:  mov    $0x81,%edx
    0.00 :   c8c0c:  mov    $0x1,%ecx
    0.00 :   c8c11:  xor    %eax,%eax
    0.00 :   c8c13:  call   *0xc99bf(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   c8c19:  cmpq   $0x0,0x50(%rsp)
    0.00 :   c8c1f:  jne    c8b4c <std::sys::backtrace::__rust_begin_short_backtrace+0x24cc>
    0.00 :   c8c25:  jmp    c8a9f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c8c2a:  call   *0xc9998(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   c8c30:  test   %al,%al
    0.00 :   c8c32:  mov    0xe8(%rsp),%rbp
    0.00 :   c8c3a:  mov    $0x1,%r15d
    0.00 :   c8c40:  jne    c8b32 <std::sys::backtrace::__rust_begin_short_backtrace+0x24b2>
    0.00 :   c8c46:  mov    0x80(%rsp),%rax
    0.00 :   c8c4e:  movb   $0x1,0x24(%rax)
    0.00 :   c8c52:  jmp    c8b32 <std::sys::backtrace::__rust_begin_short_backtrace+0x24b2>
    0.00 :   c8c57:  mov    0x120(%rsp),%rax
    0.00 :   c8c5f:  mov    0x230(%rsp),%r14
    0.00 :   c8c67:  cmp    %r14,%rax
    0.00 :   c8c6a:  je     c6f72 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f2>
    0.00 :   c8c70:  jmp    c9329 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ca9>
    0.00 :   c8c75:  mov    %rbp,%rdi
    0.00 :   c8c78:  call   *0xc99a2(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   c8c7e:  jmp    c6f80 <std::sys::backtrace::__rust_begin_short_backtrace+0x900>
    0.00 :   c8c83:  call   *0xc993f(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   c8c89:  xor    $0x1,%al
    0.00 :   c8c8b:  jmp    c6f9f <std::sys::backtrace::__rust_begin_short_backtrace+0x91f>
    0.00 :   c8c90:  mov    $0xca,%edi
    0.00 :   c8c95:  mov    %r15,%rsi
    0.00 :   c8c98:  mov    $0x81,%edx
    0.00 :   c8c9d:  mov    $0x1,%ecx
    0.00 :   c8ca2:  xor    %eax,%eax
    0.00 :   c8ca4:  call   *0xc992e(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   c8caa:  jmp    c89c7 <std::sys::backtrace::__rust_begin_short_backtrace+0x2347>
    0.00 :   c8caf:  call   *0xc9913(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   c8cb5:  test   %al,%al
    0.00 :   c8cb7:  jne    c89b9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2339>
    0.00 :   c8cbd:  movb   $0x1,0x4(%r15)
    0.00 :   c8cc2:  jmp    c89b9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2339>
    0.00 :   c8cc7:  cmp    %rbx,%rax
    0.00 :   c8cca:  jne    c8d08 <std::sys::backtrace::__rust_begin_short_backtrace+0x2688>
    0.00 :   c8ccc:  mov    0x250(%rsp),%rax
    0.00 :   c8cd4:  lock decq (%rax)
    0.00 :   c8cd8:  jne    c8d15 <std::sys::backtrace::__rust_begin_short_backtrace+0x2695>
    0.00 :   c8cda:  lea    0x250(%rsp),%rdi
    0.00 :   c8ce2:  call   *0xca4b8(%rip)        # 1931a0 <_DYNAMIC+0x1188>
    0.00 :   c8ce8:  jmp    c8d15 <std::sys::backtrace::__rust_begin_short_backtrace+0x2695>
    0.00 :   c8cea:  mov    %r13d,%edx
    0.00 :   c8ced:  shr    $0x8,%edx
    0.00 :   c8cf0:  mov    %r13d,%ecx
    0.00 :   c8cf3:  and    $0xffff0000,%ecx
    0.00 :   c8cf9:  movzbl %r13b,%eax
    0.00 :   c8cfd:  mov    $0x5,%r13b
    0.00 :   c8d00:  mov    %r15,%rsi
    0.00 :   c8d03:  jmp    c8dbc <std::sys::backtrace::__rust_begin_short_backtrace+0x273c>
    0.00 :   c8d08:  lea    0x248(%rsp),%rdi
    0.00 :   c8d10:  call   d7ad0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10657235172099788962>
    0.00 :   c8d15:  mov    0x20(%rsp),%rdi
    0.00 :   c8d1a:  call   *0xc9528(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c8d20:  mov    0x480(%rsp),%edi
    0.00 :   c8d27:  call   *0xc9b0b(%rip)        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c8d2d:  mov    0x418(%rsp),%r15
    0.00 :   c8d35:  mov    0x420(%rsp),%rbx
    0.00 :   c8d3d:  test   %rbx,%rbx
    0.00 :   c8d40:  je     c8d74 <std::sys::backtrace::__rust_begin_short_backtrace+0x26f4>
    0.00 :   c8d42:  lea    0xe(%r15),%r14
    0.00 :   c8d46:  mov    0xc9aeb(%rip),%r12        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c8d4d:  jmp    c8d58 <std::sys::backtrace::__rust_begin_short_backtrace+0x26d8>
    0.00 :   c8d4f:  add    $0x18,%r14
    0.00 :   c8d53:  dec    %rbx
    0.00 :   c8d56:  je     c8d74 <std::sys::backtrace::__rust_begin_short_backtrace+0x26f4>
    0.00 :   c8d58:  mov    -0x6(%r14),%edi
    0.00 :   c8d5c:  cmpb   $0x2,(%r14)
    0.00 :   c8d60:  setne  %al
    0.00 :   c8d63:  test   %edi,%edi
    0.00 :   c8d65:  setns  %cl
    0.00 :   c8d68:  and    %al,%cl
    0.00 :   c8d6a:  cmp    $0x1,%cl
    0.00 :   c8d6d:  jne    c8d4f <std::sys::backtrace::__rust_begin_short_backtrace+0x26cf>
    0.00 :   c8d6f:  call   *%r12
    0.00 :   c8d72:  jmp    c8d4f <std::sys::backtrace::__rust_begin_short_backtrace+0x26cf>
    0.00 :   c8d74:  cmpq   $0x0,0x410(%rsp)
    0.00 :   c8d7d:  je     c8d88 <std::sys::backtrace::__rust_begin_short_backtrace+0x2708>
    0.00 :   c8d7f:  mov    %r15,%rdi
    0.00 :   c8d82:  call   *0xc94c0(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c8d88:  mov    0x448(%rsp),%rax
    0.00 :   c8d90:  lock decq (%rax)
    0.00 :   c8d94:  mov    0x80(%rsp),%rbx
    0.00 :   c8d9c:  jne    c923c <std::sys::backtrace::__rust_begin_short_backtrace+0x2bbc>
    0.00 :   c8da2:  lea    0x448(%rsp),%rdi
    0.00 :   c8daa:  call   *0xca3f8(%rip)        # 1931a8 <_DYNAMIC+0x1190>
    0.00 :   c8db0:  jmp    c923c <std::sys::backtrace::__rust_begin_short_backtrace+0x2bbc>
    0.00 :   c8db5:  xor    %eax,%eax
    0.00 :   c8db7:  mov    %r15,%rsi
    0.00 :   c8dba:  xor    %ecx,%ecx
    0.00 :   c8dbc:  or     %rax,%rcx
    0.00 :   c8dbf:  movzbl %dl,%eax
    0.00 :   c8dc2:  shl    $0x8,%eax
    0.00 :   c8dc5:  or     %rcx,%rax
    0.00 :   c8dc8:  mov    %r13b,0x90(%rsp)
    0.00 :   c8dd0:  movb   $0x0,0x97(%rsp)
    0.00 :   c8dd8:  movw   $0x0,0x95(%rsp)
    0.00 :   c8de2:  movl   $0x0,0x91(%rsp)
    0.00 :   c8ded:  lea    0x98(%rsp),%r14
    0.00 :   c8df5:  mov    %rsi,0x98(%rsp)
    0.00 :   c8dfd:  mov    %rax,0xa0(%rsp)
    0.00 :   c8e05:  mov    %r12,0xa8(%rsp)
    0.00 :   c8e0d:  mov    %r15,0xb0(%rsp)
    0.00 :   c8e15:  movq   $0x0,0x120(%rsp)
    0.00 :   c8e21:  movq   $0x1,0x128(%rsp)
    0.00 :   c8e2d:  movq   $0x0,0x130(%rsp)
    0.00 :   c8e39:  movq   $0x60000020,0x60(%rsp)
    0.00 :   c8e42:  lea    0x120(%rsp),%rax
    0.00 :   c8e4a:  mov    %rax,0x50(%rsp)
    0.00 :   c8e4f:  lea    0xc4992(%rip),%rax        # 18d7e8 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0xe8>
    0.00 :   c8e56:  mov    %rax,0x58(%rsp)
    0.00 :   c8e5b:  lea    0x90(%rsp),%rdi
    0.00 :   c8e63:  lea    0x50(%rsp),%rsi
    0.00 :   c8e68:  call   *0xca38a(%rip)        # 1931f8 <_DYNAMIC+0x11e0>
    0.00 :   c8e6e:  test   %al,%al
    0.00 :   c8e70:  jne    c94aa <std::sys::backtrace::__rust_begin_short_backtrace+0x2e2a>
    0.00 :   c8e76:  mov    0x120(%rsp),%r15
    0.00 :   c8e7e:  movdqu 0x128(%rsp),%xmm0
    0.00 :   c8e87:  movdqa %xmm0,0x20(%rsp)
    0.00 :   c8e8d:  cmp    $0x1,%r13b
    0.00 :   c8e91:  ja     c8e9b <std::sys::backtrace::__rust_begin_short_backtrace+0x281b>
    0.00 :   c8e93:  mov    %r14,%rdi
    0.00 :   c8e96:  call   d7a40 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10657235172099788962>
    0.00 :   c8e9b:  cmpq   $0x0,0x8(%rsp)
    0.00 :   c8ea1:  je     c8eae <std::sys::backtrace::__rust_begin_short_backtrace+0x282e>
    0.00 :   c8ea3:  mov    0x10(%rsp),%rdi
    0.00 :   c8ea8:  call   *0xc939a(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c8eae:  mov    %r15,%r14
    0.00 :   c8eb1:  mov    0x160(%rsp),%r15
    0.00 :   c8eb9:  cmpb   $0x0,0x168(%rsp)
    0.00 :   c8ec1:  jne    c8ee0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2860>
    0.00 :   c8ec3:  mov    0xc96de(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c8eca:  mov    (%rax),%rax
    0.00 :   c8ecd:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c8ed7:  test   %rcx,%rax
    0.00 :   c8eda:  jne    c94d4 <std::sys::backtrace::__rust_begin_short_backtrace+0x2e54>
    0.00 :   c8ee0:  xor    %eax,%eax
    0.00 :   c8ee2:  xchg   %eax,(%r15)
    0.00 :   c8ee5:  cmp    $0x2,%eax
    0.00 :   c8ee8:  je     c948b <std::sys::backtrace::__rust_begin_short_backtrace+0x2e0b>
    0.00 :   c8eee:  lea    0x100(%rsp),%rdi
    0.00 :   c8ef6:  call   d5480 <core::ptr::drop_in_place<alloc::collections::btree::map::BTreeMap<u64,zio::registration::Registration>>>
    0.00 :   c8efb:  mov    %r14,%rax
    0.00 :   c8efe:  neg    %rax
    0.00 :   c8f01:  jo     c9164 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ae4>
    0.00 :   c8f07:  movabs $0x8000000000000001,%rax
    0.00 :   c8f11:  cmp    %rax,%r14
    0.00 :   c8f14:  jne    c8f71 <std::sys::backtrace::__rust_begin_short_backtrace+0x28f1>
    0.00 :   c8f16:  movdqa 0x20(%rsp),%xmm0
    0.00 :   c8f1c:  movq   %xmm0,%rsi
    0.00 :   c8f21:  pshufd $0xee,%xmm0,%xmm0
    0.00 :   c8f26:  movq   %xmm0,%rdx
    0.00 :   c8f2b:  mov    $0x1,%bpl
    0.00 :   c8f2e:  lea    0x198(%rsp),%rdi
    0.00 :   c8f36:  call   *0xca234(%rip)        # 193170 <_DYNAMIC+0x1158>
    0.00 :   c8f3c:  mov    0x80(%rsp),%r13
    0.00 :   c8f44:  add    $0x10,%r13
    0.00 :   c8f48:  mov    0x1a0(%rsp),%r14
    0.00 :   c8f50:  mov    0x1a8(%rsp),%r12
    0.00 :   c8f58:  test   %r12,%r12
    0.00 :   c8f5b:  jns    c8fa9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2929>
    0.00 :   c8f5d:  xor    %r15d,%r15d
    0.00 :   c8f60:  mov    %r15,%rdi
    0.00 :   c8f63:  mov    %r12,%rsi
    0.00 :   c8f66:  call   *0xc92a4(%rip)        # 192210 <_DYNAMIC+0x1f8>
    0.00 :   c8f6c:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8f71:  mov    0x80(%rsp),%rdi
    0.00 :   c8f79:  add    $0x10,%rdi
    0.00 :   c8f7d:  mov    %r14,0x198(%rsp)
    0.00 :   c8f85:  movdqa 0x20(%rsp),%xmm0
    0.00 :   c8f8b:  movdqu %xmm0,0x1a0(%rsp)
    0.00 :   c8f94:  mov    $0x1,%bpl
    0.00 :   c8f97:  lea    0x198(%rsp),%rsi
    0.00 :   c8f9f:  call   130350 <vthread::readiness::Inner::close>
    0.00 :   c8fa4:  jmp    c9164 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ae4>
    0.00 :   c8fa9:  je     c9123 <std::sys::backtrace::__rust_begin_short_backtrace+0x2aa3>
    0.00 :   c8faf:  mov    $0x1,%r15d
    0.00 :   c8fb5:  mov    $0x1,%esi
    0.00 :   c8fba:  mov    %r12,%rdi
    0.00 :   c8fbd:  call   52cd0 <__rustc::__rust_alloc>
    0.00 :   c8fc2:  test   %rax,%rax
    0.00 :   c8fc5:  je     c8f60 <std::sys::backtrace::__rust_begin_short_backtrace+0x28e0>
    0.00 :   c8fc7:  mov    %rax,%rbp
    0.00 :   c8fca:  mov    %rax,%rdi
    0.00 :   c8fcd:  mov    %r14,%rsi
    0.00 :   c8fd0:  mov    %r12,%rdx
    0.00 :   c8fd3:  call   *0xc9257(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   c8fd9:  jmp    c9128 <std::sys::backtrace::__rust_begin_short_backtrace+0x2aa8>
    0.00 :   c8fde:  movq   $0x0,0x50(%rsp)
    0.00 :   c8fe7:  movb   $0x4,0x68(%rsp)
    0.00 :   c8fec:  jmp    c900b <std::sys::backtrace::__rust_begin_short_backtrace+0x298b>
    0.00 :   c8fee:  mov    0x1a0(%rsp),%rax
    0.00 :   c8ff6:  movq   $0x0,0x50(%rsp)
    0.00 :   c8fff:  movw   $0x300,0x68(%rsp)
    0.00 :   c9006:  mov    %rax,0x70(%rsp)
    0.00 :   c900b:  mov    0x50(%rsp),%rax
    0.00 :   c9010:  mov    0x58(%rsp),%rcx
    0.00 :   c9015:  mov    0x60(%rsp),%rdx
    0.00 :   c901a:  movzbl 0x68(%rsp),%esi
    0.00 :   c901f:  mov    0x69(%rsp),%edi
    0.00 :   c9023:  movzwl 0x6d(%rsp),%r8d
    0.00 :   c9029:  movzbl 0x6f(%rsp),%r9d
    0.00 :   c902f:  mov    0x70(%rsp),%r10
    0.00 :   c9034:  mov    %r10,0xb0(%rsp)
    0.00 :   c903c:  mov    0x78(%rsp),%r10
    0.00 :   c9041:  mov    %r10,0xb8(%rsp)
    0.00 :   c9049:  mov    %rdx,0xa0(%rsp)
    0.00 :   c9051:  mov    %sil,0xa8(%rsp)
    0.00 :   c9059:  mov    %edi,0xa9(%rsp)
    0.00 :   c9060:  mov    %r8w,0xad(%rsp)
    0.00 :   c9069:  mov    %r9b,0xaf(%rsp)
    0.00 :   c9071:  mov    %rax,0x90(%rsp)
    0.00 :   c9079:  mov    %rcx,0x98(%rsp)
    0.00 :   c9081:  movq   $0x0,0x180(%rsp)
    0.00 :   c908d:  movq   $0x1,0x188(%rsp)
    0.00 :   c9099:  movq   $0x0,0x190(%rsp)
    0.00 :   c90a5:  movq   $0x60000020,0x130(%rsp)
    0.00 :   c90b1:  lea    0x180(%rsp),%rax
    0.00 :   c90b9:  mov    %rax,0x120(%rsp)
    0.00 :   c90c1:  lea    0xc4720(%rip),%rax        # 18d7e8 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0xe8>
    0.00 :   c90c8:  mov    %rax,0x128(%rsp)
    0.00 :   c90d0:  lea    0xa8(%rsp),%rdi
    0.00 :   c90d8:  lea    0x120(%rsp),%rsi
    0.00 :   c90e0:  call   *0xca112(%rip)        # 1931f8 <_DYNAMIC+0x11e0>
    0.00 :   c90e6:  test   %al,%al
    0.00 :   c90e8:  jne    c952f <std::sys::backtrace::__rust_begin_short_backtrace+0x2eaf>
    0.00 :   c90ee:  mov    0x180(%rsp),%r14
    0.00 :   c90f6:  movups 0x188(%rsp),%xmm0
    0.00 :   c90fe:  movaps %xmm0,0x20(%rsp)
    0.00 :   c9103:  cmpb   $0x1,0xa8(%rsp)
    0.00 :   c910b:  ja     c8eb1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2831>
    0.00 :   c9111:  lea    0xb0(%rsp),%rdi
    0.00 :   c9119:  call   d7a40 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10657235172099788962>
    0.00 :   c911e:  jmp    c8eb1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2831>
    0.00 :   c9123:  mov    $0x1,%ebp
    0.00 :   c9128:  mov    %r12,0x488(%rsp)
    0.00 :   c9130:  mov    %rbp,0x490(%rsp)
    0.00 :   c9138:  mov    %r12,0x498(%rsp)
    0.00 :   c9140:  lea    0x488(%rsp),%rsi
    0.00 :   c9148:  mov    %r13,%rdi
    0.00 :   c914b:  call   130350 <vthread::readiness::Inner::close>
    0.00 :   c9150:  cmpq   $0x0,0x198(%rsp)
    0.00 :   c9159:  je     c9164 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ae4>
    0.00 :   c915b:  mov    %r14,%rdi
    0.00 :   c915e:  call   *0xc90e4(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c9164:  lea    0x198(%rsp),%rdi
    0.00 :   c916c:  lea    0x248(%rsp),%rsi
    0.00 :   c9174:  mov    $0x88,%edx
    0.00 :   c9179:  call   *0xc90b1(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   c917f:  mov    0x218(%rsp),%edi
    0.00 :   c9186:  call   *0xc96ac(%rip)        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c918c:  mov    0x1b0(%rsp),%r15
    0.00 :   c9194:  mov    0x1b8(%rsp),%r14
    0.00 :   c919c:  test   %r14,%r14
    0.00 :   c919f:  je     c91cd <std::sys::backtrace::__rust_begin_short_backtrace+0x2b4d>
    0.00 :   c91a1:  lea    0xe(%r15),%r12
    0.00 :   c91a5:  jmp    c91b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2b30>
    0.00 :   c91a7:  add    $0x18,%r12
    0.00 :   c91ab:  dec    %r14
    0.00 :   c91ae:  je     c91cd <std::sys::backtrace::__rust_begin_short_backtrace+0x2b4d>
    0.00 :   c91b0:  mov    -0x6(%r12),%edi
    0.00 :   c91b5:  cmpb   $0x2,(%r12)
    0.00 :   c91ba:  setne  %al
    0.00 :   c91bd:  test   %edi,%edi
    0.00 :   c91bf:  setns  %cl
    0.00 :   c91c2:  and    %al,%cl
    0.00 :   c91c4:  cmp    $0x1,%cl
    0.00 :   c91c7:  jne    c91a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x2b27>
    0.00 :   c91c9:  call   *%rbx
    0.00 :   c91cb:  jmp    c91a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x2b27>
    0.00 :   c91cd:  cmpq   $0x0,0x1a8(%rsp)
    0.00 :   c91d6:  je     c91e1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2b61>
    0.00 :   c91d8:  mov    %r15,%rdi
    0.00 :   c91db:  call   *0xc9067(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c91e1:  mov    0x1e0(%rsp),%rax
    0.00 :   c91e9:  lock decq (%rax)
    0.00 :   c91ed:  jne    c91ff <std::sys::backtrace::__rust_begin_short_backtrace+0x2b7f>
    0.00 :   c91ef:  lea    0x1e0(%rsp),%rdi
    0.00 :   c91f7:  xor    %ebp,%ebp
    0.00 :   c91f9:  call   *0xc9fa9(%rip)        # 1931a8 <_DYNAMIC+0x1190>
    0.00 :   c91ff:  mov    0x80(%rsp),%rbx
    0.00 :   c9207:  movq   $0x0,0x70(%rbx)
    0.00 :   c920f:  cmpq   $0x0,0x330(%rsp)
    0.00 :   c9218:  je     c9228 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ba8>
    0.00 :   c921a:  mov    0x338(%rsp),%rdi
    0.00 :   c9222:  call   *0xc9020(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c9228:  lock decq (%rbx)
    0.00 :   c922c:  jne    c923c <std::sys::backtrace::__rust_begin_short_backtrace+0x2bbc>
    0.00 :   c922e:  lea    0x328(%rsp),%rdi
    0.00 :   c9236:  call   *0xc9f64(%rip)        # 1931a0 <_DYNAMIC+0x1188>
    0.00 :   c923c:  mov    0x3e0(%rsp),%rax
    0.00 :   c9244:  cmp    %rax,0x3e8(%rsp)
    0.00 :   c924c:  je     c6870 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c9252:  lock decq (%rbx)
    0.00 :   c9256:  jne    c6870 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c925c:  lea    0x320(%rsp),%rdi
    0.00 :   c9264:  call   *0xc9f36(%rip)        # 1931a0 <_DYNAMIC+0x1188>
    0.00 :   c926a:  jmp    c6870 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c926f:  jmp    c8eb1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2831>
    0.00 :   c9274:  lea    0x98(%rsp),%rcx
    0.00 :   c927c:  mov    0x10(%rcx),%rax
    0.00 :   c9280:  mov    %rax,0x170(%rsp)
    0.00 :   c9288:  movups (%rcx),%xmm0
    0.00 :   c928b:  movaps %xmm0,0x160(%rsp)
    0.00 :   c9293:  movq   $0x0,0x180(%rsp)
    0.00 :   c929f:  movq   $0x1,0x188(%rsp)
    0.00 :   c92ab:  movq   $0x0,0x190(%rsp)
    0.00 :   c92b7:  movq   $0x60000020,0x60(%rsp)
    0.00 :   c92c0:  lea    0x180(%rsp),%rax
    0.00 :   c92c8:  mov    %rax,0x50(%rsp)
    0.00 :   c92cd:  lea    0xc4514(%rip),%rax        # 18d7e8 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0xe8>
    0.00 :   c92d4:  mov    %rax,0x58(%rsp)
    0.00 :   c92d9:  lea    0x160(%rsp),%rdi
    0.00 :   c92e1:  lea    0x50(%rsp),%rsi
    0.00 :   c92e6:  call   *0xc9f0c(%rip)        # 1931f8 <_DYNAMIC+0x11e0>
    0.00 :   c92ec:  test   %al,%al
    0.00 :   c92ee:  jne    c9615 <std::sys::backtrace::__rust_begin_short_backtrace+0x2f95>
    0.00 :   c92f4:  mov    0x180(%rsp),%r14
    0.00 :   c92fc:  movups 0x188(%rsp),%xmm0
    0.00 :   c9304:  movaps %xmm0,0x20(%rsp)
    0.00 :   c9309:  cmpb   $0x1,0x160(%rsp)
    0.00 :   c9311:  ja     c8eee <std::sys::backtrace::__rust_begin_short_backtrace+0x286e>
    0.00 :   c9317:  lea    0x168(%rsp),%rdi
    0.00 :   c931f:  call   d7a40 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10657235172099788962>
    0.00 :   c9324:  jmp    c8eee <std::sys::backtrace::__rust_begin_short_backtrace+0x286e>
    0.00 :   c9329:  mov    %rax,0x90(%rsp)
    0.00 :   c9331:  lea    0x128(%rsp),%rax
    0.00 :   c9339:  movups (%rax),%xmm0
    0.00 :   c933c:  movups 0x10(%rax),%xmm1
    0.00 :   c9340:  movups %xmm0,0x98(%rsp)
    0.00 :   c9348:  movups %xmm1,0xa8(%rsp)
    0.00 :   c9350:  lea    0x50(%rsp),%rdi
    0.00 :   c9355:  lea    0x90(%rsp),%rsi
    0.00 :   c935d:  call   d3bb0 <<T as alloc::string::SpecToString>::spec_to_string>
    0.00 :   c9362:  mov    0x50(%rsp),%r14
    0.00 :   c9367:  movups 0x58(%rsp),%xmm0
    0.00 :   c936c:  movaps %xmm0,0x20(%rsp)
    0.00 :   c9371:  lea    0x90(%rsp),%rdi
    0.00 :   c9379:  call   da590 <core::ptr::drop_in_place<zio::error::recovery::RecoveryFailure>>
    0.00 :   c937e:  jmp    c8eee <std::sys::backtrace::__rust_begin_short_backtrace+0x286e>
    0.00 :   c9383:  lea    0xc49fe(%rip),%rcx        # 18dd88 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x518>
    0.00 :   c938a:  mov    $0xb,%edx
    0.00 :   c938f:  xor    %edi,%edi
    0.00 :   c9391:  mov    %r15,%rsi
    0.00 :   c9394:  call   *0xc8fde(%rip)        # 192378 <_DYNAMIC+0x360>
    0.00 :   c939a:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c939f:  lea    0xc49fa(%rip),%rcx        # 18dda0 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x530>
    0.00 :   c93a6:  mov    %rdx,%rsi
    0.00 :   c93a9:  mov    $0xc,%edx
    0.00 :   c93ae:  xor    %edi,%edi
    0.00 :   c93b0:  call   *0xc8fc2(%rip)        # 192378 <_DYNAMIC+0x360>
    0.00 :   c93b6:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c93bb:  mov    $0x8,%edi
    0.00 :   c93c0:  mov    %r15,%rsi
    0.00 :   c93c3:  call   *0xc8ebf(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   c93c9:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c93ce:  mov    $0x35,%esi
    0.00 :   c93d3:  lea    -0xabb6f(%rip),%rax        # 1d86b <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x453>
    0.00 :   c93da:  mov    %rax,0x308(%rsp)
    0.00 :   c93e2:  lea    0xc49cf(%rip),%rax        # 18ddb8 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x548>
    0.00 :   c93e9:  mov    %rax,0x310(%rsp)
    0.00 :   c93f1:  mov    0x308(%rsp),%rdi
    0.00 :   c93f9:  mov    0x310(%rsp),%rdx
    0.00 :   c9401:  call   *0xc8f31(%rip)        # 192338 <_DYNAMIC+0x320>
    0.00 :   c9407:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c940c:  lea    -0xabbd0(%rip),%rdi        # 1d843 <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x42b>
    0.00 :   c9413:  lea    0xc4956(%rip),%rdx        # 18dd70 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x500>
    0.00 :   c941a:  mov    $0x28,%esi
    0.00 :   c941f:  call   *0xc8f13(%rip)        # 192338 <_DYNAMIC+0x320>
    0.00 :   c9425:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c942a:  lea    0x1a8(%rsp),%r15
    0.00 :   c9432:  mov    $0x8,%edi
    0.00 :   c9437:  mov    $0x78,%esi
    0.00 :   c943c:  call   *0xc8e46(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   c9442:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c9447:  lea    -0xabc2c(%rip),%rdi        # 1d822 <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x40a>
    0.00 :   c944e:  lea    0xc4903(%rip),%rdx        # 18dd58 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x4e8>
    0.00 :   c9455:  mov    $0x21,%esi
    0.00 :   c945a:  call   *0xc8ed8(%rip)        # 192338 <_DYNAMIC+0x320>
    0.00 :   c9460:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c9465:  mov    $0xb,%r13b
    0.00 :   c9468:  xor    %eax,%eax
    0.00 :   c946a:  jmp    c8dba <std::sys::backtrace::__rust_begin_short_backtrace+0x273a>
    0.00 :   c946f:  lea    0xc4912(%rip),%rcx        # 18dd88 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x518>
    0.00 :   c9476:  mov    $0xb,%edx
    0.00 :   c947b:  xor    %edi,%edi
    0.00 :   c947d:  mov    %r15,%rsi
    0.00 :   c9480:  call   *0xc8ef2(%rip)        # 192378 <_DYNAMIC+0x360>
    0.00 :   c9486:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c948b:  mov    $0xca,%edi
    0.00 :   c9490:  mov    %r15,%rsi
    0.00 :   c9493:  mov    $0x81,%edx
    0.00 :   c9498:  mov    $0x1,%ecx
    0.00 :   c949d:  xor    %eax,%eax
    0.00 :   c949f:  call   *0xc9133(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   c94a5:  jmp    c8eee <std::sys::backtrace::__rust_begin_short_backtrace+0x286e>
    0.00 :   c94aa:  lea    -0xac026(%rip),%rdi        # 1d48b <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x73>
    0.00 :   c94b1:  lea    0xc43d8(%rip),%rcx        # 18d890 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x20>
    0.00 :   c94b8:  lea    0xc4359(%rip),%r8        # 18d818 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0x118>
    0.00 :   c94bf:  lea    0x1f(%rsp),%rdx
    0.00 :   c94c4:  mov    $0x37,%esi
    0.00 :   c94c9:  call   *0xc8db1(%rip)        # 192280 <_DYNAMIC+0x268>
    0.00 :   c94cf:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c94d4:  call   *0xc90ee(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   c94da:  test   %al,%al
    0.00 :   c94dc:  jne    c8ee0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2860>
    0.00 :   c94e2:  movb   $0x1,0x4(%r15)
    0.00 :   c94e7:  jmp    c8ee0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2860>
    0.00 :   c94ec:  lea    0xc47ed(%rip),%rdi        # 18dce0 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x470>
    0.00 :   c94f3:  call   *0xc8f17(%rip)        # 192410 <_DYNAMIC+0x3f8>
    0.00 :   c94f9:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c94fe:  mov    $0x8,%edi
    0.00 :   c9503:  mov    $0x178,%esi
    0.00 :   c9508:  call   *0xc8d7a(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   c950e:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c9513:  lea    0xc480e(%rip),%rdi        # 18dd28 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x4b8>
    0.00 :   c951a:  call   *0xc8ef0(%rip)        # 192410 <_DYNAMIC+0x3f8>
    0.00 :   c9520:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c9525:  mov    $0x30,%esi
    0.00 :   c952a:  jmp    c93f1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2d71>
    0.00 :   c952f:  lea    -0xac0ab(%rip),%rdi        # 1d48b <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x73>
    0.00 :   c9536:  lea    0xc4353(%rip),%rcx        # 18d890 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x20>
    0.00 :   c953d:  lea    0xc42d4(%rip),%r8        # 18d818 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0x118>
    0.00 :   c9544:  lea    0x1f(%rsp),%rdx
    0.00 :   c9549:  mov    $0x37,%esi
    0.00 :   c954e:  call   *0xc8d2c(%rip)        # 192280 <_DYNAMIC+0x268>
    0.00 :   c9554:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c9559:  lea    0xc4948(%rip),%rdi        # 18dea8 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x638>
    0.00 :   c9560:  call   *0xc8eaa(%rip)        # 192410 <_DYNAMIC+0x3f8>
    0.00 :   c9566:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c956b:  mov    0x38(%rsp),%rax
    0.00 :   c9570:  mov    %rax,0x90(%rsp)
    0.00 :   c9578:  mov    0x30(%rsp),%eax
    0.00 :   c957c:  mov    %al,0x98(%rsp)
    0.00 :   c9583:  test   %al,%al
    0.00 :   c9585:  je     c9678 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ff8>
    0.00 :   c958b:  movzbl 0x30(%rsp),%eax
    0.00 :   c9590:  cmp    $0x1,%eax
    0.00 :   c9593:  jne    c95d6 <std::sys::backtrace::__rust_begin_short_backtrace+0x2f56>
    0.00 :   c9595:  cmpl   $0xffffffff,0x10(%rbp)
    0.00 :   c9599:  je     c963c <std::sys::backtrace::__rust_begin_short_backtrace+0x2fbc>
    0.00 :   c959f:  mov    0x8(%rbp),%edi
    0.00 :   c95a2:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c95a6:  setne  %al
    0.00 :   c95a9:  test   %edi,%edi
    0.00 :   c95ab:  setns  %cl
    0.00 :   c95ae:  and    %al,%cl
    0.00 :   c95b0:  cmp    $0x1,%cl
    0.00 :   c95b3:  jne    c95bb <std::sys::backtrace::__rust_begin_short_backtrace+0x2f3b>
    0.00 :   c95b5:  call   *0xc927d(%rip)        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c95bb:  movb   $0x2,0xe(%rbp)
    0.00 :   c95bf:  mov    0x280(%rsp),%eax
    0.00 :   c95c6:  mov    %eax,0x14(%rbp)
    0.00 :   c95c9:  mov    %r13d,0x280(%rsp)
    0.00 :   c95d1:  jmp    c9678 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ff8>
    0.00 :   c95d6:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c95da:  jne    c960f <std::sys::backtrace::__rust_begin_short_backtrace+0x2f8f>
    0.00 :   c95dc:  lea    0x90(%rsp),%rdi
    0.00 :   c95e4:  call   d7a40 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10657235172099788962>
    0.00 :   c95e9:  mov    $0xb,%r13b
    0.00 :   c95ec:  jmp    c967b <std::sys::backtrace::__rust_begin_short_backtrace+0x2ffb>
    0.00 :   c95f1:  lea    -0xaa6d8(%rip),%rdi        # 1ef20 <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962+0x2e1>
    0.00 :   c95f8:  lea    0xc5e91(%rip),%rdx        # 18f490 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x360>
    0.00 :   c95ff:  mov    $0xd,%esi
    0.00 :   c9604:  call   *0xc8e36(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   c960a:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c960f:  movb   $0x2,0xd(%rbp)
    0.00 :   c9613:  jmp    c9678 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ff8>
    0.00 :   c9615:  lea    -0xac191(%rip),%rdi        # 1d48b <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x73>
    0.00 :   c961c:  lea    0xc426d(%rip),%rcx        # 18d890 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x20>
    0.00 :   c9623:  lea    0xc41ee(%rip),%r8        # 18d818 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0x118>
    0.00 :   c962a:  lea    0x1f(%rsp),%rdx
    0.00 :   c962f:  mov    $0x37,%esi
    0.00 :   c9634:  call   *0xc8c46(%rip)        # 192280 <_DYNAMIC+0x268>
    0.00 :   c963a:  jmp    c96a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c963c:  mov    0x278(%rsp),%r14
    0.00 :   c9644:  inc    %r14
    0.00 :   c9647:  je     c95dc <std::sys::backtrace::__rust_begin_short_backtrace+0x2f5c>
    0.00 :   c9649:  mov    0x8(%rbp),%edi
    0.00 :   c964c:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c9650:  setne  %al
    0.00 :   c9653:  test   %edi,%edi
    0.00 :   c9655:  setns  %cl
    0.00 :   c9658:  and    %al,%cl
    0.00 :   c965a:  cmp    $0x1,%cl
    0.00 :   c965d:  jne    c9665 <std::sys::backtrace::__rust_begin_short_backtrace+0x2fe5>
    0.00 :   c965f:  call   *0xc91d3(%rip)        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c9665:  movb   $0x2,0xe(%rbp)
    0.00 :   c9669:  movl   $0xffffffff,0x14(%rbp)
    0.00 :   c9670:  mov    %r14,0x278(%rsp)
    0.00 :   c9678:  mov    $0x1,%r13b
    0.00 :   c967b:  mov    $0x5,%eax
    0.00 :   c9680:  xor    %ecx,%ecx
    0.00 :   c9682:  mov    0x30(%rsp),%edx
    0.00 :   c9686:  mov    0x38(%rsp),%rsi
    0.00 :   c968b:  jmp    c8dbc <std::sys::backtrace::__rust_begin_short_backtrace+0x273c>
    0.00 :   c9690:  mov    $0x8,%edi
    0.00 :   c9695:  mov    $0x20,%esi
    0.00 :   c969a:  call   *0xc8b70(%rip)        # 192210 <_DYNAMIC+0x1f8>
    0.00 :   c96a0:  ud2
    0.00 :   c96a2:  jmp    c96f6 <std::sys::backtrace::__rust_begin_short_backtrace+0x3076>
    0.00 :   c96a4:  jmp    c970e <std::sys::backtrace::__rust_begin_short_backtrace+0x308e>
    0.00 :   c96a6:  mov    %rax,%rbp
    0.00 :   c96a9:  cmpq   $0x0,0x50(%rsp)
    0.00 :   c96af:  je     c9798 <std::sys::backtrace::__rust_begin_short_backtrace+0x3118>
    0.00 :   c96b5:  jmp    c973d <std::sys::backtrace::__rust_begin_short_backtrace+0x30bd>
    0.00 :   c96ba:  mov    %rax,%rbp
    0.00 :   c96bd:  jmp    c9798 <std::sys::backtrace::__rust_begin_short_backtrace+0x3118>
    0.00 :   c96c2:  jmp    c96f6 <std::sys::backtrace::__rust_begin_short_backtrace+0x3076>
    0.00 :   c96c4:  jmp    c96f6 <std::sys::backtrace::__rust_begin_short_backtrace+0x3076>
    0.00 :   c96c6:  mov    %rax,%rbp
    0.00 :   c96c9:  lea    0x90(%rsp),%rdi
    0.00 :   c96d1:  call   da590 <core::ptr::drop_in_place<zio::error::recovery::RecoveryFailure>>
    0.00 :   c96d6:  jmp    c9988 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c96db:  jmp    c970e <std::sys::backtrace::__rust_begin_short_backtrace+0x308e>
    0.00 :   c96dd:  mov    %rax,%rbp
    0.00 :   c96e0:  jmp    c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c96e5:  jmp    c96f6 <std::sys::backtrace::__rust_begin_short_backtrace+0x3076>
    0.00 :   c96e7:  mov    %rax,%r13
    0.00 :   c96ea:  jmp    c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c96ef:  mov    %rax,%r13
    0.00 :   c96f2:  jmp    c9764 <std::sys::backtrace::__rust_begin_short_backtrace+0x30e4>
    0.00 :   c96f4:  jmp    c970e <std::sys::backtrace::__rust_begin_short_backtrace+0x308e>
    0.00 :   c96f6:  mov    %rax,%rbp
    0.00 :   c96f9:  jmp    c9988 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c96fe:  mov    %rax,%rbp
    0.00 :   c9701:  jmp    c9995 <std::sys::backtrace::__rust_begin_short_backtrace+0x3315>
    0.00 :   c9706:  mov    %rax,%r13
    0.00 :   c9709:  jmp    c9a10 <std::sys::backtrace::__rust_begin_short_backtrace+0x3390>
    0.00 :   c970e:  mov    %rax,%rbp
    0.00 :   c9711:  test   %r15d,%r15d
    0.00 :   c9714:  js     c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c971a:  mov    %r15d,%edi
    0.00 :   c971d:  call   *0xc9115(%rip)        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c9723:  jmp    c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c9728:  mov    %rax,%rbp
    0.00 :   c972b:  jmp    c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c9730:  mov    %rax,%r13
    0.00 :   c9733:  mov    $0x1,%bl
    0.00 :   c9735:  jmp    c98f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3270>
    0.00 :   c973a:  mov    %rax,%rbp
    0.00 :   c973d:  lea    0x50(%rsp),%rdi
    0.00 :   c9742:  call   d8520 <core::ptr::drop_in_place<vthread::readiness::Entry>>
    0.00 :   c9747:  jmp    c9798 <std::sys::backtrace::__rust_begin_short_backtrace+0x3118>
    0.00 :   c9749:  mov    %rax,%r13
    0.00 :   c974c:  mov    0x20(%rsp),%rdi
    0.00 :   c9751:  call   *0xc8af1(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c9757:  lea    0x400(%rsp),%rdi
    0.00 :   c975f:  call   d7850 <core::ptr::drop_in_place<zio::poll::Poll>>
    0.00 :   c9764:  mov    0x80(%rsp),%rax
    0.00 :   c976c:  lock decq (%rax)
    0.00 :   c9770:  jne    c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9776:  lea    0x320(%rsp),%rdi
    0.00 :   c977e:  call   *0xc9a1c(%rip)        # 1931a0 <_DYNAMIC+0x1188>
    0.00 :   c9784:  jmp    c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9789:  mov    %rbp,%rdi
    0.00 :   c978c:  mov    %rax,%rbp
    0.00 :   c978f:  movzbl %r12b,%esi
    0.00 :   c9793:  call   d5340 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::thread_failure::ThreadFailures>>>
    0.00 :   c9798:  lea    0x120(%rsp),%rdi
    0.00 :   c97a0:  call   d91e0 <core::ptr::drop_in_place<zio::wait_report::WaitReport>>
    0.00 :   c97a5:  jmp    c9988 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c97aa:  jmp    c98d1 <std::sys::backtrace::__rust_begin_short_backtrace+0x3251>
    0.00 :   c97af:  mov    %rax,%r13
    0.00 :   c97b2:  mov    $0x1,%bl
    0.00 :   c97b4:  jmp    c98fb <std::sys::backtrace::__rust_begin_short_backtrace+0x327b>
    0.00 :   c97b9:  mov    %rax,%rbp
    0.00 :   c97bc:  cmpq   $0x0,0x180(%rsp)
    0.00 :   c97c5:  je     c97d5 <std::sys::backtrace::__rust_begin_short_backtrace+0x3155>
    0.00 :   c97c7:  mov    0x188(%rsp),%rdi
    0.00 :   c97cf:  call   *0xc8a73(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c97d5:  cmpb   $0x1,0x160(%rsp)
    0.00 :   c97dd:  ja     c9988 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c97e3:  lea    0x168(%rsp),%rdi
    0.00 :   c97eb:  call   d7a40 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10657235172099788962>
    0.00 :   c97f0:  jmp    c9988 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c97f5:  mov    %rax,%rbp
    0.00 :   c97f8:  cmpq   $0x0,0x50(%rsp)
    0.00 :   c97fe:  je     c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c9804:  mov    0x58(%rsp),%rdi
    0.00 :   c9809:  jmp    c994d <std::sys::backtrace::__rust_begin_short_backtrace+0x32cd>
    0.00 :   c980e:  ud2
    0.00 :   c9810:  mov    %rax,%rbp
    0.00 :   c9813:  cmpq   $0x0,0x180(%rsp)
    0.00 :   c981c:  je     c982c <std::sys::backtrace::__rust_begin_short_backtrace+0x31ac>
    0.00 :   c981e:  mov    0x188(%rsp),%rdi
    0.00 :   c9826:  call   *0xc8a1c(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c982c:  cmpb   $0x1,0xa8(%rsp)
    0.00 :   c9834:  ja     c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c983a:  lea    0xb0(%rsp),%rdi
    0.00 :   c9842:  call   d7a40 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10657235172099788962>
    0.00 :   c9847:  jmp    c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c984c:  call   *0xc8c06(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   c9852:  mov    %rax,%r13
    0.00 :   c9855:  cmp    $0xffffffffffffffff,%r12
    0.00 :   c9859:  je     c986c <std::sys::backtrace::__rust_begin_short_backtrace+0x31ec>
    0.00 :   c985b:  lock decq 0x8(%r12)
    0.00 :   c9861:  jne    c986c <std::sys::backtrace::__rust_begin_short_backtrace+0x31ec>
    0.00 :   c9863:  mov    %r12,%rdi
    0.00 :   c9866:  call   *0xc89dc(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c986c:  mov    (%rbx),%rdi
    0.00 :   c986f:  mov    0x8(%rbx),%rsi
    0.00 :   c9873:  call   d65a0 <core::ptr::drop_in_place<std::sync::mpsc::SyncSender<core::result::Result<alloc::sync::Arc<vthread::readiness::Inner>,vthread::error::Error>>>>
    0.00 :   c9878:  jmp    c9ab1 <std::sys::backtrace::__rust_begin_short_backtrace+0x3431>
    0.00 :   c987d:  call   *0xc8bd5(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   c9883:  mov    %r15,%rdi
    0.00 :   c9886:  call   *0xc89bc(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c988c:  ud2
    0.00 :   c988e:  ud2
    0.00 :   c9890:  mov    %rax,%r13
    0.00 :   c9893:  jmp    c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9898:  mov    %rax,%rbp
    0.00 :   c989b:  cmpq   $0x0,0x120(%rsp)
    0.00 :   c98a4:  je     c98b4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3234>
    0.00 :   c98a6:  mov    0x128(%rsp),%rdi
    0.00 :   c98ae:  call   *0xc8994(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c98b4:  cmp    $0x1,%r13b
    0.00 :   c98b8:  ja     c98d4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3254>
    0.00 :   c98ba:  mov    %r14,%rdi
    0.00 :   c98bd:  call   d7a40 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10657235172099788962>
    0.00 :   c98c2:  jmp    c98d4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3254>
    0.00 :   c98c4:  call   *0xc8b8e(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   c98ca:  mov    %rax,%r13
    0.00 :   c98cd:  jmp    c9910 <std::sys::backtrace::__rust_begin_short_backtrace+0x3290>
    0.00 :   c98cf:  jmp    c9947 <std::sys::backtrace::__rust_begin_short_backtrace+0x32c7>
    0.00 :   c98d1:  mov    %rax,%rbp
    0.00 :   c98d4:  cmpq   $0x0,0x8(%rsp)
    0.00 :   c98da:  je     c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c98dc:  mov    0x10(%rsp),%rdi
    0.00 :   c98e1:  jmp    c994d <std::sys::backtrace::__rust_begin_short_backtrace+0x32cd>
    0.00 :   c98e3:  mov    %rax,%r13
    0.00 :   c98e6:  mov    %r15,%rdi
    0.00 :   c98e9:  call   d8550 <core::ptr::drop_in_place<vthread::readiness::Inner>>
    0.00 :   c98ee:  xor    %ebx,%ebx
    0.00 :   c98f0:  mov    0x20(%rsp),%rdi
    0.00 :   c98f5:  call   *0xc894d(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c98fb:  lea    0x248(%rsp),%rdi
    0.00 :   c9903:  call   d7850 <core::ptr::drop_in_place<zio::poll::Poll>>
    0.00 :   c9908:  test   %bl,%bl
    0.00 :   c990a:  je     c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9910:  cmp    $0xffffffffffffffff,%r12
    0.00 :   c9914:  je     c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c991a:  lock decq 0x8(%r12)
    0.00 :   c9920:  jne    c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9926:  mov    %r12,%rdi
    0.00 :   c9929:  call   *0xc8919(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c992f:  jmp    c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9934:  call   *0xc8b1e(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   c993a:  call   *0xc8b18(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   c9940:  jmp    c9947 <std::sys::backtrace::__rust_begin_short_backtrace+0x32c7>
    0.00 :   c9942:  mov    %rax,%rbp
    0.00 :   c9945:  jmp    c9953 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c9947:  mov    %rax,%rbp
    0.00 :   c994a:  mov    %r12,%rdi
    0.00 :   c994d:  call   *0xc88f5(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c9953:  mov    0x160(%rsp),%r15
    0.00 :   c995b:  cmpb   $0x0,0x168(%rsp)
    0.00 :   c9963:  jne    c997e <std::sys::backtrace::__rust_begin_short_backtrace+0x32fe>
    0.00 :   c9965:  mov    0xc8c3c(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c996c:  mov    (%rax),%rax
    0.00 :   c996f:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9979:  test   %rcx,%rax
    0.00 :   c997c:  jne    c99df <std::sys::backtrace::__rust_begin_short_backtrace+0x335f>
    0.00 :   c997e:  xor    %eax,%eax
    0.00 :   c9980:  xchg   %eax,(%r15)
    0.00 :   c9983:  cmp    $0x2,%eax
    0.00 :   c9986:  je     c99c3 <std::sys::backtrace::__rust_begin_short_backtrace+0x3343>
    0.00 :   c9988:  lea    0x100(%rsp),%rdi
    0.00 :   c9990:  call   d5480 <core::ptr::drop_in_place<alloc::collections::btree::map::BTreeMap<u64,zio::registration::Registration>>>
    0.00 :   c9995:  mov    %rbp,%rdi
    0.00 :   c9998:  call   *0xc9092(%rip)        # 192a30 <_DYNAMIC+0xa18>
    0.00 :   c999e:  mov    %rax,%rsi
    0.00 :   c99a1:  mov    0xc8c00(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   c99a8:  lock decq (%rax)
    0.00 :   c99ac:  decq   %fs:0xffffffffffffff70
    0.00 :   c99b5:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   c99be:  jmp    c8f2b <std::sys::backtrace::__rust_begin_short_backtrace+0x28ab>
    0.00 :   c99c3:  mov    $0xca,%edi
    0.00 :   c99c8:  mov    %r15,%rsi
    0.00 :   c99cb:  mov    $0x81,%edx
    0.00 :   c99d0:  mov    $0x1,%ecx
    0.00 :   c99d5:  xor    %eax,%eax
    0.00 :   c99d7:  call   *0xc8bfb(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   c99dd:  jmp    c9988 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c99df:  call   *0xc8be3(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   c99e5:  test   %al,%al
    0.00 :   c99e7:  jne    c997e <std::sys::backtrace::__rust_begin_short_backtrace+0x32fe>
    0.00 :   c99e9:  movb   $0x1,0x4(%r15)
    0.00 :   c99ee:  jmp    c997e <std::sys::backtrace::__rust_begin_short_backtrace+0x32fe>
    0.00 :   c99f0:  call   *0xc8a62(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   c99f6:  mov    %rax,%r13
    0.00 :   c99f9:  mov    $0x1,%bpl
    0.00 :   c99fc:  cmpq   $0x0,0x198(%rsp)
    0.00 :   c9a05:  je     c9a10 <std::sys::backtrace::__rust_begin_short_backtrace+0x3390>
    0.00 :   c9a07:  mov    %r14,%rdi
    0.00 :   c9a0a:  call   *0xc8838(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c9a10:  cmpq   $0x0,0x330(%rsp)
    0.00 :   c9a19:  je     c9a29 <std::sys::backtrace::__rust_begin_short_backtrace+0x33a9>
    0.00 :   c9a1b:  mov    0x338(%rsp),%rdi
    0.00 :   c9a23:  call   *0xc881f(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c9a29:  test   %bpl,%bpl
    0.00 :   c9a2c:  je     c9a80 <std::sys::backtrace::__rust_begin_short_backtrace+0x3400>
    0.00 :   c9a2e:  mov    0x2c8(%rsp),%edi
    0.00 :   c9a35:  call   *0xc8dfd(%rip)        # 192838 <close@GLIBC_2.2.5>
    0.00 :   c9a3b:  mov    0x260(%rsp),%r15
    0.00 :   c9a43:  mov    0x268(%rsp),%r14
    0.00 :   c9a4b:  test   %r14,%r14
    0.00 :   c9a4e:  jne    c9ab9 <std::sys::backtrace::__rust_begin_short_backtrace+0x3439>
    0.00 :   c9a50:  cmpq   $0x0,0x258(%rsp)
    0.00 :   c9a59:  je     c9a64 <std::sys::backtrace::__rust_begin_short_backtrace+0x33e4>
    0.00 :   c9a5b:  mov    %r15,%rdi
    0.00 :   c9a5e:  call   *0xc87e4(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   c9a64:  mov    0x290(%rsp),%rax
    0.00 :   c9a6c:  lock decq (%rax)
    0.00 :   c9a70:  jne    c9a80 <std::sys::backtrace::__rust_begin_short_backtrace+0x3400>
    0.00 :   c9a72:  lea    0x290(%rsp),%rdi
    0.00 :   c9a7a:  call   *0xc9728(%rip)        # 1931a8 <_DYNAMIC+0x1190>
    0.00 :   c9a80:  mov    0x80(%rsp),%rax
    0.00 :   c9a88:  lock decq (%rax)
    0.00 :   c9a8c:  jne    c9a9c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9a8e:  lea    0x328(%rsp),%rdi
    0.00 :   c9a96:  call   *0xc9704(%rip)        # 1931a0 <_DYNAMIC+0x1188>
    0.00 :   c9a9c:  mov    0x238(%rsp),%rdi
    0.00 :   c9aa4:  mov    0x240(%rsp),%rsi
    0.00 :   c9aac:  call   d65a0 <core::ptr::drop_in_place<std::sync::mpsc::SyncSender<core::result::Result<alloc::sync::Arc<vthread::readiness::Inner>,vthread::error::Error>>>>
    0.00 :   c9ab1:  mov    %r13,%rdi
    0.00 :   c9ab4:  call   187ca0 <_Unwind_Resume@plt>
    0.00 :   c9ab9:  lea    0xe(%r15),%r12
    0.00 :   c9abd:  jmp    c9acd <std::sys::backtrace::__rust_begin_short_backtrace+0x344d>
    0.00 :   c9abf:  nop
    0.00 :   c9ac0:  add    $0x18,%r12
    0.00 :   c9ac4:  dec    %r14
    0.00 :   c9ac7:  je     c9a50 <std::sys::backtrace::__rust_begin_short_backtrace+0x33d0>
    0.00 :   c9acd:  mov    -0x6(%r12),%edi
    0.00 :   c9ad2:  cmpb   $0x2,(%r12)
    0.00 :   c9ad7:  setne  %al
    0.00 :   c9ada:  test   %edi,%edi
    0.00 :   c9adc:  setns  %cl
    0.00 :   c9adf:  and    %al,%cl
    0.00 :   c9ae1:  cmp    $0x1,%cl
    0.00 :   c9ae4:  jne    c9ac0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3440>
    0.00 :   c9ae6:  call   *%rbx
    0.00 :   c9ae8:  jmp    c9ac0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3440>
    0.00 :   c9aea:  call   *0xc8968(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   c9af0:  call   *0xc8962(%rip)        # 192458 <_DYNAMIC+0x440>
 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (5 samples, percent: global period)
---------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000cc700 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   cc700:  push   %rbp
    0.00 :   cc701:  push   %r15
    0.00 :   cc703:  push   %r14
    0.00 :   cc705:  push   %r13
    0.00 :   cc707:  push   %r12
    0.00 :   cc709:  push   %rbx
    0.00 :   cc70a:  sub    $0xc8,%rsp
    0.00 :   cc711:  mov    %rdi,0x78(%rsp)
    0.00 :   cc716:  mov    (%rdi),%rbp
    0.00 :   cc719:  mov    0x8(%rdi),%rax
    0.00 :   cc71d:  mov    %rax,0x8(%rsp)
    0.00 :   cc722:  test   %rbp,%rbp
    0.00 :   cc725:  mov    %rbp,0x10(%rsp)
    0.00 :   cc72a:  je     cca86 <std::sys::backtrace::__rust_begin_short_backtrace+0x386>
    0.00 :   cc730:  cmp    $0x1,%ebp
    0.00 :   cc733:  jne    cce1e <std::sys::backtrace::__rust_begin_short_backtrace+0x71e>
    0.00 :   cc739:  movl   $0x3b9aca00,0x88(%rsp)
    0.00 :   cc744:  mov    %fs:0x0,%r14
    0.00 :   cc74d:  lea    -0x68(%r14),%r14
    0.00 :   cc754:  xorps  %xmm0,%xmm0
    0.00 :   cc757:  movaps %xmm0,0x30(%rsp)
    0.00 :   cc75c:  movaps %xmm0,0x20(%rsp)
    0.00 :   cc761:  movq   $0x0,0x40(%rsp)
    0.00 :   cc76a:  xor    %eax,%eax
    0.00 :   cc76c:  jmp    cc77a <std::sys::backtrace::__rust_begin_short_backtrace+0x7a>
    0.00 :   cc76e:  xchg   %ax,%ax
    0.00 :   cc770:  call   *0xc6002(%rip)        # 192778 <sched_yield@GLIBC_2.2.5>
    0.00 :   cc776:  inc    %ebx
    0.00 :   cc778:  mov    %ebx,%eax
    0.00 :   cc77a:  mov    %eax,%ebx
    0.00 :   cc77c:  mov    0x8(%rsp),%rcx
    0.00 :   cc781:  mov    (%rcx),%rax
    0.00 :   cc784:  mov    0x8(%rcx),%r12
    0.00 :   cc788:  mov    %rax,%rcx
    0.00 :   cc78b:  shr    %rcx
    0.00 :   cc78e:  mov    %ecx,%r15d
    0.00 :   cc791:  and    $0x1f,%r15d
    0.00 :   cc795:  cmp    $0x1f,%r15
    0.00 :   cc799:  jne    cc7f0 <std::sys::backtrace::__rust_begin_short_backtrace+0xf0>
    0.00 :   cc79b:  cmp    $0x7,%ebx
    0.00 :   cc79e:  jae    cc770 <std::sys::backtrace::__rust_begin_short_backtrace+0x70>
    0.00 :   cc7a0:  test   %ebx,%ebx
    0.00 :   cc7a2:  je     cc776 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc7a4:  mov    %ebx,%ecx
    0.00 :   cc7a6:  imul   %ebx,%ecx
    0.00 :   cc7a9:  mov    %ecx,%eax
    0.00 :   cc7ab:  and    $0x5,%eax
    0.00 :   cc7ae:  cmp    $0x8,%ecx
    0.00 :   cc7b1:  jb     cc7e0 <std::sys::backtrace::__rust_begin_short_backtrace+0xe0>
    0.00 :   cc7b3:  and    $0x38,%ecx
    0.00 :   cc7b6:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cc7c0:  pause
    0.00 :   cc7c2:  pause
    0.00 :   cc7c4:  pause
    0.00 :   cc7c6:  pause
    0.00 :   cc7c8:  pause
    0.00 :   cc7ca:  pause
    0.00 :   cc7cc:  pause
    0.00 :   cc7ce:  pause
    0.00 :   cc7d0:  add    $0xfffffff8,%ecx
    0.00 :   cc7d3:  jne    cc7c0 <std::sys::backtrace::__rust_begin_short_backtrace+0xc0>
    0.00 :   cc7d5:  test   %eax,%eax
    0.00 :   cc7d7:  je     cc776 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc7d9:  nopl   0x0(%rax)
    0.00 :   cc7e0:  pause
    0.00 :   cc7e2:  dec    %eax
    0.00 :   cc7e4:  jne    cc7e0 <std::sys::backtrace::__rust_begin_short_backtrace+0xe0>
    0.00 :   cc7e6:  jmp    cc776 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc7e8:  nopl   0x0(%rax,%rax,1)
    0.00 :   cc7f0:  lea    0x2(%rax),%r13
    0.00 :   cc7f4:  test   $0x1,%al
    0.00 :   cc7f6:  jne    cc828 <std::sys::backtrace::__rust_begin_short_backtrace+0x128>
    0.00 :   cc7f8:  lock orl $0x0,-0x40(%rsp)
    0.00 :   cc7fe:  mov    0x8(%rsp),%rdx
    0.00 :   cc803:  mov    0x80(%rdx),%rdx
    0.00 :   cc80a:  mov    %rdx,%rsi
    0.00 :   cc80d:  shr    %rsi
    0.00 :   cc810:  cmp    %rsi,%rcx
    0.00 :   cc813:  je     cc8f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   cc819:  xor    %rax,%rdx
    0.00 :   cc81c:  xor    %ecx,%ecx
    0.00 :   cc81e:  cmp    $0x40,%rdx
    0.00 :   cc822:  setae  %cl
    0.00 :   cc825:  or     %rcx,%r13
    0.00 :   cc828:  test   %r12,%r12
    0.00 :   cc82b:  je     cc89b <std::sys::backtrace::__rust_begin_short_backtrace+0x19b>
    0.00 :   cc82d:  mov    0x8(%rsp),%rcx
    0.00 :   cc832:  lock cmpxchg %r13,(%rcx)
    0.00 :   cc837:  je     cd065 <std::sys::backtrace::__rust_begin_short_backtrace+0x965>
    0.00 :   cc83d:  cmp    $0x6,%ebx
    0.00 :   cc840:  mov    $0x6,%ecx
    0.00 :   cc845:  cmovb  %ebx,%ecx
    0.00 :   cc848:  mov    $0x1,%eax
    0.00 :   cc84d:  test   %ebx,%ebx
    0.00 :   cc84f:  je     cc77a <std::sys::backtrace::__rust_begin_short_backtrace+0x7a>
    0.00 :   cc855:  imul   %ecx,%ecx
    0.00 :   cc858:  mov    %ecx,%eax
    0.00 :   cc85a:  and    $0x5,%eax
    0.00 :   cc85d:  cmp    $0x8,%ecx
    0.00 :   cc860:  jb     cc890 <std::sys::backtrace::__rust_begin_short_backtrace+0x190>
    0.00 :   cc862:  and    $0x38,%ecx
    0.00 :   cc865:  data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cc870:  pause
    0.00 :   cc872:  pause
    0.00 :   cc874:  pause
    0.00 :   cc876:  pause
    0.00 :   cc878:  pause
    0.00 :   cc87a:  pause
    0.00 :   cc87c:  pause
    0.00 :   cc87e:  pause
    0.00 :   cc880:  add    $0xfffffff8,%ecx
    0.00 :   cc883:  jne    cc870 <std::sys::backtrace::__rust_begin_short_backtrace+0x170>
    0.00 :   cc885:  test   %eax,%eax
    0.00 :   cc887:  je     cc776 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc88d:  nopl   (%rax)
    0.00 :   cc890:  pause
    0.00 :   cc892:  dec    %eax
    0.00 :   cc894:  jne    cc890 <std::sys::backtrace::__rust_begin_short_backtrace+0x190>
    0.00 :   cc896:  jmp    cc776 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc89b:  cmp    $0x7,%ebx
    0.00 :   cc89e:  jae    cc770 <std::sys::backtrace::__rust_begin_short_backtrace+0x70>
    0.00 :   cc8a4:  test   %ebx,%ebx
    0.00 :   cc8a6:  je     cc776 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc8ac:  mov    %ebx,%ecx
    0.00 :   cc8ae:  imul   %ebx,%ecx
    0.00 :   cc8b1:  mov    %ecx,%eax
    0.00 :   cc8b3:  and    $0x5,%eax
    0.00 :   cc8b6:  cmp    $0x8,%ecx
    0.00 :   cc8b9:  jb     cc8e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1e0>
    0.00 :   cc8bb:  and    $0x38,%ecx
    0.00 :   cc8be:  xchg   %ax,%ax
    0.00 :   cc8c0:  pause
    0.00 :   cc8c2:  pause
    0.00 :   cc8c4:  pause
    0.00 :   cc8c6:  pause
    0.00 :   cc8c8:  pause
    0.00 :   cc8ca:  pause
    0.00 :   cc8cc:  pause
    0.00 :   cc8ce:  pause
    0.00 :   cc8d0:  add    $0xfffffff8,%ecx
    0.00 :   cc8d3:  jne    cc8c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c0>
    0.00 :   cc8d5:  test   %eax,%eax
    0.00 :   cc8d7:  je     cc776 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc8dd:  nopl   (%rax)
    0.00 :   cc8e0:  pause
    0.00 :   cc8e2:  dec    %eax
    0.00 :   cc8e4:  jne    cc8e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1e0>
    0.00 :   cc8e6:  jmp    cc776 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc8eb:  nopl   0x0(%rax,%rax,1)
    0.00 :   cc8f0:  test   $0x1,%dl
    0.00 :   cc8f3:  jne    cd96f <std::sys::backtrace::__rust_begin_short_backtrace+0x126f>
    0.00 :   cc8f9:  mov    0x88(%rsp),%ebx
    0.00 :   cc900:  cmp    $0x3b9aca00,%ebx
    0.00 :   cc906:  je     cc931 <std::sys::backtrace::__rust_begin_short_backtrace+0x231>
    0.00 :   cc908:  mov    0x80(%rsp),%r15
    0.00 :   cc910:  mov    $0x1,%edi
    0.00 :   cc915:  call   a17e0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   cc91a:  cmp    %r15,%rax
    0.00 :   cc91d:  jne    cc928 <std::sys::backtrace::__rust_begin_short_backtrace+0x228>
    0.00 :   cc91f:  cmp    %ebx,%edx
    0.00 :   cc921:  jb     cc931 <std::sys::backtrace::__rust_begin_short_backtrace+0x231>
    0.00 :   cc923:  jmp    cd9e8 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e8>
    0.00 :   cc928:  cmp    %r15,%rax
    0.00 :   cc92b:  jge    cd9e8 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e8>
    0.00 :   cc931:  lea    0x20(%rsp),%rax
    0.00 :   cc936:  mov    %rax,0x90(%rsp)
    0.00 :   cc93e:  mov    0x8(%rsp),%rax
    0.00 :   cc943:  mov    %rax,0x98(%rsp)
    0.00 :   cc94b:  lea    0x80(%rsp),%rax
    0.00 :   cc953:  mov    %rax,0xa0(%rsp)
    0.00 :   cc95b:  mov    $0xffffffffffffff98,%rax
    0.00 :   cc962:  cmpb   $0x1,%fs:0x8(%rax)
    0.00 :   cc967:  mov    %r14,%r15
    0.00 :   cc96a:  jne    cc9fe <std::sys::backtrace::__rust_begin_short_backtrace+0x2fe>
    0.00 :   cc970:  mov    (%r15),%r12
    0.00 :   cc973:  movq   $0x0,(%r15)
    0.00 :   cc97a:  test   %r12,%r12
    0.00 :   cc97d:  je     cca24 <std::sys::backtrace::__rust_begin_short_backtrace+0x324>
    0.00 :   cc983:  mov    %r12,0x18(%rsp)
    0.00 :   cc988:  movq   $0x0,0x18(%r12)
    0.00 :   cc991:  movq   $0x0,0x20(%r12)
    0.00 :   cc99a:  movq   $0x0,0x90(%rsp)
    0.00 :   cc9a6:  lea    0x20(%rsp),%rax
    0.00 :   cc9ab:  mov    %rax,0x50(%rsp)
    0.00 :   cc9b0:  lea    0x98(%rsp),%rax
    0.00 :   cc9b8:  movups (%rax),%xmm0
    0.00 :   cc9bb:  lea    0x58(%rsp),%rax
    0.00 :   cc9c0:  movups %xmm0,(%rax)
    0.00 :   cc9c3:  lea    0x50(%rsp),%rdi
    0.00 :   cc9c8:  mov    %r12,%rsi
    0.00 :   cc9cb:  call   cfa60 <std::sync::mpmc::list::Channel<T>::recv::{{closure}}>
    0.00 :   cc9d0:  mov    (%r15),%rax
    0.00 :   cc9d3:  mov    %rax,0x50(%rsp)
    0.00 :   cc9d8:  mov    %r12,(%r15)
    0.00 :   cc9db:  test   %rax,%rax
    0.00 :   cc9de:  je     cc76a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc9e4:  lock decq (%rax)
    0.00 :   cc9e8:  jne    cc76a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc9ee:  lea    0x50(%rsp),%rdi
    0.00 :   cc9f3:  call   *0xc674f(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   cc9f9:  jmp    cc76a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc9fe:  mov    %r14,%rdi
    0.00 :   cca01:  call   c64f0 <std::sys::thread_local::native::lazy::Storage<T,D>::get_or_init_slow>
    0.00 :   cca06:  mov    %rax,%r15
    0.00 :   cca09:  test   %rax,%rax
    0.00 :   cca0c:  jne    cc970 <std::sys::backtrace::__rust_begin_short_backtrace+0x270>
    0.00 :   cca12:  lea    0x90(%rsp),%rdi
    0.00 :   cca1a:  call   d1ac0 <std::sync::mpmc::context::Context::with::{{closure}}>
    0.00 :   cca1f:  jmp    cc76a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cca24:  call   *0xc634e(%rip)        # 192d78 <_DYNAMIC+0xd60>
    0.00 :   cca2a:  mov    %rax,%r15
    0.00 :   cca2d:  mov    %rax,0x18(%rsp)
    0.00 :   cca32:  movq   $0x0,0x90(%rsp)
    0.00 :   cca3e:  lea    0x20(%rsp),%rax
    0.00 :   cca43:  mov    %rax,0x50(%rsp)
    0.00 :   cca48:  mov    0x8(%rsp),%rax
    0.00 :   cca4d:  mov    %rax,0x58(%rsp)
    0.00 :   cca52:  lea    0x80(%rsp),%rax
    0.00 :   cca5a:  mov    %rax,0x60(%rsp)
    0.00 :   cca5f:  lea    0x50(%rsp),%rdi
    0.00 :   cca64:  mov    %r15,%rsi
    0.00 :   cca67:  call   cfa60 <std::sync::mpmc::list::Channel<T>::recv::{{closure}}>
    0.00 :   cca6c:  lock decq (%r15)
    0.00 :   cca70:  jne    cc76a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cca76:  lea    0x18(%rsp),%rdi
    0.00 :   cca7b:  call   *0xc66c7(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   cca81:  jmp    cc76a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cca86:  movl   $0x3b9aca00,0x88(%rsp)
    0.00 :   cca91:  mov    %fs:0x0,%r12
    0.00 :   cca9a:  add    $0xffffffffffffff98,%r12
    0.00 :   ccaa1:  xorps  %xmm0,%xmm0
    0.00 :   ccaa4:  movaps %xmm0,0x30(%rsp)
    0.00 :   ccaa9:  movaps %xmm0,0x20(%rsp)
    0.00 :   ccaae:  movq   $0x0,0x40(%rsp)
    0.00 :   ccab7:  lea    0x80(%rsp),%r15
    0.00 :   ccabf:  mov    0xc62b2(%rip),%rbx        # 192d78 <_DYNAMIC+0xd60>
    0.00 :   ccac6:  mov    0xc5cab(%rip),%r13        # 192778 <sched_yield@GLIBC_2.2.5>
    0.00 :   ccacd:  xor    %eax,%eax
    0.00 :   ccacf:  jmp    ccae4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e4>
    0.00 :   ccad1:  call   *%r13
    0.00 :   ccad4:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   ccae0:  inc    %ebp
    0.00 :   ccae2:  mov    %ebp,%eax
    0.00 :   ccae4:  mov    %eax,%ebp
    0.00 :   ccae6:  mov    0x8(%rsp),%r9
    0.00 :   ccaeb:  mov    (%r9),%rcx
    0.00 :   ccaee:  mov    0x190(%r9),%rdx
    0.00 :   ccaf5:  mov    0x198(%r9),%rsi
    0.00 :   ccafc:  dec    %rdx
    0.00 :   ccaff:  xor    %eax,%eax
    0.00 :   ccb01:  sub    0x188(%r9),%rax
    0.00 :   ccb08:  and    %rcx,%rdx
    0.00 :   ccb0b:  mov    (%rsi,%rdx,8),%rdi
    0.00 :   ccb0f:  lea    0x1(%rcx),%r8
    0.00 :   ccb13:  cmp    %rdi,%r8
    0.00 :   ccb16:  jne    ccba0 <std::sys::backtrace::__rust_begin_short_backtrace+0x4a0>
    0.00 :   ccb1c:  lea    0x1(%rdx),%r8
    0.00 :   ccb20:  cmp    0x180(%r9),%r8
    0.00 :   ccb27:  jb     ccb36 <std::sys::backtrace::__rust_begin_short_backtrace+0x436>
    0.00 :   ccb29:  and    %rcx,%rax
    0.00 :   ccb2c:  add    0x188(%r9),%rax
    0.00 :   ccb33:  mov    %rax,%rdi
    0.00 :   ccb36:  mov    %rcx,%rax
    0.00 :   ccb39:  lock cmpxchg %rdi,(%r9)
    0.00 :   ccb3e:  je     cd02d <std::sys::backtrace::__rust_begin_short_backtrace+0x92d>
    0.00 :   ccb44:  cmp    $0x6,%ebp
    0.00 :   ccb47:  mov    $0x6,%ecx
    0.00 :   ccb4c:  cmovb  %ebp,%ecx
    0.00 :   ccb4f:  mov    $0x1,%eax
    0.00 :   ccb54:  test   %ebp,%ebp
    0.00 :   ccb56:  je     ccae4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e4>
    0.00 :   ccb58:  imul   %ecx,%ecx
    0.00 :   ccb5b:  mov    %ecx,%eax
    0.00 :   ccb5d:  and    $0x5,%eax
    0.00 :   ccb60:  cmp    $0x8,%ecx
    0.00 :   ccb63:  jb     ccb90 <std::sys::backtrace::__rust_begin_short_backtrace+0x490>
    0.00 :   ccb65:  and    $0x38,%ecx
    0.00 :   ccb68:  nopl   0x0(%rax,%rax,1)
    0.00 :   ccb70:  pause
    0.00 :   ccb72:  pause
    0.00 :   ccb74:  pause
    0.00 :   ccb76:  pause
    0.00 :   ccb78:  pause
    0.00 :   ccb7a:  pause
    0.00 :   ccb7c:  pause
    0.00 :   ccb7e:  pause
    0.00 :   ccb80:  add    $0xfffffff8,%ecx
    0.00 :   ccb83:  jne    ccb70 <std::sys::backtrace::__rust_begin_short_backtrace+0x470>
    0.00 :   ccb85:  test   %eax,%eax
    0.00 :   ccb87:  je     ccae0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   ccb8d:  nopl   (%rax)
    0.00 :   ccb90:  pause
    0.00 :   ccb92:  dec    %eax
    0.00 :   ccb94:  jne    ccb90 <std::sys::backtrace::__rust_begin_short_backtrace+0x490>
    0.00 :   ccb96:  jmp    ccae0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   ccb9b:  nopl   0x0(%rax,%rax,1)
    0.00 :   ccba0:  cmp    %rcx,%rdi
    0.00 :   ccba3:  jne    ccc30 <std::sys::backtrace::__rust_begin_short_backtrace+0x530>
    0.00 :   ccba9:  lock orl $0x0,-0x40(%rsp)
    0.00 :   ccbaf:  mov    0x8(%rsp),%rdx
    0.00 :   ccbb4:  mov    0x80(%rdx),%rax
    0.00 :   ccbbb:  mov    0x190(%rdx),%rdx
    0.00 :   ccbc2:  mov    %rdx,%rsi
    0.00 :   ccbc5:  not    %rsi
    0.00 :   ccbc8:  and    %rax,%rsi
    0.00 :   ccbcb:  cmp    %rcx,%rsi
    0.00 :   ccbce:  je     ccc8b <std::sys::backtrace::__rust_begin_short_backtrace+0x58b>
    0.00 :   ccbd4:  cmp    $0x6,%ebp
    0.00 :   ccbd7:  mov    $0x6,%ecx
    0.00 :   ccbdc:  cmovb  %ebp,%ecx
    0.00 :   ccbdf:  mov    $0x1,%eax
    0.00 :   ccbe4:  test   %ebp,%ebp
    0.00 :   ccbe6:  je     ccae4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e4>
    0.00 :   ccbec:  imul   %ecx,%ecx
    0.00 :   ccbef:  mov    %ecx,%eax
    0.00 :   ccbf1:  and    $0x5,%eax
    0.00 :   ccbf4:  cmp    $0x8,%ecx
    0.00 :   ccbf7:  jb     ccc20 <std::sys::backtrace::__rust_begin_short_backtrace+0x520>
    0.00 :   ccbf9:  and    $0x38,%ecx
    0.00 :   ccbfc:  nopl   0x0(%rax)
    0.00 :   ccc00:  pause
    0.00 :   ccc02:  pause
    0.00 :   ccc04:  pause
    0.00 :   ccc06:  pause
    0.00 :   ccc08:  pause
    0.00 :   ccc0a:  pause
    0.00 :   ccc0c:  pause
    0.00 :   ccc0e:  pause
    0.00 :   ccc10:  add    $0xfffffff8,%ecx
    0.00 :   ccc13:  jne    ccc00 <std::sys::backtrace::__rust_begin_short_backtrace+0x500>
    0.00 :   ccc15:  test   %eax,%eax
    0.00 :   ccc17:  je     ccae0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   ccc1d:  nopl   (%rax)
    0.00 :   ccc20:  pause
    0.00 :   ccc22:  dec    %eax
    0.00 :   ccc24:  jne    ccc20 <std::sys::backtrace::__rust_begin_short_backtrace+0x520>
    0.00 :   ccc26:  jmp    ccae0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   ccc2b:  nopl   0x0(%rax,%rax,1)
    0.00 :   ccc30:  cmp    $0x7,%ebp
    0.00 :   ccc33:  jae    ccad1 <std::sys::backtrace::__rust_begin_short_backtrace+0x3d1>
    0.00 :   ccc39:  test   %ebp,%ebp
    0.00 :   ccc3b:  je     ccae0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   ccc41:  mov    %ebp,%ecx
    0.00 :   ccc43:  imul   %ebp,%ecx
    0.00 :   ccc46:  mov    %ecx,%eax
    0.00 :   ccc48:  and    $0x5,%eax
    0.00 :   ccc4b:  cmp    $0x8,%ecx
    0.00 :   ccc4e:  jb     ccc80 <std::sys::backtrace::__rust_begin_short_backtrace+0x580>
    0.00 :   ccc50:  and    $0x38,%ecx
    0.00 :   ccc53:  data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   ccc60:  pause
    0.00 :   ccc62:  pause
    0.00 :   ccc64:  pause
    0.00 :   ccc66:  pause
    0.00 :   ccc68:  pause
    0.00 :   ccc6a:  pause
    0.00 :   ccc6c:  pause
    0.00 :   ccc6e:  pause
    0.00 :   ccc70:  add    $0xfffffff8,%ecx
    0.00 :   ccc73:  jne    ccc60 <std::sys::backtrace::__rust_begin_short_backtrace+0x560>
    0.00 :   ccc75:  test   %eax,%eax
    0.00 :   ccc77:  je     ccae0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   ccc7d:  nopl   (%rax)
    0.00 :   ccc80:  pause
    0.00 :   ccc82:  dec    %eax
    0.00 :   ccc84:  jne    ccc80 <std::sys::backtrace::__rust_begin_short_backtrace+0x580>
    0.00 :   ccc86:  jmp    ccae0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   ccc8b:  test   %rax,%rdx
    0.00 :   ccc8e:  jne    cd96f <std::sys::backtrace::__rust_begin_short_backtrace+0x126f>
    0.00 :   ccc94:  mov    0x88(%rsp),%ebp
    0.00 :   ccc9b:  cmp    $0x3b9aca00,%ebp
    0.00 :   ccca1:  je     cccd5 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d5>
    0.00 :   ccca3:  mov    %r15,%r14
    0.00 :   ccca6:  mov    0x80(%rsp),%r15
    0.00 :   cccae:  mov    $0x1,%edi
    0.00 :   cccb3:  call   a17e0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   cccb8:  cmp    %r15,%rax
    0.00 :   cccbb:  jne    cccc9 <std::sys::backtrace::__rust_begin_short_backtrace+0x5c9>
    0.00 :   cccbd:  cmp    %ebp,%edx
    0.00 :   cccbf:  mov    %r14,%r15
    0.00 :   cccc2:  jb     cccd5 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d5>
    0.00 :   cccc4:  jmp    cd9e8 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e8>
    0.00 :   cccc9:  cmp    %r15,%rax
    0.00 :   ccccc:  mov    %r14,%r15
    0.00 :   ccccf:  jge    cd9e8 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e8>
    0.00 :   cccd5:  lea    0x20(%rsp),%rax
    0.00 :   cccda:  mov    %rax,0x90(%rsp)
    0.00 :   ccce2:  mov    0x8(%rsp),%rax
    0.00 :   ccce7:  mov    %rax,0x98(%rsp)
    0.00 :   cccef:  mov    %r15,%r14
    0.00 :   cccf2:  mov    %r15,0xa0(%rsp)
    0.00 :   cccfa:  mov    $0xffffffffffffff98,%rax
    0.00 :   ccd01:  cmpb   $0x1,%fs:0x8(%rax)
    0.00 :   ccd06:  mov    %r12,%r15
    0.00 :   ccd09:  jne    ccd9e <std::sys::backtrace::__rust_begin_short_backtrace+0x69e>
    0.00 :   ccd0f:  mov    (%r15),%rbp
    0.00 :   ccd12:  movq   $0x0,(%r15)
    0.00 :   ccd19:  test   %rbp,%rbp
    0.00 :   ccd1c:  je     ccdc1 <std::sys::backtrace::__rust_begin_short_backtrace+0x6c1>
    0.00 :   ccd22:  mov    %rbp,0x18(%rsp)
    0.00 :   ccd27:  movq   $0x0,0x18(%rbp)
    0.00 :   ccd2f:  movq   $0x0,0x20(%rbp)
    0.00 :   ccd37:  movq   $0x0,0x90(%rsp)
    0.00 :   ccd43:  lea    0x20(%rsp),%rax
    0.00 :   ccd48:  mov    %rax,0x50(%rsp)
    0.00 :   ccd4d:  lea    0x98(%rsp),%rax
    0.00 :   ccd55:  movups (%rax),%xmm0
    0.00 :   ccd58:  lea    0x58(%rsp),%rax
    0.00 :   ccd5d:  movups %xmm0,(%rax)
    0.00 :   ccd60:  lea    0x50(%rsp),%rdi
    0.00 :   ccd65:  mov    %rbp,%rsi
    0.00 :   ccd68:  call   d11f0 <std::sync::mpmc::array::Channel<T>::recv::{{closure}}>
    0.00 :   ccd6d:  mov    (%r15),%rax
    0.00 :   ccd70:  mov    %rax,0x50(%rsp)
    0.00 :   ccd75:  mov    %rbp,(%r15)
    0.00 :   ccd78:  test   %rax,%rax
    0.00 :   ccd7b:  je     cce16 <std::sys::backtrace::__rust_begin_short_backtrace+0x716>
    0.00 :   ccd81:  lock decq (%rax)
    0.00 :   ccd85:  jne    cce16 <std::sys::backtrace::__rust_begin_short_backtrace+0x716>
    0.00 :   ccd8b:  lea    0x50(%rsp),%rdi
    0.00 :   ccd90:  call   *0xc63b2(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   ccd96:  mov    %r14,%r15
    0.00 :   ccd99:  jmp    ccacd <std::sys::backtrace::__rust_begin_short_backtrace+0x3cd>
    0.00 :   ccd9e:  mov    %r12,%rdi
    0.00 :   ccda1:  call   c64f0 <std::sys::thread_local::native::lazy::Storage<T,D>::get_or_init_slow>
    0.00 :   ccda6:  mov    %rax,%r15
    0.00 :   ccda9:  test   %rax,%rax
    0.00 :   ccdac:  jne    ccd0f <std::sys::backtrace::__rust_begin_short_backtrace+0x60f>
    0.00 :   ccdb2:  lea    0x90(%rsp),%rdi
    0.00 :   ccdba:  call   d1980 <std::sync::mpmc::context::Context::with::{{closure}}>
    0.00 :   ccdbf:  jmp    cce16 <std::sys::backtrace::__rust_begin_short_backtrace+0x716>
    0.00 :   ccdc1:  call   *%rbx
    0.00 :   ccdc3:  mov    %rax,%r15
    0.00 :   ccdc6:  mov    %rax,0x18(%rsp)
    0.00 :   ccdcb:  movq   $0x0,0x90(%rsp)
    0.00 :   ccdd7:  lea    0x20(%rsp),%rax
    0.00 :   ccddc:  mov    %rax,0x50(%rsp)
    0.00 :   ccde1:  mov    0x8(%rsp),%rax
    0.00 :   ccde6:  mov    %rax,0x58(%rsp)
    0.00 :   ccdeb:  mov    %r14,0x60(%rsp)
    0.00 :   ccdf0:  lea    0x50(%rsp),%rdi
    0.00 :   ccdf5:  mov    %r15,%rsi
    0.00 :   ccdf8:  call   d11f0 <std::sync::mpmc::array::Channel<T>::recv::{{closure}}>
    0.00 :   ccdfd:  lock decq (%r15)
    0.00 :   cce01:  jne    cce16 <std::sys::backtrace::__rust_begin_short_backtrace+0x716>
    0.00 :   cce03:  lea    0x18(%rsp),%rdi
    0.00 :   cce08:  call   *0xc633a(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   cce0e:  mov    %r14,%r15
    0.00 :   cce11:  jmp    ccacd <std::sys::backtrace::__rust_begin_short_backtrace+0x3cd>
    0.00 :   cce16:  mov    %r14,%r15
    0.00 :   cce19:  jmp    ccacd <std::sys::backtrace::__rust_begin_short_backtrace+0x3cd>
    0.00 :   cce1e:  movl   $0x3b9aca00,0x88(%rsp)
    0.00 :   cce29:  xorps  %xmm0,%xmm0
    0.00 :   cce2c:  movaps %xmm0,0xa0(%rsp)
    0.00 :   cce34:  movaps %xmm0,0x90(%rsp)
    0.00 :   cce3c:  movq   $0x0,0xb0(%rsp)
    0.00 :   cce48:  mov    $0x1,%ecx
    0.00 :   cce4d:  xor    %eax,%eax
    0.00 :   cce4f:  mov    0x8(%rsp),%rdx
    0.00 :   cce54:  lock cmpxchg %ecx,(%rdx)
    0.00 :   cce58:  jne    cd9ef <std::sys::backtrace::__rust_begin_short_backtrace+0x12ef>
    0.00 :   cce5e:  mov    0xc5743(%rip),%r14        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cce65:  mov    (%r14),%rax
    0.00 :   cce68:  shl    %rax
    0.00 :   cce6b:  test   %rax,%rax
    0.00 :   cce6e:  jne    cd9ff <std::sys::backtrace::__rust_begin_short_backtrace+0x12ff>
    0.00 :   cce74:  xor    %ebp,%ebp
    0.00 :   cce76:  mov    0x8(%rsp),%rcx
    0.00 :   cce7b:  movzbl 0x4(%rcx),%eax
    0.00 :   cce7f:  test   %al,%al
    0.00 :   cce81:  jne    cda22 <std::sys::backtrace::__rust_begin_short_backtrace+0x1322>
    0.00 :   cce87:  movabs $0x7fffffffffffffff,%r9
    0.00 :   cce91:  mov    0x18(%rcx),%rax
    0.00 :   cce95:  test   %rax,%rax
    0.00 :   cce98:  je     cd6d4 <std::sys::backtrace::__rust_begin_short_backtrace+0xfd4>
    0.00 :   cce9e:  mov    %fs:0x0,%rcx
    0.00 :   ccea7:  lea    -0x170(%rcx),%rcx
    0.00 :   cceae:  mov    0x8(%rsp),%rdx
    0.00 :   cceb3:  mov    0x10(%rdx),%rdx
    0.00 :   cceb7:  shl    $0x3,%rax
    0.00 :   ccebb:  lea    (%rax,%rax,2),%rsi
    0.00 :   ccebf:  mov    $0x1,%ebx
    0.00 :   ccec4:  xor    %r13d,%r13d
    0.00 :   ccec7:  jmp    ccee0 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e0>
    0.00 :   ccec9:  nopl   0x0(%rax)
    0.00 :   cced0:  add    $0x18,%r13
    0.00 :   cced4:  inc    %rbx
    0.00 :   cced7:  cmp    %r13,%rsi
    0.00 :   cceda:  je     cd6d4 <std::sys::backtrace::__rust_begin_short_backtrace+0xfd4>
    0.00 :   ccee0:  mov    (%rdx,%r13,1),%rdi
    0.00 :   ccee4:  cmp    %rcx,0x28(%rdi)
    0.00 :   ccee8:  je     cced0 <std::sys::backtrace::__rust_begin_short_backtrace+0x7d0>
    0.00 :   cceea:  mov    0x8(%rdx,%r13,1),%r8
    0.00 :   cceef:  xor    %eax,%eax
    0.00 :   ccef1:  lock cmpxchg %r8,0x18(%rdi)
    0.00 :   ccef7:  jne    cced0 <std::sys::backtrace::__rust_begin_short_backtrace+0x7d0>
    0.00 :   ccef9:  mov    0x10(%rdx,%r13,1),%rax
    0.00 :   ccefe:  test   %rax,%rax
    0.00 :   ccf01:  je     ccf07 <std::sys::backtrace::__rust_begin_short_backtrace+0x807>
    0.00 :   ccf03:  mov    %rax,0x20(%rdi)
    0.00 :   ccf07:  lea    -0x1(%rbx),%r15
    0.00 :   ccf0b:  mov    0x10(%rdi),%rsi
    0.00 :   ccf0f:  mov    $0x1,%eax
    0.00 :   ccf14:  xchg   %eax,0x28(%rsi)
    0.00 :   ccf17:  cmp    $0xffffffff,%eax
    0.00 :   ccf1a:  jne    ccf37 <std::sys::backtrace::__rust_begin_short_backtrace+0x837>
    0.00 :   ccf1c:  add    $0x28,%rsi
    0.00 :   ccf20:  mov    $0xca,%edi
    0.00 :   ccf25:  mov    $0x81,%edx
    0.00 :   ccf2a:  mov    $0x1,%ecx
    0.00 :   ccf2f:  xor    %eax,%eax
    0.00 :   ccf31:  call   *0xc56a1(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ccf37:  mov    0x8(%rsp),%r14
    0.00 :   ccf3c:  mov    0x18(%r14),%r12
    0.00 :   ccf40:  mov    %r15,0xc0(%rsp)
    0.00 :   ccf48:  cmp    %r12,%r15
    0.00 :   ccf4b:  jae    ce21e <std::sys::backtrace::__rust_begin_short_backtrace+0x1b1e>
    0.00 :   ccf51:  mov    0x10(%r14),%rax
    0.00 :   ccf55:  lea    (%rax,%r13,1),%rdi
    0.00 :   ccf59:  mov    (%rax,%r13,1),%r15
    0.00 :   ccf5d:  movups 0x8(%rax,%r13,1),%xmm0
    0.00 :   ccf63:  movaps %xmm0,0x50(%rsp)
    0.00 :   ccf68:  lea    (%rax,%r13,1),%rsi
    0.00 :   ccf6c:  add    $0x18,%rsi
    0.00 :   ccf70:  mov    %r12,%rax
    0.00 :   ccf73:  sub    %rbx,%rax
    0.00 :   ccf76:  shl    $0x3,%rax
    0.00 :   ccf7a:  lea    (%rax,%rax,2),%rdx
    0.00 :   ccf7e:  call   *0xc57d4(%rip)        # 192758 <memmove@GLIBC_2.2.5>
    0.00 :   ccf84:  dec    %r12
    0.00 :   ccf87:  mov    %r12,0x18(%r14)
    0.00 :   ccf8b:  test   %r15,%r15
    0.00 :   ccf8e:  je     ce21e <std::sys::backtrace::__rust_begin_short_backtrace+0x1b1e>
    0.00 :   ccf94:  mov    %r15,%r14
    0.00 :   ccf97:  movaps 0x50(%rsp),%xmm0
    0.00 :   ccf9c:  movups %xmm0,0x28(%rsp)
    0.00 :   ccfa1:  mov    %r15,0x20(%rsp)
    0.00 :   ccfa6:  mov    0x30(%rsp),%rax
    0.00 :   ccfab:  mov    %rax,0xb0(%rsp)
    0.00 :   ccfb3:  test   %bpl,%bpl
    0.00 :   ccfb6:  mov    0xc55eb(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   ccfbd:  jne    ccfd5 <std::sys::backtrace::__rust_begin_short_backtrace+0x8d5>
    0.00 :   ccfbf:  mov    (%rax),%rax
    0.00 :   ccfc2:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ccfcc:  test   %rcx,%rax
    0.00 :   ccfcf:  jne    ce0ca <std::sys::backtrace::__rust_begin_short_backtrace+0x19ca>
    0.00 :   ccfd5:  xor    %eax,%eax
    0.00 :   ccfd7:  mov    0x8(%rsp),%rsi
    0.00 :   ccfdc:  xchg   %eax,(%rsi)
    0.00 :   ccfde:  cmp    $0x2,%eax
    0.00 :   ccfe1:  je     cdacf <std::sys::backtrace::__rust_begin_short_backtrace+0x13cf>
    0.00 :   ccfe7:  mov    0xb0(%rsp),%r12
    0.00 :   ccfef:  test   %r12,%r12
    0.00 :   ccff2:  je     cdaf7 <std::sys::backtrace::__rust_begin_short_backtrace+0x13f7>
    0.00 :   ccff8:  cmpb   $0x0,(%r12)
    0.00 :   ccffd:  je     cd938 <std::sys::backtrace::__rust_begin_short_backtrace+0x1238>
    0.00 :   cd003:  cmpb   $0x0,0x2(%r12)
    0.00 :   cd009:  movb   $0x0,0x2(%r12)
    0.00 :   cd00f:  je     ce206 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b06>
    0.00 :   cd015:  movb   $0x1,0x1(%r12)
    0.00 :   cd01b:  mov    $0x2,%bpl
    0.00 :   cd01e:  lock decq (%r14)
    0.00 :   cd022:  je     cdb00 <std::sys::backtrace::__rust_begin_short_backtrace+0x1400>
    0.00 :   cd028:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd02d:  lea    (%rsi,%rdx,8),%rax
    0.00 :   cd031:  mov    %rax,0x20(%rsp)
    0.00 :   cd036:  mov    0x8(%rsp),%rax
    0.00 :   cd03b:  add    0x188(%rax),%rcx
    0.00 :   cd042:  mov    %rcx,0x28(%rsp)
    0.00 :   cd047:  mov    %rcx,(%rsi,%rdx,8)
    0.00 :   cd04b:  lea    0x100(%rax),%rdi
    0.00 :   cd052:  mov    $0x1,%r12b
    0.00 :   cd055:  mov    $0x2,%bpl
    0.00 :   cd058:  mov    $0x1,%r13b
    0.00 :   cd05b:  call   c43b0 <<std::sync::mpmc::waker::SyncWaker>::notify>
    0.00 :   cd060:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd065:  cmp    $0x1e,%r15d
    0.00 :   cd069:  jne    cd09b <std::sys::backtrace::__rust_begin_short_backtrace+0x99b>
    0.00 :   cd06b:  mov    (%r12),%rax
    0.00 :   cd06f:  test   %rax,%rax
    0.00 :   cd072:  je     cd8c3 <std::sys::backtrace::__rust_begin_short_backtrace+0x11c3>
    0.00 :   cd078:  and    $0xfffffffffffffffe,%r13
    0.00 :   cd07c:  mov    (%rax),%rcx
    0.00 :   cd07f:  xor    %edx,%edx
    0.00 :   cd081:  test   %rcx,%rcx
    0.00 :   cd084:  setne  %dl
    0.00 :   cd087:  lea    (%rdx,%r13,1),%rcx
    0.00 :   cd08b:  add    $0x2,%rcx
    0.00 :   cd08f:  mov    0x8(%rsp),%rdx
    0.00 :   cd094:  mov    %rax,0x8(%rdx)
    0.00 :   cd098:  mov    %rcx,(%rdx)
    0.00 :   cd09b:  mov    %r12,0x30(%rsp)
    0.00 :   cd0a0:  mov    %r15,0x38(%rsp)
    0.00 :   cd0a5:  mov    0x8(%r12,%r15,8),%rax
    0.00 :   cd0aa:  test   $0x1,%al
    0.00 :   cd0ac:  jne    cd128 <std::sys::backtrace::__rust_begin_short_backtrace+0xa28>
    0.00 :   cd0ae:  xor    %ebx,%ebx
    0.00 :   cd0b0:  xor    %r13d,%r13d
    0.00 :   cd0b3:  jmp    cd0dd <std::sys::backtrace::__rust_begin_short_backtrace+0x9dd>
    0.00 :   cd0b5:  data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cd0c0:  call   *0xc56b2(%rip)        # 192778 <sched_yield@GLIBC_2.2.5>
    0.00 :   cd0c6:  lea    0x1(,%r13,2),%eax
    0.00 :   cd0ce:  inc    %r13d
    0.00 :   cd0d1:  mov    0x8(%r12,%r15,8),%rcx
    0.00 :   cd0d6:  add    %eax,%ebx
    0.00 :   cd0d8:  test   $0x1,%cl
    0.00 :   cd0db:  jne    cd128 <std::sys::backtrace::__rust_begin_short_backtrace+0xa28>
    0.00 :   cd0dd:  cmp    $0x7,%r13d
    0.00 :   cd0e1:  jae    cd0c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x9c0>
    0.00 :   cd0e3:  test   %r13d,%r13d
    0.00 :   cd0e6:  je     cd0c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x9c6>
    0.00 :   cd0e8:  lea    -0x1(%rbx),%ecx
    0.00 :   cd0eb:  mov    %ebx,%eax
    0.00 :   cd0ed:  and    $0x7,%eax
    0.00 :   cd0f0:  cmp    $0x7,%ecx
    0.00 :   cd0f3:  jb     cd120 <std::sys::backtrace::__rust_begin_short_backtrace+0xa20>
    0.00 :   cd0f5:  mov    %ebx,%ecx
    0.00 :   cd0f7:  and    $0xfffffff8,%ecx
    0.00 :   cd0fa:  nopw   0x0(%rax,%rax,1)
    0.00 :   cd100:  pause
    0.00 :   cd102:  pause
    0.00 :   cd104:  pause
    0.00 :   cd106:  pause
    0.00 :   cd108:  pause
    0.00 :   cd10a:  pause
    0.00 :   cd10c:  pause
    0.00 :   cd10e:  pause
    0.00 :   cd110:  add    $0xfffffff8,%ecx
    0.00 :   cd113:  jne    cd100 <std::sys::backtrace::__rust_begin_short_backtrace+0xa00>
    0.00 :   cd115:  test   %eax,%eax
    0.00 :   cd117:  je     cd0c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x9c6>
    0.00 :   cd119:  nopl   0x0(%rax)
    0.00 :   cd120:  pause
    0.00 :   cd122:  dec    %eax
    0.00 :   cd124:  jne    cd120 <std::sys::backtrace::__rust_begin_short_backtrace+0xa20>
    0.00 :   cd126:  jmp    cd0c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x9c6>
    0.00 :   cd128:  lea    0x1(%r15),%rcx
    0.00 :   cd12c:  cmp    $0x1f,%rcx
    0.00 :   cd130:  jne    cd718 <std::sys::backtrace::__rust_begin_short_backtrace+0x1018>
    0.00 :   cd136:  mov    0x8(%r12),%rax
    0.00 :   cd13b:  test   $0x2,%al
    0.00 :   cd13d:  jne    cd16b <std::sys::backtrace::__rust_begin_short_backtrace+0xa6b>
    0.00 :   cd13f:  mov    0x8(%r12),%rax
    0.00 :   cd144:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cd150:  mov    %rax,%rcx
    0.00 :   cd153:  or     $0x4,%rcx
    0.00 :   cd157:  lock cmpxchg %rcx,0x8(%r12)
    0.00 :   cd15e:  jne    cd150 <std::sys::backtrace::__rust_begin_short_backtrace+0xa50>
    0.00 :   cd160:  mov    $0x2,%bpl
    0.00 :   cd163:  test   $0x2,%al
    0.00 :   cd165:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd16b:  mov    0x10(%r12),%rax
    0.00 :   cd170:  test   $0x2,%al
    0.00 :   cd172:  jne    cd19b <std::sys::backtrace::__rust_begin_short_backtrace+0xa9b>
    0.00 :   cd174:  mov    0x10(%r12),%rax
    0.00 :   cd179:  nopl   0x0(%rax)
    0.00 :   cd180:  mov    %rax,%rcx
    0.00 :   cd183:  or     $0x4,%rcx
    0.00 :   cd187:  lock cmpxchg %rcx,0x10(%r12)
    0.00 :   cd18e:  jne    cd180 <std::sys::backtrace::__rust_begin_short_backtrace+0xa80>
    0.00 :   cd190:  mov    $0x2,%bpl
    0.00 :   cd193:  test   $0x2,%al
    0.00 :   cd195:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd19b:  mov    0x18(%r12),%rax
    0.00 :   cd1a0:  test   $0x2,%al
    0.00 :   cd1a2:  jne    cd1cb <std::sys::backtrace::__rust_begin_short_backtrace+0xacb>
    0.00 :   cd1a4:  mov    0x18(%r12),%rax
    0.00 :   cd1a9:  nopl   0x0(%rax)
    0.00 :   cd1b0:  mov    %rax,%rcx
    0.00 :   cd1b3:  or     $0x4,%rcx
    0.00 :   cd1b7:  lock cmpxchg %rcx,0x18(%r12)
    0.00 :   cd1be:  jne    cd1b0 <std::sys::backtrace::__rust_begin_short_backtrace+0xab0>
    0.00 :   cd1c0:  mov    $0x2,%bpl
    0.00 :   cd1c3:  test   $0x2,%al
    0.00 :   cd1c5:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd1cb:  mov    0x20(%r12),%rax
    0.00 :   cd1d0:  test   $0x2,%al
    0.00 :   cd1d2:  jne    cd1fb <std::sys::backtrace::__rust_begin_short_backtrace+0xafb>
    0.00 :   cd1d4:  mov    0x20(%r12),%rax
    0.00 :   cd1d9:  nopl   0x0(%rax)
    0.00 :   cd1e0:  mov    %rax,%rcx
    0.00 :   cd1e3:  or     $0x4,%rcx
    0.00 :   cd1e7:  lock cmpxchg %rcx,0x20(%r12)
    0.00 :   cd1ee:  jne    cd1e0 <std::sys::backtrace::__rust_begin_short_backtrace+0xae0>
    0.00 :   cd1f0:  mov    $0x2,%bpl
    0.00 :   cd1f3:  test   $0x2,%al
    0.00 :   cd1f5:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd1fb:  mov    0x28(%r12),%rax
    0.00 :   cd200:  test   $0x2,%al
    0.00 :   cd202:  jne    cd22b <std::sys::backtrace::__rust_begin_short_backtrace+0xb2b>
    0.00 :   cd204:  mov    0x28(%r12),%rax
    0.00 :   cd209:  nopl   0x0(%rax)
    0.00 :   cd210:  mov    %rax,%rcx
    0.00 :   cd213:  or     $0x4,%rcx
    0.00 :   cd217:  lock cmpxchg %rcx,0x28(%r12)
    0.00 :   cd21e:  jne    cd210 <std::sys::backtrace::__rust_begin_short_backtrace+0xb10>
    0.00 :   cd220:  mov    $0x2,%bpl
    0.00 :   cd223:  test   $0x2,%al
    0.00 :   cd225:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd22b:  mov    0x30(%r12),%rax
    0.00 :   cd230:  test   $0x2,%al
    0.00 :   cd232:  jne    cd25b <std::sys::backtrace::__rust_begin_short_backtrace+0xb5b>
    0.00 :   cd234:  mov    0x30(%r12),%rax
    0.00 :   cd239:  nopl   0x0(%rax)
    0.00 :   cd240:  mov    %rax,%rcx
    0.00 :   cd243:  or     $0x4,%rcx
    0.00 :   cd247:  lock cmpxchg %rcx,0x30(%r12)
    0.00 :   cd24e:  jne    cd240 <std::sys::backtrace::__rust_begin_short_backtrace+0xb40>
    0.00 :   cd250:  mov    $0x2,%bpl
    0.00 :   cd253:  test   $0x2,%al
    0.00 :   cd255:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd25b:  mov    0x38(%r12),%rax
    0.00 :   cd260:  test   $0x2,%al
    0.00 :   cd262:  jne    cd28b <std::sys::backtrace::__rust_begin_short_backtrace+0xb8b>
    0.00 :   cd264:  mov    0x38(%r12),%rax
    0.00 :   cd269:  nopl   0x0(%rax)
    0.00 :   cd270:  mov    %rax,%rcx
    0.00 :   cd273:  or     $0x4,%rcx
    0.00 :   cd277:  lock cmpxchg %rcx,0x38(%r12)
    0.00 :   cd27e:  jne    cd270 <std::sys::backtrace::__rust_begin_short_backtrace+0xb70>
    0.00 :   cd280:  mov    $0x2,%bpl
    0.00 :   cd283:  test   $0x2,%al
    0.00 :   cd285:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd28b:  mov    0x40(%r12),%rax
    0.00 :   cd290:  test   $0x2,%al
    0.00 :   cd292:  jne    cd2bb <std::sys::backtrace::__rust_begin_short_backtrace+0xbbb>
    0.00 :   cd294:  mov    0x40(%r12),%rax
    0.00 :   cd299:  nopl   0x0(%rax)
    0.00 :   cd2a0:  mov    %rax,%rcx
    0.00 :   cd2a3:  or     $0x4,%rcx
    0.00 :   cd2a7:  lock cmpxchg %rcx,0x40(%r12)
    0.00 :   cd2ae:  jne    cd2a0 <std::sys::backtrace::__rust_begin_short_backtrace+0xba0>
    0.00 :   cd2b0:  mov    $0x2,%bpl
    0.00 :   cd2b3:  test   $0x2,%al
    0.00 :   cd2b5:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd2bb:  mov    0x48(%r12),%rax
    0.00 :   cd2c0:  test   $0x2,%al
    0.00 :   cd2c2:  jne    cd2eb <std::sys::backtrace::__rust_begin_short_backtrace+0xbeb>
    0.00 :   cd2c4:  mov    0x48(%r12),%rax
    0.00 :   cd2c9:  nopl   0x0(%rax)
    0.00 :   cd2d0:  mov    %rax,%rcx
    0.00 :   cd2d3:  or     $0x4,%rcx
    0.00 :   cd2d7:  lock cmpxchg %rcx,0x48(%r12)
    0.00 :   cd2de:  jne    cd2d0 <std::sys::backtrace::__rust_begin_short_backtrace+0xbd0>
    0.00 :   cd2e0:  mov    $0x2,%bpl
    0.00 :   cd2e3:  test   $0x2,%al
    0.00 :   cd2e5:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd2eb:  mov    0x50(%r12),%rax
    0.00 :   cd2f0:  test   $0x2,%al
    0.00 :   cd2f2:  jne    cd314 <std::sys::backtrace::__rust_begin_short_backtrace+0xc14>
    0.00 :   cd2f4:  mov    0x50(%r12),%rax
    0.00 :   cd2f9:  mov    %rax,%rcx
    0.00 :   cd2fc:  or     $0x4,%rcx
    0.00 :   cd300:  lock cmpxchg %rcx,0x50(%r12)
    0.00 :   cd307:  jne    cd2f9 <std::sys::backtrace::__rust_begin_short_backtrace+0xbf9>
    0.00 :   cd309:  mov    $0x2,%bpl
    0.00 :   cd30c:  test   $0x2,%al
    0.00 :   cd30e:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd314:  mov    0x58(%r12),%rax
    0.00 :   cd319:  test   $0x2,%al
    0.00 :   cd31b:  jne    cd33d <std::sys::backtrace::__rust_begin_short_backtrace+0xc3d>
    0.00 :   cd31d:  mov    0x58(%r12),%rax
    0.00 :   cd322:  mov    %rax,%rcx
    0.00 :   cd325:  or     $0x4,%rcx
    0.00 :   cd329:  lock cmpxchg %rcx,0x58(%r12)
    0.00 :   cd330:  jne    cd322 <std::sys::backtrace::__rust_begin_short_backtrace+0xc22>
    0.00 :   cd332:  mov    $0x2,%bpl
    0.00 :   cd335:  test   $0x2,%al
    0.00 :   cd337:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd33d:  mov    0x60(%r12),%rax
    0.00 :   cd342:  test   $0x2,%al
    0.00 :   cd344:  jne    cd366 <std::sys::backtrace::__rust_begin_short_backtrace+0xc66>
    0.00 :   cd346:  mov    0x60(%r12),%rax
    0.00 :   cd34b:  mov    %rax,%rcx
    0.00 :   cd34e:  or     $0x4,%rcx
    0.00 :   cd352:  lock cmpxchg %rcx,0x60(%r12)
    0.00 :   cd359:  jne    cd34b <std::sys::backtrace::__rust_begin_short_backtrace+0xc4b>
    0.00 :   cd35b:  mov    $0x2,%bpl
    0.00 :   cd35e:  test   $0x2,%al
    0.00 :   cd360:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd366:  mov    0x68(%r12),%rax
    0.00 :   cd36b:  test   $0x2,%al
    0.00 :   cd36d:  jne    cd38f <std::sys::backtrace::__rust_begin_short_backtrace+0xc8f>
    0.00 :   cd36f:  mov    0x68(%r12),%rax
    0.00 :   cd374:  mov    %rax,%rcx
    0.00 :   cd377:  or     $0x4,%rcx
    0.00 :   cd37b:  lock cmpxchg %rcx,0x68(%r12)
    0.00 :   cd382:  jne    cd374 <std::sys::backtrace::__rust_begin_short_backtrace+0xc74>
    0.00 :   cd384:  mov    $0x2,%bpl
    0.00 :   cd387:  test   $0x2,%al
    0.00 :   cd389:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd38f:  mov    0x70(%r12),%rax
    0.00 :   cd394:  test   $0x2,%al
    0.00 :   cd396:  jne    cd3b8 <std::sys::backtrace::__rust_begin_short_backtrace+0xcb8>
    0.00 :   cd398:  mov    0x70(%r12),%rax
    0.00 :   cd39d:  mov    %rax,%rcx
    0.00 :   cd3a0:  or     $0x4,%rcx
    0.00 :   cd3a4:  lock cmpxchg %rcx,0x70(%r12)
    0.00 :   cd3ab:  jne    cd39d <std::sys::backtrace::__rust_begin_short_backtrace+0xc9d>
    0.00 :   cd3ad:  mov    $0x2,%bpl
    0.00 :   cd3b0:  test   $0x2,%al
    0.00 :   cd3b2:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd3b8:  mov    0x78(%r12),%rax
    0.00 :   cd3bd:  test   $0x2,%al
    0.00 :   cd3bf:  jne    cd3e1 <std::sys::backtrace::__rust_begin_short_backtrace+0xce1>
    0.00 :   cd3c1:  mov    0x78(%r12),%rax
    0.00 :   cd3c6:  mov    %rax,%rcx
    0.00 :   cd3c9:  or     $0x4,%rcx
    0.00 :   cd3cd:  lock cmpxchg %rcx,0x78(%r12)
    0.00 :   cd3d4:  jne    cd3c6 <std::sys::backtrace::__rust_begin_short_backtrace+0xcc6>
    0.00 :   cd3d6:  mov    $0x2,%bpl
    0.00 :   cd3d9:  test   $0x2,%al
    0.00 :   cd3db:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd3e1:  mov    0x80(%r12),%rax
    0.00 :   cd3e9:  test   $0x2,%al
    0.00 :   cd3eb:  jne    cd413 <std::sys::backtrace::__rust_begin_short_backtrace+0xd13>
    0.00 :   cd3ed:  mov    0x80(%r12),%rax
    0.00 :   cd3f5:  mov    %rax,%rcx
    0.00 :   cd3f8:  or     $0x4,%rcx
    0.00 :   cd3fc:  lock cmpxchg %rcx,0x80(%r12)
    0.00 :   cd406:  jne    cd3f5 <std::sys::backtrace::__rust_begin_short_backtrace+0xcf5>
    0.00 :   cd408:  mov    $0x2,%bpl
    0.00 :   cd40b:  test   $0x2,%al
    0.00 :   cd40d:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd413:  mov    0x88(%r12),%rax
    0.00 :   cd41b:  test   $0x2,%al
    0.00 :   cd41d:  jne    cd445 <std::sys::backtrace::__rust_begin_short_backtrace+0xd45>
    0.00 :   cd41f:  mov    0x88(%r12),%rax
    0.00 :   cd427:  mov    %rax,%rcx
    0.00 :   cd42a:  or     $0x4,%rcx
    0.00 :   cd42e:  lock cmpxchg %rcx,0x88(%r12)
    0.00 :   cd438:  jne    cd427 <std::sys::backtrace::__rust_begin_short_backtrace+0xd27>
    0.00 :   cd43a:  mov    $0x2,%bpl
    0.00 :   cd43d:  test   $0x2,%al
    0.00 :   cd43f:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd445:  mov    0x90(%r12),%rax
    0.00 :   cd44d:  test   $0x2,%al
    0.00 :   cd44f:  jne    cd477 <std::sys::backtrace::__rust_begin_short_backtrace+0xd77>
    0.00 :   cd451:  mov    0x90(%r12),%rax
    0.00 :   cd459:  mov    %rax,%rcx
    0.00 :   cd45c:  or     $0x4,%rcx
    0.00 :   cd460:  lock cmpxchg %rcx,0x90(%r12)
    0.00 :   cd46a:  jne    cd459 <std::sys::backtrace::__rust_begin_short_backtrace+0xd59>
    0.00 :   cd46c:  mov    $0x2,%bpl
    0.00 :   cd46f:  test   $0x2,%al
    0.00 :   cd471:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd477:  mov    0x98(%r12),%rax
    0.00 :   cd47f:  test   $0x2,%al
    0.00 :   cd481:  jne    cd4a9 <std::sys::backtrace::__rust_begin_short_backtrace+0xda9>
    0.00 :   cd483:  mov    0x98(%r12),%rax
    0.00 :   cd48b:  mov    %rax,%rcx
    0.00 :   cd48e:  or     $0x4,%rcx
    0.00 :   cd492:  lock cmpxchg %rcx,0x98(%r12)
    0.00 :   cd49c:  jne    cd48b <std::sys::backtrace::__rust_begin_short_backtrace+0xd8b>
    0.00 :   cd49e:  mov    $0x2,%bpl
    0.00 :   cd4a1:  test   $0x2,%al
    0.00 :   cd4a3:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd4a9:  mov    0xa0(%r12),%rax
    0.00 :   cd4b1:  test   $0x2,%al
    0.00 :   cd4b3:  jne    cd4db <std::sys::backtrace::__rust_begin_short_backtrace+0xddb>
    0.00 :   cd4b5:  mov    0xa0(%r12),%rax
    0.00 :   cd4bd:  mov    %rax,%rcx
    0.00 :   cd4c0:  or     $0x4,%rcx
    0.00 :   cd4c4:  lock cmpxchg %rcx,0xa0(%r12)
    0.00 :   cd4ce:  jne    cd4bd <std::sys::backtrace::__rust_begin_short_backtrace+0xdbd>
    0.00 :   cd4d0:  mov    $0x2,%bpl
    0.00 :   cd4d3:  test   $0x2,%al
    0.00 :   cd4d5:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd4db:  mov    0xa8(%r12),%rax
    0.00 :   cd4e3:  test   $0x2,%al
    0.00 :   cd4e5:  jne    cd50d <std::sys::backtrace::__rust_begin_short_backtrace+0xe0d>
    0.00 :   cd4e7:  mov    0xa8(%r12),%rax
    0.00 :   cd4ef:  mov    %rax,%rcx
    0.00 :   cd4f2:  or     $0x4,%rcx
    0.00 :   cd4f6:  lock cmpxchg %rcx,0xa8(%r12)
    0.00 :   cd500:  jne    cd4ef <std::sys::backtrace::__rust_begin_short_backtrace+0xdef>
    0.00 :   cd502:  mov    $0x2,%bpl
    0.00 :   cd505:  test   $0x2,%al
    0.00 :   cd507:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd50d:  mov    0xb0(%r12),%rax
    0.00 :   cd515:  test   $0x2,%al
    0.00 :   cd517:  jne    cd53f <std::sys::backtrace::__rust_begin_short_backtrace+0xe3f>
    0.00 :   cd519:  mov    0xb0(%r12),%rax
    0.00 :   cd521:  mov    %rax,%rcx
    0.00 :   cd524:  or     $0x4,%rcx
    0.00 :   cd528:  lock cmpxchg %rcx,0xb0(%r12)
    0.00 :   cd532:  jne    cd521 <std::sys::backtrace::__rust_begin_short_backtrace+0xe21>
    0.00 :   cd534:  mov    $0x2,%bpl
    0.00 :   cd537:  test   $0x2,%al
    0.00 :   cd539:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd53f:  mov    0xb8(%r12),%rax
    0.00 :   cd547:  test   $0x2,%al
    0.00 :   cd549:  jne    cd571 <std::sys::backtrace::__rust_begin_short_backtrace+0xe71>
    0.00 :   cd54b:  mov    0xb8(%r12),%rax
    0.00 :   cd553:  mov    %rax,%rcx
    0.00 :   cd556:  or     $0x4,%rcx
    0.00 :   cd55a:  lock cmpxchg %rcx,0xb8(%r12)
    0.00 :   cd564:  jne    cd553 <std::sys::backtrace::__rust_begin_short_backtrace+0xe53>
    0.00 :   cd566:  mov    $0x2,%bpl
    0.00 :   cd569:  test   $0x2,%al
    0.00 :   cd56b:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd571:  mov    0xc0(%r12),%rax
    0.00 :   cd579:  test   $0x2,%al
    0.00 :   cd57b:  jne    cd5a3 <std::sys::backtrace::__rust_begin_short_backtrace+0xea3>
    0.00 :   cd57d:  mov    0xc0(%r12),%rax
    0.00 :   cd585:  mov    %rax,%rcx
    0.00 :   cd588:  or     $0x4,%rcx
    0.00 :   cd58c:  lock cmpxchg %rcx,0xc0(%r12)
    0.00 :   cd596:  jne    cd585 <std::sys::backtrace::__rust_begin_short_backtrace+0xe85>
    0.00 :   cd598:  mov    $0x2,%bpl
    0.00 :   cd59b:  test   $0x2,%al
    0.00 :   cd59d:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd5a3:  mov    0xc8(%r12),%rax
    0.00 :   cd5ab:  test   $0x2,%al
    0.00 :   cd5ad:  jne    cd5d5 <std::sys::backtrace::__rust_begin_short_backtrace+0xed5>
    0.00 :   cd5af:  mov    0xc8(%r12),%rax
    0.00 :   cd5b7:  mov    %rax,%rcx
    0.00 :   cd5ba:  or     $0x4,%rcx
    0.00 :   cd5be:  lock cmpxchg %rcx,0xc8(%r12)
    0.00 :   cd5c8:  jne    cd5b7 <std::sys::backtrace::__rust_begin_short_backtrace+0xeb7>
    0.00 :   cd5ca:  mov    $0x2,%bpl
    0.00 :   cd5cd:  test   $0x2,%al
    0.00 :   cd5cf:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd5d5:  mov    0xd0(%r12),%rax
    0.00 :   cd5dd:  test   $0x2,%al
    0.00 :   cd5df:  jne    cd607 <std::sys::backtrace::__rust_begin_short_backtrace+0xf07>
    0.00 :   cd5e1:  mov    0xd0(%r12),%rax
    0.00 :   cd5e9:  mov    %rax,%rcx
    0.00 :   cd5ec:  or     $0x4,%rcx
    0.00 :   cd5f0:  lock cmpxchg %rcx,0xd0(%r12)
    0.00 :   cd5fa:  jne    cd5e9 <std::sys::backtrace::__rust_begin_short_backtrace+0xee9>
    0.00 :   cd5fc:  mov    $0x2,%bpl
    0.00 :   cd5ff:  test   $0x2,%al
    0.00 :   cd601:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd607:  mov    0xd8(%r12),%rax
    0.00 :   cd60f:  test   $0x2,%al
    0.00 :   cd611:  jne    cd639 <std::sys::backtrace::__rust_begin_short_backtrace+0xf39>
    0.00 :   cd613:  mov    0xd8(%r12),%rax
    0.00 :   cd61b:  mov    %rax,%rcx
    0.00 :   cd61e:  or     $0x4,%rcx
    0.00 :   cd622:  lock cmpxchg %rcx,0xd8(%r12)
    0.00 :   cd62c:  jne    cd61b <std::sys::backtrace::__rust_begin_short_backtrace+0xf1b>
    0.00 :   cd62e:  mov    $0x2,%bpl
    0.00 :   cd631:  test   $0x2,%al
    0.00 :   cd633:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd639:  mov    0xe0(%r12),%rax
    0.00 :   cd641:  test   $0x2,%al
    0.00 :   cd643:  jne    cd66b <std::sys::backtrace::__rust_begin_short_backtrace+0xf6b>
    0.00 :   cd645:  mov    0xe0(%r12),%rax
    0.00 :   cd64d:  mov    %rax,%rcx
    0.00 :   cd650:  or     $0x4,%rcx
    0.00 :   cd654:  lock cmpxchg %rcx,0xe0(%r12)
    0.00 :   cd65e:  jne    cd64d <std::sys::backtrace::__rust_begin_short_backtrace+0xf4d>
    0.00 :   cd660:  mov    $0x2,%bpl
    0.00 :   cd663:  test   $0x2,%al
    0.00 :   cd665:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd66b:  mov    0xe8(%r12),%rax
    0.00 :   cd673:  test   $0x2,%al
    0.00 :   cd675:  jne    cd69d <std::sys::backtrace::__rust_begin_short_backtrace+0xf9d>
    0.00 :   cd677:  mov    0xe8(%r12),%rax
    0.00 :   cd67f:  mov    %rax,%rcx
    0.00 :   cd682:  or     $0x4,%rcx
    0.00 :   cd686:  lock cmpxchg %rcx,0xe8(%r12)
    0.00 :   cd690:  jne    cd67f <std::sys::backtrace::__rust_begin_short_backtrace+0xf7f>
    0.00 :   cd692:  mov    $0x2,%bpl
    0.00 :   cd695:  test   $0x2,%al
    0.00 :   cd697:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd69d:  mov    0xf0(%r12),%rax
    0.00 :   cd6a5:  test   $0x2,%al
    0.00 :   cd6a7:  jne    cd741 <std::sys::backtrace::__rust_begin_short_backtrace+0x1041>
    0.00 :   cd6ad:  mov    0xf0(%r12),%rax
    0.00 :   cd6b5:  mov    %rax,%rcx
    0.00 :   cd6b8:  or     $0x4,%rcx
    0.00 :   cd6bc:  lock cmpxchg %rcx,0xf0(%r12)
    0.00 :   cd6c6:  jne    cd6b5 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb5>
    0.00 :   cd6c8:  mov    $0x2,%bpl
    0.00 :   cd6cb:  test   $0x2,%al
    0.00 :   cd6cd:  jne    cd741 <std::sys::backtrace::__rust_begin_short_backtrace+0x1041>
    0.00 :   cd6cf:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd6d4:  mov    0x8(%rsp),%rax
    0.00 :   cd6d9:  cmpb   $0x0,0x68(%rax)
    0.00 :   cd6dd:  je     cd799 <std::sys::backtrace::__rust_begin_short_backtrace+0x1099>
    0.00 :   cd6e3:  test   %bpl,%bpl
    0.00 :   cd6e6:  jne    cd6f4 <std::sys::backtrace::__rust_begin_short_backtrace+0xff4>
    0.00 :   cd6e8:  mov    (%r14),%rax
    0.00 :   cd6eb:  test   %r9,%rax
    0.00 :   cd6ee:  jne    ce0a8 <std::sys::backtrace::__rust_begin_short_backtrace+0x19a8>
    0.00 :   cd6f4:  xor    %eax,%eax
    0.00 :   cd6f6:  mov    0x8(%rsp),%rcx
    0.00 :   cd6fb:  xchg   %eax,(%rcx)
    0.00 :   cd6fd:  mov    $0x1,%bpl
    0.00 :   cd700:  cmp    $0x2,%eax
    0.00 :   cd703:  jne    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd709:  mov    $0xca,%edi
    0.00 :   cd70e:  mov    0x8(%rsp),%rsi
    0.00 :   cd713:  jmp    cd8ac <std::sys::backtrace::__rust_begin_short_backtrace+0x11ac>
    0.00 :   cd718:  mov    0x8(%r12,%r15,8),%rax
    0.00 :   cd71d:  nopl   (%rax)
    0.00 :   cd720:  mov    %rax,%rdx
    0.00 :   cd723:  or     $0x2,%rdx
    0.00 :   cd727:  lock cmpxchg %rdx,0x8(%r12,%r15,8)
    0.00 :   cd72e:  jne    cd720 <std::sys::backtrace::__rust_begin_short_backtrace+0x1020>
    0.00 :   cd730:  mov    $0x2,%bpl
    0.00 :   cd733:  test   $0x4,%al
    0.00 :   cd735:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd73b:  cmp    $0x1c,%r15d
    0.00 :   cd73f:  jbe    cd769 <std::sys::backtrace::__rust_begin_short_backtrace+0x1069>
    0.00 :   cd741:  mov    %r12,%rdi
    0.00 :   cd744:  call   *0xc4afe(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cd74a:  mov    $0x2,%bpl
    0.00 :   cd74d:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd752:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cd760:  inc    %rcx
    0.00 :   cd763:  cmp    $0x1e,%rcx
    0.00 :   cd767:  je     cd741 <std::sys::backtrace::__rust_begin_short_backtrace+0x1041>
    0.00 :   cd769:  mov    0x8(%r12,%rcx,8),%rax
    0.00 :   cd76e:  test   $0x2,%al
    0.00 :   cd770:  jne    cd760 <std::sys::backtrace::__rust_begin_short_backtrace+0x1060>
    0.00 :   cd772:  mov    0x8(%r12,%rcx,8),%rax
    0.00 :   cd777:  nopw   0x0(%rax,%rax,1)
    0.00 :   cd780:  mov    %rax,%rdx
    0.00 :   cd783:  or     $0x4,%rdx
    0.00 :   cd787:  lock cmpxchg %rdx,0x8(%r12,%rcx,8)
    0.00 :   cd78e:  jne    cd780 <std::sys::backtrace::__rust_begin_short_backtrace+0x1080>
    0.00 :   cd790:  test   $0x2,%al
    0.00 :   cd792:  jne    cd760 <std::sys::backtrace::__rust_begin_short_backtrace+0x1060>
    0.00 :   cd794:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd799:  lea    0x90(%rsp),%rbx
    0.00 :   cd7a1:  mov    %rbx,0x50(%rsp)
    0.00 :   cd7a6:  lea    0x80(%rsp),%r13
    0.00 :   cd7ae:  mov    %r13,0x58(%rsp)
    0.00 :   cd7b3:  mov    %rax,0x60(%rsp)
    0.00 :   cd7b8:  mov    %rax,0x68(%rsp)
    0.00 :   cd7bd:  mov    %bpl,0x70(%rsp)
    0.00 :   cd7c2:  mov    $0xffffffffffffff98,%rax
    0.00 :   cd7c9:  mov    %fs:0x0,%r15
    0.00 :   cd7d2:  add    %rax,%r15
    0.00 :   cd7d5:  cmpb   $0x1,%fs:0x8(%rax)
    0.00 :   cd7da:  jne    cda56 <std::sys::backtrace::__rust_begin_short_backtrace+0x1356>
    0.00 :   cd7e0:  mov    (%r15),%r12
    0.00 :   cd7e3:  movq   $0x0,(%r15)
    0.00 :   cd7ea:  test   %r12,%r12
    0.00 :   cd7ed:  je     cda7b <std::sys::backtrace::__rust_begin_short_backtrace+0x137b>
    0.00 :   cd7f3:  lea    0x71(%rsp),%rax
    0.00 :   cd7f8:  mov    %r12,0x18(%rsp)
    0.00 :   cd7fd:  movq   $0x0,0x18(%r12)
    0.00 :   cd806:  movq   $0x0,0x20(%r12)
    0.00 :   cd80f:  movb   $0x2,0x70(%rsp)
    0.00 :   cd814:  movups 0x50(%rsp),%xmm0
    0.00 :   cd819:  movups 0x60(%rsp),%xmm1
    0.00 :   cd81e:  movaps %xmm0,0x20(%rsp)
    0.00 :   cd823:  movaps %xmm1,0x30(%rsp)
    0.00 :   cd828:  mov    %bpl,0x40(%rsp)
    0.00 :   cd82d:  mov    (%rax),%ecx
    0.00 :   cd82f:  mov    0x3(%rax),%eax
    0.00 :   cd832:  mov    %ecx,0x41(%rsp)
    0.00 :   cd836:  mov    %eax,0x44(%rsp)
    0.00 :   cd83a:  lea    0x20(%rsp),%rdi
    0.00 :   cd83f:  mov    %r12,%rsi
    0.00 :   cd842:  call   cfdd0 <std::sync::mpmc::zero::Channel<T>::recv::{{closure}}>
    0.00 :   cd847:  mov    %eax,%ebp
    0.00 :   cd849:  mov    (%r15),%rax
    0.00 :   cd84c:  mov    %rax,0x20(%rsp)
    0.00 :   cd851:  mov    %r12,(%r15)
    0.00 :   cd854:  test   %rax,%rax
    0.00 :   cd857:  je     cd86a <std::sys::backtrace::__rust_begin_short_backtrace+0x116a>
    0.00 :   cd859:  lock decq (%rax)
    0.00 :   cd85d:  jne    cd86a <std::sys::backtrace::__rust_begin_short_backtrace+0x116a>
    0.00 :   cd85f:  lea    0x20(%rsp),%rdi
    0.00 :   cd864:  call   *0xc58de(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   cd86a:  movzbl 0x70(%rsp),%eax
    0.00 :   cd86f:  cmp    $0x2,%al
    0.00 :   cd871:  je     cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd877:  mov    0x68(%rsp),%r15
    0.00 :   cd87c:  test   $0x1,%al
    0.00 :   cd87e:  jne    cd896 <std::sys::backtrace::__rust_begin_short_backtrace+0x1196>
    0.00 :   cd880:  mov    (%r14),%rax
    0.00 :   cd883:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cd88d:  test   %rcx,%rax
    0.00 :   cd890:  jne    ce0e6 <std::sys::backtrace::__rust_begin_short_backtrace+0x19e6>
    0.00 :   cd896:  xor    %eax,%eax
    0.00 :   cd898:  xchg   %eax,(%r15)
    0.00 :   cd89b:  cmp    $0x2,%eax
    0.00 :   cd89e:  jne    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd8a4:  mov    $0xca,%edi
    0.00 :   cd8a9:  mov    %r15,%rsi
    0.00 :   cd8ac:  mov    $0x81,%edx
    0.00 :   cd8b1:  mov    $0x1,%ecx
    0.00 :   cd8b6:  xor    %eax,%eax
    0.00 :   cd8b8:  call   *0xc4d1a(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cd8be:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd8c3:  xor    %ebx,%ebx
    0.00 :   cd8c5:  xor    %ebp,%ebp
    0.00 :   cd8c7:  jmp    cd8ee <std::sys::backtrace::__rust_begin_short_backtrace+0x11ee>
    0.00 :   cd8c9:  nopl   0x0(%rax)
    0.00 :   cd8d0:  call   *0xc4ea2(%rip)        # 192778 <sched_yield@GLIBC_2.2.5>
    0.00 :   cd8d6:  lea    0x1(,%rbp,2),%ecx
    0.00 :   cd8dd:  inc    %ebp
    0.00 :   cd8df:  mov    (%r12),%rax
    0.00 :   cd8e3:  add    %ecx,%ebx
    0.00 :   cd8e5:  test   %rax,%rax
    0.00 :   cd8e8:  jne    cd078 <std::sys::backtrace::__rust_begin_short_backtrace+0x978>
    0.00 :   cd8ee:  cmp    $0x7,%ebp
    0.00 :   cd8f1:  jae    cd8d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x11d0>
    0.00 :   cd8f3:  test   %ebp,%ebp
    0.00 :   cd8f5:  je     cd8d6 <std::sys::backtrace::__rust_begin_short_backtrace+0x11d6>
    0.00 :   cd8f7:  lea    -0x1(%rbx),%ecx
    0.00 :   cd8fa:  mov    %ebx,%eax
    0.00 :   cd8fc:  and    $0x7,%eax
    0.00 :   cd8ff:  cmp    $0x7,%ecx
    0.00 :   cd902:  jb     cd930 <std::sys::backtrace::__rust_begin_short_backtrace+0x1230>
    0.00 :   cd904:  mov    %ebx,%ecx
    0.00 :   cd906:  and    $0xfffffff8,%ecx
    0.00 :   cd909:  nopl   0x0(%rax)
    0.00 :   cd910:  pause
    0.00 :   cd912:  pause
    0.00 :   cd914:  pause
    0.00 :   cd916:  pause
    0.00 :   cd918:  pause
    0.00 :   cd91a:  pause
    0.00 :   cd91c:  pause
    0.00 :   cd91e:  pause
    0.00 :   cd920:  add    $0xfffffff8,%ecx
    0.00 :   cd923:  jne    cd910 <std::sys::backtrace::__rust_begin_short_backtrace+0x1210>
    0.00 :   cd925:  test   %eax,%eax
    0.00 :   cd927:  je     cd8d6 <std::sys::backtrace::__rust_begin_short_backtrace+0x11d6>
    0.00 :   cd929:  nopl   0x0(%rax)
    0.00 :   cd930:  pause
    0.00 :   cd932:  dec    %eax
    0.00 :   cd934:  jne    cd930 <std::sys::backtrace::__rust_begin_short_backtrace+0x1230>
    0.00 :   cd936:  jmp    cd8d6 <std::sys::backtrace::__rust_begin_short_backtrace+0x11d6>
    0.00 :   cd938:  movzbl 0x1(%r12),%eax
    0.00 :   cd93e:  test   %al,%al
    0.00 :   cd940:  je     cd977 <std::sys::backtrace::__rust_begin_short_backtrace+0x1277>
    0.00 :   cd942:  cmpb   $0x0,0x2(%r12)
    0.00 :   cd948:  movb   $0x0,0x2(%r12)
    0.00 :   cd94e:  je     ce20f <std::sys::backtrace::__rust_begin_short_backtrace+0x1b0f>
    0.00 :   cd954:  mov    %r12,%rdi
    0.00 :   cd957:  call   *0xc48eb(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cd95d:  mov    $0x2,%bpl
    0.00 :   cd960:  lock decq (%r14)
    0.00 :   cd964:  je     cdb00 <std::sys::backtrace::__rust_begin_short_backtrace+0x1400>
    0.00 :   cd96a:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd96f:  mov    $0x1,%bpl
    0.00 :   cd972:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd977:  xor    %ebx,%ebx
    0.00 :   cd979:  mov    0xc4df8(%rip),%r15        # 192778 <sched_yield@GLIBC_2.2.5>
    0.00 :   cd980:  xor    %ebp,%ebp
    0.00 :   cd982:  jmp    cd99c <std::sys::backtrace::__rust_begin_short_backtrace+0x129c>
    0.00 :   cd984:  call   *%r15
    0.00 :   cd987:  lea    0x1(,%rbp,2),%eax
    0.00 :   cd98e:  inc    %ebp
    0.00 :   cd990:  movzbl 0x1(%r12),%ecx
    0.00 :   cd996:  add    %eax,%ebx
    0.00 :   cd998:  test   %cl,%cl
    0.00 :   cd99a:  jne    cd942 <std::sys::backtrace::__rust_begin_short_backtrace+0x1242>
    0.00 :   cd99c:  cmp    $0x7,%ebp
    0.00 :   cd99f:  jae    cd984 <std::sys::backtrace::__rust_begin_short_backtrace+0x1284>
    0.00 :   cd9a1:  test   %ebp,%ebp
    0.00 :   cd9a3:  je     cd987 <std::sys::backtrace::__rust_begin_short_backtrace+0x1287>
    0.00 :   cd9a5:  lea    -0x1(%rbx),%ecx
    0.00 :   cd9a8:  mov    %ebx,%eax
    0.00 :   cd9aa:  and    $0x7,%eax
    0.00 :   cd9ad:  cmp    $0x7,%ecx
    0.00 :   cd9b0:  jb     cd9e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e0>
    0.00 :   cd9b2:  mov    %ebx,%ecx
    0.00 :   cd9b4:  and    $0xfffffff8,%ecx
    0.00 :   cd9b7:  nopw   0x0(%rax,%rax,1)
    0.00 :   cd9c0:  pause
    0.00 :   cd9c2:  pause
    0.00 :   cd9c4:  pause
    0.00 :   cd9c6:  pause
    0.00 :   cd9c8:  pause
    0.00 :   cd9ca:  pause
    0.00 :   cd9cc:  pause
    0.00 :   cd9ce:  pause
    0.00 :   cd9d0:  add    $0xfffffff8,%ecx
    0.00 :   cd9d3:  jne    cd9c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x12c0>
    0.00 :   cd9d5:  test   %eax,%eax
    0.00 :   cd9d7:  je     cd987 <std::sys::backtrace::__rust_begin_short_backtrace+0x1287>
    0.00 :   cd9d9:  nopl   0x0(%rax)
    0.00 :   cd9e0:  pause
    0.00 :   cd9e2:  dec    %eax
    0.00 :   cd9e4:  jne    cd9e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e0>
    0.00 :   cd9e6:  jmp    cd987 <std::sys::backtrace::__rust_begin_short_backtrace+0x1287>
    0.00 :   cd9e8:  xor    %ebp,%ebp
    0.00 :   cd9ea:  jmp    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd9ef:  mov    0x8(%rsp),%rdi
    0.00 :   cd9f4:  call   *0xc4c26(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cd9fa:  jmp    cce5e <std::sys::backtrace::__rust_begin_short_backtrace+0x75e>
    0.00 :   cd9ff:  mov    $0x1,%r12b
    0.00 :   cda02:  mov    $0x1,%r13b
    0.00 :   cda05:  call   *0xc4bbd(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cda0b:  mov    %eax,%ebp
    0.00 :   cda0d:  xor    $0x1,%bpl
    0.00 :   cda11:  mov    0x8(%rsp),%rcx
    0.00 :   cda16:  movzbl 0x4(%rcx),%eax
    0.00 :   cda1a:  test   %al,%al
    0.00 :   cda1c:  je     cce87 <std::sys::backtrace::__rust_begin_short_backtrace+0x787>
    0.00 :   cda22:  mov    %rcx,0x20(%rsp)
    0.00 :   cda27:  mov    %bpl,0x28(%rsp)
    0.00 :   cda2c:  lea    -0xb0549(%rip),%rdi        # 1d4ea <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0xd2>
    0.00 :   cda33:  lea    0xbfe96(%rip),%rcx        # 18d8d0 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x60>
    0.00 :   cda3a:  lea    0xbf94f(%rip),%r8        # 18d390 <anon.de2471ab41e489a293ba001b839d8fc3.75.llvm.10657235172099788962+0x180>
    0.00 :   cda41:  lea    0x20(%rsp),%rdx
    0.00 :   cda46:  mov    $0x2b,%esi
    0.00 :   cda4b:  call   *0xc482f(%rip)        # 192280 <_DYNAMIC+0x268>
    0.00 :   cda51:  jmp    ce236 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b36>
    0.00 :   cda56:  mov    %r15,%rdi
    0.00 :   cda59:  call   c64f0 <std::sys::thread_local::native::lazy::Storage<T,D>::get_or_init_slow>
    0.00 :   cda5e:  mov    %rax,%r15
    0.00 :   cda61:  test   %rax,%rax
    0.00 :   cda64:  jne    cd7e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x10e0>
    0.00 :   cda6a:  lea    0x50(%rsp),%rdi
    0.00 :   cda6f:  call   d1a10 <std::sync::mpmc::context::Context::with::{{closure}}>
    0.00 :   cda74:  mov    %eax,%ebp
    0.00 :   cda76:  jmp    cd86a <std::sys::backtrace::__rust_begin_short_backtrace+0x116a>
    0.00 :   cda7b:  call   *0xc52f7(%rip)        # 192d78 <_DYNAMIC+0xd60>
    0.00 :   cda81:  mov    %rax,%r15
    0.00 :   cda84:  mov    %rax,0x18(%rsp)
    0.00 :   cda89:  movb   $0x2,0x70(%rsp)
    0.00 :   cda8e:  mov    %rbx,0x20(%rsp)
    0.00 :   cda93:  mov    %r13,0x28(%rsp)
    0.00 :   cda98:  mov    0x8(%rsp),%rax
    0.00 :   cda9d:  mov    %rax,0x30(%rsp)
    0.00 :   cdaa2:  mov    %rax,0x38(%rsp)
    0.00 :   cdaa7:  mov    %bpl,0x40(%rsp)
    0.00 :   cdaac:  lea    0x20(%rsp),%rdi
    0.00 :   cdab1:  mov    %r15,%rsi
    0.00 :   cdab4:  call   cfdd0 <std::sync::mpmc::zero::Channel<T>::recv::{{closure}}>
    0.00 :   cdab9:  mov    %eax,%ebp
    0.00 :   cdabb:  lock decq (%r15)
    0.00 :   cdabf:  jne    cd86a <std::sys::backtrace::__rust_begin_short_backtrace+0x116a>
    0.00 :   cdac5:  lea    0x18(%rsp),%rdi
    0.00 :   cdaca:  jmp    cd864 <std::sys::backtrace::__rust_begin_short_backtrace+0x1164>
    0.00 :   cdacf:  mov    $0xca,%edi
    0.00 :   cdad4:  mov    $0x81,%edx
    0.00 :   cdad9:  mov    $0x1,%ecx
    0.00 :   cdade:  xor    %eax,%eax
    0.00 :   cdae0:  call   *0xc4af2(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cdae6:  mov    0xb0(%rsp),%r12
    0.00 :   cdaee:  test   %r12,%r12
    0.00 :   cdaf1:  jne    ccff8 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f8>
    0.00 :   cdaf7:  mov    $0x1,%bpl
    0.00 :   cdafa:  lock decq (%r14)
    0.00 :   cdafe:  jne    cdb0b <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cdb00:  lea    0x20(%rsp),%rdi
    0.00 :   cdb05:  call   *0xc563d(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   cdb0b:  cmp    $0x2,%bpl
    0.00 :   cdb0f:  jne    cdb5d <std::sys::backtrace::__rust_begin_short_backtrace+0x145d>
    0.00 :   cdb11:  mov    0x78(%rsp),%rax
    0.00 :   cdb16:  mov    0x10(%rax),%rdi
    0.00 :   cdb1a:  mov    $0x1,%r13b
    0.00 :   cdb1d:  xor    %r12d,%r12d
    0.00 :   cdb20:  mov    $0x4,%esi
    0.00 :   cdb25:  call   102ff0 <vthread::worker_context::attach>
    0.00 :   cdb2a:  mov    0x78(%rsp),%rax
    0.00 :   cdb2f:  movups 0x18(%rax),%xmm0
    0.00 :   cdb33:  movaps %xmm0,0x50(%rsp)
    0.00 :   cdb38:  mov    0x28(%rax),%rax
    0.00 :   cdb3c:  mov    %rax,0x60(%rsp)
    0.00 :   cdb41:  mov    0x50(%rsp),%r12
    0.00 :   cdb46:  mov    0x58(%rsp),%rbx
    0.00 :   cdb4b:  lea    0x108(%r12),%r13
    0.00 :   cdb53:  lea    0x168(%r12),%rbp
    0.00 :   cdb5b:  jmp    cdbd3 <std::sys::backtrace::__rust_begin_short_backtrace+0x14d3>
    0.00 :   cdb5d:  mov    0x10(%rsp),%rdi
    0.00 :   cdb62:  mov    0x8(%rsp),%rsi
    0.00 :   cdb67:  mov    0x78(%rsp),%r15
    0.00 :   cdb6c:  call   da810 <core::ptr::drop_in_place<std::sync::mpsc::Receiver<()>>>
    0.00 :   cdb71:  mov    0x10(%r15),%rdi
    0.00 :   cdb75:  cmp    $0xffffffffffffffff,%rdi
    0.00 :   cdb79:  je     cdb88 <std::sys::backtrace::__rust_begin_short_backtrace+0x1488>
    0.00 :   cdb7b:  lock decq 0x8(%rdi)
    0.00 :   cdb80:  jne    cdb88 <std::sys::backtrace::__rust_begin_short_backtrace+0x1488>
    0.00 :   cdb82:  call   *0xc46c0(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cdb88:  lea    0x18(%r15),%rdi
    0.00 :   cdb8c:  call   d5850 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   cdb91:  mov    0x30(%r15),%rbx
    0.00 :   cdb95:  jmp    cdfcc <std::sys::backtrace::__rust_begin_short_backtrace+0x18cc>
    0.00 :   cdb9a:  mov    $0xca,%edi
    0.00 :   cdb9f:  mov    %rbp,%rsi
    0.00 :   cdba2:  mov    $0x81,%edx
    0.00 :   cdba7:  mov    $0x1,%ecx
    0.00 :   cdbac:  xor    %eax,%eax
    0.00 :   cdbae:  call   *0xc4a24(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cdbb4:  test   %r13b,%r13b
    0.00 :   cdbb7:  jne    cdc8b <std::sys::backtrace::__rust_begin_short_backtrace+0x158b>
    0.00 :   cdbbd:  nopl   (%rax)
    0.00 :   cdbc0:  mov    %r14,%r13
    0.00 :   cdbc3:  mov    %r14,%rdi
    0.00 :   cdbc6:  mov    %r15,%rsi
    0.00 :   cdbc9:  mov    $0x3b9aca00,%ecx
    0.00 :   cdbce:  call   118180 <vthread::signal::Signal::wait>
    0.00 :   cdbd3:  mov    %r13,%r14
    0.00 :   cdbd6:  mov    0x0(%r13),%r15
    0.00 :   cdbda:  movzbl 0x10(%rbx),%eax
    0.00 :   cdbde:  test   %al,%al
    0.00 :   cdbe0:  je     cdbc0 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c0>
    0.00 :   cdbe2:  xor    %eax,%eax
    0.00 :   cdbe4:  mov    $0x1,%ecx
    0.00 :   cdbe9:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   cdbee:  jne    cdc4d <std::sys::backtrace::__rust_begin_short_backtrace+0x154d>
    0.00 :   cdbf0:  mov    0xc49b1(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cdbf7:  mov    (%rax),%rax
    0.00 :   cdbfa:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cdc04:  test   %rcx,%rax
    0.00 :   cdc07:  jne    cdc58 <std::sys::backtrace::__rust_begin_short_backtrace+0x1558>
    0.00 :   cdc09:  movzbl 0x16c(%r12),%eax
    0.00 :   cdc12:  movzbl 0x221(%r12),%r13d
    0.00 :   cdc1b:  mov    0xc4986(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cdc22:  mov    (%rax),%rax
    0.00 :   cdc25:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cdc2f:  test   %rcx,%rax
    0.00 :   cdc32:  jne    cdc76 <std::sys::backtrace::__rust_begin_short_backtrace+0x1576>
    0.00 :   cdc34:  xor    %eax,%eax
    0.00 :   cdc36:  xchg   %eax,0x0(%rbp)
    0.00 :   cdc39:  cmp    $0x2,%eax
    0.00 :   cdc3c:  je     cdb9a <std::sys::backtrace::__rust_begin_short_backtrace+0x149a>
    0.00 :   cdc42:  test   %r13b,%r13b
    0.00 :   cdc45:  je     cdbc0 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c0>
    0.00 :   cdc4b:  jmp    cdc8b <std::sys::backtrace::__rust_begin_short_backtrace+0x158b>
    0.00 :   cdc4d:  mov    %rbp,%rdi
    0.00 :   cdc50:  call   *0xc49ca(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cdc56:  jmp    cdbf0 <std::sys::backtrace::__rust_begin_short_backtrace+0x14f0>
    0.00 :   cdc58:  call   *0xc496a(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cdc5e:  movzbl 0x16c(%r12),%ecx
    0.00 :   cdc67:  movzbl 0x221(%r12),%r13d
    0.00 :   cdc70:  test   %al,%al
    0.00 :   cdc72:  jne    cdc1b <std::sys::backtrace::__rust_begin_short_backtrace+0x151b>
    0.00 :   cdc74:  jmp    cdc34 <std::sys::backtrace::__rust_begin_short_backtrace+0x1534>
    0.00 :   cdc76:  call   *0xc494c(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cdc7c:  test   %al,%al
    0.00 :   cdc7e:  jne    cdc34 <std::sys::backtrace::__rust_begin_short_backtrace+0x1534>
    0.00 :   cdc80:  movb   $0x1,0x16c(%r12)
    0.00 :   cdc89:  jmp    cdc34 <std::sys::backtrace::__rust_begin_short_backtrace+0x1534>
    0.00 :   cdc8b:  mov    $0x1,%ecx
    0.00 :   cdc90:  xor    %eax,%eax
    0.00 :   cdc92:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   cdc97:  jne    ce027 <std::sys::backtrace::__rust_begin_short_backtrace+0x1927>
    0.00 :   cdc9d:  mov    0xc4904(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cdca4:  mov    (%rax),%rax
    0.00 :   cdca7:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cdcb1:  test   %rcx,%rax
    0.00 :   cdcb4:  jne    ce035 <std::sys::backtrace::__rust_begin_short_backtrace+0x1935>
    0.00 :   cdcba:  movzbl 0x16c(%r12),%eax
    0.00 :   cdcc3:  movzbl 0x221(%r12),%eax
    0.00 :   cdccc:  cmp    $0x3,%al
    0.00 :   cdcce:  mov    $0x2,%ecx
    0.00 :   cdcd3:  cmovae %eax,%ecx
    0.00 :   cdcd6:  mov    %cl,0x221(%r12)
    0.00 :   cdcde:  mov    0xc48c3(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cdce5:  mov    (%rax),%rax
    0.00 :   cdce8:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cdcf2:  test   %rcx,%rax
    0.00 :   cdcf5:  jne    ce08c <std::sys::backtrace::__rust_begin_short_backtrace+0x198c>
    0.00 :   cdcfb:  xor    %eax,%eax
    0.00 :   cdcfd:  xchg   %eax,0x0(%rbp)
    0.00 :   cdd00:  cmp    $0x2,%eax
    0.00 :   cdd03:  je     ce06d <std::sys::backtrace::__rust_begin_short_backtrace+0x196d>
    0.00 :   cdd09:  mov    %r14,%rdi
    0.00 :   cdd0c:  call   118460 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10657235172099788962>
    0.00 :   cdd11:  mov    0x60(%rsp),%rbx
    0.00 :   cdd16:  mov    0x10(%rbx),%rdi
    0.00 :   cdd1a:  lea    0x8(%r12),%r15
    0.00 :   cdd1f:  jmp    cdd32 <std::sys::backtrace::__rust_begin_short_backtrace+0x1632>
    0.00 :   cdd21:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cdd30:  pause
    0.00 :   cdd32:  mov    (%r15),%rax
    0.00 :   cdd35:  data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cdd40:  cmp    $0xffffffffffffffff,%rax
    0.00 :   cdd44:  je     cdd30 <std::sys::backtrace::__rust_begin_short_backtrace+0x1630>
    0.00 :   cdd46:  test   %rax,%rax
    0.00 :   cdd49:  js     cdff1 <std::sys::backtrace::__rust_begin_short_backtrace+0x18f1>
    0.00 :   cdd4f:  lea    0x1(%rax),%rcx
    0.00 :   cdd53:  lock cmpxchg %rcx,(%r15)
    0.00 :   cdd58:  jne    cdd40 <std::sys::backtrace::__rust_begin_short_backtrace+0x1640>
    0.00 :   cdd5a:  add    $0x10,%rdi
    0.00 :   cdd5e:  mov    %r12,0x20(%rsp)
    0.00 :   cdd63:  lea    0x20(%rsp),%rsi
    0.00 :   cdd68:  xor    %edx,%edx
    0.00 :   cdd6a:  call   12eb00 <vthread::join_slot::JoinSlots::join_all>
    0.00 :   cdd6f:  cmp    $0xffffffffffffffff,%r12
    0.00 :   cdd73:  je     cdd84 <std::sys::backtrace::__rust_begin_short_backtrace+0x1684>
    0.00 :   cdd75:  lock decq (%r15)
    0.00 :   cdd79:  jne    cdd84 <std::sys::backtrace::__rust_begin_short_backtrace+0x1684>
    0.00 :   cdd7b:  mov    %r12,%rdi
    0.00 :   cdd7e:  call   *0xc44c4(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cdd84:  mov    0x10(%rbx),%rdi
    0.00 :   cdd88:  add    $0x10,%rdi
    0.00 :   cdd8c:  call   12e8d0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   cdd91:  test   %al,%al
    0.00 :   cdd93:  je     cdfa0 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cdd99:  mov    0x98(%r12),%rax
    0.00 :   cdda1:  mov    0xa0(%r12),%rcx
    0.00 :   cdda9:  shl    $0x3,%rcx
    0.00 :   cddad:  xor    %edx,%edx
    0.00 :   cddaf:  jmp    cddd4 <std::sys::backtrace::__rust_begin_short_backtrace+0x16d4>
    0.00 :   cddb1:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cddc0:  mov    0xd0(%rsi),%rsi
    0.00 :   cddc7:  add    $0x8,%rdx
    0.00 :   cddcb:  test   %rsi,%rsi
    0.00 :   cddce:  jne    cdfa0 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cddd4:  cmp    %rdx,%rcx
    0.00 :   cddd7:  je     cde0a <std::sys::backtrace::__rust_begin_short_backtrace+0x170a>
    0.00 :   cddd9:  mov    (%rax,%rdx,1),%rsi
    0.00 :   cdddd:  movzbl 0xe8(%rsi),%edi
    0.00 :   cdde4:  test   %dil,%dil
    0.00 :   cdde7:  je     cddc0 <std::sys::backtrace::__rust_begin_short_backtrace+0x16c0>
    0.00 :   cdde9:  movzbl 0xe9(%rsi),%edi
    0.00 :   cddf0:  test   %dil,%dil
    0.00 :   cddf3:  je     cdfa0 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cddf9:  movzbl 0xea(%rsi),%edi
    0.00 :   cde00:  test   %dil,%dil
    0.00 :   cde03:  jne    cddc0 <std::sys::backtrace::__rust_begin_short_backtrace+0x16c0>
    0.00 :   cde05:  jmp    cdfa0 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cde0a:  mov    0x100(%r12),%eax
    0.00 :   cde12:  test   %eax,%eax
    0.00 :   cde14:  jne    cdfa0 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cde1a:  mov    0xd8(%r12),%r15
    0.00 :   cde22:  mov    0xe8(%r12),%rdi
    0.00 :   cde2a:  call   12b9a0 <vthread::blocking::pool::Pool::stop>
    0.00 :   cde2f:  add    $0x10,%r15
    0.00 :   cde33:  movabs $0x7fffffffffffffff,%rax
    0.00 :   cde3d:  inc    %rax
    0.00 :   cde40:  mov    %rax,0x20(%rsp)
    0.00 :   cde45:  lea    0x20(%rsp),%rsi
    0.00 :   cde4a:  mov    %r15,%rdi
    0.00 :   cde4d:  call   130350 <vthread::readiness::Inner::close>
    0.00 :   cde52:  mov    $0x1,%ecx
    0.00 :   cde57:  xor    %eax,%eax
    0.00 :   cde59:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   cde5e:  jne    ce104 <std::sys::backtrace::__rust_begin_short_backtrace+0x1a04>
    0.00 :   cde64:  mov    0xc473d(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cde6b:  mov    (%rax),%rax
    0.00 :   cde6e:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cde78:  test   %rcx,%rax
    0.00 :   cde7b:  jne    ce112 <std::sys::backtrace::__rust_begin_short_backtrace+0x1a12>
    0.00 :   cde81:  movzbl 0x16c(%r12),%eax
    0.00 :   cde8a:  movzbl 0x221(%r12),%eax
    0.00 :   cde93:  cmp    $0x4,%al
    0.00 :   cde95:  mov    $0x3,%ecx
    0.00 :   cde9a:  cmovae %eax,%ecx
    0.00 :   cde9d:  mov    %cl,0x221(%r12)
    0.00 :   cdea5:  mov    0xc46fc(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cdeac:  mov    (%rax),%rax
    0.00 :   cdeaf:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cdeb9:  test   %rcx,%rax
    0.00 :   cdebc:  jne    ce1ce <std::sys::backtrace::__rust_begin_short_backtrace+0x1ace>
    0.00 :   cdec2:  xor    %eax,%eax
    0.00 :   cdec4:  xchg   %eax,0x0(%rbp)
    0.00 :   cdec7:  cmp    $0x2,%eax
    0.00 :   cdeca:  je     ce14a <std::sys::backtrace::__rust_begin_short_backtrace+0x1a4a>
    0.00 :   cded0:  mov    %r14,%rdi
    0.00 :   cded3:  call   118460 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10657235172099788962>
    0.00 :   cded8:  mov    0xd8(%r12),%rsi
    0.00 :   cdee0:  mov    0xe0(%r12),%rdi
    0.00 :   cdee8:  add    $0x10,%rdi
    0.00 :   cdeec:  add    $0x10,%rsi
    0.00 :   cdef0:  mov    $0x3,%edx
    0.00 :   cdef5:  call   12eb00 <vthread::join_slot::JoinSlots::join_all>
    0.00 :   cdefa:  mov    $0x1,%ecx
    0.00 :   cdeff:  xor    %eax,%eax
    0.00 :   cdf01:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   cdf06:  jne    ce169 <std::sys::backtrace::__rust_begin_short_backtrace+0x1a69>
    0.00 :   cdf0c:  mov    0xc4695(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cdf13:  mov    (%rax),%rax
    0.00 :   cdf16:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cdf20:  test   %rcx,%rax
    0.00 :   cdf23:  jne    ce177 <std::sys::backtrace::__rust_begin_short_backtrace+0x1a77>
    0.00 :   cdf29:  movzbl 0x16c(%r12),%eax
    0.00 :   cdf32:  movzbl 0x221(%r12),%eax
    0.00 :   cdf3b:  cmp    $0x5,%al
    0.00 :   cdf3d:  mov    $0x4,%ecx
    0.00 :   cdf42:  cmovae %eax,%ecx
    0.00 :   cdf45:  mov    %cl,0x221(%r12)
    0.00 :   cdf4d:  mov    0xc4654(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cdf54:  mov    (%rax),%rax
    0.00 :   cdf57:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cdf61:  test   %rcx,%rax
    0.00 :   cdf64:  jne    ce1ea <std::sys::backtrace::__rust_begin_short_backtrace+0x1aea>
    0.00 :   cdf6a:  xor    %eax,%eax
    0.00 :   cdf6c:  xchg   %eax,0x0(%rbp)
    0.00 :   cdf6f:  cmp    $0x2,%eax
    0.00 :   cdf72:  je     ce1af <std::sys::backtrace::__rust_begin_short_backtrace+0x1aaf>
    0.00 :   cdf78:  mov    %r14,%rdi
    0.00 :   cdf7b:  call   118460 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10657235172099788962>
    0.00 :   cdf80:  mov    0xf0(%r12),%rdi
    0.00 :   cdf88:  add    $0x10,%rdi
    0.00 :   cdf8c:  add    $0xf8,%r12
    0.00 :   cdf93:  mov    %r12,%rsi
    0.00 :   cdf96:  mov    $0x2,%edx
    0.00 :   cdf9b:  call   12eb00 <vthread::join_slot::JoinSlots::join_all>
    0.00 :   cdfa0:  xor    %r12d,%r12d
    0.00 :   cdfa3:  lea    0x50(%rsp),%rdi
    0.00 :   cdfa8:  xor    %r13d,%r13d
    0.00 :   cdfab:  call   d5850 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   cdfb0:  mov    0x78(%rsp),%r15
    0.00 :   cdfb5:  mov    0x30(%r15),%rbx
    0.00 :   cdfb9:  movb   $0x1,0x38(%rbx)
    0.00 :   cdfbd:  mov    0x10(%rsp),%rdi
    0.00 :   cdfc2:  mov    0x8(%rsp),%rsi
    0.00 :   cdfc7:  call   da810 <core::ptr::drop_in_place<std::sync::mpsc::Receiver<()>>>
    0.00 :   cdfcc:  lock decq (%rbx)
    0.00 :   cdfd0:  jne    cdfdf <std::sys::backtrace::__rust_begin_short_backtrace+0x18df>
    0.00 :   cdfd2:  add    $0x30,%r15
    0.00 :   cdfd6:  mov    %r15,%rdi
    0.00 :   cdfd9:  call   *0xc5271(%rip)        # 193250 <_DYNAMIC+0x1238>
    0.00 :   cdfdf:  add    $0xc8,%rsp
    0.00 :   cdfe6:  pop    %rbx
    0.00 :   cdfe7:  pop    %r12
    0.00 :   cdfe9:  pop    %r13
    0.00 :   cdfeb:  pop    %r14
    0.00 :   cdfed:  pop    %r15
    0.00 :   cdfef:  pop    %rbp
    0.00 :   cdff0:  ret
    0.00 :   cdff1:  lea    0xbf158(%rip),%rax        # 18d150 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x210>
    0.00 :   cdff8:  mov    %rax,0x20(%rsp)
    0.00 :   cdffd:  lea    0x5aec(%rip),%rax        # d3af0 <_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hb2a2ab9295a6d20aE.llvm.10657235172099788962>
    0.00 :   ce004:  mov    %rax,0x28(%rsp)
    0.00 :   ce009:  lea    -0xbb815(%rip),%rdi        # 127fb <anon.48996dcd35f4b7aad43cb5fc1472ecbf.144.llvm.7041895458470441471>
    0.00 :   ce010:  lea    0xbff09(%rip),%rdx        # 18df20 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x6b0>
    0.00 :   ce017:  lea    0x20(%rsp),%rsi
    0.00 :   ce01c:  call   *0xc427e(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   ce022:  jmp    ce236 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b36>
    0.00 :   ce027:  mov    %rbp,%rdi
    0.00 :   ce02a:  call   *0xc45f0(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ce030:  jmp    cdc9d <std::sys::backtrace::__rust_begin_short_backtrace+0x159d>
    0.00 :   ce035:  call   *0xc458d(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce03b:  movzbl 0x16c(%r12),%ecx
    0.00 :   ce044:  movzbl 0x221(%r12),%ecx
    0.00 :   ce04d:  cmp    $0x3,%cl
    0.00 :   ce050:  mov    $0x2,%edx
    0.00 :   ce055:  cmovae %ecx,%edx
    0.00 :   ce058:  mov    %dl,0x221(%r12)
    0.00 :   ce060:  test   %al,%al
    0.00 :   ce062:  jne    cdcde <std::sys::backtrace::__rust_begin_short_backtrace+0x15de>
    0.00 :   ce068:  jmp    cdcfb <std::sys::backtrace::__rust_begin_short_backtrace+0x15fb>
    0.00 :   ce06d:  mov    $0xca,%edi
    0.00 :   ce072:  mov    %rbp,%rsi
    0.00 :   ce075:  mov    $0x81,%edx
    0.00 :   ce07a:  mov    $0x1,%ecx
    0.00 :   ce07f:  xor    %eax,%eax
    0.00 :   ce081:  call   *0xc4551(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ce087:  jmp    cdd09 <std::sys::backtrace::__rust_begin_short_backtrace+0x1609>
    0.00 :   ce08c:  call   *0xc4536(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce092:  test   %al,%al
    0.00 :   ce094:  jne    cdcfb <std::sys::backtrace::__rust_begin_short_backtrace+0x15fb>
    0.00 :   ce09a:  movb   $0x1,0x16c(%r12)
    0.00 :   ce0a3:  jmp    cdcfb <std::sys::backtrace::__rust_begin_short_backtrace+0x15fb>
    0.00 :   ce0a8:  mov    $0x1,%r12b
    0.00 :   ce0ab:  mov    $0x1,%r13b
    0.00 :   ce0ae:  call   *0xc4514(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce0b4:  test   %al,%al
    0.00 :   ce0b6:  jne    cd6f4 <std::sys::backtrace::__rust_begin_short_backtrace+0xff4>
    0.00 :   ce0bc:  mov    0x8(%rsp),%rax
    0.00 :   ce0c1:  movb   $0x1,0x4(%rax)
    0.00 :   ce0c5:  jmp    cd6f4 <std::sys::backtrace::__rust_begin_short_backtrace+0xff4>
    0.00 :   ce0ca:  call   *0xc44f8(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce0d0:  test   %al,%al
    0.00 :   ce0d2:  jne    ccfd5 <std::sys::backtrace::__rust_begin_short_backtrace+0x8d5>
    0.00 :   ce0d8:  mov    0x8(%rsp),%rax
    0.00 :   ce0dd:  movb   $0x1,0x4(%rax)
    0.00 :   ce0e1:  jmp    ccfd5 <std::sys::backtrace::__rust_begin_short_backtrace+0x8d5>
    0.00 :   ce0e6:  mov    $0x1,%r12b
    0.00 :   ce0e9:  mov    $0x1,%r13b
    0.00 :   ce0ec:  call   *0xc44d6(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce0f2:  test   %al,%al
    0.00 :   ce0f4:  jne    cd896 <std::sys::backtrace::__rust_begin_short_backtrace+0x1196>
    0.00 :   ce0fa:  movb   $0x1,0x4(%r15)
    0.00 :   ce0ff:  jmp    cd896 <std::sys::backtrace::__rust_begin_short_backtrace+0x1196>
    0.00 :   ce104:  mov    %rbp,%rdi
    0.00 :   ce107:  call   *0xc4513(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ce10d:  jmp    cde64 <std::sys::backtrace::__rust_begin_short_backtrace+0x1764>
    0.00 :   ce112:  call   *0xc44b0(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce118:  movzbl 0x16c(%r12),%ecx
    0.00 :   ce121:  movzbl 0x221(%r12),%ecx
    0.00 :   ce12a:  cmp    $0x4,%cl
    0.00 :   ce12d:  mov    $0x3,%edx
    0.00 :   ce132:  cmovae %ecx,%edx
    0.00 :   ce135:  mov    %dl,0x221(%r12)
    0.00 :   ce13d:  test   %al,%al
    0.00 :   ce13f:  jne    cdea5 <std::sys::backtrace::__rust_begin_short_backtrace+0x17a5>
    0.00 :   ce145:  jmp    cdec2 <std::sys::backtrace::__rust_begin_short_backtrace+0x17c2>
    0.00 :   ce14a:  mov    $0xca,%edi
    0.00 :   ce14f:  mov    %rbp,%rsi
    0.00 :   ce152:  mov    $0x81,%edx
    0.00 :   ce157:  mov    $0x1,%ecx
    0.00 :   ce15c:  xor    %eax,%eax
    0.00 :   ce15e:  call   *0xc4474(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ce164:  jmp    cded0 <std::sys::backtrace::__rust_begin_short_backtrace+0x17d0>
    0.00 :   ce169:  mov    %rbp,%rdi
    0.00 :   ce16c:  call   *0xc44ae(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   ce172:  jmp    cdf0c <std::sys::backtrace::__rust_begin_short_backtrace+0x180c>
    0.00 :   ce177:  call   *0xc444b(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce17d:  movzbl 0x16c(%r12),%ecx
    0.00 :   ce186:  movzbl 0x221(%r12),%ecx
    0.00 :   ce18f:  cmp    $0x5,%cl
    0.00 :   ce192:  mov    $0x4,%edx
    0.00 :   ce197:  cmovae %ecx,%edx
    0.00 :   ce19a:  mov    %dl,0x221(%r12)
    0.00 :   ce1a2:  test   %al,%al
    0.00 :   ce1a4:  jne    cdf4d <std::sys::backtrace::__rust_begin_short_backtrace+0x184d>
    0.00 :   ce1aa:  jmp    cdf6a <std::sys::backtrace::__rust_begin_short_backtrace+0x186a>
    0.00 :   ce1af:  mov    $0xca,%edi
    0.00 :   ce1b4:  mov    %rbp,%rsi
    0.00 :   ce1b7:  mov    $0x81,%edx
    0.00 :   ce1bc:  mov    $0x1,%ecx
    0.00 :   ce1c1:  xor    %eax,%eax
    0.00 :   ce1c3:  call   *0xc440f(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   ce1c9:  jmp    cdf78 <std::sys::backtrace::__rust_begin_short_backtrace+0x1878>
    0.00 :   ce1ce:  call   *0xc43f4(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce1d4:  test   %al,%al
    0.00 :   ce1d6:  jne    cdec2 <std::sys::backtrace::__rust_begin_short_backtrace+0x17c2>
    0.00 :   ce1dc:  movb   $0x1,0x16c(%r12)
    0.00 :   ce1e5:  jmp    cdec2 <std::sys::backtrace::__rust_begin_short_backtrace+0x17c2>
    0.00 :   ce1ea:  call   *0xc43d8(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   ce1f0:  test   %al,%al
    0.00 :   ce1f2:  jne    cdf6a <std::sys::backtrace::__rust_begin_short_backtrace+0x186a>
    0.00 :   ce1f8:  movb   $0x1,0x16c(%r12)
    0.00 :   ce201:  jmp    cdf6a <std::sys::backtrace::__rust_begin_short_backtrace+0x186a>
    0.00 :   ce206:  lea    0xbf16b(%rip),%rdi        # 18d378 <anon.de2471ab41e489a293ba001b839d8fc3.75.llvm.10657235172099788962+0x168>
    0.00 :   ce20d:  jmp    ce216 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b16>
    0.00 :   ce20f:  lea    0xbf14a(%rip),%rdi        # 18d360 <anon.de2471ab41e489a293ba001b839d8fc3.75.llvm.10657235172099788962+0x150>
    0.00 :   ce216:  call   *0xc41f4(%rip)        # 192410 <_DYNAMIC+0x3f8>
    0.00 :   ce21c:  jmp    ce236 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b36>
    0.00 :   ce21e:  lea    0xbee83(%rip),%rdx        # 18d0a8 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x168>
    0.00 :   ce225:  mov    0xc0(%rsp),%rdi
    0.00 :   ce22d:  mov    %r12,%rsi
    0.00 :   ce230:  call   *0xc4082(%rip)        # 1922b8 <_DYNAMIC+0x2a0>
    0.00 :   ce236:  ud2
    0.00 :   ce238:  mov    %rax,%rbx
    0.00 :   ce23b:  lock decq (%r15)
    0.00 :   ce23f:  je     ce2a5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ba5>
    0.00 :   ce241:  jmp    ce2b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1bb0>
    0.00 :   ce243:  mov    %rax,%rbx
    0.00 :   ce246:  jmp    ce2b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1bb0>
    0.00 :   ce248:  mov    %rax,%rbx
    0.00 :   ce24b:  lock decq (%r15)
    0.00 :   ce24f:  jmp    ce2dc <std::sys::backtrace::__rust_begin_short_backtrace+0x1bdc>
    0.00 :   ce254:  mov    %rax,%rbx
    0.00 :   ce257:  lock decq (%r15)
    0.00 :   ce25b:  mov    $0x1,%r12b
    0.00 :   ce25e:  je     ce302 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c02>
    0.00 :   ce264:  jmp    ce30d <std::sys::backtrace::__rust_begin_short_backtrace+0x1c0d>
    0.00 :   ce269:  mov    %rax,%rbx
    0.00 :   ce26c:  movzbl %bpl,%esi
    0.00 :   ce270:  mov    0x8(%rsp),%rdi
    0.00 :   ce275:  call   dce00 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::control::State>>>
    0.00 :   ce27a:  jmp    ce3b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1cb8>
    0.00 :   ce27f:  call   *0xc41d3(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   ce285:  mov    %rax,%rbx
    0.00 :   ce288:  jmp    ce3b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1cb8>
    0.00 :   ce28d:  mov    %rax,%rbx
    0.00 :   ce290:  mov    $0x1,%r12b
    0.00 :   ce293:  mov    $0x1,%r13b
    0.00 :   ce296:  jmp    ce3e3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ce3>
    0.00 :   ce29b:  mov    %rax,%rbx
    0.00 :   ce29e:  lock decq (%r12)
    0.00 :   ce2a3:  jne    ce2b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1bb0>
    0.00 :   ce2a5:  lea    0x18(%rsp),%rdi
    0.00 :   ce2aa:  call   *0xc4e98(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   ce2b0:  mov    0x68(%rsp),%rdi
    0.00 :   ce2b5:  mov    $0x1,%r12b
    0.00 :   ce2b8:  mov    0x70(%rsp),%esi
    0.00 :   ce2bc:  call   d5d80 <core::ptr::drop_in_place<core::option::Option<std::sync::poison::mutex::MutexGuard<vthread::control::State>>>>
    0.00 :   ce2c1:  mov    $0x1,%r13b
    0.00 :   ce2c4:  mov    0x10(%rsp),%rbp
    0.00 :   ce2c9:  jmp    ce3e3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ce3>
    0.00 :   ce2ce:  call   *0xc4184(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   ce2d4:  mov    %rax,%rbx
    0.00 :   ce2d7:  lock decq 0x0(%rbp)
    0.00 :   ce2dc:  mov    $0x1,%r12b
    0.00 :   ce2df:  jne    ce3bb <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbb>
    0.00 :   ce2e5:  lea    0x18(%rsp),%rdi
    0.00 :   ce2ea:  call   *0xc4e58(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   ce2f0:  jmp    ce3bb <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbb>
    0.00 :   ce2f5:  mov    %rax,%rbx
    0.00 :   ce2f8:  lock decq (%r12)
    0.00 :   ce2fd:  mov    $0x1,%r12b
    0.00 :   ce300:  jne    ce30d <std::sys::backtrace::__rust_begin_short_backtrace+0x1c0d>
    0.00 :   ce302:  lea    0x18(%rsp),%rdi
    0.00 :   ce307:  call   *0xc4e3b(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   ce30d:  mov    $0x1,%r13b
    0.00 :   ce310:  jmp    ce3e3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ce3>
    0.00 :   ce315:  jmp    ce33c <std::sys::backtrace::__rust_begin_short_backtrace+0x1c3c>
    0.00 :   ce317:  mov    %rax,%rbx
    0.00 :   ce31a:  cmp    $0xffffffffffffffff,%r12
    0.00 :   ce31e:  je     ce3ce <std::sys::backtrace::__rust_begin_short_backtrace+0x1cce>
    0.00 :   ce324:  lock decq (%r15)
    0.00 :   ce328:  jne    ce3ce <std::sys::backtrace::__rust_begin_short_backtrace+0x1cce>
    0.00 :   ce32e:  mov    %r12,%rdi
    0.00 :   ce331:  call   *0xc3f11(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   ce337:  jmp    ce3ce <std::sys::backtrace::__rust_begin_short_backtrace+0x1cce>
    0.00 :   ce33c:  mov    %rax,%rbx
    0.00 :   ce33f:  jmp    ce369 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c69>
    0.00 :   ce341:  mov    %rax,%rbx
    0.00 :   ce344:  mov    0x10(%r15),%rdi
    0.00 :   ce348:  cmp    $0xffffffffffffffff,%rdi
    0.00 :   ce34c:  je     ce35b <std::sys::backtrace::__rust_begin_short_backtrace+0x1c5b>
    0.00 :   ce34e:  lock decq 0x8(%rdi)
    0.00 :   ce353:  jne    ce35b <std::sys::backtrace::__rust_begin_short_backtrace+0x1c5b>
    0.00 :   ce355:  call   *0xc3eed(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   ce35b:  mov    0x78(%rsp),%r15
    0.00 :   ce360:  lea    0x18(%r15),%rdi
    0.00 :   ce364:  call   d5850 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   ce369:  mov    0x30(%r15),%rax
    0.00 :   ce36d:  lock decq (%rax)
    0.00 :   ce371:  jne    ce436 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d36>
    0.00 :   ce377:  mov    0x78(%rsp),%rdi
    0.00 :   ce37c:  add    $0x30,%rdi
    0.00 :   ce380:  call   *0xc4eca(%rip)        # 193250 <_DYNAMIC+0x1238>
    0.00 :   ce386:  jmp    ce436 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d36>
    0.00 :   ce38b:  mov    %rax,%rbx
    0.00 :   ce38e:  jmp    ce3be <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbe>
    0.00 :   ce390:  mov    %rax,%rbx
    0.00 :   ce393:  lock decq (%r14)
    0.00 :   ce397:  mov    $0x1,%r12b
    0.00 :   ce39a:  jne    ce3bb <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbb>
    0.00 :   ce39c:  lea    0x20(%rsp),%rdi
    0.00 :   ce3a1:  call   *0xc4da1(%rip)        # 193148 <_DYNAMIC+0x1130>
    0.00 :   ce3a7:  jmp    ce3bb <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbb>
    0.00 :   ce3a9:  jmp    ce3cb <std::sys::backtrace::__rust_begin_short_backtrace+0x1ccb>
    0.00 :   ce3ab:  mov    %rax,%rbx
    0.00 :   ce3ae:  lea    0x20(%rsp),%rdi
    0.00 :   ce3b3:  call   d6190 <core::ptr::drop_in_place<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<std::sync::mpmc::zero::Inner>>>>
    0.00 :   ce3b8:  mov    $0x1,%r12b
    0.00 :   ce3bb:  mov    $0x1,%r13b
    0.00 :   ce3be:  mov    0x10(%rsp),%rbp
    0.00 :   ce3c3:  jmp    ce3e3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ce3>
    0.00 :   ce3c5:  call   *0xc408d(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   ce3cb:  mov    %rax,%rbx
    0.00 :   ce3ce:  lea    0x50(%rsp),%rdi
    0.00 :   ce3d3:  call   d5850 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   ce3d8:  mov    0x10(%rsp),%rbp
    0.00 :   ce3dd:  xor    %r12d,%r12d
    0.00 :   ce3e0:  xor    %r13d,%r13d
    0.00 :   ce3e3:  mov    %rbp,%rdi
    0.00 :   ce3e6:  mov    0x8(%rsp),%rsi
    0.00 :   ce3eb:  call   da810 <core::ptr::drop_in_place<std::sync::mpsc::Receiver<()>>>
    0.00 :   ce3f0:  mov    0x78(%rsp),%r14
    0.00 :   ce3f5:  test   %r12b,%r12b
    0.00 :   ce3f8:  je     ce411 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d11>
    0.00 :   ce3fa:  mov    0x10(%r14),%rdi
    0.00 :   ce3fe:  cmp    $0xffffffffffffffff,%rdi
    0.00 :   ce402:  je     ce411 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d11>
    0.00 :   ce404:  lock decq 0x8(%rdi)
    0.00 :   ce409:  jne    ce411 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d11>
    0.00 :   ce40b:  call   *0xc3e37(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   ce411:  test   %r13b,%r13b
    0.00 :   ce414:  je     ce41f <std::sys::backtrace::__rust_begin_short_backtrace+0x1d1f>
    0.00 :   ce416:  lea    0x18(%r14),%rdi
    0.00 :   ce41a:  call   d5850 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   ce41f:  mov    0x30(%r14),%rax
    0.00 :   ce423:  lock decq (%rax)
    0.00 :   ce427:  jne    ce436 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d36>
    0.00 :   ce429:  add    $0x30,%r14
    0.00 :   ce42d:  mov    %r14,%rdi
    0.00 :   ce430:  call   *0xc4e1a(%rip)        # 193250 <_DYNAMIC+0x1238>
    0.00 :   ce436:  mov    %rbx,%rdi
    0.00 :   ce439:  call   187ca0 <_Unwind_Resume@plt>
    0.00 :   ce43e:  call   *0xc4014(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   ce444:  call   *0xc400e(%rip)        # 192458 <_DYNAMIC+0x440>
