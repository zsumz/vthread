"""Preserve complete diagnostic patches and original binary/source provenance."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/root/vthread')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

for arm in 'AE':
    checkout = OUT / f'probe{arm}'
    evidence.ROOT = checkout
    expected = json.loads((OUT / f'probe-{arm}-source.json').read_text())['source_sha256']
    assert evidence.source_digest() == expected
    with (OUT / f'probe-{arm}-complete.patch').open('x') as stream:
        subprocess.run(['git', 'diff', '--binary', 'HEAD'], cwd=checkout, stdout=stream, check=True)
    sizes = []
    for name in evidence.output('git', 'ls-files').splitlines():
        path = checkout / name
        if path.suffix == '.rs' and path.is_file():
            lines = len(path.read_text().splitlines())
            sizes.append((name, lines))
            assert lines <= 300, (arm, name, lines)
    with (OUT / f'probe-{arm}-rust-sizes.json').open('x') as stream:
        json.dump(sizes, stream)

original = ROOT / 'target/finish-line/channel-publication'
for name in ('candidate-inlined.patch', 'candidate-inlined-source.json',
             'candidate-inlined.sha256', 'baseline-binary.sha256', 'restored-source.json'):
    shutil.copy2(original / name, OUT / f'original-{name}')
shutil.copy2(ROOT / 'scripts/evidence.py', OUT / 'evidence.py')
shutil.copy2(ROOT / 'target/finish-line/native-control.R84U9h/control.py', OUT / 'control.py')
with (OUT / 'final-runtime-source.json').open('x') as stream:
    evidence.ROOT = ROOT
    json.dump(evidence.metadata('attribution only; retained publication repair; no new runtime change'), stream, indent=2)
