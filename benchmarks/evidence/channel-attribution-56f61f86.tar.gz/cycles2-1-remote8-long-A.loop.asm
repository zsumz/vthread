 Percent |	Source code & Disassembly of baseline-benchmark for cycles:u (511 samples, percent: global period)
------------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000ca890 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   ca890:  push   %rbp
    0.00 :   ca891:  push   %r15
    0.00 :   ca893:  push   %r14
    0.00 :   ca895:  push   %r13
    0.00 :   ca897:  push   %r12
    0.00 :   ca899:  push   %rbx
    0.00 :   ca89a:  sub    $0x558,%rsp
    0.00 :   ca8a1:  mov    %rdi,%r12
    0.00 :   ca8a4:  mov    %rdi,0xc0(%rsp)
    0.00 :   ca8ac:  mov    %rsi,0x28(%rsp)
    0.00 :   ca8b1:  mov    %rsi,0xc8(%rsp)
    0.00 :   ca8b9:  jmp    ca8c2 <std::sys::backtrace::__rust_begin_short_backtrace+0x32>
    0.00 :   ca8bb:  nopl   0x0(%rax,%rax,1)
    0.00 :   ca8c0:  pause
    0.00 :   ca8c2:  mov    0x8(%r12),%rax
    0.00 :   ca8c7:  nopw   0x0(%rax,%rax,1)
    0.00 :   ca8d0:  cmp    $0xffffffffffffffff,%rax
    0.00 :   ca8d4:  je     ca8c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x30>
    0.00 :   ca8d6:  test   %rax,%rax
    0.00 :   ca8d9:  js     cae52 <std::sys::backtrace::__rust_begin_short_backtrace+0x5c2>
    0.00 :   ca8df:  lea    0x1(%rax),%rcx
    0.00 :   ca8e3:  lock cmpxchg %rcx,0x8(%r12)
    0.00 :   ca8ea:  jne    ca8d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x40>
    0.00 :   ca8ec:  mov    %r12,%rdi
    0.00 :   ca8ef:  xor    %esi,%esi
    0.00 :   ca8f1:  call   102ae0 <vthread::worker_context::attach>
    0.00 :   ca8f6:  lock incq (%r12)
    0.00 :   ca8fb:  jle    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   ca901:  mov    %r12,0x98(%rsp)
    0.00 :   ca909:  lock incq (%r12)
    0.00 :   ca90e:  jle    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   ca914:  mov    %r12,0xd0(%rsp)
    0.00 :   ca91c:  mov    0xa0(%r12),%rsi
    0.00 :   ca924:  mov    0x28(%rsp),%rdi
    0.00 :   ca929:  cmp    %rsi,%rdi
    0.00 :   ca92c:  jae    cbea1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1611>
    0.00 :   ca932:  movups 0x50(%r12),%xmm0
    0.00 :   ca938:  mov    0x70(%r12),%rax
    0.00 :   ca93d:  mov    0x98(%r12),%rcx
    0.00 :   ca945:  mov    (%rcx,%rdi,8),%rbx
    0.00 :   ca949:  lock incq (%rbx)
    0.00 :   ca94d:  jle    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   ca953:  mov    %rbx,0xd8(%rsp)
    0.00 :   ca95b:  mov    %r12,0x40(%rsp)
    0.00 :   ca960:  movq   $0x0,0x3a8(%rsp)
    0.00 :   ca96c:  movq   $0x8,0x3b0(%rsp)
    0.00 :   ca978:  xorps  %xmm1,%xmm1
    0.00 :   ca97b:  movups %xmm1,0x3b8(%rsp)
    0.00 :   ca983:  movq   $0x8,0x3c8(%rsp)
    0.00 :   ca98f:  movups %xmm1,0x3d0(%rsp)
    0.00 :   ca997:  movq   $0x8,0x3e0(%rsp)
    0.00 :   ca9a3:  movups %xmm1,0x3e8(%rsp)
    0.00 :   ca9ab:  movq   $0x8,0x3f8(%rsp)
    0.00 :   ca9b7:  movq   $0x0,0x400(%rsp)
    0.00 :   ca9c3:  movq   $0x0,0x480(%rsp)
    0.00 :   ca9cf:  movq   $0x8,0x488(%rsp)
    0.00 :   ca9db:  movups %xmm1,0x490(%rsp)
    0.00 :   ca9e3:  movq   $0x0,0x4a0(%rsp)
    0.00 :   ca9ef:  movq   $0x8,0x4a8(%rsp)
    0.00 :   ca9fb:  movups %xmm1,0x4b0(%rsp)
    0.00 :   caa03:  movb   $0x0,0x4c0(%rsp)
    0.00 :   caa0b:  movq   $0x0,0x58(%rsp)
    0.00 :   caa14:  movq   $0x8,0x60(%rsp)
    0.00 :   caa1d:  movups %xmm1,0x68(%rsp)
    0.00 :   caa22:  movq   $0x8,0x78(%rsp)
    0.00 :   caa2b:  movups %xmm1,0x80(%rsp)
    0.00 :   caa33:  movq   $0x2,0x100(%rsp)
    0.00 :   caa3f:  movq   $0x0,0xe0(%rsp)
    0.00 :   caa4b:  movups %xmm1,0xf0(%rsp)
    0.00 :   caa53:  movq   $0x8,0xe8(%rsp)
    0.00 :   caa5f:  movq   $0x0,0xa0(%rsp)
    0.00 :   caa6b:  movq   $0x8,0xa8(%rsp)
    0.00 :   caa77:  movq   $0x0,0xb0(%rsp)
    0.00 :   caa83:  movq   $0x1,0x120(%rsp)
    0.00 :   caa8f:  movq   $0x1,0x128(%rsp)
    0.00 :   caa9b:  movups %xmm1,0x130(%rsp)
    0.00 :   caaa3:  movq   $0x8,0x140(%rsp)
    0.00 :   caaaf:  movq   $0x0,0x148(%rsp)
    0.00 :   caabb:  movups %xmm0,0x150(%rsp)
    0.00 :   caac3:  movq   $0x1,0x160(%rsp)
    0.00 :   caacf:  movups %xmm1,0x168(%rsp)
    0.00 :   caad7:  movups %xmm1,0x178(%rsp)
    0.00 :   caadf:  movups %xmm1,0x188(%rsp)
    0.00 :   caae7:  movq   $0x0,0x198(%rsp)
    0.00 :   caaf3:  movq   $0x8,0x1a0(%rsp)
    0.00 :   caaff:  movups %xmm1,0x1a8(%rsp)
    0.00 :   cab07:  movups %xmm1,0x1b8(%rsp)
    0.00 :   cab0f:  movq   $0x0,0x1c8(%rsp)
    0.00 :   cab1b:  movq   $0x8,0x1d0(%rsp)
    0.00 :   cab27:  movups %xmm1,0x1d8(%rsp)
    0.00 :   cab2f:  movups %xmm1,0x1e8(%rsp)
    0.00 :   cab37:  mov    %rax,0x1f8(%rsp)
    0.00 :   cab3f:  mov    $0xe0,%edi
    0.00 :   cab44:  call   *0xc64be(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   cab4a:  test   %rax,%rax
    0.00 :   cab4d:  je     cae91 <std::sys::backtrace::__rust_begin_short_backtrace+0x601>
    0.00 :   cab53:  mov    %rax,%r14
    0.00 :   cab56:  lea    0x120(%rsp),%rsi
    0.00 :   cab5e:  mov    $0xe0,%edx
    0.00 :   cab63:  mov    %rax,%rdi
    0.00 :   cab66:  call   *0xc646c(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   cab6c:  mov    %r12,0x2b8(%rsp)
    0.00 :   cab74:  mov    %rbx,0x2c0(%rsp)
    0.00 :   cab7c:  mov    0x28(%rsp),%rax
    0.00 :   cab81:  mov    %rax,0x2d0(%rsp)
    0.00 :   cab89:  movups 0x3a8(%rsp),%xmm0
    0.00 :   cab91:  movups 0x3b8(%rsp),%xmm1
    0.00 :   cab99:  movups 0x3c8(%rsp),%xmm2
    0.00 :   caba1:  movups 0x3d8(%rsp),%xmm3
    0.00 :   caba9:  movaps %xmm0,0x1a0(%rsp)
    0.00 :   cabb1:  movaps %xmm1,0x1b0(%rsp)
    0.00 :   cabb9:  movaps %xmm2,0x1c0(%rsp)
    0.00 :   cabc1:  movaps %xmm3,0x1d0(%rsp)
    0.00 :   cabc9:  movups 0x3e8(%rsp),%xmm0
    0.00 :   cabd1:  movaps %xmm0,0x1e0(%rsp)
    0.00 :   cabd9:  movups 0x3f8(%rsp),%xmm0
    0.00 :   cabe1:  movaps %xmm0,0x1f0(%rsp)
    0.00 :   cabe9:  movups 0x480(%rsp),%xmm0
    0.00 :   cabf1:  movups 0x490(%rsp),%xmm1
    0.00 :   cabf9:  movups 0x4a0(%rsp),%xmm2
    0.00 :   cac01:  movups 0x4b0(%rsp),%xmm3
    0.00 :   cac09:  movaps %xmm0,0x200(%rsp)
    0.00 :   cac11:  movaps %xmm1,0x210(%rsp)
    0.00 :   cac19:  movaps %xmm2,0x220(%rsp)
    0.00 :   cac21:  movaps %xmm3,0x230(%rsp)
    0.00 :   cac29:  mov    0x4c0(%rsp),%rax
    0.00 :   cac31:  mov    %rax,0x240(%rsp)
    0.00 :   cac39:  mov    0x88(%rsp),%rax
    0.00 :   cac41:  mov    %rax,0x278(%rsp)
    0.00 :   cac49:  movups 0x58(%rsp),%xmm0
    0.00 :   cac4e:  movups 0x68(%rsp),%xmm1
    0.00 :   cac53:  movups 0x78(%rsp),%xmm2
    0.00 :   cac58:  movups %xmm2,0x268(%rsp)
    0.00 :   cac60:  movups %xmm1,0x258(%rsp)
    0.00 :   cac68:  movups %xmm0,0x248(%rsp)
    0.00 :   cac70:  movq   $0x0,0x2d8(%rsp)
    0.00 :   cac7c:  movups 0x100(%rsp),%xmm0
    0.00 :   cac84:  movups 0x110(%rsp),%xmm1
    0.00 :   cac8c:  movaps %xmm0,0x120(%rsp)
    0.00 :   cac94:  movaps %xmm1,0x130(%rsp)
    0.00 :   cac9c:  movups 0xe0(%rsp),%xmm0
    0.00 :   caca4:  movups 0xf0(%rsp),%xmm1
    0.00 :   cacac:  movaps %xmm0,0x280(%rsp)
    0.00 :   cacb4:  movaps %xmm1,0x290(%rsp)
    0.00 :   cacbc:  movb   $0x0,0x39c(%rsp)
    0.00 :   cacc4:  movq   $0x18,0x140(%rsp)
    0.00 :   cacd0:  movq   $0x0,0x168(%rsp)
    0.00 :   cacdc:  movq   $0x8,0x170(%rsp)
    0.00 :   cace8:  xorps  %xmm1,%xmm1
    0.00 :   caceb:  movups %xmm1,0x2e8(%rsp)
    0.00 :   cacf3:  movups %xmm1,0x178(%rsp)
    0.00 :   cacfb:  movups %xmm1,0x188(%rsp)
    0.00 :   cad03:  movq   $0x0,0x198(%rsp)
    0.00 :   cad0f:  mov    0xb0(%rsp),%rax
    0.00 :   cad17:  mov    %rax,0x2b0(%rsp)
    0.00 :   cad1f:  movups 0xa0(%rsp),%xmm0
    0.00 :   cad27:  movaps %xmm0,0x2a0(%rsp)
    0.00 :   cad2f:  mov    %r14,0x2c8(%rsp)
    0.00 :   cad37:  movw   $0x0,0x39d(%rsp)
    0.00 :   cad41:  movaps %xmm1,0x300(%rsp)
    0.00 :   cad49:  movups %xmm1,0x388(%rsp)
    0.00 :   cad51:  movups %xmm1,0x378(%rsp)
    0.00 :   cad59:  movups %xmm1,0x368(%rsp)
    0.00 :   cad61:  movups %xmm1,0x358(%rsp)
    0.00 :   cad69:  movups %xmm1,0x348(%rsp)
    0.00 :   cad71:  movups %xmm1,0x338(%rsp)
    0.00 :   cad79:  movups %xmm1,0x328(%rsp)
    0.00 :   cad81:  movups %xmm1,0x318(%rsp)
    0.00 :   cad89:  movl   $0x0,0x398(%rsp)
    0.00 :   cad94:  mov    $0x280,%edi
    0.00 :   cad99:  call   *0xc6269(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   cad9f:  test   %rax,%rax
    0.00 :   cada2:  je     caea6 <std::sys::backtrace::__rust_begin_short_backtrace+0x616>
    0.00 :   cada8:  mov    %rax,%rbx
    0.00 :   cadab:  lea    0x120(%rsp),%rsi
    0.00 :   cadb3:  mov    $0x280,%edx
    0.00 :   cadb8:  mov    %rax,%rdi
    0.00 :   cadbb:  call   *0xc6217(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   cadc1:  mov    0x1a0(%rbx),%rax
    0.00 :   cadc8:  mov    %rbx,0x8(%rsp)
    0.00 :   cadcd:  mov    0x1a8(%rbx),%rbx
    0.00 :   cadd4:  mov    0xe0(%rax),%r14
    0.00 :   caddb:  lock incq (%r14)
    0.00 :   caddf:  jle    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cade5:  incq   (%rbx)
    0.00 :   cade8:  je     cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cadee:  mov    %r14,0x3a8(%rsp)
    0.00 :   cadf6:  mov    %rbx,0x3b0(%rsp)
    0.00 :   cadfe:  movzbl %fs:0xffffffffffffffd8,%eax
    0.00 :   cae07:  cmp    $0x1,%eax
    0.00 :   cae0a:  je     caee1 <std::sys::backtrace::__rust_begin_short_backtrace+0x651>
    0.00 :   cae10:  cmp    $0x2,%eax
    0.00 :   cae13:  jne    caebb <std::sys::backtrace::__rust_begin_short_backtrace+0x62b>
    0.00 :   cae19:  lock decq (%r14)
    0.00 :   cae1d:  jne    cae2d <std::sys::backtrace::__rust_begin_short_backtrace+0x59d>
    0.00 :   cae1f:  lea    0x3a8(%rsp),%rdi
    0.00 :   cae27:  call   *0xc70fb(%rip)        # 191f28 <_DYNAMIC+0x1168>
    0.00 :   cae2d:  decq   (%rbx)
    0.00 :   cae30:  jne    cae40 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b0>
    0.00 :   cae32:  lea    0x3b0(%rsp),%rdi
    0.00 :   cae3a:  call   *0xc70f0(%rip)        # 191f30 <_DYNAMIC+0x1170>
    0.00 :   cae40:  lea    0xc16a9(%rip),%rdi        # 18c4f0 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058>
    0.00 :   cae47:  call   *0xc678b(%rip)        # 1915d8 <_DYNAMIC+0x818>
    0.00 :   cae4d:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae52:  lea    0xc10e7(%rip),%rax        # 18bf40 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x210>
    0.00 :   cae59:  mov    %rax,0x120(%rsp)
    0.00 :   cae61:  lea    0x8778(%rip),%rax        # d35e0 <_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hb2a2ab9295a6d20aE.llvm.10013882635303053058>
    0.00 :   cae68:  mov    %rax,0x128(%rsp)
    0.00 :   cae70:  lea    -0xb8702(%rip),%rdi        # 12775 <anon.48996dcd35f4b7aad43cb5fc1472ecbf.144.llvm.7041895458470441471>
    0.00 :   cae77:  lea    0xc1e92(%rip),%rdx        # 18cd10 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x6b0>
    0.00 :   cae7e:  lea    0x120(%rsp),%rsi
    0.00 :   cae86:  call   *0xc61bc(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   cae8c:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae91:  mov    $0x8,%edi
    0.00 :   cae96:  mov    $0xe0,%esi
    0.00 :   cae9b:  call   *0xc618f(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   caea1:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   caea6:  mov    $0x8,%edi
    0.00 :   caeab:  mov    $0x280,%esi
    0.00 :   caeb0:  call   *0xc617a(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   caeb6:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   caebb:  mov    %fs:0x0,%rax
    0.00 :   caec4:  lea    -0x40(%rax),%rdi
    0.00 :   caecb:  lea    -0x4db2(%rip),%rsi        # c6120 <std::sys::thread_local::native::eager::destroy>
    0.00 :   caed2:  call   *0xc6850(%rip)        # 191728 <_DYNAMIC+0x968>
    0.00 :   caed8:  movb   $0x1,%fs:0xffffffffffffffd8
    0.00 :   caee1:  mov    %r14,0x120(%rsp)
    0.00 :   caee9:  mov    %rbx,0x128(%rsp)
    0.00 :   caef1:  cmpq   $0x0,%fs:0xffffffffffffffc0
    0.00 :   caefb:  jne    cbd80 <std::sys::backtrace::__rust_begin_short_backtrace+0x14f0>
    0.00 :   caf01:  movups %fs:0xffffffffffffffc8,%xmm0
    0.00 :   caf0a:  mov    %r14,%fs:0xffffffffffffffc8
    0.00 :   caf13:  mov    %rbx,%fs:0xffffffffffffffd0
    0.00 :   caf1c:  movaps %xmm0,0x40(%rsp)
    0.00 :   caf21:  mov    %r12,0x18(%rsp)
    0.00 :   caf26:  lea    0x10(%r12),%rax
    0.00 :   caf2b:  mov    %rax,0x20(%rsp)
    0.00 :   caf30:  mov    0x8(%rsp),%rdi
    0.00 :   caf35:  lea    0x20(%rdi),%rax
    0.00 :   caf39:  mov    %rax,0x90(%rsp)
    0.00 :   caf41:  mov    %rdi,%rax
    0.00 :   caf44:  add    $0x58,%rax
    0.00 :   caf48:  mov    %rax,0xb8(%rsp)
    0.00 :   caf50:  mov    $0x1,%al
    0.00 :   caf52:  jmp    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   caf54:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   caf60:  mov    0x1a0(%rdi),%rax
    0.00 :   caf67:  mov    0xd0(%rax),%rax
    0.00 :   caf6e:  test   %rax,%rax
    0.00 :   caf71:  je     cb450 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc0>
    0.00 :   caf77:  movb   $0x1,0x27c(%rdi)
    0.00 :   caf7e:  xor    %eax,%eax
    0.00 :   caf80:  mov    0x1a0(%rdi),%rcx
    0.00 :   caf87:  mov    0xd8(%rcx),%rcx
    0.00 :   caf8e:  mov    0x10(%rcx),%rcx
    0.00 :   caf92:  mov    %rcx,0x38(%rsp)
    0.00 :   caf97:  cmp    %rcx,%r15
    0.00 :   caf9a:  setne  %bl
    0.00 :   caf9d:  or     %al,%bl
    0.00 :   caf9f:  test   $0x1,%bl
    0.00 :   cafa2:  je     cb200 <std::sys::backtrace::__rust_begin_short_backtrace+0x970>
    0.00 :   cafa8:  mov    0x1a0(%rdi),%rax
    0.00 :   cafaf:  movzbl 0xeb(%rax),%eax
    0.00 :   cafb6:  test   %al,%al
    0.00 :   cafb8:  jne    cbaef <std::sys::backtrace::__rust_begin_short_backtrace+0x125f>
    0.00 :   cafbe:  mov    %bl,0x14(%rsp)
    0.00 :   cafc2:  mov    0x1a0(%rdi),%r12
    0.00 :   cafc9:  movzbl 0xec(%r12),%eax
    0.00 :   cafd2:  test   %al,%al
    0.00 :   cafd4:  je     cb210 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cafda:  lea    0xec(%r12),%rbx
    0.00 :   cafe2:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   caff0:  lea    0x88(%r12),%r13
    0.00 :   caff8:  xor    %eax,%eax
    0.00 :   caffa:  mov    $0x1,%ecx
    0.00 :   cafff:  lock cmpxchg %ecx,0x88(%r12)
    0.00 :   cb009:  jne    cb195 <std::sys::backtrace::__rust_begin_short_backtrace+0x905>
    0.00 :   cb00f:  mov    0xc633a(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cb016:  mov    (%rax),%rax
    0.00 :   cb019:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb023:  test   %rcx,%rax
    0.00 :   cb026:  jne    cb1a3 <std::sys::backtrace::__rust_begin_short_backtrace+0x913>
    0.00 :   cb02c:  xor    %ebp,%ebp
    0.00 :   cb02e:  movzbl 0x8c(%r12),%eax
    0.00 :   cb037:  mov    0xb0(%r12),%rax
    0.00 :   cb03f:  mov    $0x6,%r14b
    0.00 :   cb042:  test   %rax,%rax
    0.00 :   cb045:  je     cb100 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb04b:  mov    0xb8(%r12),%rcx
    0.00 :   cb053:  test   %rcx,%rcx
    0.00 :   cb056:  je     cb0b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb058:  mov    %rcx,%rdx
    0.00 :   cb05b:  and    $0x7,%rdx
    0.00 :   cb05f:  je     cb183 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f3>
    0.00 :   cb065:  xor    %esi,%esi
    0.00 :   cb067:  nopw   0x0(%rax,%rax,1)
    0.00 :   cb070:  mov    0x70(%rax),%rax
    0.00 :   cb074:  inc    %rsi
    0.00 :   cb077:  cmp    %rsi,%rdx
    0.00 :   cb07a:  jne    cb070 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e0>
    0.00 :   cb07c:  mov    %rcx,%rdx
    0.00 :   cb07f:  sub    %rsi,%rdx
    0.00 :   cb082:  cmp    $0x8,%rcx
    0.00 :   cb086:  jb     cb0b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb088:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb090:  mov    0x70(%rax),%rax
    0.00 :   cb094:  mov    0x70(%rax),%rax
    0.00 :   cb098:  mov    0x70(%rax),%rax
    0.00 :   cb09c:  mov    0x70(%rax),%rax
    0.00 :   cb0a0:  mov    0x70(%rax),%rax
    0.00 :   cb0a4:  mov    0x70(%rax),%rax
    0.00 :   cb0a8:  mov    0x70(%rax),%rax
    0.00 :   cb0ac:  mov    0x70(%rax),%rax
    0.00 :   cb0b0:  add    $0xfffffffffffffff8,%rdx
    0.00 :   cb0b4:  jne    cb090 <std::sys::backtrace::__rust_begin_short_backtrace+0x800>
    0.00 :   cb0b6:  cmpw   $0x0,0x62(%rax)
    0.00 :   cb0bb:  je     cb100 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb0bd:  lea    0xb0(%r12),%rcx
    0.00 :   cb0c5:  lea    0x128(%rsp),%rdx
    0.00 :   cb0cd:  xorps  %xmm0,%xmm0
    0.00 :   cb0d0:  movups %xmm0,(%rdx)
    0.00 :   cb0d3:  mov    %rax,0x120(%rsp)
    0.00 :   cb0db:  mov    %rcx,0x138(%rsp)
    0.00 :   cb0e3:  lea    0x120(%rsp),%rdi
    0.00 :   cb0eb:  call   e44f0 <alloc::collections::btree::map::entry::OccupiedEntry<K,V,A>::remove_kv>
    0.00 :   cb0f0:  mov    %rax,%r15
    0.00 :   cb0f3:  mov    %edx,%r14d
    0.00 :   cb0f6:  jmp    cb100 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb0f8:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb100:  cmpq   $0x0,0xc0(%r12)
    0.00 :   cb109:  setne  %al
    0.00 :   cb10c:  mov    %al,(%rbx)
    0.00 :   cb10e:  test   %bpl,%bpl
    0.00 :   cb111:  jne    cb130 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb113:  mov    0xc6236(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cb11a:  mov    (%rax),%rax
    0.00 :   cb11d:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb127:  test   %rcx,%rax
    0.00 :   cb12a:  jne    cb1da <std::sys::backtrace::__rust_begin_short_backtrace+0x94a>
    0.00 :   cb130:  xor    %eax,%eax
    0.00 :   cb132:  xchg   %eax,0x0(%r13)
    0.00 :   cb136:  cmp    $0x2,%eax
    0.00 :   cb139:  je     cb1b4 <std::sys::backtrace::__rust_begin_short_backtrace+0x924>
    0.00 :   cb13b:  cmp    $0x6,%r14b
    0.00 :   cb13f:  je     cb210 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb145:  movzbl %r14b,%ecx
    0.00 :   cb149:  mov    $0x1,%esi
    0.00 :   cb14e:  mov    0x8(%rsp),%rbx
    0.00 :   cb153:  mov    %rbx,%rdi
    0.00 :   cb156:  mov    %r15,%rdx
    0.00 :   cb159:  call   1131f0 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cb15e:  mov    0x1a0(%rbx),%r12
    0.00 :   cb165:  lea    0xec(%r12),%rbx
    0.00 :   cb16d:  movzbl 0xec(%r12),%eax
    0.00 :   cb176:  test   %al,%al
    0.00 :   cb178:  jne    caff0 <std::sys::backtrace::__rust_begin_short_backtrace+0x760>
    0.00 :   cb17e:  jmp    cb210 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb183:  mov    %rcx,%rdx
    0.00 :   cb186:  cmp    $0x8,%rcx
    0.00 :   cb18a:  jae    cb090 <std::sys::backtrace::__rust_begin_short_backtrace+0x800>
    0.00 :   cb190:  jmp    cb0b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb195:  mov    %r13,%rdi
    0.00 :   cb198:  call   *0xc622a(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cb19e:  jmp    cb00f <std::sys::backtrace::__rust_begin_short_backtrace+0x77f>
    0.00 :   cb1a3:  call   *0xc61c7(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cb1a9:  mov    %eax,%ebp
    0.00 :   cb1ab:  xor    $0x1,%bpl
    0.00 :   cb1af:  jmp    cb02e <std::sys::backtrace::__rust_begin_short_backtrace+0x79e>
    0.00 :   cb1b4:  mov    $0xca,%edi
    0.00 :   cb1b9:  mov    %r13,%rsi
    0.00 :   cb1bc:  mov    $0x81,%edx
    0.00 :   cb1c1:  mov    $0x1,%ecx
    0.00 :   cb1c6:  xor    %eax,%eax
    0.00 :   cb1c8:  call   *0xc61b2(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cb1ce:  cmp    $0x6,%r14b
    0.00 :   cb1d2:  jne    cb145 <std::sys::backtrace::__rust_begin_short_backtrace+0x8b5>
    0.00 :   cb1d8:  jmp    cb210 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb1da:  call   *0xc6190(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cb1e0:  test   %al,%al
    0.00 :   cb1e2:  jne    cb130 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb1e8:  movb   $0x1,0x8c(%r12)
    0.00 :   cb1f1:  jmp    cb130 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb1f6:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb200:  cmpb   $0x0,0x27c(%rdi)
    0.23 :   cb207:  je     cb230 <std::sys::backtrace::__rust_begin_short_backtrace+0x9a0>
    0.00 :   cb209:  call   1154c0 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive>
    0.00 :   cb20e:  jmp    cb280 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb210:  mov    0x8(%rsp),%rdi
    0.00 :   cb215:  call   1154c0 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive>
    0.00 :   cb21a:  mov    0x38(%rsp),%r15
    0.00 :   cb21f:  movzbl 0x14(%rsp),%ebx
    0.00 :   cb224:  jmp    cb280 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb226:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb230:  call   114f00 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive_local_tasks>
    0.00 :   cb235:  test   %al,%al
    0.00 :   cb237:  je     cb280 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb239:  mov    0x8(%rsp),%rsi
    0.00 :   cb23e:  movb   $0x0,0x27e(%rsi)
    0.00 :   cb245:  mov    0x198(%rsi),%r14
    0.00 :   cb24c:  lea    0x120(%rsp),%rdi
    0.00 :   cb254:  mov    $0x1,%edx
    0.00 :   cb259:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cb25e:  add    $0x10,%r14
    0.00 :   cb262:  mov    %r14,%rdi
    0.00 :   cb265:  lea    0x120(%rsp),%rsi
    0.00 :   cb26d:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cb272:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb280:  movzbl %bl,%edx
    0.00 :   cb283:  and    $0x1,%edx
    0.00 :   cb286:  lea    0x120(%rsp),%rdi
    0.00 :   cb28e:  mov    0x8(%rsp),%rsi
    0.00 :   cb293:  call   10da40 <vthread::kernel::kernel_drive::<impl vthread::kernel::Kernel>::tick>
    0.00 :   cb298:  mov    0x120(%rsp),%rax
    0.18 :   cb2a0:  movabs $0x7fffffffffffffff,%rcx
    0.09 :   cb2aa:  add    $0x23,%rcx
    0.00 :   cb2ae:  cmp    %rcx,%rax
    0.00 :   cb2b1:  jne    cb8f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1060>
    0.00 :   cb2b7:  xor    %eax,%eax
    0.00 :   cb2b9:  cmpb   $0x0,0x128(%rsp)
    0.00 :   cb2c1:  mov    0x8(%rsp),%rdi
    0.00 :   cb2c6:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb2cc:  cmpq   $0x0,0x60(%rdi)
    0.00 :   cb2d1:  je     cb32d <std::sys::backtrace::__rust_begin_short_backtrace+0xa9d>
    0.00 :   cb2d3:  mov    0x1c8(%rdi),%rdx
    0.00 :   cb2da:  test   %rdx,%rdx
    0.00 :   cb2dd:  je     cbd5d <std::sys::backtrace::__rust_begin_short_backtrace+0x14cd>
    0.00 :   cb2e3:  mov    0x198(%rdi),%rdi
    0.00 :   cb2ea:  add    $0x10,%rdi
    0.00 :   cb2ee:  add    $0x40,%rdx
    0.00 :   cb2f2:  mov    0x90(%rsp),%rsi
    0.00 :   cb2fa:  call   120a50 <vthread::control::control_completion::<impl vthread::control::Shared>::publish_completions>
    0.00 :   cb2ff:  mov    0x90(%rsp),%rax
    0.00 :   cb307:  movq   $0x18,(%rax)
    0.00 :   cb30e:  mov    0xb8(%rsp),%rax
    0.00 :   cb316:  xorps  %xmm0,%xmm0
    0.00 :   cb319:  movups %xmm0,0x10(%rax)
    0.00 :   cb31d:  movups %xmm0,(%rax)
    0.00 :   cb320:  movq   $0x0,0x20(%rax)
    0.00 :   cb328:  mov    0x8(%rsp),%rdi
    0.00 :   cb32d:  mov    0x1d0(%rdi),%rax
    0.00 :   cb334:  test   %rax,%rax
    0.00 :   cb337:  je     caf60 <std::sys::backtrace::__rust_begin_short_backtrace+0x6d0>
    0.00 :   cb33d:  mov    0x1d8(%rdi),%rcx
    0.00 :   cb344:  test   %rcx,%rcx
    0.00 :   cb347:  je     cb3be <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb349:  mov    %rcx,%rdx
    0.00 :   cb34c:  and    $0x7,%rdx
    0.00 :   cb350:  je     cb55e <std::sys::backtrace::__rust_begin_short_backtrace+0xcce>
    0.00 :   cb356:  xor    %esi,%esi
    0.00 :   cb358:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb360:  mov    0x170(%rax),%rax
    0.00 :   cb367:  inc    %rsi
    0.00 :   cb36a:  cmp    %rsi,%rdx
    0.00 :   cb36d:  jne    cb360 <std::sys::backtrace::__rust_begin_short_backtrace+0xad0>
    0.00 :   cb36f:  mov    %rcx,%rdx
    0.00 :   cb372:  sub    %rsi,%rdx
    0.00 :   cb375:  cmp    $0x8,%rcx
    0.00 :   cb379:  jb     cb3be <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb37b:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb380:  mov    0x170(%rax),%rax
    0.00 :   cb387:  mov    0x170(%rax),%rax
    0.00 :   cb38e:  mov    0x170(%rax),%rax
    0.00 :   cb395:  mov    0x170(%rax),%rax
    0.00 :   cb39c:  mov    0x170(%rax),%rax
    0.00 :   cb3a3:  mov    0x170(%rax),%rax
    0.00 :   cb3aa:  mov    0x170(%rax),%rax
    0.00 :   cb3b1:  mov    0x170(%rax),%rax
    0.00 :   cb3b8:  add    $0xfffffffffffffff8,%rdx
    0.00 :   cb3bc:  jne    cb380 <std::sys::backtrace::__rust_begin_short_backtrace+0xaf0>
    0.00 :   cb3be:  cmpw   $0x0,0x16a(%rax)
    0.00 :   cb3c6:  mov    0x8(%rsp),%rdi
    0.00 :   cb3cb:  je     caf60 <std::sys::backtrace::__rust_begin_short_backtrace+0x6d0>
    0.00 :   cb3d1:  mov    (%rax),%r13
    0.00 :   cb3d4:  mov    0x8(%rax),%ebp
    0.00 :   cb3d7:  incq   0x250(%rdi)
    0.00 :   cb3de:  mov    0x1a0(%rdi),%rax
    0.00 :   cb3e5:  mov    0xd0(%rax),%rax
    0.00 :   cb3ec:  test   %rax,%rax
    0.00 :   cb3ef:  jne    caf77 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e7>
    0.00 :   cb3f5:  mov    0x1a8(%rdi),%rcx
    0.00 :   cb3fc:  xor    %eax,%eax
    0.00 :   cb3fe:  cmpq   $0x0,0xc8(%rcx)
    0.00 :   cb406:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb40c:  mov    0x1a0(%rdi),%rax
    0.00 :   cb413:  mov    0xe0(%rax),%rcx
    0.00 :   cb41a:  mov    0x80(%rcx),%rdx
    0.00 :   cb421:  xor    %eax,%eax
    0.00 :   cb423:  test   %rdx,%rdx
    0.00 :   cb426:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb42c:  mov    0x40(%rcx),%rcx
    0.00 :   cb430:  xor    %eax,%eax
    0.00 :   cb432:  mov    $0x0,%r12d
    0.00 :   cb438:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb442:  test   %rdx,%rcx
    0.00 :   cb445:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb44b:  jmp    cb575 <std::sys::backtrace::__rust_begin_short_backtrace+0xce5>
    0.00 :   cb450:  mov    0x1a8(%rdi),%rcx
    0.00 :   cb457:  xor    %eax,%eax
    0.00 :   cb459:  cmpq   $0x0,0xc8(%rcx)
    0.00 :   cb461:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb467:  mov    0x1a0(%rdi),%rax
    0.00 :   cb46e:  mov    0xe0(%rax),%rcx
    0.00 :   cb475:  mov    0x80(%rcx),%rdx
    0.00 :   cb47c:  xor    %eax,%eax
    0.00 :   cb47e:  test   %rdx,%rdx
    0.00 :   cb481:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb487:  mov    0x40(%rcx),%rcx
    0.00 :   cb48b:  xor    %eax,%eax
    0.00 :   cb48d:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb497:  test   %rdx,%rcx
    0.00 :   cb49a:  jne    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb4a0:  mov    0x198(%rdi),%rax
    0.00 :   cb4a7:  mov    $0x3b9aca00,%ebp
    0.00 :   cb4ac:  mov    $0x1,%r12b
    0.00 :   cb4af:  cmpq   $0x2,0x60(%rax)
    0.00 :   cb4b4:  jb     cb570 <std::sys::backtrace::__rust_begin_short_backtrace+0xce0>
    0.00 :   cb4ba:  mov    $0x281,%ecx
    0.87 :   cb4bf:  dec    %rcx
    0.00 :   cb4c2:  je     cb570 <std::sys::backtrace::__rust_begin_short_backtrace+0xce0>
    0.00 :   cb4c8:  pause
   76.96 :   cb4ca:  mov    0x8(%rsp),%rdi
    4.85 :   cb4cf:  mov    0x1a0(%rdi),%rax
    0.00 :   cb4d6:  mov    0xd0(%rax),%rax
    0.00 :   cb4dd:  test   %rax,%rax
    0.00 :   cb4e0:  jne    caf77 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e7>
    0.77 :   cb4e6:  mov    0x1a8(%rdi),%rax
    0.02 :   cb4ed:  cmpq   $0x0,0xc8(%rax)
    0.00 :   cb4f5:  jne    cb894 <std::sys::backtrace::__rust_begin_short_backtrace+0x1004>
    0.00 :   cb4fb:  mov    0x1a0(%rdi),%rax
    0.00 :   cb502:  mov    0xe0(%rax),%rax
    0.00 :   cb509:  mov    0x80(%rax),%rdx
    0.00 :   cb510:  test   %rdx,%rdx
    0.00 :   cb513:  jne    cb888 <std::sys::backtrace::__rust_begin_short_backtrace+0xff8>
    0.00 :   cb519:  mov    0x40(%rax),%rax
    3.25 :   cb51d:  movabs $0x7fffffffffffffff,%rdx
    0.88 :   cb527:  test   %rdx,%rax
    0.00 :   cb52a:  jne    cb888 <std::sys::backtrace::__rust_begin_short_backtrace+0xff8>
    0.00 :   cb530:  mov    0x8(%rsp),%rax
    1.99 :   cb535:  mov    0x1a0(%rax),%rax
    1.48 :   cb53c:  mov    0xd8(%rax),%rax
    2.27 :   cb543:  mov    0x10(%rax),%rdx
    5.94 :   cb547:  xor    %eax,%eax
    0.00 :   cb549:  cmp    0x38(%rsp),%rdx
    0.00 :   cb54e:  je     cb4bf <std::sys::backtrace::__rust_begin_short_backtrace+0xc2f>
    0.00 :   cb554:  mov    0x8(%rsp),%rdi
    0.00 :   cb559:  jmp    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb55e:  mov    %rcx,%rdx
    0.00 :   cb561:  cmp    $0x8,%rcx
    0.00 :   cb565:  jae    cb380 <std::sys::backtrace::__rust_begin_short_backtrace+0xaf0>
    0.00 :   cb56b:  jmp    cb3be <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb570:  mov    0x8(%rsp),%rdi
    0.00 :   cb575:  movb   $0x0,0x27e(%rdi)
    0.00 :   cb57c:  mov    0x198(%rdi),%r14
    0.00 :   cb583:  mov    %rdi,%rsi
    0.00 :   cb586:  lea    0x120(%rsp),%rdi
    0.00 :   cb58e:  xor    %edx,%edx
    0.00 :   cb590:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cb595:  add    $0x10,%r14
    0.00 :   cb599:  mov    %r14,%rdi
    0.00 :   cb59c:  lea    0x120(%rsp),%rsi
    0.00 :   cb5a4:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cb5a9:  mov    0x8(%rsp),%rax
    0.00 :   cb5ae:  mov    0x1a0(%rax),%rax
    0.00 :   cb5b5:  mov    0xe0(%rax),%rbx
    0.00 :   cb5bc:  mov    0x110(%rbx),%r14
    0.00 :   cb5c3:  lea    0x20(%r14),%rax
    0.00 :   cb5c7:  mov    %rax,0x50(%rsp)
    0.00 :   cb5cc:  xor    %eax,%eax
    0.00 :   cb5ce:  mov    $0x1,%ecx
    0.00 :   cb5d3:  lock cmpxchg %ecx,0x20(%r14)
    0.00 :   cb5d9:  jne    cb89b <std::sys::backtrace::__rust_begin_short_backtrace+0x100b>
    0.00 :   cb5df:  mov    0xc5d6a(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cb5e6:  mov    (%rax),%rax
    0.00 :   cb5e9:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb5f3:  test   %rcx,%rax
    0.00 :   cb5f6:  jne    cb8aa <std::sys::backtrace::__rust_begin_short_backtrace+0x101a>
    0.00 :   cb5fc:  movl   $0x0,0x14(%rsp)
    0.00 :   cb604:  movzbl 0x24(%r14),%eax
    0.00 :   cb609:  lock incq 0x18(%r14)
    0.00 :   cb60e:  mov    0x10(%r14),%rax
    0.00 :   cb612:  cmp    0x38(%rsp),%rax
    0.00 :   cb617:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb61d:  test   %r12b,%r12b
    0.00 :   cb620:  je     cb75d <std::sys::backtrace::__rust_begin_short_backtrace+0xecd>
    0.00 :   cb626:  mov    0x80(%rbx),%rax
    0.00 :   cb62d:  test   %rax,%rax
    0.00 :   cb630:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb636:  mov    0x40(%rbx),%rax
    0.00 :   cb63a:  nopw   0x0(%rax,%rax,1)
    0.00 :   cb640:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb64a:  test   %rcx,%rax
    0.00 :   cb64d:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb653:  test   %rax,%rax
    0.00 :   cb656:  jne    cb66c <std::sys::backtrace::__rust_begin_short_backtrace+0xddc>
    0.00 :   cb658:  xor    %eax,%eax
    0.00 :   cb65a:  movabs $0x8000000000000000,%rcx
    0.00 :   cb664:  lock cmpxchg %rcx,0x40(%rbx)
    0.00 :   cb66a:  jne    cb640 <std::sys::backtrace::__rust_begin_short_backtrace+0xdb0>
    0.00 :   cb66c:  lea    0x28(%r14),%rax
    0.00 :   cb670:  mov    (%rax),%ebp
    0.00 :   cb672:  xor    %eax,%eax
    0.00 :   cb674:  lea    0x20(%r14),%r13
    0.00 :   cb678:  xchg   %eax,0x0(%r13)
    0.00 :   cb67c:  cmp    $0x2,%eax
    0.00 :   cb67f:  je     cb71b <std::sys::backtrace::__rust_begin_short_backtrace+0xe8b>
    0.00 :   cb685:  movq   $0x0,0x120(%rsp)
    0.00 :   cb691:  mov    0xc5d88(%rip),%r12        # 191420 <__errno_location@GLIBC_2.2.5>
    0.00 :   cb698:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb6a0:  lea    0x28(%r14),%rax
    0.00 :   cb6a4:  mov    (%rax),%eax
    0.00 :   cb6a6:  cmp    %ebp,%eax
    0.00 :   cb6a8:  jne    cb6f3 <std::sys::backtrace::__rust_begin_short_backtrace+0xe63>
    0.00 :   cb6aa:  cmpb   $0x0,0x120(%rsp)
    0.00 :   cb6b2:  mov    $0x0,%r8d
    0.00 :   cb6b8:  lea    0x128(%rsp),%rax
    0.00 :   cb6c0:  cmovne %rax,%r8
    0.00 :   cb6c4:  movl   $0xffffffff,(%rsp)
    0.00 :   cb6cb:  mov    $0xca,%edi
    0.00 :   cb6d0:  lea    0x28(%r14),%rsi
    0.00 :   cb6d4:  mov    $0x89,%edx
    0.00 :   cb6d9:  mov    %ebp,%ecx
    0.00 :   cb6db:  xor    %r9d,%r9d
    0.00 :   cb6de:  xor    %eax,%eax
    0.00 :   cb6e0:  call   *0xc5c9a(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cb6e6:  test   %rax,%rax
    0.00 :   cb6e9:  jns    cb6f3 <std::sys::backtrace::__rust_begin_short_backtrace+0xe63>
    0.00 :   cb6eb:  call   *%r12
    0.00 :   cb6ee:  cmpl   $0x4,(%rax)
    0.00 :   cb6f1:  je     cb6a0 <std::sys::backtrace::__rust_begin_short_backtrace+0xe10>
    0.00 :   cb6f3:  xor    %eax,%eax
    0.00 :   cb6f5:  mov    $0x1,%ecx
    0.00 :   cb6fa:  lock cmpxchg %ecx,0x0(%r13)
    0.00 :   cb700:  jne    cb73a <std::sys::backtrace::__rust_begin_short_backtrace+0xeaa>
    0.00 :   cb702:  movzbl 0x24(%r14),%eax
    0.00 :   cb707:  mov    0x10(%r14),%rax
    0.00 :   cb70b:  cmp    0x38(%rsp),%rax
    0.00 :   cb710:  je     cb626 <std::sys::backtrace::__rust_begin_short_backtrace+0xd96>
    0.00 :   cb716:  jmp    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb71b:  mov    $0xca,%edi
    0.00 :   cb720:  mov    %r13,%rsi
    0.00 :   cb723:  mov    $0x81,%edx
    0.00 :   cb728:  mov    $0x1,%ecx
    0.00 :   cb72d:  xor    %eax,%eax
    0.00 :   cb72f:  call   *0xc5c4b(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cb735:  jmp    cb685 <std::sys::backtrace::__rust_begin_short_backtrace+0xdf5>
    0.00 :   cb73a:  lea    0x20(%r14),%rdi
    0.00 :   cb73e:  call   *0xc5c84(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cb744:  movzbl 0x24(%r14),%eax
    0.00 :   cb749:  mov    0x10(%r14),%rax
    0.00 :   cb74d:  cmp    0x38(%rsp),%rax
    0.00 :   cb752:  je     cb626 <std::sys::backtrace::__rust_begin_short_backtrace+0xd96>
    0.00 :   cb758:  jmp    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb75d:  mov    0x80(%rbx),%rax
    0.00 :   cb764:  test   %rax,%rax
    0.00 :   cb767:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb76d:  mov    0x40(%rbx),%rax
    0.00 :   cb771:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb780:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb78a:  test   %rcx,%rax
    0.00 :   cb78d:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb793:  test   %rax,%rax
    0.00 :   cb796:  jne    cb7ac <std::sys::backtrace::__rust_begin_short_backtrace+0xf1c>
    0.00 :   cb798:  xor    %eax,%eax
    0.00 :   cb79a:  movabs $0x8000000000000000,%rcx
    0.00 :   cb7a4:  lock cmpxchg %rcx,0x40(%rbx)
    0.00 :   cb7aa:  jne    cb780 <std::sys::backtrace::__rust_begin_short_backtrace+0xef0>
    0.00 :   cb7ac:  mov    %r13,0xa0(%rsp)
    0.00 :   cb7b4:  mov    %ebp,0xa8(%rsp)
    0.00 :   cb7bb:  mov    $0x1,%edi
    0.00 :   cb7c0:  call   a12d0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   cb7c5:  mov    %rax,0x100(%rsp)
    0.00 :   cb7cd:  mov    %edx,0x108(%rsp)
    0.00 :   cb7d4:  lea    0x120(%rsp),%rdi
    0.00 :   cb7dc:  lea    0xa0(%rsp),%rsi
    0.00 :   cb7e4:  lea    0x100(%rsp),%rdx
    0.00 :   cb7ec:  call   a1200 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec.llvm.13342753452097612697>
    0.00 :   cb7f1:  cmpb   $0x0,0x120(%rsp)
    0.00 :   cb7f9:  mov    0x130(%rsp),%ecx
    0.00 :   cb800:  mov    $0x0,%eax
    0.00 :   cb805:  cmovne %eax,%ecx
    0.00 :   cb808:  mov    0x128(%rsp),%rdx
    0.00 :   cb810:  cmovne %rax,%rdx
    0.00 :   cb814:  test   %rdx,%rdx
    0.00 :   cb817:  sete   %al
    0.00 :   cb81a:  test   %ecx,%ecx
    0.00 :   cb81c:  sete   %sil
    0.00 :   cb820:  test   %sil,%al
    0.00 :   cb823:  jne    cb846 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cb825:  lea    0x28(%r14),%rdi
    0.00 :   cb829:  lea    0x20(%r14),%rsi
    0.00 :   cb82d:  call   a1870 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys4sync7condvar5futexNtB2_7Condvar21wait_optional_timeout.llvm.13342753452097612697>
    0.00 :   cb832:  movzbl 0x24(%r14),%eax
    0.00 :   cb837:  mov    0x10(%r14),%rax
    0.00 :   cb83b:  cmp    0x38(%rsp),%rax
    0.00 :   cb840:  je     cb75d <std::sys::backtrace::__rust_begin_short_backtrace+0xecd>
    0.00 :   cb846:  lock decq 0x18(%r14)
    0.00 :   cb84b:  cmpb   $0x0,0x14(%rsp)
    0.00 :   cb850:  jne    cb86b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cb852:  mov    0xc5af7(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cb859:  mov    (%rax),%rax
    0.00 :   cb85c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb866:  test   %rcx,%rax
    0.00 :   cb869:  jne    cb8dc <std::sys::backtrace::__rust_begin_short_backtrace+0x104c>
    0.00 :   cb86b:  xor    %eax,%eax
    0.00 :   cb86d:  mov    0x50(%rsp),%rsi
    0.00 :   cb872:  xchg   %eax,(%rsi)
    0.00 :   cb874:  cmp    $0x2,%eax
    0.00 :   cb877:  je     cb8c3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1033>
    0.00 :   cb879:  movabs $0x7fffffffffffffff,%rax
    0.00 :   cb883:  lock and %rax,0x40(%rbx)
    0.00 :   cb888:  xor    %eax,%eax
    0.00 :   cb88a:  mov    0x8(%rsp),%rdi
    0.22 :   cb88f:  jmp    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb894:  xor    %eax,%eax
    0.00 :   cb896:  jmp    caf80 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb89b:  lea    0x20(%r14),%rdi
    0.00 :   cb89f:  call   *0xc5b23(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cb8a5:  jmp    cb5df <std::sys::backtrace::__rust_begin_short_backtrace+0xd4f>
    0.00 :   cb8aa:  call   *0xc5ac0(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cb8b0:  mov    %eax,0x14(%rsp)
    0.00 :   cb8b4:  mov    0x14(%rsp),%eax
    0.00 :   cb8b8:  xor    $0x1,%al
    0.00 :   cb8ba:  mov    %eax,0x14(%rsp)
    0.00 :   cb8be:  jmp    cb604 <std::sys::backtrace::__rust_begin_short_backtrace+0xd74>
    0.00 :   cb8c3:  mov    $0xca,%edi
    0.00 :   cb8c8:  mov    $0x81,%edx
    0.00 :   cb8cd:  mov    $0x1,%ecx
    0.00 :   cb8d2:  xor    %eax,%eax
    0.00 :   cb8d4:  call   *0xc5aa6(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cb8da:  jmp    cb879 <std::sys::backtrace::__rust_begin_short_backtrace+0xfe9>
    0.00 :   cb8dc:  call   *0xc5a8e(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cb8e2:  test   %al,%al
    0.00 :   cb8e4:  jne    cb86b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cb8e6:  movb   $0x1,0x24(%r14)
    0.00 :   cb8eb:  jmp    cb86b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cb8f0:  movups 0x128(%rsp),%xmm0
    0.00 :   cb8f8:  movups 0x138(%rsp),%xmm1
    0.00 :   cb900:  movups 0x148(%rsp),%xmm2
    0.00 :   cb908:  mov    0x158(%rsp),%rcx
    0.00 :   cb910:  mov    %rcx,0x3e0(%rsp)
    0.00 :   cb918:  movups %xmm2,0x3d0(%rsp)
    0.00 :   cb920:  movups %xmm1,0x3c0(%rsp)
    0.00 :   cb928:  mov    %rax,0x3a8(%rsp)
    0.00 :   cb930:  movups %xmm0,0x3b0(%rsp)
    0.00 :   cb938:  movq   $0x0,0x58(%rsp)
    0.00 :   cb941:  movq   $0x1,0x60(%rsp)
    0.00 :   cb94a:  movq   $0x0,0x68(%rsp)
    0.00 :   cb953:  movq   $0x60000020,0x130(%rsp)
    0.00 :   cb95f:  lea    0x58(%rsp),%rax
    0.00 :   cb964:  mov    %rax,0x120(%rsp)
    0.00 :   cb96c:  lea    0xc0c65(%rip),%rax        # 18c5d8 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0xe8>
    0.00 :   cb973:  mov    %rax,0x128(%rsp)
    0.00 :   cb97b:  lea    0x3a8(%rsp),%rdi
    0.00 :   cb983:  lea    0x120(%rsp),%rsi
    0.00 :   cb98b:  call   *0xc6647(%rip)        # 191fd8 <_DYNAMIC+0x1218>
    0.00 :   cb991:  test   %al,%al
    0.00 :   cb993:  jne    cbe13 <std::sys::backtrace::__rust_begin_short_backtrace+0x1583>
    0.00 :   cb999:  mov    0x58(%rsp),%rbx
    0.00 :   cb99e:  mov    0x60(%rsp),%r15
    0.00 :   cb9a3:  mov    0x68(%rsp),%r14
    0.00 :   cb9a8:  mov    $0x18,%edi
    0.00 :   cb9ad:  call   *0xc5655(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   cb9b3:  test   %rax,%rax
    0.00 :   cb9b6:  je     cbe3d <std::sys::backtrace::__rust_begin_short_backtrace+0x15ad>
    0.00 :   cb9bc:  mov    %rbx,(%rax)
    0.00 :   cb9bf:  mov    %r15,0x8(%rax)
    0.00 :   cb9c3:  mov    %r14,0x10(%rax)
    0.00 :   cb9c7:  lea    0xc236a(%rip),%rdx        # 18dd38 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x4c8>
    0.00 :   cb9ce:  lea    0x58(%rsp),%rdi
    0.00 :   cb9d3:  mov    %rax,%rsi
    0.00 :   cb9d6:  mov    0x18(%rsp),%r12
    0.00 :   cb9db:  mov    0x20(%rsp),%r13
    0.00 :   cb9e0:  call   *0xc6532(%rip)        # 191f18 <_DYNAMIC+0x1158>
    0.00 :   cb9e6:  lea    0x3a8(%rsp),%rdi
    0.00 :   cb9ee:  call   d75c0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10013882635303053058>
    0.00 :   cb9f3:  lea    0x58(%rsp),%rsi
    0.00 :   cb9f8:  mov    %r13,%rdi
    0.00 :   cb9fb:  call   118070 <vthread::carrier::record_failure>
    0.00 :   cba00:  mov    0x8(%rsp),%rax
    0.00 :   cba05:  mov    0x1a0(%rax),%rbx
    0.00 :   cba0c:  lea    0x88(%rbx),%r14
    0.00 :   cba13:  mov    $0x1,%ecx
    0.00 :   cba18:  xor    %eax,%eax
    0.00 :   cba1a:  lock cmpxchg %ecx,0x88(%rbx)
    0.00 :   cba22:  jne    cbda7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1517>
    0.00 :   cba28:  mov    0xc5921(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cba2f:  mov    (%rax),%rax
    0.00 :   cba32:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cba3c:  test   %rcx,%rax
    0.00 :   cba3f:  jne    cbdb5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1525>
    0.00 :   cba45:  lea    0x8c(%rbx),%r15
    0.00 :   cba4c:  movzbl 0x8c(%rbx),%eax
    0.00 :   cba53:  movb   $0x1,0xc8(%rbx)
    0.00 :   cba5a:  mov    0xc58ef(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cba61:  mov    (%rax),%rax
    0.00 :   cba64:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cba6e:  test   %rcx,%rax
    0.00 :   cba71:  jne    cbdfc <std::sys::backtrace::__rust_begin_short_backtrace+0x156c>
    0.00 :   cba77:  xor    %eax,%eax
    0.00 :   cba79:  xchg   %eax,(%r14)
    0.00 :   cba7c:  cmp    $0x2,%eax
    0.00 :   cba7f:  je     cbddd <std::sys::backtrace::__rust_begin_short_backtrace+0x154d>
    0.00 :   cba85:  movb   $0x1,0xeb(%rbx)
    0.00 :   cba8c:  mov    0xd8(%rbx),%rdi
    0.00 :   cba93:  add    $0x10,%rdi
    0.00 :   cba97:  call   117f50 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10013882635303053058>
    0.00 :   cba9c:  mov    0x8(%rsp),%rdi
    0.00 :   cbaa1:  xor    %esi,%esi
    0.00 :   cbaa3:  mov    $0x4,%ecx
    0.00 :   cbaa8:  call   1131f0 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cbaad:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbab5:  mov    0x8(%rsp),%rsi
    0.00 :   cbaba:  mov    $0x3,%edx
    0.00 :   cbabf:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbac4:  movq   $0x0,0x450(%rsp)
    0.00 :   cbad0:  mov    0x8(%rsp),%rax
    0.00 :   cbad5:  mov    0x198(%rax),%rdi
    0.00 :   cbadc:  add    $0x10,%rdi
    0.00 :   cbae0:  lea    0x3a8(%rsp),%rsi
    0.00 :   cbae8:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cbaed:  jmp    cbb46 <std::sys::backtrace::__rust_begin_short_backtrace+0x12b6>
    0.00 :   cbaef:  mov    %rdi,%rbx
    0.00 :   cbaf2:  xor    %esi,%esi
    0.00 :   cbaf4:  mov    $0x3,%ecx
    0.00 :   cbaf9:  mov    0x20(%rsp),%r13
    0.00 :   cbafe:  call   1131f0 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cbb03:  lea    0x120(%rsp),%rdi
    0.00 :   cbb0b:  mov    %rbx,%rsi
    0.00 :   cbb0e:  mov    $0x2,%edx
    0.00 :   cbb13:  mov    0x18(%rsp),%r12
    0.00 :   cbb18:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbb1d:  movq   $0x0,0x1c8(%rsp)
    0.00 :   cbb29:  mov    0x8(%rsp),%rax
    0.00 :   cbb2e:  mov    0x198(%rax),%rdi
    0.00 :   cbb35:  add    $0x10,%rdi
    0.00 :   cbb39:  lea    0x120(%rsp),%rsi
    0.00 :   cbb41:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cbb46:  mov    0xa0(%r12),%rsi
    0.00 :   cbb4e:  mov    0x28(%rsp),%rcx
    0.00 :   cbb53:  cmp    %rsi,%rcx
    0.00 :   cbb56:  jae    cbeb0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1620>
    0.00 :   cbb5c:  mov    0x98(%r12),%rax
    0.00 :   cbb64:  mov    (%rax,%rcx,8),%rax
    0.00 :   cbb68:  movb   $0x1,0xe9(%rax)
    0.00 :   cbb6f:  mov    0x8(%rsp),%rcx
    0.00 :   cbb74:  cmpl   $0x2,(%rcx)
    0.00 :   cbb77:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbb7d:  cmpq   $0x0,0x178(%rcx)
    0.00 :   cbb85:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbb8b:  cmpq   $0x0,0x1b8(%rcx)
    0.00 :   cbb93:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbb99:  cmpq   $0x0,0xf8(%rcx)
    0.00 :   cbba1:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbba7:  cmpq   $0x0,0x118(%rcx)
    0.00 :   cbbaf:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbb5:  cmpq   $0x0,0x158(%rcx)
    0.00 :   cbbbd:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbc3:  mov    0x90(%rcx),%rax
    0.00 :   cbbca:  cmp    0xa8(%rcx),%rax
    0.00 :   cbbd1:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbd7:  mov    0xc0(%rcx),%rax
    0.00 :   cbbde:  cmp    0xd8(%rcx),%rax
    0.00 :   cbbe5:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbe7:  cmpq   $0x0,0x60(%rcx)
    0.00 :   cbbec:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbbee:  mov    0x198(%rcx),%rax
    0.00 :   cbbf5:  mov    0x1b0(%rcx),%rdi
    0.00 :   cbbfc:  mov    0x88(%rax),%rsi
    0.00 :   cbc03:  cmp    %rsi,%rdi
    0.00 :   cbc06:  jae    cbec7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1637>
    0.00 :   cbc0c:  mov    0x80(%rax),%rax
    0.00 :   cbc13:  shl    $0x6,%rdi
    0.00 :   cbc17:  mov    (%rax,%rdi,1),%rax
    0.00 :   cbc1b:  test   %rax,%rax
    0.00 :   cbc1e:  mov    0x8(%rsp),%rdi
    0.00 :   cbc23:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbc25:  mov    0x1a8(%rdi),%rax
    0.00 :   cbc2c:  cmpq   $0x0,0x98(%rax)
    0.00 :   cbc34:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbc36:  cmpq   $0x0,0xc8(%rax)
    0.00 :   cbc3e:  jne    cbc57 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cbc40:  mov    0x1a0(%rdi),%rax
    0.00 :   cbc47:  mov    0xd0(%rax),%rax
    0.00 :   cbc4e:  test   %rax,%rax
    0.00 :   cbc51:  je     cbe5c <std::sys::backtrace::__rust_begin_short_backtrace+0x15cc>
    0.00 :   cbc57:  mov    $0x10,%edi
    0.00 :   cbc5c:  call   *0xc53a6(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   cbc62:  test   %rax,%rax
    0.00 :   cbc65:  je     cbd92 <std::sys::backtrace::__rust_begin_short_backtrace+0x1502>
    0.00 :   cbc6b:  lea    -0xad227(%rip),%rcx        # 1ea4b <anon.cccb389264607a2d4c2b49e143c9c1b6.746.llvm.10013882635303053058+0x321>
    0.00 :   cbc72:  mov    %rcx,(%rax)
    0.00 :   cbc75:  movq   $0x1a,0x8(%rax)
    0.00 :   cbc7d:  lea    0xc1a34(%rip),%rdx        # 18d6b8 <anon.cccb389264607a2d4c2b49e143c9c1b6.433.llvm.10013882635303053058+0x858>
    0.00 :   cbc84:  lea    0xe0(%rsp),%rdi
    0.00 :   cbc8c:  mov    %rax,%rsi
    0.00 :   cbc8f:  call   *0xc6283(%rip)        # 191f18 <_DYNAMIC+0x1158>
    0.00 :   cbc95:  lea    0xe0(%rsp),%rsi
    0.00 :   cbc9d:  mov    %r13,%rdi
    0.00 :   cbca0:  call   118070 <vthread::carrier::record_failure>
    0.00 :   cbca5:  mov    0x8(%rsp),%rsi
    0.00 :   cbcaa:  movb   $0x0,0x27e(%rsi)
    0.00 :   cbcb1:  mov    0x198(%rsi),%r14
    0.00 :   cbcb8:  lea    0x480(%rsp),%rdi
    0.00 :   cbcc0:  mov    $0x3,%edx
    0.00 :   cbcc5:  call   117990 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbcca:  add    $0x10,%r14
    0.00 :   cbcce:  lea    0x480(%rsp),%rsi
    0.00 :   cbcd6:  mov    %r14,%rdi
    0.00 :   cbcd9:  call   1219c0 <vthread::control::Shared::publish>
    0.00 :   cbcde:  mov    %r13,%rdi
    0.00 :   cbce1:  call   120fe0 <_ZN7vthread7control6Shared12request_stop17hb40bf47e89bed244E.llvm.10013882635303053058>
    0.00 :   cbce6:  lea    0x40(%rsp),%rdi
    0.00 :   cbceb:  call   *0xc62ef(%rip)        # 191fe0 <_DYNAMIC+0x1220>
    0.00 :   cbcf1:  mov    0x40(%rsp),%rax
    0.00 :   cbcf6:  test   %rax,%rax
    0.00 :   cbcf9:  je     cbd21 <std::sys::backtrace::__rust_begin_short_backtrace+0x1491>
    0.00 :   cbcfb:  lock decq (%rax)
    0.00 :   cbcff:  jne    cbd0c <std::sys::backtrace::__rust_begin_short_backtrace+0x147c>
    0.00 :   cbd01:  lea    0x40(%rsp),%rdi
    0.00 :   cbd06:  call   *0xc621c(%rip)        # 191f28 <_DYNAMIC+0x1168>
    0.00 :   cbd0c:  mov    0x48(%rsp),%rax
    0.00 :   cbd11:  decq   (%rax)
    0.00 :   cbd14:  jne    cbd21 <std::sys::backtrace::__rust_begin_short_backtrace+0x1491>
    0.00 :   cbd16:  lea    0x48(%rsp),%rdi
    0.00 :   cbd1b:  call   *0xc620f(%rip)        # 191f30 <_DYNAMIC+0x1170>
    0.00 :   cbd21:  lock decq (%r12)
    0.00 :   cbd26:  jne    cbd36 <std::sys::backtrace::__rust_begin_short_backtrace+0x14a6>
    0.00 :   cbd28:  lea    0x98(%rsp),%rdi
    0.00 :   cbd30:  call   *0xc6282(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cbd36:  lock decq (%r12)
    0.00 :   cbd3b:  jne    cbd4b <std::sys::backtrace::__rust_begin_short_backtrace+0x14bb>
    0.00 :   cbd3d:  lea    0xc0(%rsp),%rdi
    0.00 :   cbd45:  call   *0xc626d(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cbd4b:  add    $0x558,%rsp
    0.00 :   cbd52:  pop    %rbx
    0.00 :   cbd53:  pop    %r12
    0.00 :   cbd55:  pop    %r13
    0.00 :   cbd57:  pop    %r14
    0.00 :   cbd59:  pop    %r15
    0.00 :   cbd5b:  pop    %rbp
    0.00 :   cbd5c:  ret
    0.00 :   cbd5d:  lea    -0xad346(%rip),%rdi        # 1ea1e <anon.cccb389264607a2d4c2b49e143c9c1b6.746.llvm.10013882635303053058+0x2f4>
    0.00 :   cbd64:  lea    0xc1ef5(%rip),%rdx        # 18dc60 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x3f0>
    0.00 :   cbd6b:  mov    $0x19,%esi
    0.00 :   cbd70:  mov    0x20(%rsp),%r13
    0.00 :   cbd75:  call   *0xc546d(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   cbd7b:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbd80:  lea    0xc1fe9(%rip),%rdi        # 18dd70 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x500>
    0.00 :   cbd87:  call   *0xc543b(%rip)        # 1911c8 <_DYNAMIC+0x408>
    0.00 :   cbd8d:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbd92:  mov    $0x8,%edi
    0.00 :   cbd97:  mov    $0x10,%esi
    0.00 :   cbd9c:  call   *0xc528e(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   cbda2:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbda7:  mov    %r14,%rdi
    0.00 :   cbdaa:  call   *0xc5618(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cbdb0:  jmp    cba28 <std::sys::backtrace::__rust_begin_short_backtrace+0x1198>
    0.00 :   cbdb5:  call   *0xc55b5(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cbdbb:  movzbl 0x8c(%rbx),%ecx
    0.00 :   cbdc2:  movb   $0x1,0xc8(%rbx)
    0.00 :   cbdc9:  test   %al,%al
    0.00 :   cbdcb:  je     cba77 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cbdd1:  lea    0x8c(%rbx),%r15
    0.00 :   cbdd8:  jmp    cba5a <std::sys::backtrace::__rust_begin_short_backtrace+0x11ca>
    0.00 :   cbddd:  mov    $0xca,%edi
    0.00 :   cbde2:  mov    %r14,%rsi
    0.00 :   cbde5:  mov    $0x81,%edx
    0.00 :   cbdea:  mov    $0x1,%ecx
    0.00 :   cbdef:  xor    %eax,%eax
    0.00 :   cbdf1:  call   *0xc5589(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cbdf7:  jmp    cba85 <std::sys::backtrace::__rust_begin_short_backtrace+0x11f5>
    0.00 :   cbdfc:  call   *0xc556e(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cbe02:  test   %al,%al
    0.00 :   cbe04:  jne    cba77 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cbe0a:  movb   $0x1,(%r15)
    0.00 :   cbe0e:  jmp    cba77 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cbe13:  lea    -0xaea3f(%rip),%rdi        # 1d3db <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x73>
    0.00 :   cbe1a:  lea    0xc085f(%rip),%rcx        # 18c680 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x20>
    0.00 :   cbe21:  lea    0xc07e0(%rip),%r8        # 18c608 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0x118>
    0.00 :   cbe28:  lea    0x37(%rsp),%rdx
    0.00 :   cbe2d:  mov    $0x37,%esi
    0.00 :   cbe32:  call   *0xc51f0(%rip)        # 191028 <_DYNAMIC+0x268>
    0.00 :   cbe38:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbe3d:  mov    $0x8,%edi
    0.00 :   cbe42:  mov    $0x18,%esi
    0.00 :   cbe47:  mov    0x18(%rsp),%r12
    0.00 :   cbe4c:  mov    0x20(%rsp),%r13
    0.00 :   cbe51:  call   *0xc51d9(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   cbe57:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbe5c:  call   d7960 <core::ptr::drop_in_place<vthread::kernel::Kernel>>
    0.00 :   cbe61:  mov    0x8(%rsp),%rdi
    0.00 :   cbe66:  call   *0xc5184(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cbe6c:  mov    0x18(%rsp),%rax
    0.00 :   cbe71:  mov    0xa0(%rax),%rsi
    0.00 :   cbe78:  cmp    %rsi,0x28(%rsp)
    0.00 :   cbe7d:  jae    cbed9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1649>
    0.00 :   cbe7f:  mov    0x18(%rsp),%r12
    0.00 :   cbe84:  mov    0x98(%r12),%rax
    0.00 :   cbe8c:  mov    0x28(%rsp),%rcx
    0.00 :   cbe91:  mov    (%rax,%rcx,8),%rax
    0.00 :   cbe95:  movb   $0x1,0xea(%rax)
    0.00 :   cbe9c:  jmp    cbce6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1456>
    0.00 :   cbea1:  lea    0xc1dd0(%rip),%rdx        # 18dc78 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x408>
    0.00 :   cbea8:  call   *0xc511a(%rip)        # 190fc8 <_DYNAMIC+0x208>
    0.00 :   cbeae:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbeb0:  xor    %r15d,%r15d
    0.00 :   cbeb3:  lea    0xc1e4e(%rip),%rdx        # 18dd08 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x498>
    0.00 :   cbeba:  mov    0x28(%rsp),%rdi
    0.00 :   cbebf:  call   *0xc5103(%rip)        # 190fc8 <_DYNAMIC+0x208>
    0.00 :   cbec5:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbec7:  xor    %r15d,%r15d
    0.00 :   cbeca:  lea    0xc1e1f(%rip),%rdx        # 18dcf0 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x480>
    0.00 :   cbed1:  call   *0xc50f1(%rip)        # 190fc8 <_DYNAMIC+0x208>
    0.00 :   cbed7:  jmp    cbeee <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cbed9:  xor    %r15d,%r15d
    0.00 :   cbedc:  lea    0xc1e3d(%rip),%rdx        # 18dd20 <anon.cccb389264607a2d4c2b49e143c9c1b6.748.llvm.10013882635303053058+0x4b0>
    0.00 :   cbee3:  mov    0x28(%rsp),%rdi
    0.00 :   cbee8:  call   *0xc50da(%rip)        # 190fc8 <_DYNAMIC+0x208>
    0.00 :   cbeee:  ud2
    0.00 :   cbef0:  mov    %rax,%r14
    0.00 :   cbef3:  mov    0x8(%rsp),%rdi
    0.00 :   cbef8:  call   *0xc50f2(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cbefe:  xor    %r15d,%r15d
    0.00 :   cbf01:  jmp    cbf7d <std::sys::backtrace::__rust_begin_short_backtrace+0x16ed>
    0.00 :   cbf03:  mov    %rax,%r14
    0.00 :   cbf06:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbf0e:  call   dc4e0 <core::ptr::drop_in_place<vthread::context::wake::mount_carrier::{{closure}}>>
    0.00 :   cbf13:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cbf18:  call   *0xc52e2(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbf1e:  mov    %rax,%r14
    0.00 :   cbf21:  movzbl 0x14(%rsp),%esi
    0.00 :   cbf26:  mov    0x50(%rsp),%rdi
    0.00 :   cbf2b:  call   db660 <_ZN4core3ptr73drop_in_place$LT$std..sync..poison..mutex..MutexGuard$LT$$LP$$RP$$GT$$GT$17h714f23ec911ea948E.llvm.10013882635303053058>
    0.00 :   cbf30:  jmp    cbfc2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1732>
    0.00 :   cbf35:  call   *0xc52c5(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbf3b:  mov    %rax,%r14
    0.00 :   cbf3e:  movzbl 0x14(%rsp),%esi
    0.00 :   cbf43:  mov    0x50(%rsp),%rdi
    0.00 :   cbf48:  call   db660 <_ZN4core3ptr73drop_in_place$LT$std..sync..poison..mutex..MutexGuard$LT$$LP$$RP$$GT$$GT$17h714f23ec911ea948E.llvm.10013882635303053058>
    0.00 :   cbf4d:  jmp    cbfc2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1732>
    0.00 :   cbf4f:  call   *0xc52ab(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbf55:  mov    %rax,%r14
    0.00 :   cbf58:  jmp    cc014 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cbf5d:  mov    %rax,%r14
    0.00 :   cbf60:  lea    0x40(%rsp),%rdi
    0.00 :   cbf65:  call   dc420 <core::ptr::drop_in_place<core::option::Option<vthread::context::wake::CarrierRoute>>>
    0.00 :   cbf6a:  mov    0x18(%rsp),%r12
    0.00 :   cbf6f:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cbf74:  call   *0xc5286(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbf7a:  mov    %rax,%r14
    0.00 :   cbf7d:  mov    %r15,%rdi
    0.00 :   cbf80:  mov    %r12,%rsi
    0.00 :   cbf83:  call   d5c20 <core::ptr::drop_in_place<core::result::Result<(),alloc::boxed::Box<dyn core::any::Any+core::marker::Send>>>>
    0.00 :   cbf88:  mov    0x18(%rsp),%r12
    0.00 :   cbf8d:  jmp    cc0a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1810>
    0.00 :   cbf92:  mov    %rax,%r14
    0.00 :   cbf95:  lock decq (%r12)
    0.00 :   cbf9a:  jne    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cbfa0:  lea    0xd0(%rsp),%rdi
    0.00 :   cbfa8:  call   *0xc600a(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cbfae:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cbfb3:  mov    %rax,%r14
    0.00 :   cbfb6:  movzbl %bpl,%esi
    0.00 :   cbfba:  mov    %r13,%rdi
    0.00 :   cbfbd:  call   d4e30 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::thread_failure::ThreadFailures>>>
    0.00 :   cbfc2:  mov    %r14,%rdi
    0.00 :   cbfc5:  jmp    cbfd2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1742>
    0.00 :   cbfc7:  call   *0xc5233(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cbfcd:  jmp    cbfcf <std::sys::backtrace::__rust_begin_short_backtrace+0x173f>
    0.00 :   cbfcf:  mov    %rax,%rdi
    0.00 :   cbfd2:  mov    0x18(%rsp),%r12
    0.00 :   cbfd7:  mov    0x20(%rsp),%r13
    0.00 :   cbfdc:  jmp    cc161 <std::sys::backtrace::__rust_begin_short_backtrace+0x18d1>
    0.00 :   cbfe1:  mov    %rax,%r14
    0.00 :   cbfe4:  test   %rbx,%rbx
    0.00 :   cbfe7:  je     cc014 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cbfe9:  mov    %r15,%rdi
    0.00 :   cbfec:  call   *0xc4ffe(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cbff2:  jmp    cc014 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cbff4:  mov    %rax,%r14
    0.00 :   cbff7:  cmpq   $0x0,0x58(%rsp)
    0.00 :   cbffd:  je     cc00a <std::sys::backtrace::__rust_begin_short_backtrace+0x177a>
    0.00 :   cbfff:  mov    0x60(%rsp),%rdi
    0.00 :   cc004:  call   *0xc4fe6(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cc00a:  mov    0x18(%rsp),%r12
    0.00 :   cc00f:  mov    0x20(%rsp),%r13
    0.00 :   cc014:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc01c:  call   d75c0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10013882635303053058>
    0.00 :   cc021:  mov    %r14,%rdi
    0.00 :   cc024:  call   *0xc57ae(%rip)        # 1917d8 <_DYNAMIC+0xa18>
    0.00 :   cc02a:  mov    0xc531f(%rip),%rcx        # 191350 <_DYNAMIC+0x590>
    0.00 :   cc031:  lock decq (%rcx)
    0.00 :   cc035:  decq   %fs:0xffffffffffffff70
    0.00 :   cc03e:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cc047:  mov    0xa0(%r12),%rsi
    0.00 :   cc04f:  mov    0x28(%rsp),%rdi
    0.00 :   cc054:  cmp    %rsi,%rdi
    0.00 :   cc057:  jae    cc071 <std::sys::backtrace::__rust_begin_short_backtrace+0x17e1>
    0.00 :   cc059:  mov    0x98(%r12),%rcx
    0.00 :   cc061:  mov    (%rcx,%rdi,8),%rcx
    0.00 :   cc065:  movb   $0x1,0xe9(%rcx)
    0.00 :   cc06c:  jmp    cbc84 <std::sys::backtrace::__rust_begin_short_backtrace+0x13f4>
    0.00 :   cc071:  mov    %rdx,%r12
    0.00 :   cc074:  mov    %rax,%r15
    0.00 :   cc077:  jmp    cbeb3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1623>
    0.00 :   cc07c:  call   *0xc517e(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc082:  mov    %rax,%r14
    0.00 :   cc085:  lea    0x120(%rsp),%rdi
    0.00 :   cc08d:  call   dc420 <core::ptr::drop_in_place<core::option::Option<vthread::context::wake::CarrierRoute>>>
    0.00 :   cc092:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc097:  call   *0xc5163(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc09d:  mov    %rax,%r14
    0.00 :   cc0a0:  lea    0x40(%rsp),%rdi
    0.00 :   cc0a5:  call   dac60 <core::ptr::drop_in_place<vthread::context::wake::CarrierRouteGuard>>
    0.00 :   cc0aa:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc0af:  mov    %rax,%r14
    0.00 :   cc0b2:  lea    0x120(%rsp),%rdi
    0.00 :   cc0ba:  call   d7960 <core::ptr::drop_in_place<vthread::kernel::Kernel>>
    0.00 :   cc0bf:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc0c4:  call   *0xc5136(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc0ca:  mov    %rax,%r14
    0.00 :   cc0cd:  lea    0x120(%rsp),%rdi
    0.00 :   cc0d5:  call   dc0b0 <core::ptr::drop_in_place<alloc::rc::RcInner<vthread::local_carrier::LocalCarrier>>>
    0.00 :   cc0da:  lea    0xa0(%rsp),%rdi
    0.00 :   cc0e2:  call   dcb90 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::rc::Rc<vthread::context::Execution>>>>
    0.00 :   cc0e7:  lea    0xe0(%rsp),%rdi
    0.00 :   cc0ef:  call   dce20 <core::ptr::drop_in_place<alloc::collections::vec_deque::VecDeque<vthread::inbox::SpawnPacket>>>
    0.00 :   cc0f4:  lea    0x100(%rsp),%rdi
    0.00 :   cc0fc:  call   dbb50 <core::ptr::drop_in_place<core::option::Option<vthread::inbox::SpawnPacket>>>
    0.00 :   cc101:  lea    0x58(%rsp),%rdi
    0.00 :   cc106:  call   dade0 <core::ptr::drop_in_place<vthread::kernel::parked_tasks::ParkedTasks>>
    0.00 :   cc10b:  lea    0x480(%rsp),%rdi
    0.00 :   cc113:  call   d9780 <core::ptr::drop_in_place<vthread::ready_queue::ReadyQueue>>
    0.00 :   cc118:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc120:  call   d9950 <core::ptr::drop_in_place<vthread::kernel_tasks::KernelTasks>>
    0.00 :   cc125:  lock decq (%r12)
    0.00 :   cc12a:  jne    cc137 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a7>
    0.00 :   cc12c:  lea    0x40(%rsp),%rdi
    0.00 :   cc131:  call   *0xc5e81(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cc137:  lock decq (%rbx)
    0.00 :   cc13b:  jne    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc13d:  lea    0xd8(%rsp),%rdi
    0.00 :   cc145:  call   *0xc5e9d(%rip)        # 191fe8 <_DYNAMIC+0x1228>
    0.00 :   cc14b:  jmp    cc1a7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc14d:  call   *0xc50ad(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc153:  call   *0xc50a7(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc159:  mov    %rax,%rdi
    0.00 :   cc15c:  mov    0x18(%rsp),%r12
    0.00 :   cc161:  call   *0xc5671(%rip)        # 1917d8 <_DYNAMIC+0xa18>
    0.00 :   cc167:  mov    0xc51e2(%rip),%rcx        # 191350 <_DYNAMIC+0x590>
    0.00 :   cc16e:  lock decq (%rcx)
    0.00 :   cc172:  decq   %fs:0xffffffffffffff70
    0.00 :   cc17b:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cc184:  lea    0x58(%rsp),%rdi
    0.00 :   cc189:  mov    %rax,%rsi
    0.00 :   cc18c:  call   *0xc5d86(%rip)        # 191f18 <_DYNAMIC+0x1158>
    0.00 :   cc192:  jmp    cb9f3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1163>
    0.00 :   cc197:  mov    %rax,%r14
    0.00 :   cc19a:  jmp    cc021 <std::sys::backtrace::__rust_begin_short_backtrace+0x1791>
    0.00 :   cc19f:  mov    %rax,%r14
    0.00 :   cc1a2:  jmp    cc1bc <std::sys::backtrace::__rust_begin_short_backtrace+0x192c>
    0.00 :   cc1a4:  mov    %rax,%r14
    0.00 :   cc1a7:  lock decq (%r12)
    0.00 :   cc1ac:  jne    cc1bc <std::sys::backtrace::__rust_begin_short_backtrace+0x192c>
    0.00 :   cc1ae:  lea    0x98(%rsp),%rdi
    0.00 :   cc1b6:  call   *0xc5dfc(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cc1bc:  lock decq (%r12)
    0.00 :   cc1c1:  jne    cc1d1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1941>
    0.00 :   cc1c3:  lea    0xc0(%rsp),%rdi
    0.00 :   cc1cb:  call   *0xc5de7(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   cc1d1:  mov    %r14,%rdi
    0.00 :   cc1d4:  call   186a90 <_Unwind_Resume@plt>
    0.00 :   cc1d9:  call   *0xc5021(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cc1df:  call   *0xc501b(%rip)        # 191200 <_DYNAMIC+0x440>
 Percent |	Source code & Disassembly of baseline-benchmark for cycles:u (7 samples, percent: global period)
----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000c9620 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   c9620:  push   %rbp
    0.00 :   c9621:  push   %r15
    0.00 :   c9623:  push   %r14
    0.00 :   c9625:  push   %r13
    0.00 :   c9627:  push   %r12
    0.00 :   c9629:  push   %rbx
    0.00 :   c962a:  sub    $0x138,%rsp
    0.00 :   c9631:  mov    %rdi,0xe8(%rsp)
    0.00 :   c9639:  movb   $0x1,%fs:0xffffffffffffffb8
    0.00 :   c9642:  lea    0x10(%rdi),%rbx
    0.00 :   c9646:  mov    %rdi,(%rsp)
    0.00 :   c964a:  lea    0x30(%rdi),%r14
    0.00 :   c964e:  mov    %r14,0x28(%rsp)
    0.00 :   c9653:  mov    %rbx,0xe0(%rsp)
    0.00 :   c965b:  jmp    c967e <std::sys::backtrace::__rust_begin_short_backtrace+0x5e>
    0.00 :   c965d:  add    $0x989680,%ecx
    0.00 :   c9663:  mov    0xe0(%rsp),%rbx
    0.00 :   c966b:  mov    %rbx,%rdi
    0.00 :   c966e:  mov    0x110(%rsp),%rsi
    0.00 :   c9676:  mov    %rax,%rdx
    0.00 :   c9679:  call   117c70 <vthread::signal::Signal::wait>
    0.00 :   c967e:  mov    (%rbx),%rax
    0.00 :   c9681:  mov    %rax,0x110(%rsp)
    0.00 :   c9689:  xor    %eax,%eax
    0.00 :   c968b:  mov    $0x1,%ecx
    0.00 :   c9690:  lock cmpxchg %ecx,(%r14)
    0.00 :   c9695:  jne    c9ebd <std::sys::backtrace::__rust_begin_short_backtrace+0x89d>
    0.00 :   c969b:  mov    0xc7cae(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c96a2:  mov    (%rax),%rax
    0.00 :   c96a5:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c96af:  test   %rcx,%rax
    0.00 :   c96b2:  jne    c9ecb <std::sys::backtrace::__rust_begin_short_backtrace+0x8ab>
    0.00 :   c96b8:  movl   $0x0,0xc(%rsp)
    0.00 :   c96c0:  mov    (%rsp),%rcx
    0.00 :   c96c4:  movzbl 0x34(%rcx),%eax
    0.00 :   c96c8:  mov    0x48(%rcx),%rax
    0.00 :   c96cc:  test   %rax,%rax
    0.00 :   c96cf:  je     ca1c0 <std::sys::backtrace::__rust_begin_short_backtrace+0xba0>
    0.00 :   c96d5:  mov    (%rsp),%rcx
    0.00 :   c96d9:  mov    0x40(%rcx),%rbp
    0.00 :   c96dd:  shl    $0x3,%rax
    0.00 :   c96e1:  lea    (%rax,%rax,2),%rax
    0.00 :   c96e5:  mov    %rax,0x118(%rsp)
    0.00 :   c96ed:  xor    %ebx,%ebx
    0.00 :   c96ef:  xor    %r12d,%r12d
    0.00 :   c96f2:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   c9700:  mov    0x0(%rbp,%rbx,1),%r15
    0.00 :   c9705:  lea    0x10(%r15),%r14
    0.00 :   c9709:  xor    %eax,%eax
    0.00 :   c970b:  mov    $0x1,%ecx
    0.00 :   c9710:  lock cmpxchg %ecx,0x10(%r15)
    0.00 :   c9716:  jne    c9759 <std::sys::backtrace::__rust_begin_short_backtrace+0x139>
    0.00 :   c9718:  mov    0xc7c31(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c971f:  mov    (%rax),%rax
    0.00 :   c9722:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c972c:  test   %rcx,%rax
    0.00 :   c972f:  jne    c9764 <std::sys::backtrace::__rust_begin_short_backtrace+0x144>
    0.00 :   c9731:  xor    %eax,%eax
    0.00 :   c9733:  movzbl 0x14(%r15),%ecx
    0.00 :   c9738:  mov    0x18(%r15),%rcx
    0.00 :   c973c:  test   %rcx,%rcx
    0.00 :   c973f:  je     c9780 <std::sys::backtrace::__rust_begin_short_backtrace+0x160>
    0.00 :   c9741:  cmp    $0x1,%ecx
    0.00 :   c9744:  jne    c9750 <std::sys::backtrace::__rust_begin_short_backtrace+0x130>
    0.00 :   c9746:  xor    %r13d,%r13d
    0.00 :   c9749:  test   %al,%al
    0.00 :   c974b:  je     c9793 <std::sys::backtrace::__rust_begin_short_backtrace+0x173>
    0.00 :   c974d:  jmp    c97ac <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c974f:  nop
    0.00 :   c9750:  mov    $0x1,%r13b
    0.00 :   c9753:  test   %al,%al
    0.00 :   c9755:  je     c9793 <std::sys::backtrace::__rust_begin_short_backtrace+0x173>
    0.00 :   c9757:  jmp    c97ac <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9759:  mov    %r14,%rdi
    0.00 :   c975c:  call   *0xc7c66(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   c9762:  jmp    c9718 <std::sys::backtrace::__rust_begin_short_backtrace+0xf8>
    0.00 :   c9764:  call   *0xc7c06(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c976a:  xor    $0x1,%al
    0.00 :   c976c:  movzbl 0x14(%r15),%ecx
    0.00 :   c9771:  mov    0x18(%r15),%rcx
    0.00 :   c9775:  test   %rcx,%rcx
    0.00 :   c9778:  jne    c9741 <std::sys::backtrace::__rust_begin_short_backtrace+0x121>
    0.00 :   c977a:  nopw   0x0(%rax,%rax,1)
    0.00 :   c9780:  mov    0x28(%r15),%rcx
    0.00 :   c9784:  mov    (%rcx),%rcx
    0.00 :   c9787:  cmp    $0x1,%rcx
    0.00 :   c978b:  sete   %r13b
    0.00 :   c978f:  test   %al,%al
    0.00 :   c9791:  jne    c97ac <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9793:  mov    0xc7bb6(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c979a:  mov    (%rax),%rax
    0.00 :   c979d:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c97a7:  test   %rcx,%rax
    0.00 :   c97aa:  jne    c97f6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d6>
    0.00 :   c97ac:  xor    %eax,%eax
    0.00 :   c97ae:  xchg   %eax,(%r14)
    0.00 :   c97b1:  cmp    $0x2,%eax
    0.00 :   c97b4:  je     c97d5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b5>
    0.00 :   c97b6:  test   %r13b,%r13b
    0.00 :   c97b9:  jne    c9810 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c97bb:  inc    %r12
    0.00 :   c97be:  add    $0x18,%rbx
    0.00 :   c97c2:  cmp    %rbx,0x118(%rsp)
    0.00 :   c97ca:  jne    c9700 <std::sys::backtrace::__rust_begin_short_backtrace+0xe0>
    0.00 :   c97d0:  jmp    ca1c0 <std::sys::backtrace::__rust_begin_short_backtrace+0xba0>
    0.00 :   c97d5:  mov    $0xca,%edi
    0.00 :   c97da:  mov    %r14,%rsi
    0.00 :   c97dd:  mov    $0x81,%edx
    0.00 :   c97e2:  mov    $0x1,%ecx
    0.00 :   c97e7:  xor    %eax,%eax
    0.00 :   c97e9:  call   *0xc7b91(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   c97ef:  test   %r13b,%r13b
    0.00 :   c97f2:  je     c97bb <std::sys::backtrace::__rust_begin_short_backtrace+0x19b>
    0.00 :   c97f4:  jmp    c9810 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c97f6:  call   *0xc7b74(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c97fc:  test   %al,%al
    0.00 :   c97fe:  jne    c97ac <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9800:  movb   $0x1,0x14(%r15)
    0.00 :   c9805:  jmp    c97ac <std::sys::backtrace::__rust_begin_short_backtrace+0x18c>
    0.00 :   c9807:  nopw   0x0(%rax,%rax,1)
    0.00 :   c9810:  mov    (%rsp),%rdi
    0.00 :   c9814:  lock incq (%rdi)
    0.00 :   c9818:  mov    0x28(%rsp),%r14
    0.00 :   c981d:  jle    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   c9823:  mov    %rdi,0x30(%rsp)
    0.00 :   c9828:  mov    0x48(%rdi),%rsi
    0.00 :   c982c:  cmp    %rsi,%r12
    0.00 :   c982f:  jae    ca38f <std::sys::backtrace::__rust_begin_short_backtrace+0xd6f>
    0.00 :   c9835:  mov    0x40(%rdi),%rax
    0.00 :   c9839:  mov    0x10(%rax,%rbx,1),%rcx
    0.00 :   c983e:  mov    %rcx,0x130(%rsp)
    0.00 :   c9846:  movups (%rax,%rbx,1),%xmm0
    0.00 :   c984a:  movaps %xmm0,0x120(%rsp)
    0.00 :   c9852:  dec    %rsi
    0.00 :   c9855:  lea    (%rsi,%rsi,2),%rcx
    0.00 :   c9859:  mov    0x10(%rax,%rcx,8),%rdx
    0.00 :   c985e:  movups (%rax,%rcx,8),%xmm0
    0.00 :   c9862:  movups %xmm0,(%rax,%rbx,1)
    0.00 :   c9866:  mov    %rdx,0x10(%rax,%rbx,1)
    0.00 :   c986b:  mov    %rsi,0x48(%rdi)
    0.00 :   c986f:  cmpb   $0x0,0xc(%rsp)
    0.00 :   c9874:  jne    c9893 <std::sys::backtrace::__rust_begin_short_backtrace+0x273>
    0.00 :   c9876:  mov    0xc7ad3(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c987d:  mov    (%rax),%rax
    0.00 :   c9880:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c988a:  test   %rcx,%rax
    0.00 :   c988d:  jne    c9f6b <std::sys::backtrace::__rust_begin_short_backtrace+0x94b>
    0.00 :   c9893:  xor    %eax,%eax
    0.00 :   c9895:  xchg   %eax,(%r14)
    0.00 :   c9898:  cmp    $0x2,%eax
    0.00 :   c989b:  je     c9edc <std::sys::backtrace::__rust_begin_short_backtrace+0x8bc>
    0.00 :   c98a1:  mov    (%rsp),%rax
    0.00 :   c98a5:  mov    %rax,0x60(%rsp)
    0.00 :   c98aa:  mov    0x130(%rsp),%rax
    0.00 :   c98b2:  lea    0x68(%rsp),%rcx
    0.00 :   c98b7:  mov    %rax,0x10(%rcx)
    0.00 :   c98bb:  movaps 0x120(%rsp),%xmm0
    0.00 :   c98c3:  movups %xmm0,(%rcx)
    0.00 :   c98c6:  cmpq   $0x0,0x68(%rsp)
    0.00 :   c98cc:  je     ca39d <std::sys::backtrace::__rust_begin_short_backtrace+0xd7d>
    0.00 :   c98d2:  mov    0x70(%rsp),%r14
    0.00 :   c98d7:  lea    0x8(%r14),%r15
    0.00 :   c98db:  jmp    c98e2 <std::sys::backtrace::__rust_begin_short_backtrace+0x2c2>
    0.00 :   c98dd:  nopl   (%rax)
    0.00 :   c98e0:  pause
    0.00 :   c98e2:  mov    (%r15),%rax
    0.00 :   c98e5:  data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   c98f0:  cmp    $0xffffffffffffffff,%rax
    0.00 :   c98f4:  je     c98e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2c0>
    0.00 :   c98f6:  test   %rax,%rax
    0.00 :   c98f9:  js     ca359 <std::sys::backtrace::__rust_begin_short_backtrace+0xd39>
    0.00 :   c98ff:  lea    0x1(%rax),%rcx
    0.00 :   c9903:  lock cmpxchg %rcx,(%r15)
    0.00 :   c9908:  jne    c98f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2d0>
    0.00 :   c990a:  mov    %r14,0x10(%rsp)
    0.00 :   c990f:  mov    0x68(%rsp),%rsi
    0.00 :   c9914:  lea    0x30(%rsp),%rdi
    0.00 :   c9919:  call   12e0b0 <vthread::join_slot::JoinSlot::claim>
    0.00 :   c991e:  cmpq   $0x0,0x30(%rsp)
    0.00 :   c9924:  je     c9957 <std::sys::backtrace::__rust_begin_short_backtrace+0x337>
    0.00 :   c9926:  movups 0x30(%rsp),%xmm0
    0.00 :   c992b:  movups 0x40(%rsp),%xmm1
    0.00 :   c9930:  movaps %xmm1,0x100(%rsp)
    0.00 :   c9938:  movaps %xmm0,0xf0(%rsp)
    0.00 :   c9940:  lea    0xf0(%rsp),%rdi
    0.00 :   c9948:  lea    0x10(%rsp),%rsi
    0.00 :   c994d:  mov    $0x4,%edx
    0.00 :   c9952:  call   12d670 <vthread::join_slot::Claim::join>
    0.00 :   c9957:  cmp    $0xffffffffffffffff,%r14
    0.00 :   c995b:  je     c996c <std::sys::backtrace::__rust_begin_short_backtrace+0x34c>
    0.00 :   c995d:  lock decq (%r15)
    0.00 :   c9961:  jne    c996c <std::sys::backtrace::__rust_begin_short_backtrace+0x34c>
    0.00 :   c9963:  mov    %r14,%rdi
    0.00 :   c9966:  call   *0xc7684(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c996c:  mov    0x78(%rsp),%r12
    0.00 :   c9971:  mov    0x68(%rsp),%r15
    0.00 :   c9976:  mov    0x70(%rsp),%r13
    0.00 :   c997b:  lea    0x10(%r15),%r14
    0.00 :   c997f:  xor    %eax,%eax
    0.00 :   c9981:  mov    $0x1,%ecx
    0.00 :   c9986:  lock cmpxchg %ecx,0x10(%r15)
    0.00 :   c998c:  jne    c9efb <std::sys::backtrace::__rust_begin_short_backtrace+0x8db>
    0.00 :   c9992:  mov    0xc79b7(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9999:  mov    (%rax),%rax
    0.00 :   c999c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c99a6:  test   %rcx,%rax
    0.00 :   c99a9:  jne    c9f09 <std::sys::backtrace::__rust_begin_short_backtrace+0x8e9>
    0.00 :   c99af:  lea    0x14(%r15),%rbp
    0.00 :   c99b3:  movzbl 0x14(%r15),%eax
    0.00 :   c99b8:  mov    0x18(%r15),%rbx
    0.00 :   c99bc:  mov    0xc798d(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c99c3:  mov    (%rax),%rax
    0.00 :   c99c6:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c99d0:  test   %rcx,%rax
    0.00 :   c99d3:  jne    c9f54 <std::sys::backtrace::__rust_begin_short_backtrace+0x934>
    0.00 :   c99d9:  xor    %eax,%eax
    0.00 :   c99db:  xchg   %eax,(%r14)
    0.00 :   c99de:  cmp    $0x2,%eax
    0.00 :   c99e1:  je     c9f2c <std::sys::backtrace::__rust_begin_short_backtrace+0x90c>
    0.00 :   c99e7:  cmp    $0x2,%ebx
    0.00 :   c99ea:  jne    ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c99f0:  movzbl 0x38(%r12),%eax
    0.00 :   c99f6:  test   %al,%al
    0.00 :   c99f8:  je     ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c99fe:  mov    0x10(%r12),%rdi
    0.00 :   c9a03:  add    $0x10,%rdi
    0.00 :   c9a07:  call   12e3c0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9a0c:  test   %al,%al
    0.00 :   c9a0e:  je     ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9a14:  mov    0x98(%r13),%rax
    0.00 :   c9a1b:  mov    0xa0(%r13),%rcx
    0.00 :   c9a22:  shl    $0x3,%rcx
    0.00 :   c9a26:  xor    %edx,%edx
    0.00 :   c9a28:  jmp    c9a44 <std::sys::backtrace::__rust_begin_short_backtrace+0x424>
    0.00 :   c9a2a:  nopw   0x0(%rax,%rax,1)
    0.00 :   c9a30:  mov    0xd0(%rsi),%rsi
    0.00 :   c9a37:  add    $0x8,%rdx
    0.00 :   c9a3b:  test   %rsi,%rsi
    0.00 :   c9a3e:  jne    ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9a44:  cmp    %rdx,%rcx
    0.00 :   c9a47:  je     c9a7a <std::sys::backtrace::__rust_begin_short_backtrace+0x45a>
    0.00 :   c9a49:  mov    (%rax,%rdx,1),%rsi
    0.00 :   c9a4d:  movzbl 0xe8(%rsi),%edi
    0.00 :   c9a54:  test   %dil,%dil
    0.00 :   c9a57:  je     c9a30 <std::sys::backtrace::__rust_begin_short_backtrace+0x410>
    0.00 :   c9a59:  movzbl 0xe9(%rsi),%edi
    0.00 :   c9a60:  test   %dil,%dil
    0.00 :   c9a63:  je     ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9a69:  movzbl 0xea(%rsi),%edi
    0.00 :   c9a70:  test   %dil,%dil
    0.00 :   c9a73:  jne    c9a30 <std::sys::backtrace::__rust_begin_short_backtrace+0x410>
    0.00 :   c9a75:  jmp    ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9a7a:  mov    0x20(%r12),%eax
    0.00 :   c9a7f:  test   %eax,%eax
    0.00 :   c9a81:  jne    c9a99 <std::sys::backtrace::__rust_begin_short_backtrace+0x479>
    0.00 :   c9a83:  mov    0x18(%r12),%rdi
    0.00 :   c9a88:  add    $0x10,%rdi
    0.00 :   c9a8c:  call   12e3c0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9a91:  test   %al,%al
    0.00 :   c9a93:  je     ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9a99:  mov    0x30(%r12),%eax
    0.00 :   c9a9e:  test   %eax,%eax
    0.00 :   c9aa0:  jne    c9ab8 <std::sys::backtrace::__rust_begin_short_backtrace+0x498>
    0.00 :   c9aa2:  mov    0x28(%r12),%rdi
    0.00 :   c9aa7:  add    $0x10,%rdi
    0.00 :   c9aab:  call   12e3c0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9ab0:  test   %al,%al
    0.00 :   c9ab2:  je     ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9ab8:  mov    0x100(%r13),%eax
    0.00 :   c9abf:  test   %eax,%eax
    0.00 :   c9ac1:  jne    c9c0f <std::sys::backtrace::__rust_begin_short_backtrace+0x5ef>
    0.00 :   c9ac7:  mov    0xd8(%r13),%rbx
    0.00 :   c9ace:  mov    0xe0(%r13),%rdi
    0.00 :   c9ad5:  add    $0x10,%rdi
    0.00 :   c9ad9:  call   12e3c0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9ade:  test   %al,%al
    0.00 :   c9ae0:  je     ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9ae6:  lea    0x20(%rbx),%r12
    0.00 :   c9aea:  xor    %eax,%eax
    0.00 :   c9aec:  mov    $0x1,%ecx
    0.00 :   c9af1:  lock cmpxchg %ecx,0x20(%rbx)
    0.00 :   c9af6:  jne    ca0c4 <std::sys::backtrace::__rust_begin_short_backtrace+0xaa4>
    0.00 :   c9afc:  mov    0xc784d(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9b03:  mov    (%rax),%rax
    0.00 :   c9b06:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9b10:  test   %rcx,%rax
    0.00 :   c9b13:  jne    ca0d2 <std::sys::backtrace::__rust_begin_short_backtrace+0xab2>
    0.00 :   c9b19:  lea    0x24(%rbx),%r14
    0.00 :   c9b1d:  movzbl 0x24(%rbx),%eax
    0.00 :   c9b21:  cmpq   $0x0,0x50(%rbx)
    0.00 :   c9b26:  jne    ca3dd <std::sys::backtrace::__rust_begin_short_backtrace+0xdbd>
    0.00 :   c9b2c:  mov    0xc781d(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9b33:  mov    (%rax),%rax
    0.00 :   c9b36:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9b40:  test   %rcx,%rax
    0.00 :   c9b43:  jne    ca124 <std::sys::backtrace::__rust_begin_short_backtrace+0xb04>
    0.00 :   c9b49:  xor    %eax,%eax
    0.00 :   c9b4b:  xchg   %eax,(%r12)
    0.00 :   c9b4f:  cmp    $0x2,%eax
    0.00 :   c9b52:  je     ca0f8 <std::sys::backtrace::__rust_begin_short_backtrace+0xad8>
    0.00 :   c9b58:  mov    0x70(%rbx),%rax
    0.00 :   c9b5c:  test   %rax,%rax
    0.00 :   c9b5f:  jne    ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9b65:  mov    0xe8(%r13),%rbx
    0.00 :   c9b6c:  lea    0x10(%rbx),%r12
    0.00 :   c9b70:  xor    %eax,%eax
    0.00 :   c9b72:  mov    $0x1,%ecx
    0.00 :   c9b77:  lock cmpxchg %ecx,0x10(%rbx)
    0.00 :   c9b7c:  jne    ca13b <std::sys::backtrace::__rust_begin_short_backtrace+0xb1b>
    0.00 :   c9b82:  mov    0xc77c7(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9b89:  mov    (%rax),%rax
    0.00 :   c9b8c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9b96:  test   %rcx,%rax
    0.00 :   c9b99:  jne    ca149 <std::sys::backtrace::__rust_begin_short_backtrace+0xb29>
    0.00 :   c9b9f:  xor    %r14d,%r14d
    0.00 :   c9ba2:  movzbl 0x14(%rbx),%eax
    0.00 :   c9ba6:  mov    0xf0(%r13),%rdi
    0.00 :   c9bad:  add    $0x10,%rdi
    0.00 :   c9bb1:  call   12e3c0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   c9bb6:  test   %al,%al
    0.00 :   c9bb8:  je     c9bd3 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b3>
    0.00 :   c9bba:  cmpq   $0x0,0x30(%rbx)
    0.00 :   c9bbf:  jne    c9bd3 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b3>
    0.00 :   c9bc1:  cmpq   $0x0,0x50(%rbx)
    0.00 :   c9bc6:  jne    c9bd3 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b3>
    0.00 :   c9bc8:  cmpq   $0x0,0x58(%rbx)
    0.00 :   c9bcd:  je     c9ea6 <std::sys::backtrace::__rust_begin_short_backtrace+0x886>
    0.00 :   c9bd3:  xor    %ebp,%ebp
    0.00 :   c9bd5:  test   %r14b,%r14b
    0.00 :   c9bd8:  jne    c9bf7 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d7>
    0.00 :   c9bda:  mov    0xc776f(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9be1:  mov    (%rax),%rax
    0.00 :   c9be4:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9bee:  test   %rcx,%rax
    0.00 :   c9bf1:  jne    ca183 <std::sys::backtrace::__rust_begin_short_backtrace+0xb63>
    0.00 :   c9bf7:  xor    %eax,%eax
    0.00 :   c9bf9:  xchg   %eax,(%r12)
    0.00 :   c9bfd:  cmp    $0x2,%eax
    0.00 :   c9c00:  je     ca15b <std::sys::backtrace::__rust_begin_short_backtrace+0xb3b>
    0.00 :   c9c06:  test   %bpl,%bpl
    0.00 :   c9c09:  je     ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9c0f:  mov    0x70(%rsp),%rbx
    0.00 :   c9c14:  lea    0x130(%rbx),%r12
    0.00 :   c9c1b:  xor    %eax,%eax
    0.00 :   c9c1d:  mov    $0x1,%ecx
    0.00 :   c9c22:  lock cmpxchg %ecx,0x130(%rbx)
    0.00 :   c9c2a:  jne    c9f86 <std::sys::backtrace::__rust_begin_short_backtrace+0x966>
    0.00 :   c9c30:  mov    0xc7719(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9c37:  mov    (%rax),%rax
    0.00 :   c9c3a:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9c44:  test   %rcx,%rax
    0.00 :   c9c47:  jne    c9f94 <std::sys::backtrace::__rust_begin_short_backtrace+0x974>
    0.00 :   c9c4d:  xor    %eax,%eax
    0.00 :   c9c4f:  movzbl 0x134(%rbx),%ecx
    0.00 :   c9c56:  cmpq   $0x0,0x148(%rbx)
    0.00 :   c9c5e:  jne    c9c6e <std::sys::backtrace::__rust_begin_short_backtrace+0x64e>
    0.00 :   c9c60:  cmpq   $0x0,0x150(%rbx)
    0.00 :   c9c68:  je     c9e44 <std::sys::backtrace::__rust_begin_short_backtrace+0x824>
    0.00 :   c9c6e:  test   %al,%al
    0.00 :   c9c70:  jne    c9c8f <std::sys::backtrace::__rust_begin_short_backtrace+0x66f>
    0.00 :   c9c72:  mov    0xc76d7(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9c79:  mov    (%rax),%rax
    0.00 :   c9c7c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9c86:  test   %rcx,%rax
    0.00 :   c9c89:  jne    ca0aa <std::sys::backtrace::__rust_begin_short_backtrace+0xa8a>
    0.00 :   c9c8f:  xor    %eax,%eax
    0.00 :   c9c91:  xchg   %eax,(%r12)
    0.00 :   c9c95:  mov    $0x6,%r13b
    0.00 :   c9c98:  cmp    $0x2,%eax
    0.00 :   c9c9b:  je     c9e77 <std::sys::backtrace::__rust_begin_short_backtrace+0x857>
    0.00 :   c9ca1:  mov    0x70(%rsp),%r12
    0.00 :   c9ca6:  lock incq (%r12)
    0.00 :   c9cab:  jle    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   c9cb1:  mov    %r12,0xf0(%rsp)
    0.00 :   c9cb9:  lea    0x68(%rsp),%rax
    0.00 :   c9cbe:  movups (%rax),%xmm0
    0.00 :   c9cc1:  movaps %xmm0,0x30(%rsp)
    0.00 :   c9cc6:  mov    0x10(%rax),%rax
    0.00 :   c9cca:  mov    %rax,0x40(%rsp)
    0.00 :   c9ccf:  movq   $0x0,0x68(%rsp)
    0.00 :   c9cd8:  cmpq   $0x0,0x30(%rsp)
    0.00 :   c9cde:  je     c9ced <std::sys::backtrace::__rust_begin_short_backtrace+0x6cd>
    0.00 :   c9ce0:  mov    $0x1,%bpl
    0.00 :   c9ce3:  lea    0x30(%rsp),%rdi
    0.00 :   c9ce8:  call   d93f0 <core::ptr::drop_in_place<vthread::lifecycle_owner::Entry>>
    0.00 :   c9ced:  mov    0x60(%rsp),%rbx
    0.00 :   c9cf2:  lea    0x30(%rbx),%r14
    0.00 :   c9cf6:  xor    %eax,%eax
    0.00 :   c9cf8:  mov    $0x1,%ecx
    0.00 :   c9cfd:  lock cmpxchg %ecx,0x30(%rbx)
    0.00 :   c9d02:  jne    c9fb6 <std::sys::backtrace::__rust_begin_short_backtrace+0x996>
    0.00 :   c9d08:  mov    0xc7641(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9d0f:  mov    (%rax),%rax
    0.00 :   c9d12:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9d1c:  test   %rcx,%rax
    0.00 :   c9d1f:  jne    c9fc4 <std::sys::backtrace::__rust_begin_short_backtrace+0x9a4>
    0.00 :   c9d25:  lea    0x34(%rbx),%r15
    0.00 :   c9d29:  movzbl 0x34(%rbx),%eax
    0.00 :   c9d2d:  decq   0x90(%rbx)
    0.00 :   c9d34:  mov    0xc7615(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9d3b:  mov    (%rax),%rax
    0.00 :   c9d3e:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9d48:  test   %rcx,%rax
    0.00 :   c9d4b:  jne    ca078 <std::sys::backtrace::__rust_begin_short_backtrace+0xa58>
    0.00 :   c9d51:  xor    %eax,%eax
    0.00 :   c9d53:  xchg   %eax,(%r14)
    0.00 :   c9d56:  cmp    $0x2,%eax
    0.00 :   c9d59:  je     c9fec <std::sys::backtrace::__rust_begin_short_backtrace+0x9cc>
    0.00 :   c9d5f:  movups 0x60(%rsp),%xmm0
    0.00 :   c9d64:  movups 0x70(%rsp),%xmm1
    0.00 :   c9d69:  movaps %xmm1,0x40(%rsp)
    0.00 :   c9d6e:  movaps %xmm0,0x30(%rsp)
    0.00 :   c9d73:  xor    %ebp,%ebp
    0.00 :   c9d75:  lea    0x30(%rsp),%rdi
    0.00 :   c9d7a:  call   db3e0 <core::ptr::drop_in_place<vthread::lifecycle_owner::lifecycle_reaper::Claim>>
    0.00 :   c9d7f:  lea    0x168(%r12),%r14
    0.00 :   c9d87:  xor    %eax,%eax
    0.00 :   c9d89:  mov    $0x1,%ecx
    0.00 :   c9d8e:  lock cmpxchg %ecx,0x168(%r12)
    0.00 :   c9d98:  jne    ca00b <std::sys::backtrace::__rust_begin_short_backtrace+0x9eb>
    0.00 :   c9d9e:  mov    0xc75ab(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9da5:  mov    (%rax),%rax
    0.00 :   c9da8:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9db2:  test   %rcx,%rax
    0.00 :   c9db5:  jne    ca019 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f9>
    0.00 :   c9dbb:  lea    0x16c(%r12),%rbx
    0.00 :   c9dc3:  movzbl 0x16c(%r12),%eax
    0.00 :   c9dcc:  movzbl 0x221(%r12),%eax
    0.00 :   c9dd5:  movzbl %r13b,%ecx
    0.00 :   c9dd9:  cmp    %al,%r13b
    0.00 :   c9ddc:  cmovbe %eax,%ecx
    0.00 :   c9ddf:  mov    %cl,0x221(%r12)
    0.00 :   c9de7:  mov    0xc7562(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9dee:  mov    (%rax),%rax
    0.00 :   c9df1:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9dfb:  test   %rcx,%rax
    0.00 :   c9dfe:  jne    ca092 <std::sys::backtrace::__rust_begin_short_backtrace+0xa72>
    0.00 :   c9e04:  xor    %eax,%eax
    0.00 :   c9e06:  xchg   %eax,(%r14)
    0.00 :   c9e09:  cmp    $0x2,%eax
    0.00 :   c9e0c:  je     ca059 <std::sys::backtrace::__rust_begin_short_backtrace+0xa39>
    0.00 :   c9e12:  lea    0x108(%r12),%rdi
    0.00 :   c9e1a:  xor    %ebp,%ebp
    0.00 :   c9e1c:  call   117f50 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10013882635303053058>
    0.00 :   c9e21:  lock decq (%r12)
    0.00 :   c9e26:  mov    0x28(%rsp),%r14
    0.00 :   c9e2b:  jne    c9689 <std::sys::backtrace::__rust_begin_short_backtrace+0x69>
    0.00 :   c9e31:  lea    0xf0(%rsp),%rdi
    0.00 :   c9e39:  call   *0xc8179(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   c9e3f:  jmp    c9689 <std::sys::backtrace::__rust_begin_short_backtrace+0x69>
    0.00 :   c9e44:  test   %al,%al
    0.00 :   c9e46:  jne    c9e65 <std::sys::backtrace::__rust_begin_short_backtrace+0x845>
    0.00 :   c9e48:  mov    0xc7501(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9e4f:  mov    (%rax),%rax
    0.00 :   c9e52:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9e5c:  test   %rcx,%rax
    0.00 :   c9e5f:  jne    ca19a <std::sys::backtrace::__rust_begin_short_backtrace+0xb7a>
    0.00 :   c9e65:  xor    %eax,%eax
    0.00 :   c9e67:  xchg   %eax,(%r12)
    0.00 :   c9e6b:  mov    $0x5,%r13b
    0.00 :   c9e6e:  cmp    $0x2,%eax
    0.00 :   c9e71:  jne    c9ca1 <std::sys::backtrace::__rust_begin_short_backtrace+0x681>
    0.00 :   c9e77:  mov    $0xca,%edi
    0.00 :   c9e7c:  mov    %r12,%rsi
    0.00 :   c9e7f:  mov    $0x81,%edx
    0.00 :   c9e84:  mov    $0x1,%ecx
    0.00 :   c9e89:  xor    %eax,%eax
    0.00 :   c9e8b:  call   *0xc74ef(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   c9e91:  mov    0x70(%rsp),%r12
    0.00 :   c9e96:  lock incq (%r12)
    0.00 :   c9e9b:  jg     c9cb1 <std::sys::backtrace::__rust_begin_short_backtrace+0x691>
    0.00 :   c9ea1:  jmp    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   c9ea6:  cmpq   $0x0,0x60(%rbx)
    0.00 :   c9eab:  sete   %bpl
    0.00 :   c9eaf:  test   %r14b,%r14b
    0.00 :   c9eb2:  jne    c9bf7 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d7>
    0.00 :   c9eb8:  jmp    c9bda <std::sys::backtrace::__rust_begin_short_backtrace+0x5ba>
    0.00 :   c9ebd:  mov    %r14,%rdi
    0.00 :   c9ec0:  call   *0xc7502(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   c9ec6:  jmp    c969b <std::sys::backtrace::__rust_begin_short_backtrace+0x7b>
    0.00 :   c9ecb:  call   *0xc749f(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c9ed1:  xor    $0x1,%al
    0.00 :   c9ed3:  mov    %eax,0xc(%rsp)
    0.00 :   c9ed7:  jmp    c96c0 <std::sys::backtrace::__rust_begin_short_backtrace+0xa0>
    0.00 :   c9edc:  mov    $0xca,%edi
    0.00 :   c9ee1:  mov    %r14,%rsi
    0.00 :   c9ee4:  mov    $0x81,%edx
    0.00 :   c9ee9:  mov    $0x1,%ecx
    0.00 :   c9eee:  xor    %eax,%eax
    0.00 :   c9ef0:  call   *0xc748a(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   c9ef6:  jmp    c98a1 <std::sys::backtrace::__rust_begin_short_backtrace+0x281>
    0.00 :   c9efb:  mov    %r14,%rdi
    0.00 :   c9efe:  call   *0xc74c4(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   c9f04:  jmp    c9992 <std::sys::backtrace::__rust_begin_short_backtrace+0x372>
    0.00 :   c9f09:  call   *0xc7461(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c9f0f:  movzbl 0x14(%r15),%ecx
    0.00 :   c9f14:  mov    0x18(%r15),%rbx
    0.00 :   c9f18:  test   %al,%al
    0.00 :   c9f1a:  je     c99d9 <std::sys::backtrace::__rust_begin_short_backtrace+0x3b9>
    0.00 :   c9f20:  add    $0x14,%r15
    0.00 :   c9f24:  mov    %r15,%rbp
    0.00 :   c9f27:  jmp    c99bc <std::sys::backtrace::__rust_begin_short_backtrace+0x39c>
    0.00 :   c9f2c:  mov    $0xca,%edi
    0.00 :   c9f31:  mov    %r14,%rsi
    0.00 :   c9f34:  mov    $0x81,%edx
    0.00 :   c9f39:  mov    $0x1,%ecx
    0.00 :   c9f3e:  xor    %eax,%eax
    0.00 :   c9f40:  call   *0xc743a(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   c9f46:  cmp    $0x2,%ebx
    0.00 :   c9f49:  je     c99f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3d0>
    0.00 :   c9f4f:  jmp    ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   c9f54:  call   *0xc7416(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c9f5a:  test   %al,%al
    0.00 :   c9f5c:  jne    c99d9 <std::sys::backtrace::__rust_begin_short_backtrace+0x3b9>
    0.00 :   c9f62:  movb   $0x1,0x0(%rbp)
    0.00 :   c9f66:  jmp    c99d9 <std::sys::backtrace::__rust_begin_short_backtrace+0x3b9>
    0.00 :   c9f6b:  call   *0xc73ff(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c9f71:  test   %al,%al
    0.00 :   c9f73:  jne    c9893 <std::sys::backtrace::__rust_begin_short_backtrace+0x273>
    0.00 :   c9f79:  mov    (%rsp),%rax
    0.00 :   c9f7d:  movb   $0x1,0x34(%rax)
    0.00 :   c9f81:  jmp    c9893 <std::sys::backtrace::__rust_begin_short_backtrace+0x273>
    0.00 :   c9f86:  mov    %r12,%rdi
    0.00 :   c9f89:  call   *0xc7439(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   c9f8f:  jmp    c9c30 <std::sys::backtrace::__rust_begin_short_backtrace+0x610>
    0.00 :   c9f94:  call   *0xc73d6(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c9f9a:  xor    $0x1,%al
    0.00 :   c9f9c:  movzbl 0x134(%rbx),%ecx
    0.00 :   c9fa3:  cmpq   $0x0,0x148(%rbx)
    0.00 :   c9fab:  jne    c9c6e <std::sys::backtrace::__rust_begin_short_backtrace+0x64e>
    0.00 :   c9fb1:  jmp    c9c60 <std::sys::backtrace::__rust_begin_short_backtrace+0x640>
    0.00 :   c9fb6:  mov    %r14,%rdi
    0.00 :   c9fb9:  call   *0xc7409(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   c9fbf:  jmp    c9d08 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e8>
    0.00 :   c9fc4:  mov    $0x1,%bpl
    0.00 :   c9fc7:  call   *0xc73a3(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c9fcd:  movzbl 0x34(%rbx),%ecx
    0.00 :   c9fd1:  decq   0x90(%rbx)
    0.00 :   c9fd8:  test   %al,%al
    0.00 :   c9fda:  je     c9d51 <std::sys::backtrace::__rust_begin_short_backtrace+0x731>
    0.00 :   c9fe0:  add    $0x34,%rbx
    0.00 :   c9fe4:  mov    %rbx,%r15
    0.00 :   c9fe7:  jmp    c9d34 <std::sys::backtrace::__rust_begin_short_backtrace+0x714>
    0.00 :   c9fec:  mov    $0xca,%edi
    0.00 :   c9ff1:  mov    %r14,%rsi
    0.00 :   c9ff4:  mov    $0x81,%edx
    0.00 :   c9ff9:  mov    $0x1,%ecx
    0.00 :   c9ffe:  xor    %eax,%eax
    0.00 :   ca000:  call   *0xc737a(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   ca006:  jmp    c9d5f <std::sys::backtrace::__rust_begin_short_backtrace+0x73f>
    0.00 :   ca00b:  mov    %r14,%rdi
    0.00 :   ca00e:  call   *0xc73b4(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   ca014:  jmp    c9d9e <std::sys::backtrace::__rust_begin_short_backtrace+0x77e>
    0.00 :   ca019:  xor    %ebp,%ebp
    0.00 :   ca01b:  call   *0xc734f(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca021:  movzbl 0x16c(%r12),%ecx
    0.00 :   ca02a:  movzbl 0x221(%r12),%ecx
    0.00 :   ca033:  movzbl %r13b,%edx
    0.00 :   ca037:  cmp    %cl,%dl
    0.00 :   ca039:  cmova  %edx,%ecx
    0.00 :   ca03c:  mov    %cl,0x221(%r12)
    0.00 :   ca044:  test   %al,%al
    0.00 :   ca046:  je     c9e04 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e4>
    0.00 :   ca04c:  lea    0x16c(%r12),%rbx
    0.00 :   ca054:  jmp    c9de7 <std::sys::backtrace::__rust_begin_short_backtrace+0x7c7>
    0.00 :   ca059:  mov    $0xca,%edi
    0.00 :   ca05e:  mov    %r14,%rsi
    0.00 :   ca061:  mov    $0x81,%edx
    0.00 :   ca066:  mov    $0x1,%ecx
    0.00 :   ca06b:  xor    %eax,%eax
    0.00 :   ca06d:  call   *0xc730d(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   ca073:  jmp    c9e12 <std::sys::backtrace::__rust_begin_short_backtrace+0x7f2>
    0.00 :   ca078:  mov    $0x1,%bpl
    0.00 :   ca07b:  call   *0xc72ef(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca081:  test   %al,%al
    0.00 :   ca083:  jne    c9d51 <std::sys::backtrace::__rust_begin_short_backtrace+0x731>
    0.00 :   ca089:  movb   $0x1,(%r15)
    0.00 :   ca08d:  jmp    c9d51 <std::sys::backtrace::__rust_begin_short_backtrace+0x731>
    0.00 :   ca092:  xor    %ebp,%ebp
    0.00 :   ca094:  call   *0xc72d6(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca09a:  test   %al,%al
    0.00 :   ca09c:  jne    c9e04 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e4>
    0.00 :   ca0a2:  movb   $0x1,(%rbx)
    0.00 :   ca0a5:  jmp    c9e04 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e4>
    0.00 :   ca0aa:  call   *0xc72c0(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca0b0:  test   %al,%al
    0.00 :   ca0b2:  jne    c9c8f <std::sys::backtrace::__rust_begin_short_backtrace+0x66f>
    0.00 :   ca0b8:  movb   $0x1,0x134(%rbx)
    0.00 :   ca0bf:  jmp    c9c8f <std::sys::backtrace::__rust_begin_short_backtrace+0x66f>
    0.00 :   ca0c4:  mov    %r12,%rdi
    0.00 :   ca0c7:  call   *0xc72fb(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   ca0cd:  jmp    c9afc <std::sys::backtrace::__rust_begin_short_backtrace+0x4dc>
    0.00 :   ca0d2:  call   *0xc7298(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca0d8:  lea    0x24(%rbx),%r14
    0.00 :   ca0dc:  movzbl 0x24(%rbx),%ecx
    0.00 :   ca0e0:  cmpq   $0x0,0x50(%rbx)
    0.00 :   ca0e5:  jne    ca3d9 <std::sys::backtrace::__rust_begin_short_backtrace+0xdb9>
    0.00 :   ca0eb:  test   %al,%al
    0.00 :   ca0ed:  jne    c9b2c <std::sys::backtrace::__rust_begin_short_backtrace+0x50c>
    0.00 :   ca0f3:  jmp    c9b49 <std::sys::backtrace::__rust_begin_short_backtrace+0x529>
    0.00 :   ca0f8:  mov    $0xca,%edi
    0.00 :   ca0fd:  mov    %r12,%rsi
    0.00 :   ca100:  mov    $0x81,%edx
    0.00 :   ca105:  mov    $0x1,%ecx
    0.00 :   ca10a:  xor    %eax,%eax
    0.00 :   ca10c:  call   *0xc726e(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   ca112:  mov    0x70(%rbx),%rax
    0.00 :   ca116:  test   %rax,%rax
    0.00 :   ca119:  je     c9b65 <std::sys::backtrace::__rust_begin_short_backtrace+0x545>
    0.00 :   ca11f:  jmp    ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   ca124:  call   *0xc7246(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca12a:  test   %al,%al
    0.00 :   ca12c:  jne    c9b49 <std::sys::backtrace::__rust_begin_short_backtrace+0x529>
    0.00 :   ca132:  movb   $0x1,(%r14)
    0.00 :   ca136:  jmp    c9b49 <std::sys::backtrace::__rust_begin_short_backtrace+0x529>
    0.00 :   ca13b:  mov    %r12,%rdi
    0.00 :   ca13e:  call   *0xc7284(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   ca144:  jmp    c9b82 <std::sys::backtrace::__rust_begin_short_backtrace+0x562>
    0.00 :   ca149:  call   *0xc7221(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca14f:  mov    %eax,%r14d
    0.00 :   ca152:  xor    $0x1,%r14b
    0.00 :   ca156:  jmp    c9ba2 <std::sys::backtrace::__rust_begin_short_backtrace+0x582>
    0.00 :   ca15b:  mov    $0xca,%edi
    0.00 :   ca160:  mov    %r12,%rsi
    0.00 :   ca163:  mov    $0x81,%edx
    0.00 :   ca168:  mov    $0x1,%ecx
    0.00 :   ca16d:  xor    %eax,%eax
    0.00 :   ca16f:  call   *0xc720b(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   ca175:  test   %bpl,%bpl
    0.00 :   ca178:  jne    c9c0f <std::sys::backtrace::__rust_begin_short_backtrace+0x5ef>
    0.00 :   ca17e:  jmp    ca409 <std::sys::backtrace::__rust_begin_short_backtrace+0xde9>
    0.00 :   ca183:  call   *0xc71e7(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca189:  test   %al,%al
    0.00 :   ca18b:  jne    c9bf7 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d7>
    0.00 :   ca191:  movb   $0x1,0x14(%rbx)
    0.00 :   ca195:  jmp    c9bf7 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d7>
    0.00 :   ca19a:  call   *0xc71d0(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca1a0:  test   %al,%al
    0.00 :   ca1a2:  jne    c9e65 <std::sys::backtrace::__rust_begin_short_backtrace+0x845>
    0.00 :   ca1a8:  movb   $0x1,0x134(%rbx)
    0.00 :   ca1af:  jmp    c9e65 <std::sys::backtrace::__rust_begin_short_backtrace+0x845>
    0.00 :   ca1b4:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   ca1c0:  cmpb   $0x0,0xc(%rsp)
    0.00 :   ca1c5:  mov    0x28(%rsp),%r14
    0.00 :   ca1ca:  jne    ca1e9 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc9>
    0.00 :   ca1cc:  mov    0xc717d(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   ca1d3:  mov    (%rax),%rax
    0.00 :   ca1d6:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca1e0:  test   %rcx,%rax
    0.00 :   ca1e3:  jne    ca33e <std::sys::backtrace::__rust_begin_short_backtrace+0xd1e>
    0.00 :   ca1e9:  xor    %eax,%eax
    0.00 :   ca1eb:  xchg   %eax,(%r14)
    0.00 :   ca1ee:  cmp    $0x2,%eax
    0.00 :   ca1f1:  je     ca29a <std::sys::backtrace::__rust_begin_short_backtrace+0xc7a>
    0.00 :   ca1f7:  xor    %eax,%eax
    0.00 :   ca1f9:  mov    $0x1,%ecx
    0.00 :   ca1fe:  lock cmpxchg %ecx,(%r14)
    0.00 :   ca203:  jne    ca2c6 <std::sys::backtrace::__rust_begin_short_backtrace+0xca6>
    0.00 :   ca209:  mov    0xc7140(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   ca210:  mov    (%rax),%rax
    0.00 :   ca213:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca21d:  test   %rcx,%rax
    0.00 :   ca220:  jne    ca2d4 <std::sys::backtrace::__rust_begin_short_backtrace+0xcb4>
    0.00 :   ca226:  mov    (%rsp),%rcx
    0.00 :   ca22a:  movzbl 0x34(%rcx),%eax
    0.00 :   ca22e:  cmpq   $0x0,0x48(%rcx)
    0.00 :   ca233:  sete   %bl
    0.00 :   ca236:  mov    0xc7113(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   ca23d:  mov    (%rax),%rax
    0.00 :   ca240:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca24a:  test   %rcx,%rax
    0.00 :   ca24d:  jne    ca323 <std::sys::backtrace::__rust_begin_short_backtrace+0xd03>
    0.00 :   ca253:  xor    %eax,%eax
    0.00 :   ca255:  xchg   %eax,(%r14)
    0.00 :   ca258:  cmp    $0x2,%eax
    0.00 :   ca25b:  je     ca2f7 <std::sys::backtrace::__rust_begin_short_backtrace+0xcd7>
    0.00 :   ca261:  mov    $0x3b9aca00,%ecx
    0.00 :   ca266:  test   %bl,%bl
    0.00 :   ca268:  jne    c9663 <std::sys::backtrace::__rust_begin_short_backtrace+0x43>
    0.00 :   ca26e:  mov    $0x1,%edi
    0.00 :   ca273:  call   a12d0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   ca278:  mov    %edx,%ecx
    0.00 :   ca27a:  cmp    $0x3b023380,%edx
    0.00 :   ca280:  jb     c965d <std::sys::backtrace::__rust_begin_short_backtrace+0x3d>
    0.00 :   ca286:  inc    %rax
    0.00 :   ca289:  jo     ca3bb <std::sys::backtrace::__rust_begin_short_backtrace+0xd9b>
    0.00 :   ca28f:  add    $0xc4fdcc80,%ecx
    0.00 :   ca295:  jmp    c9663 <std::sys::backtrace::__rust_begin_short_backtrace+0x43>
    0.00 :   ca29a:  mov    $0xca,%edi
    0.00 :   ca29f:  mov    %r14,%rsi
    0.00 :   ca2a2:  mov    $0x81,%edx
    0.00 :   ca2a7:  mov    $0x1,%ecx
    0.00 :   ca2ac:  xor    %eax,%eax
    0.00 :   ca2ae:  call   *0xc70cc(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   ca2b4:  xor    %eax,%eax
    0.00 :   ca2b6:  mov    $0x1,%ecx
    0.00 :   ca2bb:  lock cmpxchg %ecx,(%r14)
    0.00 :   ca2c0:  je     ca209 <std::sys::backtrace::__rust_begin_short_backtrace+0xbe9>
    0.00 :   ca2c6:  mov    %r14,%rdi
    0.00 :   ca2c9:  call   *0xc70f9(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   ca2cf:  jmp    ca209 <std::sys::backtrace::__rust_begin_short_backtrace+0xbe9>
    0.00 :   ca2d4:  call   *0xc7096(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca2da:  mov    (%rsp),%rdx
    0.00 :   ca2de:  movzbl 0x34(%rdx),%ecx
    0.00 :   ca2e2:  cmpq   $0x0,0x48(%rdx)
    0.00 :   ca2e7:  sete   %bl
    0.00 :   ca2ea:  test   %al,%al
    0.00 :   ca2ec:  jne    ca236 <std::sys::backtrace::__rust_begin_short_backtrace+0xc16>
    0.00 :   ca2f2:  jmp    ca253 <std::sys::backtrace::__rust_begin_short_backtrace+0xc33>
    0.00 :   ca2f7:  mov    $0xca,%edi
    0.00 :   ca2fc:  mov    %r14,%rsi
    0.00 :   ca2ff:  mov    $0x81,%edx
    0.00 :   ca304:  mov    $0x1,%ecx
    0.00 :   ca309:  xor    %eax,%eax
    0.00 :   ca30b:  call   *0xc706f(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   ca311:  mov    $0x3b9aca00,%ecx
    0.00 :   ca316:  test   %bl,%bl
    0.00 :   ca318:  jne    c9663 <std::sys::backtrace::__rust_begin_short_backtrace+0x43>
    0.00 :   ca31e:  jmp    ca26e <std::sys::backtrace::__rust_begin_short_backtrace+0xc4e>
    0.00 :   ca323:  call   *0xc7047(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca329:  test   %al,%al
    0.00 :   ca32b:  jne    ca253 <std::sys::backtrace::__rust_begin_short_backtrace+0xc33>
    0.00 :   ca331:  mov    (%rsp),%rax
    0.00 :   ca335:  movb   $0x1,0x34(%rax)
    0.00 :   ca339:  jmp    ca253 <std::sys::backtrace::__rust_begin_short_backtrace+0xc33>
    0.00 :   ca33e:  call   *0xc702c(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca344:  test   %al,%al
    0.00 :   ca346:  jne    ca1e9 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc9>
    0.00 :   ca34c:  mov    (%rsp),%rax
    0.00 :   ca350:  movb   $0x1,0x34(%rax)
    0.00 :   ca354:  jmp    ca1e9 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc9>
    0.00 :   ca359:  lea    0xc1be0(%rip),%rax        # 18bf40 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x210>
    0.00 :   ca360:  mov    %rax,0x30(%rsp)
    0.00 :   ca365:  lea    0x9274(%rip),%rax        # d35e0 <_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hb2a2ab9295a6d20aE.llvm.10013882635303053058>
    0.00 :   ca36c:  mov    %rax,0x38(%rsp)
    0.00 :   ca371:  lea    -0xb7c03(%rip),%rdi        # 12775 <anon.48996dcd35f4b7aad43cb5fc1472ecbf.144.llvm.7041895458470441471>
    0.00 :   ca378:  lea    0xc2991(%rip),%rdx        # 18cd10 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x6b0>
    0.00 :   ca37f:  lea    0x30(%rsp),%rsi
    0.00 :   ca384:  call   *0xc6cbe(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   ca38a:  jmp    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca38f:  mov    %r12,%rdi
    0.00 :   ca392:  call   *0xc6cb8(%rip)        # 191050 <_DYNAMIC+0x290>
    0.00 :   ca398:  jmp    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca39d:  lea    -0xac29e(%rip),%rdi        # 1e106 <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0xd9e>
    0.00 :   ca3a4:  lea    0xc32f5(%rip),%rdx        # 18d6a0 <anon.cccb389264607a2d4c2b49e143c9c1b6.433.llvm.10013882635303053058+0x840>
    0.00 :   ca3ab:  mov    $0xd,%esi
    0.00 :   ca3b0:  call   *0xc6e32(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   ca3b6:  jmp    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca3bb:  lea    -0xae0b3(%rip),%rdi        # 1c30f <anon.e19cb05173cfa9d2277c28e7a8ac702e.708.llvm.13342753452097612697>
    0.00 :   ca3c2:  lea    0xc1767(%rip),%rdx        # 18bb30 <anon.e19cb05173cfa9d2277c28e7a8ac702e.791.llvm.13342753452097612697>
    0.00 :   ca3c9:  mov    $0x28,%esi
    0.00 :   ca3ce:  call   *0xc6e14(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   ca3d4:  jmp    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca3d9:  test   %al,%al
    0.00 :   ca3db:  je     ca3fa <std::sys::backtrace::__rust_begin_short_backtrace+0xdda>
    0.00 :   ca3dd:  mov    0xc6f6c(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   ca3e4:  mov    (%rax),%rax
    0.00 :   ca3e7:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ca3f1:  test   %rcx,%rax
    0.00 :   ca3f4:  jne    ca5e3 <std::sys::backtrace::__rust_begin_short_backtrace+0xfc3>
    0.00 :   ca3fa:  xor    %eax,%eax
    0.00 :   ca3fc:  xchg   %eax,(%r12)
    0.00 :   ca400:  cmp    $0x2,%eax
    0.00 :   ca403:  je     ca5a0 <std::sys::backtrace::__rust_begin_short_backtrace+0xf80>
    0.00 :   ca409:  mov    $0x10,%edi
    0.00 :   ca40e:  call   *0xc6bf4(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   ca414:  test   %rax,%rax
    0.00 :   ca417:  je     ca5ce <std::sys::backtrace::__rust_begin_short_backtrace+0xfae>
    0.00 :   ca41d:  lea    -0xac311(%rip),%rcx        # 1e113 <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0xdab>
    0.00 :   ca424:  mov    %rcx,(%rax)
    0.00 :   ca427:  movq   $0x2f,0x8(%rax)
    0.00 :   ca42f:  lea    0xc3282(%rip),%rdx        # 18d6b8 <anon.cccb389264607a2d4c2b49e143c9c1b6.433.llvm.10013882635303053058+0x858>
    0.00 :   ca436:  lea    0x30(%rsp),%rdi
    0.00 :   ca43b:  mov    %rax,%rsi
    0.00 :   ca43e:  call   *0xc7b7c(%rip)        # 191fc0 <_DYNAMIC+0x1200>
    0.00 :   ca444:  mov    0x30(%rsp),%r12
    0.00 :   ca449:  mov    0x38(%rsp),%r14
    0.00 :   ca44e:  mov    0x40(%rsp),%rax
    0.00 :   ca453:  mov    %rax,0xf0(%rsp)
    0.00 :   ca45b:  movzbl 0x48(%rsp),%eax
    0.00 :   ca460:  mov    %al,0xf8(%rsp)
    0.00 :   ca467:  movzbl 0x49(%rsp),%ebx
    0.00 :   ca46c:  mov    0x4a(%rsp),%eax
    0.00 :   ca470:  mov    %eax,0x10(%rsp)
    0.00 :   ca474:  movzwl 0x4e(%rsp),%eax
    0.00 :   ca479:  mov    %ax,0x14(%rsp)
    0.00 :   ca47e:  mov    $0x17,%edi
    0.00 :   ca483:  call   *0xc6b7f(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   ca489:  test   %rax,%rax
    0.00 :   ca48c:  je     ca5fa <std::sys::backtrace::__rust_begin_short_backtrace+0xfda>
    0.00 :   ca492:  mov    %rax,%r15
    0.00 :   ca495:  movups -0xac3ad(%rip),%xmm0        # 1e0ef <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0xd87>
    0.00 :   ca49c:  movups %xmm0,(%rax)
    0.00 :   ca49f:  movabs $0x72656e776f2d656c,%rax
    0.00 :   ca4a9:  mov    %rax,0xf(%r15)
    0.00 :   ca4ad:  mov    0xf0(%rsp),%rax
    0.00 :   ca4b5:  mov    %rax,0xd0(%rsp)
    0.00 :   ca4bd:  movzbl 0xf8(%rsp),%eax
    0.00 :   ca4c5:  mov    %al,0xd8(%rsp)
    0.00 :   ca4cc:  mov    0x10(%rsp),%eax
    0.00 :   ca4d0:  mov    %eax,0x20(%rsp)
    0.00 :   ca4d4:  movzwl 0x14(%rsp),%eax
    0.00 :   ca4d9:  mov    %ax,0x24(%rsp)
    0.00 :   ca4de:  lea    0x60(%rsp),%rdi
    0.00 :   ca4e3:  call   db3e0 <core::ptr::drop_in_place<vthread::lifecycle_owner::lifecycle_reaper::Claim>>
    0.00 :   ca4e8:  mov    %r12,0x98(%rsp)
    0.00 :   ca4f0:  mov    %r14,0xa0(%rsp)
    0.00 :   ca4f8:  mov    0xd0(%rsp),%rax
    0.00 :   ca500:  mov    %rax,0xa8(%rsp)
    0.00 :   ca508:  movzbl 0xd8(%rsp),%eax
    0.00 :   ca510:  mov    %al,0xb0(%rsp)
    0.00 :   ca517:  mov    %bl,0xb1(%rsp)
    0.00 :   ca51e:  mov    0x20(%rsp),%eax
    0.00 :   ca522:  mov    %eax,0xb2(%rsp)
    0.00 :   ca529:  movzwl 0x24(%rsp),%eax
    0.00 :   ca52e:  mov    %ax,0xb6(%rsp)
    0.00 :   ca536:  movl   $0x10000,0xb8(%rsp)
    0.00 :   ca541:  movq   $0x17,0x80(%rsp)
    0.00 :   ca54d:  mov    %r15,0x88(%rsp)
    0.00 :   ca555:  movq   $0x17,0x90(%rsp)
    0.00 :   ca561:  lea    0x80(%rsp),%rsi
    0.00 :   ca569:  mov    0xe0(%rsp),%rdi
    0.00 :   ca571:  call   1033b0 <vthread::lifecycle_owner::State::fail>
    0.00 :   ca576:  mov    (%rsp),%rax
    0.00 :   ca57a:  lock decq (%rax)
    0.00 :   ca57e:  jne    ca58e <std::sys::backtrace::__rust_begin_short_backtrace+0xf6e>
    0.00 :   ca580:  lea    0xe8(%rsp),%rdi
    0.00 :   ca588:  call   *0xc7a3a(%rip)        # 191fc8 <_DYNAMIC+0x1208>
    0.00 :   ca58e:  add    $0x138,%rsp
    0.00 :   ca595:  pop    %rbx
    0.00 :   ca596:  pop    %r12
    0.00 :   ca598:  pop    %r13
    0.00 :   ca59a:  pop    %r14
    0.00 :   ca59c:  pop    %r15
    0.00 :   ca59e:  pop    %rbp
    0.00 :   ca59f:  ret
    0.00 :   ca5a0:  mov    $0xca,%edi
    0.00 :   ca5a5:  mov    %r12,%rsi
    0.00 :   ca5a8:  mov    $0x81,%edx
    0.00 :   ca5ad:  mov    $0x1,%ecx
    0.00 :   ca5b2:  xor    %eax,%eax
    0.00 :   ca5b4:  call   *0xc6dc6(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   ca5ba:  mov    $0x10,%edi
    0.00 :   ca5bf:  call   *0xc6a43(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   ca5c5:  test   %rax,%rax
    0.00 :   ca5c8:  jne    ca41d <std::sys::backtrace::__rust_begin_short_backtrace+0xdfd>
    0.00 :   ca5ce:  mov    $0x8,%edi
    0.00 :   ca5d3:  mov    $0x10,%esi
    0.00 :   ca5d8:  call   *0xc6a52(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   ca5de:  jmp    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca5e3:  call   *0xc6d87(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   ca5e9:  test   %al,%al
    0.00 :   ca5eb:  jne    ca3fa <std::sys::backtrace::__rust_begin_short_backtrace+0xdda>
    0.00 :   ca5f1:  movb   $0x1,(%r14)
    0.00 :   ca5f5:  jmp    ca3fa <std::sys::backtrace::__rust_begin_short_backtrace+0xdda>
    0.00 :   ca5fa:  mov    $0x1,%edi
    0.00 :   ca5ff:  mov    $0x17,%esi
    0.00 :   ca604:  call   *0xc69ae(%rip)        # 190fb8 <_DYNAMIC+0x1f8>
    0.00 :   ca60a:  jmp    ca841 <std::sys::backtrace::__rust_begin_short_backtrace+0x1221>
    0.00 :   ca60f:  mov    %rax,%rbx
    0.00 :   ca612:  mov    0x28(%rsp),%r14
    0.00 :   ca617:  jmp    ca6a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1080>
    0.00 :   ca61c:  mov    %rax,%rbx
    0.00 :   ca61f:  movzbl %r14b,%esi
    0.00 :   ca623:  mov    %r12,%rdi
    0.00 :   ca626:  call   d4e30 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::thread_failure::ThreadFailures>>>
    0.00 :   ca62b:  jmp    ca6b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   ca630:  call   *0xc6bca(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   ca636:  jmp    ca683 <std::sys::backtrace::__rust_begin_short_backtrace+0x1063>
    0.00 :   ca638:  mov    %rax,%rbx
    0.00 :   ca63b:  lock decq (%r12)
    0.00 :   ca640:  jne    ca650 <std::sys::backtrace::__rust_begin_short_backtrace+0x1030>
    0.00 :   ca642:  lea    0xf0(%rsp),%rdi
    0.00 :   ca64a:  call   *0xc7968(%rip)        # 191fb8 <_DYNAMIC+0x11f8>
    0.00 :   ca650:  test   %bpl,%bpl
    0.00 :   ca653:  jne    ca6b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   ca655:  jmp    ca6c2 <std::sys::backtrace::__rust_begin_short_backtrace+0x10a2>
    0.00 :   ca657:  jmp    ca683 <std::sys::backtrace::__rust_begin_short_backtrace+0x1063>
    0.00 :   ca659:  mov    %rax,%rbx
    0.00 :   ca65c:  test   %r12,%r12
    0.00 :   ca65f:  jne    ca678 <std::sys::backtrace::__rust_begin_short_backtrace+0x1058>
    0.00 :   ca661:  jmp    ca6b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   ca663:  jmp    ca6b5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1095>
    0.00 :   ca665:  jmp    ca6b5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1095>
    0.00 :   ca667:  jmp    ca683 <std::sys::backtrace::__rust_begin_short_backtrace+0x1063>
    0.00 :   ca669:  mov    %rax,%rbx
    0.00 :   ca66c:  cmp    $0xffffffffffffffff,%r14
    0.00 :   ca670:  je     ca6b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   ca672:  lock decq (%r15)
    0.00 :   ca676:  jne    ca6b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   ca678:  mov    %r14,%rdi
    0.00 :   ca67b:  call   *0xc696f(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   ca681:  jmp    ca6b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1098>
    0.00 :   ca683:  mov    %rax,%rbx
    0.00 :   ca686:  jmp    ca6c2 <std::sys::backtrace::__rust_begin_short_backtrace+0x10a2>
    0.00 :   ca688:  mov    %rax,%rbx
    0.00 :   ca68b:  mov    (%rsp),%rax
    0.00 :   ca68f:  lock decq (%rax)
    0.00 :   ca693:  jne    ca6a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1080>
    0.00 :   ca695:  lea    0x30(%rsp),%rdi
    0.00 :   ca69a:  call   *0xc7928(%rip)        # 191fc8 <_DYNAMIC+0x1208>
    0.00 :   ca6a0:  movzbl 0xc(%rsp),%esi
    0.00 :   ca6a5:  mov    %r14,%rdi
    0.00 :   ca6a8:  call   dc8f0 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::control::State>>>
    0.00 :   ca6ad:  jmp    ca6c2 <std::sys::backtrace::__rust_begin_short_backtrace+0x10a2>
    0.00 :   ca6af:  call   *0xc6b4b(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   ca6b5:  mov    %rax,%rbx
    0.00 :   ca6b8:  lea    0x60(%rsp),%rdi
    0.00 :   ca6bd:  call   db3e0 <core::ptr::drop_in_place<vthread::lifecycle_owner::lifecycle_reaper::Claim>>
    0.00 :   ca6c2:  movabs $0x54535552005a4f4d,%rax
    0.00 :   ca6cc:  cmp    %rax,(%rbx)
    0.00 :   ca6cf:  jne    ca822 <std::sys::backtrace::__rust_begin_short_backtrace+0x1202>
    0.00 :   ca6d5:  lea    -0xb15e1(%rip),%rax        # 190fb <_RNvNtCsiPbkgJzcHgT_12panic_unwind3imp6CANARY.llvm.187188839016265319>
    0.00 :   ca6dc:  cmp    %rax,0x20(%rbx)
    0.00 :   ca6e0:  jne    ca82b <std::sys::backtrace::__rust_begin_short_backtrace+0x120b>
    0.00 :   ca6e6:  mov    0x28(%rbx),%r14
    0.00 :   ca6ea:  mov    0x30(%rbx),%r15
    0.00 :   ca6ee:  mov    %rbx,%rdi
    0.00 :   ca6f1:  call   *0xc68f9(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   ca6f7:  mov    0xc6c52(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   ca6fe:  lock decq (%rax)
    0.00 :   ca702:  decq   %fs:0xffffffffffffff70
    0.00 :   ca70b:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   ca714:  lea    0x80(%rsp),%rdi
    0.00 :   ca71c:  mov    %r14,%rsi
    0.00 :   ca71f:  mov    %r15,%rdx
    0.00 :   ca722:  call   *0xc7898(%rip)        # 191fc0 <_DYNAMIC+0x1200>
    0.00 :   ca728:  mov    0x80(%rsp),%rbx
    0.00 :   ca730:  mov    0x88(%rsp),%r14
    0.00 :   ca738:  mov    0x90(%rsp),%rax
    0.00 :   ca740:  mov    %rax,0xc0(%rsp)
    0.00 :   ca748:  movzbl 0x98(%rsp),%eax
    0.00 :   ca750:  mov    %al,0xc8(%rsp)
    0.00 :   ca757:  movzbl 0x99(%rsp),%ebp
    0.00 :   ca75f:  mov    0x9a(%rsp),%eax
    0.00 :   ca766:  mov    %eax,0x18(%rsp)
    0.00 :   ca76a:  movzwl 0x9e(%rsp),%eax
    0.00 :   ca772:  mov    %ax,0x1c(%rsp)
    0.00 :   ca777:  mov    $0x17,%edi
    0.00 :   ca77c:  call   *0xc6886(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   ca782:  test   %rax,%rax
    0.00 :   ca785:  je     ca831 <std::sys::backtrace::__rust_begin_short_backtrace+0x1211>
    0.00 :   ca78b:  movups -0xac6a3(%rip),%xmm0        # 1e0ef <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0xd87>
    0.00 :   ca792:  movups %xmm0,(%rax)
    0.00 :   ca795:  movabs $0x72656e776f2d656c,%rcx
    0.00 :   ca79f:  mov    %rcx,0xf(%rax)
    0.00 :   ca7a3:  movq   $0x17,0x80(%rsp)
    0.00 :   ca7af:  mov    %rax,0x88(%rsp)
    0.00 :   ca7b7:  movq   $0x17,0x90(%rsp)
    0.00 :   ca7c3:  mov    %rbx,0x98(%rsp)
    0.00 :   ca7cb:  mov    %r14,0xa0(%rsp)
    0.00 :   ca7d3:  mov    0xc0(%rsp),%rax
    0.00 :   ca7db:  mov    %rax,0xa8(%rsp)
    0.00 :   ca7e3:  movzbl 0xc8(%rsp),%eax
    0.00 :   ca7eb:  mov    %al,0xb0(%rsp)
    0.00 :   ca7f2:  mov    %bpl,0xb1(%rsp)
    0.00 :   ca7fa:  mov    0x18(%rsp),%eax
    0.00 :   ca7fe:  mov    %eax,0xb2(%rsp)
    0.00 :   ca805:  movzwl 0x1c(%rsp),%eax
    0.00 :   ca80a:  mov    %ax,0xb6(%rsp)
    0.00 :   ca812:  movl   $0x10000,0xb8(%rsp)
    0.00 :   ca81d:  jmp    ca561 <std::sys::backtrace::__rust_begin_short_backtrace+0xf41>
    0.00 :   ca822:  mov    %rbx,%rdi
    0.00 :   ca825:  call   *0xc6c0d(%rip)        # 191438 <_Unwind_DeleteException@GCC_3.0>
    0.00 :   ca82b:  call   *0xc6c0f(%rip)        # 191440 <_DYNAMIC+0x680>
    0.00 :   ca831:  mov    $0x1,%edi
    0.00 :   ca836:  mov    $0x17,%esi
    0.00 :   ca83b:  call   *0xc6777(%rip)        # 190fb8 <_DYNAMIC+0x1f8>
    0.00 :   ca841:  ud2
    0.00 :   ca843:  call   *0xc69b7(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   ca849:  mov    %rax,%r15
    0.00 :   ca84c:  test   %rbx,%rbx
    0.00 :   ca84f:  je     ca85f <std::sys::backtrace::__rust_begin_short_backtrace+0x123f>
    0.00 :   ca851:  mov    %r14,%rdi
    0.00 :   ca854:  call   *0xc6796(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   ca85a:  jmp    ca85f <std::sys::backtrace::__rust_begin_short_backtrace+0x123f>
    0.00 :   ca85c:  mov    %rax,%r15
    0.00 :   ca85f:  mov    (%rsp),%rax
    0.00 :   ca863:  lock decq (%rax)
    0.00 :   ca867:  jne    ca877 <std::sys::backtrace::__rust_begin_short_backtrace+0x1257>
    0.00 :   ca869:  lea    0xe8(%rsp),%rdi
    0.00 :   ca871:  call   *0xc7751(%rip)        # 191fc8 <_DYNAMIC+0x1208>
    0.00 :   ca877:  mov    %r15,%rdi
    0.00 :   ca87a:  call   186a90 <_Unwind_Resume@plt>
    0.00 :   ca87f:  call   *0xc697b(%rip)        # 191200 <_DYNAMIC+0x440>
 Percent |	Source code & Disassembly of baseline-benchmark for cycles:u (8 samples, percent: global period)
----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000c6170 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   c6170:  push   %rbp
    0.00 :   c6171:  push   %r15
    0.00 :   c6173:  push   %r14
    0.00 :   c6175:  push   %r13
    0.00 :   c6177:  push   %r12
    0.00 :   c6179:  push   %rbx
    0.00 :   c617a:  sub    $0x4b8,%rsp
    0.00 :   c6181:  mov    %rdi,%rbx
    0.00 :   c6184:  mov    0x10(%rdi),%r12
    0.00 :   c6188:  cmp    $0xffffffffffffffff,%r12
    0.00 :   c618c:  je     c619a <std::sys::backtrace::__rust_begin_short_backtrace+0x2a>
    0.00 :   c618e:  lock incq 0x8(%r12)
    0.00 :   c6194:  jle    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c619a:  mov    %r12,%rdi
    0.00 :   c619d:  mov    $0x3,%esi
    0.00 :   c61a2:  call   102ae0 <vthread::worker_context::attach>
    0.00 :   c61a7:  mov    0x18(%rbx),%rbp
    0.00 :   c61ab:  mov    (%rbx),%rax
    0.00 :   c61ae:  mov    %rax,0x238(%rsp)
    0.00 :   c61b6:  mov    0x8(%rbx),%rax
    0.00 :   c61ba:  mov    %rax,0x240(%rsp)
    0.00 :   c61c2:  cmp    $0x3,%rbp
    0.00 :   c61c6:  mov    $0x2,%esi
    0.00 :   c61cb:  cmovae %rbp,%rsi
    0.00 :   c61cf:  lea    0x198(%rsp),%rdi
    0.00 :   c61d7:  mov    %rbp,%rdx
    0.00 :   c61da:  call   *0xcbd60(%rip)        # 191f40 <_DYNAMIC+0x1180>
    0.00 :   c61e0:  movabs $0x7fffffffffffffff,%rbx
    0.00 :   c61ea:  mov    0x198(%rsp),%rax
    0.00 :   c61f2:  cmp    $0x2,%rax
    0.00 :   c61f6:  jne    c6387 <std::sys::backtrace::__rust_begin_short_backtrace+0x217>
    0.00 :   c61fc:  lea    0x1a0(%rsp),%rsi
    0.00 :   c6204:  lea    0x400(%rsp),%rdi
    0.00 :   c620c:  call   1318f0 <vthread::readiness::io_error>
    0.00 :   c6211:  mov    0x400(%rsp),%rbx
    0.00 :   c6219:  mov    0x408(%rsp),%r14
    0.00 :   c6221:  mov    0x410(%rsp),%rbp
    0.00 :   c6229:  movups 0x418(%rsp),%xmm0
    0.00 :   c6231:  movups 0x428(%rsp),%xmm1
    0.00 :   c6239:  movaps %xmm1,0x350(%rsp)
    0.00 :   c6241:  mov    0x438(%rsp),%rax
    0.00 :   c6249:  movaps %xmm0,0x120(%rsp)
    0.00 :   c6251:  movaps %xmm1,0x3a0(%rsp)
    0.00 :   c6259:  mov    %rax,0x3b0(%rsp)
    0.00 :   c6261:  movaps %xmm0,0x2f0(%rsp)
    0.00 :   c6269:  mov    0x3b0(%rsp),%rax
    0.00 :   c6271:  mov    %rax,0x2e0(%rsp)
    0.00 :   c6279:  movdqa 0x3a0(%rsp),%xmm0
    0.00 :   c6282:  movdqa %xmm0,0x2d0(%rsp)
    0.00 :   c628b:  cmp    $0xffffffffffffffff,%r12
    0.00 :   c628f:  je     c62a2 <std::sys::backtrace::__rust_begin_short_backtrace+0x132>
    0.00 :   c6291:  lock decq 0x8(%r12)
    0.00 :   c6297:  jne    c62a2 <std::sys::backtrace::__rust_begin_short_backtrace+0x132>
    0.00 :   c6299:  mov    %r12,%rdi
    0.00 :   c629c:  call   *0xcad4e(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c62a2:  movaps 0x2f0(%rsp),%xmm0
    0.00 :   c62aa:  movups %xmm0,0x1b0(%rsp)
    0.00 :   c62b2:  movdqa 0x2d0(%rsp),%xmm0
    0.00 :   c62bb:  movdqu %xmm0,0x1c0(%rsp)
    0.00 :   c62c4:  mov    0x2e0(%rsp),%rax
    0.00 :   c62cc:  mov    %rax,0x1d0(%rsp)
    0.00 :   c62d4:  mov    %rbx,0x198(%rsp)
    0.00 :   c62dc:  mov    %r14,0x1a0(%rsp)
    0.00 :   c62e4:  mov    %rbp,0x1a8(%rsp)
    0.00 :   c62ec:  lea    0x248(%rsp),%rdi
    0.00 :   c62f4:  lea    0x198(%rsp),%rcx
    0.00 :   c62fc:  mov    0x238(%rsp),%rsi
    0.00 :   c6304:  mov    0x240(%rsp),%rdx
    0.00 :   c630c:  call   ce2d0 <std::sync::mpmc::Sender<T>::send>
    0.00 :   c6311:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   c631b:  mov    0x248(%rsp),%rax
    0.00 :   c6323:  lea    0x24(%rdx),%rcx
    0.00 :   c6327:  cmp    %rcx,%rax
    0.00 :   c632a:  je     c6360 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c632c:  add    $0x23,%rdx
    0.00 :   c6330:  cmp    %rdx,%rax
    0.00 :   c6333:  jne    c6353 <std::sys::backtrace::__rust_begin_short_backtrace+0x1e3>
    0.00 :   c6335:  mov    0x250(%rsp),%rax
    0.00 :   c633d:  lock decq (%rax)
    0.00 :   c6341:  jne    c6360 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c6343:  lea    0x250(%rsp),%rdi
    0.00 :   c634b:  call   *0xcbbf7(%rip)        # 191f48 <_DYNAMIC+0x1188>
    0.00 :   c6351:  jmp    c6360 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c6353:  lea    0x248(%rsp),%rdi
    0.00 :   c635b:  call   d75c0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10013882635303053058>
    0.00 :   c6360:  mov    0x238(%rsp),%rdi
    0.00 :   c6368:  mov    0x240(%rsp),%rsi
    0.00 :   c6370:  call   d6090 <core::ptr::drop_in_place<std::sync::mpsc::SyncSender<core::result::Result<alloc::sync::Arc<vthread::readiness::Inner>,vthread::error::Error>>>>
    0.00 :   c6375:  add    $0x4b8,%rsp
    0.00 :   c637c:  pop    %rbx
    0.00 :   c637d:  pop    %r12
    0.00 :   c637f:  pop    %r13
    0.00 :   c6381:  pop    %r14
    0.00 :   c6383:  pop    %r15
    0.00 :   c6385:  pop    %rbp
    0.00 :   c6386:  ret
    0.00 :   c6387:  mov    0x1b0(%rsp),%rcx
    0.00 :   c638f:  movups 0x1b8(%rsp),%xmm0
    0.00 :   c6397:  movaps %xmm0,0x50(%rsp)
    0.00 :   c639c:  movups 0x1c8(%rsp),%xmm1
    0.00 :   c63a4:  movaps %xmm1,0x350(%rsp)
    0.00 :   c63ac:  mov    0x1d8(%rsp),%rdx
    0.00 :   c63b4:  mov    %rdx,0x360(%rsp)
    0.00 :   c63bc:  lea    0x290(%rsp),%r13
    0.00 :   c63c4:  movups 0x1e0(%rsp),%xmm1
    0.00 :   c63cc:  movups %xmm1,0x290(%rsp)
    0.00 :   c63d4:  movups 0x1f0(%rsp),%xmm1
    0.00 :   c63dc:  movups %xmm1,0x2a0(%rsp)
    0.00 :   c63e4:  movups 0x200(%rsp),%xmm1
    0.00 :   c63ec:  movups %xmm1,0x2b0(%rsp)
    0.00 :   c63f4:  movups 0x210(%rsp),%xmm1
    0.00 :   c63fc:  movups %xmm1,0x2c0(%rsp)
    0.00 :   c6404:  movups 0x1a0(%rsp),%xmm1
    0.00 :   c640c:  movaps %xmm0,0x120(%rsp)
    0.00 :   c6414:  mov    0x360(%rsp),%rdx
    0.00 :   c641c:  mov    %rdx,0x3b0(%rsp)
    0.00 :   c6424:  movaps 0x350(%rsp),%xmm0
    0.00 :   c642c:  movaps %xmm0,0x3a0(%rsp)
    0.00 :   c6434:  movups %xmm1,0x250(%rsp)
    0.00 :   c643c:  mov    %rcx,0x260(%rsp)
    0.00 :   c6444:  movaps 0x120(%rsp),%xmm0
    0.00 :   c644c:  movups %xmm0,0x268(%rsp)
    0.00 :   c6454:  mov    0x3b0(%rsp),%rcx
    0.00 :   c645c:  mov    %rcx,0x288(%rsp)
    0.00 :   c6464:  movdqa 0x3a0(%rsp),%xmm0
    0.00 :   c646d:  movdqu %xmm0,0x278(%rsp)
    0.00 :   c6476:  mov    %rax,0x248(%rsp)
    0.00 :   c647e:  mov    0x288(%rsp),%r15
    0.00 :   c6486:  lea    0x198(%rsp),%rdi
    0.00 :   c648e:  mov    $0x8,%edx
    0.00 :   c6493:  mov    $0x10,%r8d
    0.00 :   c6499:  xor    %esi,%esi
    0.00 :   c649b:  mov    %r15,%rcx
    0.00 :   c649e:  call   186670 <_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h4ed0753c4cf49bf8E.llvm.534919669303308328>
    0.00 :   c64a3:  cmpb   $0x0,0x198(%rsp)
    0.00 :   c64ab:  je     c6531 <std::sys::backtrace::__rust_begin_short_backtrace+0x3c1>
    0.00 :   c64b1:  lea    0x408(%rsp),%rsi
    0.00 :   c64b9:  movb   $0x7,0x408(%rsp)
    0.00 :   c64c1:  mov    %r15,0x410(%rsp)
    0.00 :   c64c9:  lea    0x1(%rbx),%rax
    0.00 :   c64cd:  mov    %rax,0x400(%rsp)
    0.00 :   c64d5:  lea    0x198(%rsp),%rdi
    0.00 :   c64dd:  call   1318f0 <vthread::readiness::io_error>
    0.00 :   c64e2:  mov    0x198(%rsp),%rbx
    0.00 :   c64ea:  mov    0x1a0(%rsp),%r14
    0.00 :   c64f2:  mov    0x1a8(%rsp),%rbp
    0.00 :   c64fa:  movdqu 0x1b0(%rsp),%xmm0
    0.00 :   c6503:  movups 0x1c0(%rsp),%xmm1
    0.00 :   c650b:  movaps %xmm1,0x2d0(%rsp)
    0.00 :   c6513:  mov    0x1d0(%rsp),%rax
    0.00 :   c651b:  mov    %rax,0x2e0(%rsp)
    0.00 :   c6523:  movdqa %xmm0,0x2f0(%rsp)
    0.00 :   c652c:  jmp    c6611 <std::sys::backtrace::__rust_begin_short_backtrace+0x4a1>
    0.00 :   c6531:  mov    0x1a0(%rsp),%rcx
    0.00 :   c6539:  mov    %r15,0x418(%rsp)
    0.00 :   c6541:  movq   $0x0,0x410(%rsp)
    0.00 :   c654d:  mov    0x410(%rsp),%rax
    0.00 :   c6555:  mov    %rax,0x50(%rsp)
    0.00 :   c655a:  mov    0x418(%rsp),%rax
    0.00 :   c6562:  mov    %rax,0x58(%rsp)
    0.00 :   c6567:  cmpl   $0x1,0x248(%rsp)
    0.00 :   c656f:  mov    %rcx,0x20(%rsp)
    0.00 :   c6574:  jne    c66b3 <std::sys::backtrace::__rust_begin_short_backtrace+0x543>
    0.00 :   c657a:  mov    0x250(%rsp),%rax
    0.00 :   c6582:  test   %rax,%rax
    0.00 :   c6585:  je     c66cb <std::sys::backtrace::__rust_begin_short_backtrace+0x55b>
    0.00 :   c658b:  movb   $0x2,0x90(%rsp)
    0.00 :   c6593:  mov    %rax,0x98(%rsp)
    0.00 :   c659b:  movq   $0x0,0xa0(%rsp)
    0.00 :   c65a7:  lea    0x198(%rsp),%rdi
    0.00 :   c65af:  lea    0x90(%rsp),%rsi
    0.00 :   c65b7:  call   1318f0 <vthread::readiness::io_error>
    0.00 :   c65bc:  mov    0x198(%rsp),%rbx
    0.00 :   c65c4:  mov    0x1a0(%rsp),%r14
    0.00 :   c65cc:  mov    0x1a8(%rsp),%rbp
    0.00 :   c65d4:  movups 0x1b0(%rsp),%xmm0
    0.00 :   c65dc:  movaps %xmm0,0x2f0(%rsp)
    0.00 :   c65e4:  movdqu 0x1c0(%rsp),%xmm0
    0.00 :   c65ed:  movdqa %xmm0,0x2d0(%rsp)
    0.00 :   c65f6:  mov    0x1d0(%rsp),%rax
    0.00 :   c65fe:  mov    %rax,0x2e0(%rsp)
    0.00 :   c6606:  mov    0x20(%rsp),%rdi
    0.00 :   c660b:  call   *0xca9df(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c6611:  mov    0x2c8(%rsp),%edi
    0.00 :   c6618:  call   *0xcafc2(%rip)        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c661e:  mov    0x260(%rsp),%rax
    0.00 :   c6626:  mov    %rax,0x20(%rsp)
    0.00 :   c662b:  mov    0x268(%rsp),%r13
    0.00 :   c6633:  test   %r13,%r13
    0.00 :   c6636:  je     c6678 <std::sys::backtrace::__rust_begin_short_backtrace+0x508>
    0.00 :   c6638:  mov    0x20(%rsp),%rax
    0.00 :   c663d:  lea    0xe(%rax),%r15
    0.00 :   c6641:  jmp    c6659 <std::sys::backtrace::__rust_begin_short_backtrace+0x4e9>
    0.00 :   c6643:  data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   c6650:  add    $0x18,%r15
    0.00 :   c6654:  dec    %r13
    0.00 :   c6657:  je     c6678 <std::sys::backtrace::__rust_begin_short_backtrace+0x508>
    0.00 :   c6659:  mov    -0x6(%r15),%edi
    0.00 :   c665d:  cmpb   $0x2,(%r15)
    0.00 :   c6661:  setne  %al
    0.00 :   c6664:  test   %edi,%edi
    0.00 :   c6666:  setns  %cl
    0.00 :   c6669:  and    %al,%cl
    0.00 :   c666b:  cmp    $0x1,%cl
    0.00 :   c666e:  jne    c6650 <std::sys::backtrace::__rust_begin_short_backtrace+0x4e0>
    0.00 :   c6670:  call   *0xcaf6a(%rip)        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c6676:  jmp    c6650 <std::sys::backtrace::__rust_begin_short_backtrace+0x4e0>
    0.00 :   c6678:  cmpq   $0x0,0x258(%rsp)
    0.00 :   c6681:  je     c668e <std::sys::backtrace::__rust_begin_short_backtrace+0x51e>
    0.00 :   c6683:  mov    0x20(%rsp),%rdi
    0.00 :   c6688:  call   *0xca962(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c668e:  mov    0x290(%rsp),%rax
    0.00 :   c6696:  lock decq (%rax)
    0.00 :   c669a:  lea    0x290(%rsp),%rdi
    0.00 :   c66a2:  jne    c628b <std::sys::backtrace::__rust_begin_short_backtrace+0x11b>
    0.00 :   c66a8:  call   *0xcb8a2(%rip)        # 191f50 <_DYNAMIC+0x1190>
    0.00 :   c66ae:  jmp    c628b <std::sys::backtrace::__rust_begin_short_backtrace+0x11b>
    0.00 :   c66b3:  movq   $0x1,0x248(%rsp)
    0.00 :   c66bf:  movq   $0x0,0x250(%rsp)
    0.00 :   c66cb:  mov    0x290(%rsp),%rax
    0.00 :   c66d3:  lock incq (%rax)
    0.00 :   c66d7:  jle    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c66dd:  movq   $0x1,0x198(%rsp)
    0.00 :   c66e9:  movq   $0x1,0x1a0(%rsp)
    0.00 :   c66f5:  mov    %r12,0x1a8(%rsp)
    0.00 :   c66fd:  mov    %rax,0x1b0(%rsp)
    0.00 :   c6705:  movl   $0x0,0x1b8(%rsp)
    0.00 :   c6710:  movb   $0x0,0x1bc(%rsp)
    0.00 :   c6718:  lea    0x1(%rbx),%rax
    0.00 :   c671c:  mov    %rax,0x230(%rsp)
    0.00 :   c6724:  mov    %rax,0x1c0(%rsp)
    0.00 :   c672c:  movq   $0x0,0x1d8(%rsp)
    0.00 :   c6738:  movq   $0x0,0x1e8(%rsp)
    0.00 :   c6744:  movq   $0x1,0x1f0(%rsp)
    0.00 :   c6750:  movb   $0x0,0x1f8(%rsp)
    0.00 :   c6758:  mov    %rbp,0x200(%rsp)
    0.00 :   c6760:  movq   $0x0,0x208(%rsp)
    0.00 :   c676c:  mov    $0x78,%edi
    0.00 :   c6771:  call   *0xca891(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   c6777:  test   %rax,%rax
    0.00 :   c677a:  je     c8f1a <std::sys::backtrace::__rust_begin_short_backtrace+0x2daa>
    0.00 :   c6780:  lea    0x268(%rsp),%rcx
    0.00 :   c6788:  lea    0x278(%rsp),%rdi
    0.00 :   c6790:  mov    0x208(%rsp),%rdx
    0.00 :   c6798:  mov    %rdx,0x70(%rax)
    0.00 :   c679c:  movups 0x1f8(%rsp),%xmm0
    0.00 :   c67a4:  movups %xmm0,0x60(%rax)
    0.00 :   c67a8:  movups 0x1e8(%rsp),%xmm0
    0.00 :   c67b0:  movups %xmm0,0x50(%rax)
    0.00 :   c67b4:  movups 0x1d8(%rsp),%xmm0
    0.00 :   c67bc:  movups %xmm0,0x40(%rax)
    0.00 :   c67c0:  movups 0x198(%rsp),%xmm0
    0.00 :   c67c8:  movups 0x1a8(%rsp),%xmm1
    0.00 :   c67d0:  movups 0x1b8(%rsp),%xmm2
    0.00 :   c67d8:  movups 0x1c8(%rsp),%xmm3
    0.00 :   c67e0:  movups %xmm3,0x30(%rax)
    0.00 :   c67e4:  movups %xmm2,0x20(%rax)
    0.00 :   c67e8:  movups %xmm1,0x10(%rax)
    0.00 :   c67ec:  movups %xmm0,(%rax)
    0.00 :   c67ef:  mov    0x248(%rsp),%rsi
    0.00 :   c67f7:  mov    0x250(%rsp),%rbx
    0.00 :   c67ff:  mov    0x258(%rsp),%r14
    0.00 :   c6807:  mov    0x260(%rsp),%rbp
    0.00 :   c680f:  movups (%rcx),%xmm0
    0.00 :   c6812:  movaps %xmm0,0x2f0(%rsp)
    0.00 :   c681a:  mov    0x10(%rdi),%rcx
    0.00 :   c681e:  mov    %rcx,0x2e0(%rsp)
    0.00 :   c6826:  movups (%rdi),%xmm0
    0.00 :   c6829:  movaps %xmm0,0x2d0(%rsp)
    0.00 :   c6831:  movups 0x0(%r13),%xmm0
    0.00 :   c6836:  movups 0x10(%r13),%xmm1
    0.00 :   c683b:  movups 0x20(%r13),%xmm2
    0.00 :   c6840:  movups 0x30(%r13),%xmm3
    0.00 :   c6845:  movaps %xmm0,0x3a0(%rsp)
    0.00 :   c684d:  movaps %xmm1,0x3b0(%rsp)
    0.00 :   c6855:  movaps %xmm2,0x3c0(%rsp)
    0.00 :   c685d:  movaps %xmm3,0x3d0(%rsp)
    0.00 :   c6865:  movdqa 0x50(%rsp),%xmm0
    0.00 :   c686b:  movdqa %xmm0,0x4a0(%rsp)
    0.00 :   c6874:  cmp    $0x2,%rsi
    0.00 :   c6878:  je     c62a2 <std::sys::backtrace::__rust_begin_short_backtrace+0x132>
    0.00 :   c687e:  mov    %rax,%rdx
    0.00 :   c6881:  mov    %rdi,0x228(%rsp)
    0.00 :   c6889:  mov    %rax,0x320(%rsp)
    0.00 :   c6891:  mov    %rsi,0x400(%rsp)
    0.00 :   c6899:  mov    %rbx,0x408(%rsp)
    0.00 :   c68a1:  mov    %r14,0x410(%rsp)
    0.00 :   c68a9:  mov    %rbp,0x418(%rsp)
    0.00 :   c68b1:  movaps 0x2f0(%rsp),%xmm0
    0.00 :   c68b9:  movups %xmm0,0x420(%rsp)
    0.00 :   c68c1:  movaps 0x2d0(%rsp),%xmm0
    0.00 :   c68c9:  movups %xmm0,0x430(%rsp)
    0.00 :   c68d1:  mov    0x2e0(%rsp),%rax
    0.00 :   c68d9:  mov    %rax,0x440(%rsp)
    0.00 :   c68e1:  movdqa 0x3a0(%rsp),%xmm0
    0.00 :   c68ea:  movaps 0x3b0(%rsp),%xmm1
    0.00 :   c68f2:  movaps 0x3c0(%rsp),%xmm2
    0.00 :   c68fa:  movaps 0x3d0(%rsp),%xmm3
    0.00 :   c6902:  movdqu %xmm0,0x448(%rsp)
    0.00 :   c690b:  movups %xmm1,0x458(%rsp)
    0.00 :   c6913:  movups %xmm2,0x468(%rsp)
    0.00 :   c691b:  movups %xmm3,0x478(%rsp)
    0.00 :   c6923:  lock incq (%rdx)
    0.00 :   c6927:  jle    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c692d:  mov    %rdx,0x80(%rsp)
    0.00 :   c6935:  mov    %rdx,0x1a0(%rsp)
    0.00 :   c693d:  movabs $0x7fffffffffffffff,%r14
    0.00 :   c6947:  lea    0x23(%r14),%rbx
    0.00 :   c694b:  mov    %rbx,0x198(%rsp)
    0.00 :   c6953:  lea    0x248(%rsp),%rdi
    0.00 :   c695b:  lea    0x198(%rsp),%rcx
    0.00 :   c6963:  mov    0x238(%rsp),%rsi
    0.00 :   c696b:  mov    0x240(%rsp),%rdx
    0.00 :   c6973:  call   ce2d0 <std::sync::mpmc::Sender<T>::send>
    0.00 :   c6978:  mov    0x248(%rsp),%rax
    0.00 :   c6980:  lea    0x24(%r14),%rcx
    0.00 :   c6984:  mov    %rcx,0x3e0(%rsp)
    0.00 :   c698c:  cmp    %rcx,%rax
    0.00 :   c698f:  mov    %rax,0x3e8(%rsp)
    0.00 :   c6997:  jne    c87b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x2647>
    0.00 :   c699d:  lea    0x248(%rsp),%rdi
    0.00 :   c69a5:  lea    0x400(%rsp),%rsi
    0.00 :   c69ad:  mov    $0x88,%edx
    0.00 :   c69b2:  call   *0xca620(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   c69b8:  mov    %r15,0x330(%rsp)
    0.00 :   c69c0:  mov    0x20(%rsp),%rax
    0.00 :   c69c5:  mov    %rax,0x338(%rsp)
    0.00 :   c69cd:  movdqa 0x4a0(%rsp),%xmm0
    0.00 :   c69d6:  movdqu %xmm0,0x340(%rsp)
    0.00 :   c69df:  mov    0x80(%rsp),%rax
    0.00 :   c69e7:  mov    %rax,0x328(%rsp)
    0.00 :   c69ef:  movq   $0x0,0x100(%rsp)
    0.00 :   c69fb:  movq   $0x0,0x110(%rsp)
    0.00 :   c6a07:  lea    0x20(%rax),%rbp
    0.00 :   c6a0b:  lea    0x280(%rsp),%rcx
    0.00 :   c6a13:  mov    %rcx,0x220(%rsp)
    0.00 :   c6a1b:  lea    0x40(%rax),%rax
    0.00 :   c6a1f:  mov    %rax,0x3f8(%rsp)
    0.00 :   c6a27:  mov    $0x1,%r15d
    0.00 :   c6a2d:  mov    0xcabac(%rip),%rbx        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c6a34:  lea    0xc60c5(%rip),%rax        # 18cb00 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x4a0>
    0.00 :   c6a3b:  mov    %rax,0x310(%rsp)
    0.00 :   c6a43:  lea    -0xa9345(%rip),%rax        # 1d705 <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x39d>
    0.00 :   c6a4a:  mov    %rax,0x308(%rsp)
    0.00 :   c6a52:  mov    0x230(%rsp),%r14
    0.00 :   c6a5a:  mov    %rbp,0xe8(%rsp)
    0.00 :   c6a62:  xor    %eax,%eax
    0.00 :   c6a64:  lock cmpxchg %r15d,0x0(%rbp)
    0.00 :   c6a6a:  jne    c8765 <std::sys::backtrace::__rust_begin_short_backtrace+0x25f5>
    0.00 :   c6a70:  mov    0xca8d9(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c6a77:  mov    (%rax),%rax
    0.00 :   c6a7a:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c6a84:  test   %rcx,%rax
    0.00 :   c6a87:  jne    c8773 <std::sys::backtrace::__rust_begin_short_backtrace+0x2603>
    0.00 :   c6a8d:  xor    %eax,%eax
    0.00 :   c6a8f:  mov    0x80(%rsp),%rdx
    0.00 :   c6a97:  movzbl 0x24(%rdx),%ecx
    0.00 :   c6a9b:  mov    %rbp,0x160(%rsp)
    0.00 :   c6aa3:  mov    %al,0x168(%rsp)
    0.00 :   c6aaa:  cmpb   $0x0,0x60(%rdx)
    0.00 :   c6aae:  jne    c8d5f <std::sys::backtrace::__rust_begin_short_backtrace+0x2bef>
    0.00 :   c6ab4:  mov    0x100(%rsp),%rax
    0.00 :   c6abc:  xor    %ecx,%ecx
    0.00 :   c6abe:  mov    %rax,%rdx
    0.00 :   c6ac1:  test   %rax,%rax
    0.00 :   c6ac4:  setne  %sil
    0.00 :   c6ac8:  je     c6ad2 <std::sys::backtrace::__rust_begin_short_backtrace+0x962>
    0.00 :   c6aca:  mov    0x110(%rsp),%rdx
    0.00 :   c6ad2:  mov    0x108(%rsp),%rdi
    0.00 :   c6ada:  mov    %sil,%cl
    0.00 :   c6add:  mov    %rcx,0x350(%rsp)
    0.00 :   c6ae5:  movq   $0x0,0x358(%rsp)
    0.00 :   c6af1:  mov    %rax,0x360(%rsp)
    0.00 :   c6af9:  mov    %rdi,0x368(%rsp)
    0.00 :   c6b01:  mov    %rcx,0x370(%rsp)
    0.00 :   c6b09:  movq   $0x0,0x378(%rsp)
    0.00 :   c6b15:  mov    %rax,0x380(%rsp)
    0.00 :   c6b1d:  mov    %rdi,0x388(%rsp)
    0.00 :   c6b25:  mov    %rdx,0x390(%rsp)
    0.00 :   c6b2d:  lea    0x160(%rsp),%rax
    0.00 :   c6b35:  mov    %rax,0x398(%rsp)
    0.00 :   c6b3d:  lea    0x350(%rsp),%rdi
    0.00 :   c6b45:  call   c4d70 <<core::iter::adapters::copied::Copied<I> as core::iter::traits::iterator::Iterator>::next>
    0.00 :   c6b4a:  test   $0x1,%al
    0.00 :   c6b4c:  je     c708b <std::sys::backtrace::__rust_begin_short_backtrace+0xf1b>
    0.00 :   c6b52:  mov    %rdx,%r12
    0.00 :   c6b55:  mov    $0x20,%edi
    0.00 :   c6b5a:  call   *0xca4a8(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   c6b60:  test   %rax,%rax
    0.00 :   c6b63:  je     c9180 <std::sys::backtrace::__rust_begin_short_backtrace+0x3010>
    0.00 :   c6b69:  mov    %rax,%r15
    0.00 :   c6b6c:  mov    %r12,(%rax)
    0.00 :   c6b6f:  movq   $0x4,0x50(%rsp)
    0.00 :   c6b78:  mov    %rax,0x58(%rsp)
    0.00 :   c6b7d:  movq   $0x1,0x60(%rsp)
    0.00 :   c6b86:  movups 0x390(%rsp),%xmm0
    0.00 :   c6b8e:  movaps %xmm0,0xd0(%rsp)
    0.00 :   c6b96:  movdqu 0x350(%rsp),%xmm0
    0.00 :   c6b9f:  movups 0x360(%rsp),%xmm1
    0.00 :   c6ba7:  movups 0x370(%rsp),%xmm2
    0.00 :   c6baf:  movups 0x380(%rsp),%xmm3
    0.00 :   c6bb7:  movaps %xmm3,0xc0(%rsp)
    0.00 :   c6bbf:  movaps %xmm2,0xb0(%rsp)
    0.00 :   c6bc7:  movaps %xmm1,0xa0(%rsp)
    0.00 :   c6bcf:  movdqa %xmm0,0x90(%rsp)
    0.00 :   c6bd8:  mov    $0x1,%r12d
    0.00 :   c6bde:  mov    $0xfffffffffffffff8,%r14
    0.00 :   c6be5:  lea    0x90(%rsp),%rbp
    0.00 :   c6bed:  jmp    c6c04 <std::sys::backtrace::__rust_begin_short_backtrace+0xa94>
    0.00 :   c6bef:  mov    0x58(%rsp),%r15
    0.00 :   c6bf4:  mov    %r13,(%r15,%r12,8)
    0.00 :   c6bf8:  inc    %r12
    0.00 :   c6bfb:  mov    %r12,0x60(%rsp)
    0.00 :   c6c00:  add    $0xfffffffffffffff8,%r14
    0.00 :   c6c04:  mov    %rbp,%rdi
    0.00 :   c6c07:  call   c4d70 <<core::iter::adapters::copied::Copied<I> as core::iter::traits::iterator::Iterator>::next>
    0.00 :   c6c0c:  cmp    $0x1,%rax
    0.00 :   c6c10:  jne    c6c3b <std::sys::backtrace::__rust_begin_short_backtrace+0xacb>
    0.00 :   c6c12:  mov    %rdx,%r13
    0.00 :   c6c15:  cmp    0x50(%rsp),%r12
    0.00 :   c6c1a:  jne    c6bf4 <std::sys::backtrace::__rust_begin_short_backtrace+0xa84>
    0.00 :   c6c1c:  mov    $0x1,%edx
    0.00 :   c6c21:  mov    $0x8,%ecx
    0.00 :   c6c26:  mov    $0x8,%r8d
    0.00 :   c6c2c:  lea    0x50(%rsp),%rdi
    0.00 :   c6c31:  mov    %r12,%rsi
    0.00 :   c6c34:  call   f24c0 <alloc::raw_vec::RawVecInner<A>::reserve::do_reserve_and_handle>
    0.00 :   c6c39:  jmp    c6bef <std::sys::backtrace::__rust_begin_short_backtrace+0xa7f>
    0.00 :   c6c3b:  mov    0x50(%rsp),%rax
    0.00 :   c6c40:  mov    %rax,0x8(%rsp)
    0.00 :   c6c45:  mov    0x58(%rsp),%rax
    0.00 :   c6c4a:  mov    %rax,%rcx
    0.00 :   c6c4d:  sub    %r14,%rcx
    0.00 :   c6c50:  mov    %rcx,0x20(%rsp)
    0.00 :   c6c55:  mov    %rax,0x10(%rsp)
    0.00 :   c6c5a:  mov    %rax,%r14
    0.00 :   c6c5d:  jmp    c6c80 <std::sys::backtrace::__rust_begin_short_backtrace+0xb10>
    0.00 :   c6c5f:  movb   $0x2,0xe(%rbp)
    0.00 :   c6c63:  mov    0x280(%rsp),%eax
    0.00 :   c6c6a:  mov    %eax,0x14(%rbp)
    0.00 :   c6c6d:  mov    %r13d,0x280(%rsp)
    0.00 :   c6c75:  cmp    %r14,0x20(%rsp)
    0.00 :   c6c7a:  je     c7068 <std::sys::backtrace::__rust_begin_short_backtrace+0xef8>
    0.00 :   c6c80:  mov    0x100(%rsp),%r13
    0.00 :   c6c88:  test   %r13,%r13
    0.00 :   c6c8b:  je     c90e1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2f71>
    0.00 :   c6c91:  mov    (%r14),%rdx
    0.00 :   c6c94:  add    $0x8,%r14
    0.00 :   c6c98:  mov    0x108(%rsp),%rbp
    0.00 :   c6ca0:  lea    0x7(%rbp),%esi
    0.00 :   c6ca3:  xor    %eax,%eax
    0.00 :   c6ca5:  mov    %rbp,%rcx
    0.00 :   c6ca8:  mov    %r13,%rdi
    0.00 :   c6cab:  movzwl 0x112(%rdi),%r9d
    0.00 :   c6cb3:  mov    %r9d,%r10d
    0.00 :   c6cb6:  shl    $0x3,%r10d
    0.00 :   c6cba:  mov    $0xffffffffffffffff,%r8
    0.00 :   c6cc1:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   c6cd0:  test   %r10,%r10
    0.00 :   c6cd3:  je     c6cfd <std::sys::backtrace::__rust_begin_short_backtrace+0xb8d>
    0.00 :   c6cd5:  cmp    0xc0(%rdi,%r8,8),%rdx
    0.00 :   c6cdd:  seta   %r11b
    0.00 :   c6ce1:  sbb    $0x0,%r11b
    0.00 :   c6ce5:  inc    %r8
    0.00 :   c6ce8:  add    $0xfffffffffffffff8,%r10
    0.00 :   c6cec:  cmp    $0x1,%r11b
    0.00 :   c6cf0:  je     c6cd0 <std::sys::backtrace::__rust_begin_short_backtrace+0xb60>
    0.00 :   c6cf2:  movzbl %r11b,%r9d
    0.00 :   c6cf6:  test   %r9d,%r9d
    0.00 :   c6cf9:  jne    c6d00 <std::sys::backtrace::__rust_begin_short_backtrace+0xb90>
    0.00 :   c6cfb:  jmp    c6d1d <std::sys::backtrace::__rust_begin_short_backtrace+0xbad>
    0.00 :   c6cfd:  mov    %r9,%r8
    0.00 :   c6d00:  test   %rcx,%rcx
    0.00 :   c6d03:  je     c90e1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2f71>
    0.00 :   c6d09:  mov    0x118(%rdi,%r8,8),%rdi
    0.00 :   c6d11:  dec    %rcx
    0.00 :   c6d14:  inc    %rax
    0.00 :   c6d17:  add    $0x7,%sil
    0.00 :   c6d1b:  jmp    c6cab <std::sys::backtrace::__rust_begin_short_backtrace+0xb3b>
    0.00 :   c6d1d:  movb   $0x0,0x120(%rsp)
    0.00 :   c6d25:  test   %rcx,%rcx
    0.00 :   c6d28:  je     c6eb4 <std::sys::backtrace::__rust_begin_short_backtrace+0xd44>
    0.00 :   c6d2e:  mov    0x118(%rdi,%r8,8),%rdx
    0.00 :   c6d36:  mov    %rcx,%rdi
    0.00 :   c6d39:  dec    %rdi
    0.00 :   c6d3c:  je     c6e14 <std::sys::backtrace::__rust_begin_short_backtrace+0xca4>
    0.00 :   c6d42:  test   $0x7,%dil
    0.00 :   c6d46:  je     c6d86 <std::sys::backtrace::__rust_begin_short_backtrace+0xc16>
    0.00 :   c6d48:  movzbl %sil,%esi
    0.00 :   c6d4c:  and    $0x7,%esi
    0.00 :   c6d4f:  neg    %rsi
    0.00 :   c6d52:  mov    $0x1,%edi
    0.00 :   c6d57:  nopw   0x0(%rax,%rax,1)
    0.00 :   c6d60:  movzwl 0x112(%rdx),%r8d
    0.00 :   c6d68:  mov    0x118(%rdx,%r8,8),%rdx
    0.00 :   c6d70:  lea    (%rsi,%rdi,1),%r8
    0.00 :   c6d74:  inc    %r8
    0.00 :   c6d77:  inc    %rdi
    0.00 :   c6d7a:  cmp    $0x1,%r8
    0.00 :   c6d7e:  jne    c6d60 <std::sys::backtrace::__rust_begin_short_backtrace+0xbf0>
    0.00 :   c6d80:  sub    %rdi,%rcx
    0.00 :   c6d83:  mov    %rcx,%rdi
    0.00 :   c6d86:  mov    %rbp,%rcx
    0.00 :   c6d89:  sub    %rax,%rcx
    0.00 :   c6d8c:  add    $0xfffffffffffffffe,%rcx
    0.00 :   c6d90:  cmp    $0x7,%rcx
    0.00 :   c6d94:  jb     c6e14 <std::sys::backtrace::__rust_begin_short_backtrace+0xca4>
    0.00 :   c6d96:  movzwl 0x112(%rdx),%eax
    0.00 :   c6d9d:  mov    0x118(%rdx,%rax,8),%rax
    0.00 :   c6da5:  movzwl 0x112(%rax),%ecx
    0.00 :   c6dac:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c6db4:  movzwl 0x112(%rax),%ecx
    0.00 :   c6dbb:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c6dc3:  movzwl 0x112(%rax),%ecx
    0.00 :   c6dca:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c6dd2:  movzwl 0x112(%rax),%ecx
    0.00 :   c6dd9:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c6de1:  movzwl 0x112(%rax),%ecx
    0.00 :   c6de8:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c6df0:  movzwl 0x112(%rax),%ecx
    0.00 :   c6df7:  mov    0x118(%rax,%rcx,8),%rax
    0.00 :   c6dff:  movzwl 0x112(%rax),%ecx
    0.00 :   c6e06:  mov    0x118(%rax,%rcx,8),%rdx
    0.00 :   c6e0e:  add    $0xfffffffffffffff8,%rdi
    0.00 :   c6e12:  jne    c6d96 <std::sys::backtrace::__rust_begin_short_backtrace+0xc26>
    0.00 :   c6e14:  movzwl 0x112(%rdx),%eax
    0.00 :   c6e1b:  dec    %rax
    0.00 :   c6e1e:  mov    %rdx,0x50(%rsp)
    0.00 :   c6e23:  movq   $0x0,0x58(%rsp)
    0.00 :   c6e2c:  mov    %rax,0x60(%rsp)
    0.00 :   c6e31:  lea    0x90(%rsp),%rdi
    0.00 :   c6e39:  lea    0x50(%rsp),%rsi
    0.00 :   c6e3e:  lea    0x120(%rsp),%rdx
    0.00 :   c6e46:  call   efb00 <alloc::collections::btree::remove::<impl alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut,K,V,alloc::collections::btree::node::marker::Leaf>,alloc::collections::btree::node::marker::KV>>::remove_leaf_kv>
    0.00 :   c6e4b:  mov    0xa8(%rsp),%rax
    0.00 :   c6e53:  mov    0xb8(%rsp),%rcx
    0.00 :   c6e5b:  movzwl 0x112(%rax),%edx
    0.00 :   c6e62:  cmp    %rdx,%rcx
    0.00 :   c6e65:  jb     c6e87 <std::sys::backtrace::__rust_begin_short_backtrace+0xd17>
    0.00 :   c6e67:  nopw   0x0(%rax,%rax,1)
    0.00 :   c6e70:  movzwl 0x110(%rax),%ecx
    0.00 :   c6e77:  mov    0xb0(%rax),%rax
    0.00 :   c6e7e:  cmp    0x112(%rax),%cx
    0.00 :   c6e85:  jae    c6e70 <std::sys::backtrace::__rust_begin_short_backtrace+0xd00>
    0.00 :   c6e87:  mov    0x90(%rsp),%rdx
    0.00 :   c6e8f:  movdqu 0x98(%rsp),%xmm0
    0.00 :   c6e98:  mov    %rdx,0xb8(%rax,%rcx,8)
    0.00 :   c6ea0:  shl    $0x4,%rcx
    0.00 :   c6ea4:  mov    (%rax,%rcx,1),%r12
    0.00 :   c6ea8:  mov    0x8(%rax,%rcx,1),%r15
    0.00 :   c6ead:  movdqu %xmm0,(%rax,%rcx,1)
    0.00 :   c6eb2:  jmp    c6ef1 <std::sys::backtrace::__rust_begin_short_backtrace+0xd81>
    0.00 :   c6eb4:  mov    %rdi,0x50(%rsp)
    0.00 :   c6eb9:  movq   $0x0,0x58(%rsp)
    0.00 :   c6ec2:  mov    %r8,0x60(%rsp)
    0.00 :   c6ec7:  lea    0x90(%rsp),%rdi
    0.00 :   c6ecf:  lea    0x50(%rsp),%rsi
    0.00 :   c6ed4:  lea    0x120(%rsp),%rdx
    0.00 :   c6edc:  call   efb00 <alloc::collections::btree::remove::<impl alloc::collections::btree::node::Handle<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut,K,V,alloc::collections::btree::node::marker::Leaf>,alloc::collections::btree::node::marker::KV>>::remove_leaf_kv>
    0.00 :   c6ee1:  mov    0x98(%rsp),%r12
    0.00 :   c6ee9:  mov    0xa0(%rsp),%r15
    0.00 :   c6ef1:  decq   0x110(%rsp)
    0.00 :   c6ef9:  cmpb   $0x1,0x120(%rsp)
    0.00 :   c6f01:  jne    c6f3a <std::sys::backtrace::__rust_begin_short_backtrace+0xdca>
    0.00 :   c6f03:  test   %rbp,%rbp
    0.00 :   c6f06:  je     c8f37 <std::sys::backtrace::__rust_begin_short_backtrace+0x2dc7>
    0.00 :   c6f0c:  mov    0x118(%r13),%rax
    0.00 :   c6f13:  mov    %rax,0x100(%rsp)
    0.00 :   c6f1b:  dec    %rbp
    0.00 :   c6f1e:  mov    %rbp,0x108(%rsp)
    0.00 :   c6f26:  movq   $0x0,0xb0(%rax)
    0.00 :   c6f31:  mov    %r13,%rdi
    0.00 :   c6f34:  call   *0xca0b6(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c6f3a:  mov    0x298(%rsp),%rax
    0.00 :   c6f42:  mov    $0x3,%r13b
    0.00 :   c6f45:  test   %rax,%rax
    0.00 :   c6f48:  je     c88a5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2735>
    0.00 :   c6f4e:  cmp    %r12,%rax
    0.00 :   c6f51:  jne    c88a5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2735>
    0.00 :   c6f57:  lea    -0x1(%r15),%r13d
    0.00 :   c6f5b:  cmp    %r13,0x268(%rsp)
    0.00 :   c6f63:  jbe    c87da <std::sys::backtrace::__rust_begin_short_backtrace+0x266a>
    0.00 :   c6f69:  mov    %r15,%r8
    0.00 :   c6f6c:  shr    $0x20,%r8
    0.00 :   c6f70:  mov    0x260(%rsp),%rax
    0.00 :   c6f78:  lea    0x0(,%r13,2),%rcx
    0.00 :   c6f80:  add    %r13,%rcx
    0.00 :   c6f83:  cmp    %r8d,0x10(%rax,%rcx,8)
    0.00 :   c6f88:  jne    c87da <std::sys::backtrace::__rust_begin_short_backtrace+0x266a>
    0.00 :   c6f8e:  lea    (%rax,%rcx,8),%rbp
    0.00 :   c6f92:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c6f96:  je     c87da <std::sys::backtrace::__rust_begin_short_backtrace+0x266a>
    0.00 :   c6f9c:  mov    0x8(%rbp),%edx
    0.00 :   c6f9f:  and    $0x7fffffff,%edx
    0.00 :   c6fa5:  mov    0x2c8(%rsp),%edi
    0.00 :   c6fac:  mov    $0xe9,%eax
    0.00 :   c6fb1:  mov    $0x2,%esi
    0.00 :   c6fb6:  xor    %r10d,%r10d
    0.00 :   c6fb9:  syscall
    0.00 :   c6fbb:  test   %rax,%rax
    0.00 :   c6fbe:  jne    c6fe7 <std::sys::backtrace::__rust_begin_short_backtrace+0xe77>
    0.00 :   c6fc0:  cmp    $0xffffffff,%r8d
    0.00 :   c6fc4:  je     c7021 <std::sys::backtrace::__rust_begin_short_backtrace+0xeb1>
    0.00 :   c6fc6:  mov    0x8(%rbp),%edi
    0.00 :   c6fc9:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c6fcd:  setne  %al
    0.00 :   c6fd0:  test   %edi,%edi
    0.00 :   c6fd2:  setns  %cl
    0.00 :   c6fd5:  and    %al,%cl
    0.00 :   c6fd7:  cmp    $0x1,%cl
    0.00 :   c6fda:  jne    c6c5f <std::sys::backtrace::__rust_begin_short_backtrace+0xaef>
    0.00 :   c6fe0:  call   *%rbx
    0.00 :   c6fe2:  jmp    c6c5f <std::sys::backtrace::__rust_begin_short_backtrace+0xaef>
    0.00 :   c6fe7:  movswq %ax,%rdi
    0.00 :   c6feb:  movabs $0xffffffff00000000,%rax
    0.00 :   c6ff5:  imul   %rax,%rdi
    0.00 :   c6ff9:  or     $0x2,%rdi
    0.00 :   c6ffd:  call   *0xcaf55(%rip)        # 191f58 <_DYNAMIC+0x1198>
    0.00 :   c7003:  mov    %rax,0x38(%rsp)
    0.00 :   c7008:  mov    %edx,0x30(%rsp)
    0.00 :   c700c:  cmpb   $0x3,0x30(%rsp)
    0.00 :   c7011:  jne    c905b <std::sys::backtrace::__rust_begin_short_backtrace+0x2eeb>
    0.00 :   c7017:  mov    0x10(%rbp),%r8d
    0.00 :   c701b:  cmp    $0xffffffff,%r8d
    0.00 :   c701f:  jne    c6fc6 <std::sys::backtrace::__rust_begin_short_backtrace+0xe56>
    0.00 :   c7021:  mov    0x278(%rsp),%r13
    0.00 :   c7029:  inc    %r13
    0.00 :   c702c:  je     c8f55 <std::sys::backtrace::__rust_begin_short_backtrace+0x2de5>
    0.00 :   c7032:  mov    0x8(%rbp),%edi
    0.00 :   c7035:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c7039:  setne  %al
    0.00 :   c703c:  test   %edi,%edi
    0.00 :   c703e:  setns  %cl
    0.00 :   c7041:  and    %al,%cl
    0.00 :   c7043:  cmp    $0x1,%cl
    0.00 :   c7046:  jne    c704a <std::sys::backtrace::__rust_begin_short_backtrace+0xeda>
    0.00 :   c7048:  call   *%rbx
    0.00 :   c704a:  movb   $0x2,0xe(%rbp)
    0.00 :   c704e:  movl   $0xffffffff,0x14(%rbp)
    0.00 :   c7055:  mov    %r13,0x278(%rsp)
    0.00 :   c705d:  cmp    %r14,0x20(%rsp)
    0.00 :   c7062:  jne    c6c80 <std::sys::backtrace::__rust_begin_short_backtrace+0xb10>
    0.00 :   c7068:  cmpq   $0x0,0x8(%rsp)
    0.00 :   c706e:  mov    0x230(%rsp),%r14
    0.00 :   c7076:  mov    0xe8(%rsp),%rbp
    0.00 :   c707e:  je     c708b <std::sys::backtrace::__rust_begin_short_backtrace+0xf1b>
    0.00 :   c7080:  mov    0x10(%rsp),%rdi
    0.00 :   c7085:  call   *0xc9f65(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c708b:  mov    0x160(%rsp),%r15
    0.00 :   c7093:  mov    0x20(%r15),%rdx
    0.00 :   c7097:  test   %rdx,%rdx
    0.00 :   c709a:  je     c846e <std::sys::backtrace::__rust_begin_short_backtrace+0x22fe>
    0.00 :   c70a0:  mov    0x30(%r15),%r12
    0.00 :   c70a4:  test   %r12,%r12
    0.00 :   c70a7:  je     c846e <std::sys::backtrace::__rust_begin_short_backtrace+0x22fe>
    0.00 :   c70ad:  mov    0x28(%r15),%r15
    0.00 :   c70b1:  xor    %r14d,%r14d
    0.00 :   c70b4:  jmp    c70e4 <std::sys::backtrace::__rust_begin_short_backtrace+0xf74>
    0.00 :   c70b6:  lea    0x100(%rsp),%rax
    0.00 :   c70be:  mov    %rax,0xf8(%rsp)
    0.00 :   c70c6:  mov    %rsi,0x318(%rsp)
    0.00 :   c70ce:  mov    0xe8(%rsp),%rbp
    0.00 :   c70d6:  mov    $0x0,%edx
    0.00 :   c70db:  dec    %r12
    0.00 :   c70de:  je     c845e <std::sys::backtrace::__rust_begin_short_backtrace+0x22ee>
    0.00 :   c70e4:  test   %r14,%r14
    0.00 :   c70e7:  jne    c7164 <std::sys::backtrace::__rust_begin_short_backtrace+0xff4>
    0.00 :   c70e9:  test   %r15,%r15
    0.00 :   c70ec:  je     c7113 <std::sys::backtrace::__rust_begin_short_backtrace+0xfa3>
    0.00 :   c70ee:  mov    %r15,%rax
    0.00 :   c70f1:  mov    %rdx,%r14
    0.00 :   c70f4:  and    $0x7,%rax
    0.00 :   c70f8:  je     c7118 <std::sys::backtrace::__rust_begin_short_backtrace+0xfa8>
    0.00 :   c70fa:  xor    %ecx,%ecx
    0.00 :   c70fc:  mov    0x220(%r14),%r14
    0.00 :   c7103:  inc    %rcx
    0.00 :   c7106:  cmp    %rcx,%rax
    0.00 :   c7109:  jne    c70fc <std::sys::backtrace::__rust_begin_short_backtrace+0xf8c>
    0.00 :   c710b:  mov    %r15,%rax
    0.00 :   c710e:  sub    %rcx,%rax
    0.00 :   c7111:  jmp    c711b <std::sys::backtrace::__rust_begin_short_backtrace+0xfab>
    0.00 :   c7113:  mov    %rdx,%r14
    0.00 :   c7116:  jmp    c715f <std::sys::backtrace::__rust_begin_short_backtrace+0xfef>
    0.00 :   c7118:  mov    %r15,%rax
    0.00 :   c711b:  cmp    $0x8,%r15
    0.00 :   c711f:  jb     c715f <std::sys::backtrace::__rust_begin_short_backtrace+0xfef>
    0.00 :   c7121:  mov    0x220(%r14),%rcx
    0.00 :   c7128:  mov    0x220(%rcx),%rcx
    0.00 :   c712f:  mov    0x220(%rcx),%rcx
    0.00 :   c7136:  mov    0x220(%rcx),%rcx
    0.00 :   c713d:  mov    0x220(%rcx),%rcx
    0.00 :   c7144:  mov    0x220(%rcx),%rcx
    0.00 :   c714b:  mov    0x220(%rcx),%rcx
    0.00 :   c7152:  mov    0x220(%rcx),%r14
    0.00 :   c7159:  add    $0xfffffffffffffff8,%rax
    0.00 :   c715d:  jne    c7121 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb1>
    0.00 :   c715f:  xor    %edx,%edx
    0.00 :   c7161:  xor    %r15d,%r15d
    0.00 :   c7164:  movzwl 0x21a(%r14),%eax
    0.00 :   c716c:  cmp    %rax,%r15
    0.00 :   c716f:  jae    c7180 <std::sys::backtrace::__rust_begin_short_backtrace+0x1010>
    0.00 :   c7171:  mov    %r14,%rax
    0.00 :   c7174:  mov    %r15,%rcx
    0.00 :   c7177:  jmp    c71a3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1033>
    0.00 :   c7179:  nopl   0x0(%rax)
    0.00 :   c7180:  mov    (%r14),%rax
    0.00 :   c7183:  test   %rax,%rax
    0.00 :   c7186:  je     c9049 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ed9>
    0.00 :   c718c:  inc    %rdx
    0.00 :   c718f:  movzwl 0x218(%r14),%ecx
    0.00 :   c7197:  mov    %rax,%r14
    0.00 :   c719a:  cmp    0x21a(%rax),%cx
    0.00 :   c71a1:  jae    c7180 <std::sys::backtrace::__rust_begin_short_backtrace+0x1010>
    0.00 :   c71a3:  test   %rdx,%rdx
    0.00 :   c71a6:  je     c71da <std::sys::backtrace::__rust_begin_short_backtrace+0x106a>
    0.00 :   c71a8:  lea    (%rax,%rcx,8),%rsi
    0.00 :   c71ac:  add    $0x228,%rsi
    0.00 :   c71b3:  mov    %rdx,%rdi
    0.00 :   c71b6:  and    $0x7,%rdi
    0.00 :   c71ba:  je     c71e3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1073>
    0.00 :   c71bc:  xor    %r8d,%r8d
    0.00 :   c71bf:  nop
    0.00 :   c71c0:  mov    (%rsi),%r14
    0.00 :   c71c3:  lea    0x220(%r14),%rsi
    0.00 :   c71ca:  inc    %r8
    0.00 :   c71cd:  cmp    %r8,%rdi
    0.00 :   c71d0:  jne    c71c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1050>
    0.00 :   c71d2:  mov    %rdx,%rdi
    0.00 :   c71d5:  sub    %r8,%rdi
    0.00 :   c71d8:  jmp    c71e6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1076>
    0.00 :   c71da:  lea    0x1(%rcx),%r15
    0.00 :   c71de:  mov    %rax,%r14
    0.00 :   c71e1:  jmp    c7234 <std::sys::backtrace::__rust_begin_short_backtrace+0x10c4>
    0.00 :   c71e3:  mov    %rdx,%rdi
    0.00 :   c71e6:  cmp    $0x8,%rdx
    0.00 :   c71ea:  jb     c7231 <std::sys::backtrace::__rust_begin_short_backtrace+0x10c1>
    0.00 :   c71ec:  nopl   0x0(%rax)
    0.00 :   c71f0:  mov    (%rsi),%rdx
    0.00 :   c71f3:  mov    0x220(%rdx),%rdx
    0.00 :   c71fa:  mov    0x220(%rdx),%rdx
    0.00 :   c7201:  mov    0x220(%rdx),%rdx
    0.00 :   c7208:  mov    0x220(%rdx),%rdx
    0.00 :   c720f:  mov    0x220(%rdx),%rdx
    0.00 :   c7216:  mov    0x220(%rdx),%rdx
    0.00 :   c721d:  mov    0x220(%rdx),%r14
    0.00 :   c7224:  lea    0x220(%r14),%rsi
    0.00 :   c722b:  add    $0xfffffffffffffff8,%rdi
    0.00 :   c722f:  jne    c71f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1080>
    0.00 :   c7231:  xor    %r15d,%r15d
    0.00 :   c7234:  mov    0x8(%rax,%rcx,8),%rbp
    0.00 :   c7239:  mov    0x100(%rsp),%rdx
    0.00 :   c7241:  test   %rdx,%rdx
    0.00 :   c7244:  je     c72b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1147>
    0.00 :   c7246:  mov    %rdx,%rdi
    0.00 :   c7249:  mov    0x108(%rsp),%rdx
    0.00 :   c7251:  mov    %rdi,%r13
    0.00 :   c7254:  movzwl 0x112(%rdi),%edi
    0.00 :   c725b:  mov    %edi,%r8d
    0.00 :   c725e:  shl    $0x3,%r8d
    0.00 :   c7262:  mov    $0xffffffffffffffff,%rsi
    0.00 :   c7269:  nopl   0x0(%rax)
    0.00 :   c7270:  test   %r8,%r8
    0.00 :   c7273:  je     c72a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1130>
    0.00 :   c7275:  cmp    0xc0(%r13,%rsi,8),%rbp
    0.00 :   c727d:  seta   %r9b
    0.00 :   c7281:  sbb    $0x0,%r9b
    0.00 :   c7285:  inc    %rsi
    0.00 :   c7288:  add    $0xfffffffffffffff8,%r8
    0.00 :   c728c:  cmp    $0x1,%r9b
    0.00 :   c7290:  je     c7270 <std::sys::backtrace::__rust_begin_short_backtrace+0x1100>
    0.00 :   c7292:  movzbl %r9b,%edi
    0.00 :   c7296:  test   %edi,%edi
    0.00 :   c7298:  je     c70b6 <std::sys::backtrace::__rust_begin_short_backtrace+0xf46>
    0.00 :   c729e:  jmp    c72a3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1133>
    0.00 :   c72a0:  mov    %rdi,%rsi
    0.00 :   c72a3:  sub    $0x1,%rdx
    0.00 :   c72a7:  jb     c749f <std::sys::backtrace::__rust_begin_short_backtrace+0x132f>
    0.00 :   c72ad:  mov    0x118(%r13,%rsi,8),%rdi
    0.00 :   c72b5:  jmp    c7251 <std::sys::backtrace::__rust_begin_short_backtrace+0x10e1>
    0.00 :   c72b7:  xor    %r13d,%r13d
    0.00 :   c72ba:  lea    (%rcx,%rcx,4),%rcx
    0.00 :   c72be:  lea    (%rax,%rcx,8),%rax
    0.00 :   c72c2:  add    $0x60,%rax
    0.00 :   c72c6:  movzbl 0x20(%rax),%ecx
    0.00 :   c72ca:  mov    %rcx,0x20(%rsp)
    0.00 :   c72cf:  test   %ecx,%ecx
    0.00 :   c72d1:  je     c8ace <std::sys::backtrace::__rust_begin_short_backtrace+0x295e>
    0.00 :   c72d7:  mov    (%rax),%rax
    0.00 :   c72da:  mov    0x10(%rax),%eax
    0.00 :   c72dd:  mov    %eax,0x90(%rsp)
    0.00 :   c72e4:  lea    0x198(%rsp),%rdi
    0.00 :   c72ec:  lea    0x90(%rsp),%rsi
    0.00 :   c72f4:  call   *0xca8b6(%rip)        # 191bb0 <_DYNAMIC+0xdf0>
    0.00 :   c72fa:  cmpl   $0x1,0x198(%rsp)
    0.00 :   c7302:  je     c8ade <std::sys::backtrace::__rust_begin_short_backtrace+0x296e>
    0.00 :   c7308:  mov    %r15,0x3f0(%rsp)
    0.00 :   c7310:  mov    %r12,0x148(%rsp)
    0.00 :   c7318:  mov    0x19c(%rsp),%r15d
    0.00 :   c7320:  mov    0x280(%rsp),%r12d
    0.00 :   c7328:  mov    0x2c8(%rsp),%eax
    0.00 :   c732f:  mov    %rax,0x8(%rsp)
    0.00 :   c7334:  mov    $0xffffffff,%eax
    0.00 :   c7339:  cmp    %rax,%r12
    0.00 :   c733c:  je     c7459 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e9>
    0.00 :   c7342:  cmp    %r12,0x268(%rsp)
    0.00 :   c734a:  jbe    c7435 <std::sys::backtrace::__rust_begin_short_backtrace+0x12c5>
    0.00 :   c7350:  mov    0x260(%rsp),%rax
    0.00 :   c7358:  lea    (%r12,%r12,2),%rcx
    0.00 :   c735c:  cmpb   $0x2,0xe(%rax,%rcx,8)
    0.00 :   c7361:  jne    c7435 <std::sys::backtrace::__rust_begin_short_backtrace+0x12c5>
    0.00 :   c7367:  lea    (%rax,%rcx,8),%r8
    0.00 :   c736b:  mov    0x10(%r8),%ecx
    0.00 :   c736f:  mov    $0xffffffff,%eax
    0.00 :   c7374:  cmp    %rax,%rcx
    0.00 :   c7377:  je     c7435 <std::sys::backtrace::__rust_begin_short_backtrace+0x12c5>
    0.00 :   c737d:  mov    %rcx,0x10(%rsp)
    0.00 :   c7382:  mov    0x14(%r8),%eax
    0.00 :   c7386:  mov    %eax,0x30(%rsp)
    0.00 :   c738a:  mov    0x298(%rsp),%r9
    0.00 :   c7392:  test   %r9,%r9
    0.00 :   c7395:  je     c818e <std::sys::backtrace::__rust_begin_short_backtrace+0x201e>
    0.00 :   c739b:  mov    %rbp,(%r8)
    0.00 :   c739e:  mov    %r15d,0x8(%r8)
    0.00 :   c73a2:  mov    0x20(%rsp),%rcx
    0.00 :   c73a7:  mov    %cl,0xc(%r8)
    0.00 :   c73ab:  movw   $0x0,0xd(%r8)
    0.00 :   c73b2:  mov    %r8,%rsi
    0.00 :   c73b5:  mov    0x10(%rsp),%rdx
    0.00 :   c73ba:  inc    %rdx
    0.00 :   c73bd:  mov    %rdx,%rax
    0.00 :   c73c0:  shl    $0x20,%rax
    0.00 :   c73c4:  lea    (%r12,%rax,1),%r15
    0.00 :   c73c8:  inc    %r15
    0.00 :   c73cb:  mov    0x30(%rsp),%eax
    0.00 :   c73cf:  mov    %eax,0x280(%rsp)
    0.00 :   c73d6:  mov    %edx,0x10(%r8)
    0.00 :   c73da:  mov    0x8(%rsi),%edx
    0.00 :   c73dd:  and    $0x7fffffff,%edx
    0.00 :   c73e3:  mov    %ecx,%eax
    0.00 :   c73e5:  and    $0x1,%al
    0.00 :   c73e7:  movzbl %al,%eax
    0.00 :   c73ea:  and    $0x2,%ecx
    0.00 :   c73ed:  lea    (%rax,%rcx,2),%eax
    0.00 :   c73f0:  add    $0x2000,%eax
    0.00 :   c73f5:  mov    %eax,0x198(%rsp)
    0.00 :   c73fc:  mov    %r15,0x19c(%rsp)
    0.00 :   c7404:  mov    $0xe9,%eax
    0.00 :   c7409:  mov    $0x1,%esi
    0.00 :   c740e:  mov    0x8(%rsp),%rdi
    0.00 :   c7413:  lea    0x198(%rsp),%r10
    0.00 :   c741b:  syscall
    0.00 :   c741d:  test   %rax,%rax
    0.00 :   c7420:  jne    c824e <std::sys::backtrace::__rust_begin_short_backtrace+0x20de>
    0.00 :   c7426:  mov    %r9,0x58(%rsp)
    0.00 :   c742b:  mov    %r15,0x60(%rsp)
    0.00 :   c7430:  jmp    c75f1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1481>
    0.00 :   c7435:  movq   $0xb,0x90(%rsp)
    0.00 :   c7441:  lea    0x90(%rsp),%rsi
    0.00 :   c7449:  lea    0x50(%rsp),%rdi
    0.00 :   c744e:  call   *0xcab0c(%rip)        # 191f60 <_DYNAMIC+0x11a0>
    0.00 :   c7454:  jmp    c762b <std::sys::backtrace::__rust_begin_short_backtrace+0x14bb>
    0.00 :   c7459:  mov    0x268(%rsp),%r12
    0.00 :   c7461:  mov    0x270(%rsp),%rax
    0.00 :   c7469:  cmp    %rax,%r12
    0.00 :   c746c:  jae    c7484 <std::sys::backtrace::__rust_begin_short_backtrace+0x1314>
    0.00 :   c746e:  mov    %r12,%rax
    0.00 :   c7471:  shr    $0x20,%rax
    0.00 :   c7475:  je     c74b8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1348>
    0.00 :   c7477:  movb   $0xa,0x98(%rsp)
    0.00 :   c747f:  jmp    c760c <std::sys::backtrace::__rust_begin_short_backtrace+0x149c>
    0.00 :   c7484:  cmp    %rax,0x278(%rsp)
    0.00 :   c748c:  jne    c75fc <std::sys::backtrace::__rust_begin_short_backtrace+0x148c>
    0.00 :   c7492:  movb   $0x8,0x98(%rsp)
    0.00 :   c749a:  jmp    c760c <std::sys::backtrace::__rust_begin_short_backtrace+0x149c>
    0.00 :   c749f:  movq   $0x0,0x318(%rsp)
    0.00 :   c74ab:  mov    %rsi,0xf8(%rsp)
    0.00 :   c74b3:  jmp    c72ba <std::sys::backtrace::__rust_begin_short_backtrace+0x114a>
    0.00 :   c74b8:  mov    $0xffffffff,%eax
    0.00 :   c74bd:  cmp    %rax,%r12
    0.00 :   c74c0:  je     c7492 <std::sys::backtrace::__rust_begin_short_backtrace+0x1322>
    0.00 :   c74c2:  mov    0x298(%rsp),%rdx
    0.00 :   c74ca:  mov    %r12,0x10(%rsp)
    0.00 :   c74cf:  mov    %rdx,0x30(%rsp)
    0.00 :   c74d4:  test   %rdx,%rdx
    0.00 :   c74d7:  je     c82a2 <std::sys::backtrace::__rust_begin_short_backtrace+0x2132>
    0.00 :   c74dd:  cmp    0x258(%rsp),%r12
    0.00 :   c74e5:  jne    c74f5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1385>
    0.00 :   c74e7:  lea    0x258(%rsp),%rdi
    0.00 :   c74ef:  call   *0xcaa03(%rip)        # 191ef8 <_DYNAMIC+0x1138>
    0.00 :   c74f5:  mov    0x260(%rsp),%rax
    0.00 :   c74fd:  lea    (%r12,%r12,2),%rcx
    0.00 :   c7501:  movb   $0x2,0xe(%rax,%rcx,8)
    0.00 :   c7506:  movabs $0xffffffff00000001,%rdx
    0.00 :   c7510:  mov    %rdx,0x10(%rax,%rcx,8)
    0.00 :   c7515:  inc    %r12
    0.00 :   c7518:  mov    %r12,0x268(%rsp)
    0.00 :   c7520:  mov    0x10(%rsp),%rax
    0.00 :   c7525:  cmp    %r12,%rax
    0.00 :   c7528:  jae    c8030 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ec0>
    0.00 :   c752e:  mov    0x260(%rsp),%r12
    0.00 :   c7536:  lea    (%rax,%rax,2),%rdx
    0.00 :   c753a:  mov    0x8(%r12,%rdx,8),%edi
    0.00 :   c753f:  cmpb   $0x2,0xe(%r12,%rdx,8)
    0.00 :   c7545:  setne  %al
    0.00 :   c7548:  test   %edi,%edi
    0.00 :   c754a:  setns  %cl
    0.00 :   c754d:  and    %al,%cl
    0.00 :   c754f:  cmp    $0x1,%cl
    0.00 :   c7552:  jne    c7560 <std::sys::backtrace::__rust_begin_short_backtrace+0x13f0>
    0.00 :   c7554:  mov    %rdx,0x38(%rsp)
    0.00 :   c7559:  call   *%rbx
    0.00 :   c755b:  mov    0x38(%rsp),%rdx
    0.00 :   c7560:  mov    0x10(%rsp),%rax
    0.00 :   c7565:  lea    0x1(%rax),%r8
    0.00 :   c7569:  movabs $0x100000000,%rax
    0.00 :   c7573:  or     %rax,%r8
    0.00 :   c7576:  lea    (%r12,%rdx,8),%r12
    0.00 :   c757a:  mov    %rbp,(%r12)
    0.00 :   c757e:  mov    %r15d,0x8(%r12)
    0.00 :   c7583:  mov    0x20(%rsp),%rcx
    0.00 :   c7588:  mov    %cl,0xc(%r12)
    0.00 :   c758d:  movw   $0x0,0xd(%r12)
    0.00 :   c7595:  and    $0x7fffffff,%r15d
    0.00 :   c759c:  mov    %ecx,%eax
    0.00 :   c759e:  and    $0x1,%al
    0.00 :   c75a0:  movzbl %al,%eax
    0.00 :   c75a3:  and    $0x2,%ecx
    0.00 :   c75a6:  lea    (%rax,%rcx,2),%eax
    0.00 :   c75a9:  add    $0x2000,%eax
    0.00 :   c75ae:  mov    %eax,0x198(%rsp)
    0.00 :   c75b5:  mov    %r8,0x19c(%rsp)
    0.00 :   c75bd:  mov    $0xe9,%eax
    0.00 :   c75c2:  mov    $0x1,%esi
    0.00 :   c75c7:  mov    0x8(%rsp),%rdi
    0.00 :   c75cc:  mov    %r15,%rdx
    0.00 :   c75cf:  lea    0x198(%rsp),%r10
    0.00 :   c75d7:  syscall
    0.00 :   c75d9:  test   %rax,%rax
    0.00 :   c75dc:  jne    c83a5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2235>
    0.00 :   c75e2:  mov    0x30(%rsp),%rax
    0.00 :   c75e7:  mov    %rax,0x58(%rsp)
    0.00 :   c75ec:  mov    %r8,0x60(%rsp)
    0.00 :   c75f1:  movq   $0x2,0x50(%rsp)
    0.00 :   c75fa:  jmp    c7635 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c75fc:  movb   $0x7,0x98(%rsp)
    0.00 :   c7604:  mov    %rax,0xa0(%rsp)
    0.00 :   c760c:  movq   $0x0,0x90(%rsp)
    0.00 :   c7618:  lea    0x50(%rsp),%rdi
    0.00 :   c761d:  lea    0x98(%rsp),%rsi
    0.00 :   c7625:  call   *0xca935(%rip)        # 191f60 <_DYNAMIC+0x11a0>
    0.00 :   c762b:  test   %r15d,%r15d
    0.00 :   c762e:  js     c7635 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c7630:  mov    %r15d,%edi
    0.00 :   c7633:  call   *%rbx
    0.00 :   c7635:  cmpq   $0x2,0x50(%rsp)
    0.00 :   c763b:  jne    c8afb <std::sys::backtrace::__rust_begin_short_backtrace+0x298b>
    0.00 :   c7641:  mov    0x58(%rsp),%rdx
    0.00 :   c7646:  mov    0x60(%rsp),%rcx
    0.00 :   c764b:  test   %r13,%r13
    0.00 :   c764e:  je     c7690 <std::sys::backtrace::__rust_begin_short_backtrace+0x1520>
    0.00 :   c7650:  mov    %r13,%r15
    0.00 :   c7653:  movzwl 0x112(%r13),%r12d
    0.00 :   c765b:  cmp    $0xb,%r12
    0.00 :   c765f:  jae    c76eb <std::sys::backtrace::__rust_begin_short_backtrace+0x157b>
    0.00 :   c7665:  mov    0xf8(%rsp),%r8
    0.00 :   c766d:  lea    0x1(%r8),%r13
    0.00 :   c7671:  lea    (%r15,%r8,8),%rsi
    0.00 :   c7675:  add    $0xb8,%rsi
    0.00 :   c767c:  cmp    %r12,%r13
    0.00 :   c767f:  jbe    c7726 <std::sys::backtrace::__rust_begin_short_backtrace+0x15b6>
    0.00 :   c7685:  mov    %rbp,(%rsi)
    0.00 :   c7688:  mov    %r8,%rax
    0.00 :   c768b:  jmp    c77a5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1635>
    0.00 :   c7690:  mov    %rdx,%r13
    0.00 :   c7693:  mov    %rcx,%r12
    0.00 :   c7696:  mov    $0x118,%r15d
    0.00 :   c769c:  mov    $0x118,%edi
    0.00 :   c76a1:  call   *0xc9961(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   c76a7:  test   %rax,%rax
    0.00 :   c76aa:  je     c8eab <std::sys::backtrace::__rust_begin_short_backtrace+0x2d3b>
    0.00 :   c76b0:  movq   $0x0,0xb0(%rax)
    0.00 :   c76bb:  mov    %rax,0x100(%rsp)
    0.00 :   c76c3:  movq   $0x0,0x108(%rsp)
    0.00 :   c76cf:  movw   $0x1,0x112(%rax)
    0.00 :   c76d8:  mov    %rbp,0xb8(%rax)
    0.00 :   c76df:  mov    %r13,(%rax)
    0.00 :   c76e2:  mov    %r12,0x8(%rax)
    0.00 :   c76e6:  jmp    c7f19 <std::sys::backtrace::__rust_begin_short_backtrace+0x1da9>
    0.00 :   c76eb:  mov    0xf8(%rsp),%rax
    0.00 :   c76f3:  cmp    $0x5,%rax
    0.00 :   c76f7:  mov    %rcx,0x48(%rsp)
    0.00 :   c76fc:  mov    %rdx,0x88(%rsp)
    0.00 :   c7704:  jae    c77c2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1652>
    0.00 :   c770a:  mov    $0x4,%ecx
    0.00 :   c770f:  mov    %rcx,0x8(%rsp)
    0.00 :   c7714:  movl   $0x0,0x40(%rsp)
    0.00 :   c771c:  mov    %rax,0x10(%rsp)
    0.00 :   c7721:  jmp    c7822 <std::sys::backtrace::__rust_begin_short_backtrace+0x16b2>
    0.00 :   c7726:  lea    0xb8(%r15),%rax
    0.00 :   c772d:  lea    (%rax,%r13,8),%rdi
    0.00 :   c7731:  mov    %r12,%rax
    0.00 :   c7734:  sub    %r8,%rax
    0.00 :   c7737:  mov    %rax,0x20(%rsp)
    0.00 :   c773c:  mov    %rdx,0x88(%rsp)
    0.00 :   c7744:  lea    0x0(,%rax,8),%rdx
    0.00 :   c774c:  mov    %rcx,0x48(%rsp)
    0.00 :   c7751:  mov    %r8,0xf8(%rsp)
    0.00 :   c7759:  call   *0xc9da1(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c775f:  mov    0xf8(%rsp),%rax
    0.00 :   c7767:  mov    %rbp,0xb8(%r15,%rax,8)
    0.00 :   c776f:  mov    %rax,%rsi
    0.00 :   c7772:  mov    %rax,%rbp
    0.00 :   c7775:  shl    $0x4,%rsi
    0.00 :   c7779:  add    %r15,%rsi
    0.00 :   c777c:  shl    $0x4,%r13
    0.00 :   c7780:  add    %r15,%r13
    0.00 :   c7783:  mov    0x20(%rsp),%rdx
    0.00 :   c7788:  shl    $0x4,%rdx
    0.00 :   c778c:  mov    %r13,%rdi
    0.00 :   c778f:  call   *0xc9d6b(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c7795:  mov    0x88(%rsp),%rdx
    0.00 :   c779d:  mov    0x48(%rsp),%rcx
    0.00 :   c77a2:  mov    %rbp,%rax
    0.00 :   c77a5:  inc    %r12d
    0.00 :   c77a8:  shl    $0x4,%rax
    0.00 :   c77ac:  mov    %rdx,(%r15,%rax,1)
    0.00 :   c77b0:  mov    %rcx,0x8(%r15,%rax,1)
    0.00 :   c77b5:  mov    %r12w,0x112(%r15)
    0.00 :   c77bd:  jmp    c7f19 <std::sys::backtrace::__rust_begin_short_backtrace+0x1da9>
    0.00 :   c77c2:  je     c77ed <std::sys::backtrace::__rust_begin_short_backtrace+0x167d>
    0.00 :   c77c4:  mov    0xf8(%rsp),%rax
    0.00 :   c77cc:  cmp    $0x6,%rax
    0.00 :   c77d0:  jne    c7809 <std::sys::backtrace::__rust_begin_short_backtrace+0x1699>
    0.00 :   c77d2:  mov    $0x5,%eax
    0.00 :   c77d7:  mov    %rax,0x8(%rsp)
    0.00 :   c77dc:  mov    $0x1,%al
    0.00 :   c77de:  mov    %eax,0x40(%rsp)
    0.00 :   c77e2:  movq   $0x0,0x10(%rsp)
    0.00 :   c77eb:  jmp    c7822 <std::sys::backtrace::__rust_begin_short_backtrace+0x16b2>
    0.00 :   c77ed:  movl   $0x0,0x40(%rsp)
    0.00 :   c77f5:  mov    0xf8(%rsp),%rax
    0.00 :   c77fd:  mov    %rax,0x10(%rsp)
    0.00 :   c7802:  mov    %rax,0x8(%rsp)
    0.00 :   c7807:  jmp    c7822 <std::sys::backtrace::__rust_begin_short_backtrace+0x16b2>
    0.00 :   c7809:  add    $0xfffffffffffffff9,%rax
    0.00 :   c780d:  mov    %rax,0x10(%rsp)
    0.00 :   c7812:  mov    $0x6,%eax
    0.00 :   c7817:  mov    %rax,0x8(%rsp)
    0.00 :   c781c:  mov    $0x1,%al
    0.00 :   c781e:  mov    %eax,0x40(%rsp)
    0.00 :   c7822:  mov    $0x118,%r15d
    0.00 :   c7828:  mov    $0x118,%edi
    0.00 :   c782d:  call   *0xc97d5(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   c7833:  test   %rax,%rax
    0.00 :   c7836:  je     c8eab <std::sys::backtrace::__rust_begin_short_backtrace+0x2d3b>
    0.00 :   c783c:  mov    %rax,%r12
    0.00 :   c783f:  movq   $0x0,0xb0(%rax)
    0.00 :   c784a:  movzwl 0x112(%r13),%eax
    0.00 :   c7852:  mov    0x8(%rsp),%rcx
    0.00 :   c7857:  mov    %rcx,%r15
    0.00 :   c785a:  not    %r15
    0.00 :   c785d:  add    %rax,%r15
    0.00 :   c7860:  mov    %r15w,0x112(%r12)
    0.00 :   c7869:  cmp    $0xc,%r15
    0.00 :   c786d:  jae    c8f5f <std::sys::backtrace::__rust_begin_short_backtrace+0x2def>
    0.00 :   c7873:  mov    %rcx,%rax
    0.00 :   c7876:  shl    $0x4,%rax
    0.00 :   c787a:  mov    %rcx,%rsi
    0.00 :   c787d:  mov    0x0(%r13,%rax,1),%rcx
    0.00 :   c7882:  mov    %rcx,0x30(%rsp)
    0.00 :   c7887:  mov    0x8(%r13,%rax,1),%rax
    0.00 :   c788c:  mov    %rax,0x38(%rsp)
    0.00 :   c7891:  mov    %rsi,0x8(%rsp)
    0.00 :   c7896:  mov    0xb8(%r13,%rsi,8),%rax
    0.00 :   c789e:  mov    %rax,0xf0(%rsp)
    0.00 :   c78a6:  lea    0x1(%rsi),%rax
    0.00 :   c78aa:  mov    %rax,0x158(%rsp)
    0.00 :   c78b2:  lea    0xc0(%r13,%rsi,8),%rsi
    0.00 :   c78ba:  lea    0xb8(%r12),%rdi
    0.00 :   c78c2:  mov    %r13,0x20(%rsp)
    0.00 :   c78c7:  lea    0x0(,%r15,8),%rdx
    0.00 :   c78cf:  call   *0xc9703(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   c78d5:  mov    0x158(%rsp),%rsi
    0.00 :   c78dd:  shl    $0x4,%rsi
    0.00 :   c78e1:  add    0x20(%rsp),%rsi
    0.00 :   c78e6:  shl    $0x4,%r15
    0.00 :   c78ea:  mov    %r12,%rdi
    0.00 :   c78ed:  mov    %r15,%rdx
    0.00 :   c78f0:  call   *0xc96e2(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   c78f6:  cmpb   $0x0,0x40(%rsp)
    0.00 :   c78fb:  mov    %r12,%r15
    0.00 :   c78fe:  mov    0x20(%rsp),%rcx
    0.00 :   c7903:  cmove  %rcx,%r15
    0.00 :   c7907:  mov    0x8(%rsp),%rax
    0.00 :   c790c:  mov    %ax,0x112(%rcx)
    0.00 :   c7913:  movzwl 0x112(%r15),%r8d
    0.00 :   c791b:  mov    0x10(%rsp),%rdx
    0.00 :   c7920:  lea    (%r15,%rdx,8),%rsi
    0.00 :   c7924:  add    $0xb8,%rsi
    0.00 :   c792b:  cmp    %rdx,%r8
    0.00 :   c792e:  jbe    c79a3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1833>
    0.00 :   c7930:  lea    0xb8(%r15),%rax
    0.00 :   c7937:  lea    0x1(%rdx),%rcx
    0.00 :   c793b:  mov    %rcx,0x8(%rsp)
    0.00 :   c7940:  lea    (%rax,%rdx,8),%rdi
    0.00 :   c7944:  add    $0x8,%rdi
    0.00 :   c7948:  mov    %r8d,%eax
    0.00 :   c794b:  sub    %edx,%eax
    0.00 :   c794d:  mov    %rax,0x40(%rsp)
    0.00 :   c7952:  lea    0x0(,%rax,8),%edx
    0.00 :   c7959:  mov    %r8,0x20(%rsp)
    0.00 :   c795e:  call   *0xc9b9c(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c7964:  mov    0x10(%rsp),%rax
    0.00 :   c7969:  mov    %rbp,0xb8(%r15,%rax,8)
    0.00 :   c7971:  mov    0x10(%rsp),%rsi
    0.00 :   c7976:  shl    $0x4,%rsi
    0.00 :   c797a:  add    %r15,%rsi
    0.00 :   c797d:  mov    0x8(%rsp),%rdi
    0.00 :   c7982:  shl    $0x4,%rdi
    0.00 :   c7986:  add    %r15,%rdi
    0.00 :   c7989:  mov    0x40(%rsp),%rdx
    0.00 :   c798e:  shl    $0x4,%edx
    0.00 :   c7991:  call   *0xc9b69(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c7997:  mov    0x20(%rsp),%r8
    0.00 :   c799c:  mov    0x10(%rsp),%rdx
    0.00 :   c79a1:  jmp    c79a6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1836>
    0.00 :   c79a3:  mov    %rbp,(%rsi)
    0.00 :   c79a6:  mov    0x48(%rsp),%rax
    0.00 :   c79ab:  mov    0x88(%rsp),%rcx
    0.00 :   c79b3:  inc    %r8d
    0.00 :   c79b6:  shl    $0x4,%rdx
    0.00 :   c79ba:  mov    %rcx,(%r15,%rdx,1)
    0.00 :   c79be:  mov    %rax,0x8(%r15,%rdx,1)
    0.00 :   c79c3:  mov    %r8w,0x112(%r15)
    0.00 :   c79cb:  mov    0xb0(%r13),%r15
    0.00 :   c79d2:  test   %r15,%r15
    0.00 :   c79d5:  je     c7e43 <std::sys::backtrace::__rust_begin_short_backtrace+0x1cd3>
    0.00 :   c79db:  mov    0x318(%rsp),%rdx
    0.00 :   c79e3:  test   %rdx,%rdx
    0.00 :   c79e6:  sete   %cl
    0.00 :   c79e9:  mov    %rdx,0x2e8(%rsp)
    0.00 :   c79f1:  jmp    c7a0a <std::sys::backtrace::__rust_begin_short_backtrace+0x189a>
    0.00 :   c79f3:  mov    0x20(%rsp),%r13
    0.00 :   c79f8:  mov    0xb0(%r13),%r15
    0.00 :   c79ff:  mov    $0x1,%cl
    0.00 :   c7a01:  test   %r15,%r15
    0.00 :   c7a04:  je     c7e4f <std::sys::backtrace::__rust_begin_short_backtrace+0x1cdf>
    0.00 :   c7a0a:  mov    0x38(%rsp),%rbp
    0.00 :   c7a0f:  mov    0x30(%rsp),%rdi
    0.00 :   c7a14:  mov    0xf0(%rsp),%r8
    0.00 :   c7a1c:  test   $0x1,%cl
    0.00 :   c7a1f:  je     c8ebe <std::sys::backtrace::__rust_begin_short_backtrace+0x2d4e>
    0.00 :   c7a25:  mov    %r12,%rsi
    0.00 :   c7a28:  movzwl 0x110(%r13),%r10d
    0.00 :   c7a30:  movzwl 0x112(%r15),%r11d
    0.00 :   c7a38:  cmp    $0xb,%r11
    0.00 :   c7a3c:  mov    %r15,0x20(%rsp)
    0.00 :   c7a41:  mov    %r12,0x88(%rsp)
    0.00 :   c7a49:  mov    %rbp,0x40(%rsp)
    0.00 :   c7a4e:  mov    %rdi,0x158(%rsp)
    0.00 :   c7a56:  mov    %r11,0x48(%rsp)
    0.00 :   c7a5b:  mov    %r8,0x150(%rsp)
    0.00 :   c7a63:  jb     c7f4c <std::sys::backtrace::__rust_begin_short_backtrace+0x1ddc>
    0.00 :   c7a69:  cmp    $0x5,%r10w
    0.00 :   c7a6e:  jae    c7a8c <std::sys::backtrace::__rust_begin_short_backtrace+0x191c>
    0.00 :   c7a70:  mov    %r10,0x8(%rsp)
    0.00 :   c7a75:  mov    $0x4,%eax
    0.00 :   c7a7a:  mov    %rax,0x10(%rsp)
    0.00 :   c7a7f:  movl   $0x0,0x118(%rsp)
    0.00 :   c7a8a:  jmp    c7ae9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1979>
    0.00 :   c7a8c:  cmp    $0x5,%r10
    0.00 :   c7a90:  je     c7ab6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1946>
    0.00 :   c7a92:  cmp    $0x6,%r10d
    0.00 :   c7a96:  jne    c7acd <std::sys::backtrace::__rust_begin_short_backtrace+0x195d>
    0.00 :   c7a98:  mov    $0x1,%al
    0.00 :   c7a9a:  mov    %eax,0x118(%rsp)
    0.00 :   c7aa1:  mov    $0x5,%eax
    0.00 :   c7aa6:  mov    %rax,0x10(%rsp)
    0.00 :   c7aab:  movq   $0x0,0x8(%rsp)
    0.00 :   c7ab4:  jmp    c7ae9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1979>
    0.00 :   c7ab6:  movl   $0x0,0x118(%rsp)
    0.00 :   c7ac1:  mov    %r10,0x8(%rsp)
    0.00 :   c7ac6:  mov    %r10,0x10(%rsp)
    0.00 :   c7acb:  jmp    c7ae9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1979>
    0.00 :   c7acd:  add    $0xfffffffffffffff9,%r10
    0.00 :   c7ad1:  mov    %r10,0x8(%rsp)
    0.00 :   c7ad6:  mov    $0x1,%al
    0.00 :   c7ad8:  mov    %eax,0x118(%rsp)
    0.00 :   c7adf:  mov    $0x6,%eax
    0.00 :   c7ae4:  mov    %rax,0x10(%rsp)
    0.00 :   c7ae9:  mov    $0x178,%r15d
    0.00 :   c7aef:  mov    $0x178,%edi
    0.00 :   c7af4:  call   *0xc950e(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   c7afa:  test   %rax,%rax
    0.00 :   c7afd:  je     c8eab <std::sys::backtrace::__rust_begin_short_backtrace+0x2d3b>
    0.00 :   c7b03:  mov    %rax,%r13
    0.00 :   c7b06:  mov    %rax,%r12
    0.00 :   c7b09:  movq   $0x0,0xb0(%r13)
    0.00 :   c7b14:  mov    0x20(%rsp),%rcx
    0.00 :   c7b19:  movzwl 0x112(%rcx),%eax
    0.00 :   c7b20:  mov    0x10(%rsp),%rsi
    0.00 :   c7b25:  mov    %rsi,%r15
    0.00 :   c7b28:  not    %r15
    0.00 :   c7b2b:  add    %rax,%r15
    0.00 :   c7b2e:  mov    %r15w,0x112(%r13)
    0.00 :   c7b36:  cmp    $0xc,%r15
    0.00 :   c7b3a:  jae    c8e73 <std::sys::backtrace::__rust_begin_short_backtrace+0x2d03>
    0.00 :   c7b40:  mov    %esi,%eax
    0.00 :   c7b42:  shl    $0x4,%eax
    0.00 :   c7b45:  mov    (%rcx,%rax,1),%rdx
    0.00 :   c7b49:  mov    %rdx,0x30(%rsp)
    0.00 :   c7b4e:  mov    0x8(%rcx,%rax,1),%rax
    0.00 :   c7b53:  mov    %rax,0x38(%rsp)
    0.00 :   c7b58:  mov    0xb8(%rcx,%rsi,8),%rax
    0.00 :   c7b60:  mov    %rax,0xf0(%rsp)
    0.00 :   c7b68:  lea    0x1(%rsi),%ebp
    0.00 :   c7b6b:  mov    0x20(%rsp),%rax
    0.00 :   c7b70:  lea    (%rax,%rbp,8),%rsi
    0.00 :   c7b74:  add    $0xb8,%rsi
    0.00 :   c7b7b:  lea    0xb8(%r13),%rdi
    0.00 :   c7b82:  lea    0x0(,%r15,8),%rdx
    0.00 :   c7b8a:  call   *0xc9448(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   c7b90:  shl    $0x4,%ebp
    0.00 :   c7b93:  add    0x20(%rsp),%rbp
    0.00 :   c7b98:  shl    $0x4,%r15
    0.00 :   c7b9c:  mov    %r12,%rdi
    0.00 :   c7b9f:  mov    %rbp,%rsi
    0.00 :   c7ba2:  mov    0x20(%rsp),%rbp
    0.00 :   c7ba7:  mov    %r15,%rdx
    0.00 :   c7baa:  call   *0xc9428(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   c7bb0:  mov    0x10(%rsp),%rcx
    0.00 :   c7bb5:  mov    %cx,0x112(%rbp)
    0.00 :   c7bbc:  movzwl 0x112(%r12),%r15d
    0.00 :   c7bc5:  lea    0x1(%r15),%rdx
    0.00 :   c7bc9:  cmp    $0xc,%r15
    0.00 :   c7bcd:  jae    c8e8f <std::sys::backtrace::__rust_begin_short_backtrace+0x2d1f>
    0.00 :   c7bd3:  mov    0x48(%rsp),%rax
    0.00 :   c7bd8:  sub    %ecx,%eax
    0.00 :   c7bda:  cmp    %edx,%eax
    0.00 :   c7bdc:  jne    c8efc <std::sys::backtrace::__rust_begin_short_backtrace+0x2d8c>
    0.00 :   c7be2:  incq   0x2e8(%rsp)
    0.00 :   c7bea:  lea    0x118(%r13),%rdi
    0.00 :   c7bf1:  lea    0x120(,%rcx,8),%rsi
    0.00 :   c7bf9:  add    %rbp,%rsi
    0.00 :   c7bfc:  shl    $0x3,%edx
    0.00 :   c7bff:  call   *0xc93d3(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   c7c05:  xor    %eax,%eax
    0.00 :   c7c07:  nopw   0x0(%rax,%rax,1)
    0.00 :   c7c10:  mov    %rax,%rcx
    0.00 :   c7c13:  cmp    %r15,%rax
    0.00 :   c7c16:  adc    $0x0,%rax
    0.00 :   c7c1a:  mov    0x118(%r12,%rcx,8),%rdx
    0.00 :   c7c22:  mov    %r12,0xb0(%rdx)
    0.00 :   c7c29:  mov    %cx,0x110(%rdx)
    0.00 :   c7c30:  cmp    %r15,%rcx
    0.00 :   c7c33:  jae    c7c3a <std::sys::backtrace::__rust_begin_short_backtrace+0x1aca>
    0.00 :   c7c35:  cmp    %r15,%rax
    0.00 :   c7c38:  jbe    c7c10 <std::sys::backtrace::__rust_begin_short_backtrace+0x1aa0>
    0.00 :   c7c3a:  cmpb   $0x0,0x118(%rsp)
    0.00 :   c7c42:  cmove  %rbp,%r13
    0.00 :   c7c46:  movzwl 0x112(%r13),%ebp
    0.00 :   c7c4e:  mov    0x8(%rsp),%rdx
    0.00 :   c7c53:  lea    0x1(%rdx),%r15
    0.00 :   c7c57:  mov    %rbp,%r8
    0.00 :   c7c5a:  sub    %rdx,%r8
    0.00 :   c7c5d:  jbe    c7d2f <std::sys::backtrace::__rust_begin_short_backtrace+0x1bbf>
    0.00 :   c7c63:  lea    0xb8(%r13),%rax
    0.00 :   c7c6a:  lea    0xb8(,%rdx,8),%rsi
    0.00 :   c7c72:  add    %r13,%rsi
    0.00 :   c7c75:  lea    (%rax,%r15,8),%rdi
    0.00 :   c7c79:  mov    %ebp,%eax
    0.00 :   c7c7b:  sub    %edx,%eax
    0.00 :   c7c7d:  mov    %rax,0x118(%rsp)
    0.00 :   c7c85:  lea    0x0(,%rax,8),%edx
    0.00 :   c7c8c:  mov    %rdx,0x48(%rsp)
    0.00 :   c7c91:  mov    %r8,0x10(%rsp)
    0.00 :   c7c96:  call   *0xc9864(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c7c9c:  mov    0x8(%rsp),%rax
    0.00 :   c7ca1:  mov    0x150(%rsp),%rcx
    0.00 :   c7ca9:  mov    %rcx,0xb8(%r13,%rax,8)
    0.00 :   c7cb1:  mov    0x8(%rsp),%rax
    0.00 :   c7cb6:  shl    $0x4,%rax
    0.00 :   c7cba:  mov    %rax,0x150(%rsp)
    0.00 :   c7cc2:  lea    (%rax,%r13,1),%rsi
    0.00 :   c7cc6:  mov    %r15,%rdi
    0.00 :   c7cc9:  shl    $0x4,%rdi
    0.00 :   c7ccd:  add    %r13,%rdi
    0.00 :   c7cd0:  mov    0x118(%rsp),%rdx
    0.00 :   c7cd8:  shl    $0x4,%edx
    0.00 :   c7cdb:  call   *0xc981f(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c7ce1:  mov    0x158(%rsp),%rax
    0.00 :   c7ce9:  mov    0x150(%rsp),%rcx
    0.00 :   c7cf1:  mov    %rax,0x0(%r13,%rcx,1)
    0.00 :   c7cf6:  mov    0x40(%rsp),%rax
    0.00 :   c7cfb:  mov    %rax,0x8(%r13,%rcx,1)
    0.00 :   c7d00:  lea    0x118(%r13,%r15,8),%rsi
    0.00 :   c7d08:  mov    0x8(%rsp),%rax
    0.00 :   c7d0d:  lea    0x128(,%rax,8),%rdi
    0.00 :   c7d15:  add    %r13,%rdi
    0.00 :   c7d18:  mov    0x48(%rsp),%rdx
    0.00 :   c7d1d:  call   *0xc97dd(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c7d23:  mov    0x10(%rsp),%r8
    0.00 :   c7d28:  mov    0x8(%rsp),%rdx
    0.00 :   c7d2d:  jmp    c7d5d <std::sys::backtrace::__rust_begin_short_backtrace+0x1bed>
    0.00 :   c7d2f:  mov    0x150(%rsp),%rax
    0.00 :   c7d37:  mov    %rax,0xb8(%r13,%rdx,8)
    0.00 :   c7d3f:  mov    %rdx,%rax
    0.00 :   c7d42:  shl    $0x4,%rax
    0.00 :   c7d46:  mov    0x158(%rsp),%rcx
    0.00 :   c7d4e:  mov    %rcx,0x0(%r13,%rax,1)
    0.00 :   c7d53:  mov    0x40(%rsp),%rcx
    0.00 :   c7d58:  mov    %rcx,0x8(%r13,%rax,1)
    0.00 :   c7d5d:  mov    0x88(%rsp),%rsi
    0.00 :   c7d65:  lea    0x1(%rbp),%ecx
    0.00 :   c7d68:  lea    0x2(%rbp),%rax
    0.00 :   c7d6c:  mov    %rsi,0x120(%r13,%rdx,8)
    0.00 :   c7d74:  mov    %cx,0x112(%r13)
    0.00 :   c7d7c:  cmp    %eax,%r15d
    0.00 :   c7d7f:  jae    c79f3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1883>
    0.00 :   c7d85:  sub    %edx,%ebp
    0.00 :   c7d87:  inc    %ebp
    0.00 :   c7d89:  and    $0x3,%ebp
    0.00 :   c7d8c:  je     c7dc1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c51>
    0.00 :   c7d8e:  lea    0x120(,%rdx,8),%rdx
    0.00 :   c7d96:  add    %r13,%rdx
    0.00 :   c7d99:  xor    %ecx,%ecx
    0.00 :   c7d9b:  nopl   0x0(%rax,%rax,1)
    0.00 :   c7da0:  mov    (%rdx,%rcx,8),%rsi
    0.00 :   c7da4:  mov    %r13,0xb0(%rsi)
    0.00 :   c7dab:  lea    (%r15,%rcx,1),%edi
    0.00 :   c7daf:  mov    %di,0x110(%rsi)
    0.00 :   c7db6:  inc    %rcx
    0.00 :   c7db9:  cmp    %rcx,%rbp
    0.00 :   c7dbc:  jne    c7da0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c30>
    0.00 :   c7dbe:  add    %rcx,%r15
    0.00 :   c7dc1:  cmp    $0x3,%r8d
    0.00 :   c7dc5:  jb     c79f3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1883>
    0.00 :   c7dcb:  nopl   0x0(%rax,%rax,1)
    0.00 :   c7dd0:  mov    0x118(%r13,%r15,8),%rcx
    0.00 :   c7dd8:  mov    %r13,0xb0(%rcx)
    0.00 :   c7ddf:  mov    %r15w,0x110(%rcx)
    0.00 :   c7de7:  mov    0x120(%r13,%r15,8),%rcx
    0.00 :   c7def:  mov    %r13,0xb0(%rcx)
    0.00 :   c7df6:  lea    0x1(%r15),%edx
    0.00 :   c7dfa:  mov    %dx,0x110(%rcx)
    0.00 :   c7e01:  mov    0x128(%r13,%r15,8),%rcx
    0.00 :   c7e09:  mov    %r13,0xb0(%rcx)
    0.00 :   c7e10:  lea    0x2(%r15),%edx
    0.00 :   c7e14:  mov    %dx,0x110(%rcx)
    0.00 :   c7e1b:  mov    0x130(%r13,%r15,8),%rcx
    0.00 :   c7e23:  mov    %r13,0xb0(%rcx)
    0.00 :   c7e2a:  lea    0x3(%r15),%edx
    0.00 :   c7e2e:  mov    %dx,0x110(%rcx)
    0.00 :   c7e35:  add    $0x4,%r15
    0.00 :   c7e39:  cmp    %rax,%r15
    0.00 :   c7e3c:  jne    c7dd0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c60>
    0.00 :   c7e3e:  jmp    c79f3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1883>
    0.00 :   c7e43:  movq   $0x0,0x2e8(%rsp)
    0.00 :   c7e4f:  mov    0x100(%rsp),%r13
    0.00 :   c7e57:  test   %r13,%r13
    0.00 :   c7e5a:  je     c8fdc <std::sys::backtrace::__rust_begin_short_backtrace+0x2e6c>
    0.00 :   c7e60:  mov    0x108(%rsp),%rbp
    0.00 :   c7e68:  mov    $0x178,%edi
    0.00 :   c7e6d:  call   *0xc9195(%rip)        # 191008 <malloc@GLIBC_2.2.5>
    0.00 :   c7e73:  test   %rax,%rax
    0.00 :   c7e76:  je     c8fee <std::sys::backtrace::__rust_begin_short_backtrace+0x2e7e>
    0.00 :   c7e7c:  mov    %rax,%r15
    0.00 :   c7e7f:  movq   $0x0,0xb0(%rax)
    0.00 :   c7e8a:  movw   $0x0,0x112(%rax)
    0.00 :   c7e93:  mov    %r13,0x118(%rax)
    0.00 :   c7e9a:  mov    %rbp,%rax
    0.00 :   c7e9d:  inc    %rax
    0.00 :   c7ea0:  je     c9003 <std::sys::backtrace::__rust_begin_short_backtrace+0x2e93>
    0.00 :   c7ea6:  mov    %r15,0xb0(%r13)
    0.00 :   c7ead:  movw   $0x0,0x110(%r13)
    0.00 :   c7eb7:  mov    %r15,0x100(%rsp)
    0.00 :   c7ebf:  mov    %rax,0x108(%rsp)
    0.00 :   c7ec7:  cmp    %rbp,0x2e8(%rsp)
    0.00 :   c7ecf:  jne    c9015 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ea5>
    0.00 :   c7ed5:  movw   $0x1,0x112(%r15)
    0.00 :   c7edf:  mov    0xf0(%rsp),%rax
    0.00 :   c7ee7:  mov    %rax,0xb8(%r15)
    0.00 :   c7eee:  mov    0x30(%rsp),%rax
    0.00 :   c7ef3:  mov    %rax,(%r15)
    0.00 :   c7ef6:  mov    0x38(%rsp),%rax
    0.00 :   c7efb:  mov    %rax,0x8(%r15)
    0.00 :   c7eff:  mov    %r12,0x120(%r15)
    0.00 :   c7f06:  mov    %r15,0xb0(%r12)
    0.00 :   c7f0e:  movw   $0x1,0x110(%r12)
    0.00 :   c7f19:  mov    0xe8(%rsp),%rbp
    0.00 :   c7f21:  mov    0x148(%rsp),%r12
    0.00 :   c7f29:  incq   0x110(%rsp)
    0.00 :   c7f31:  mov    0x3f0(%rsp),%r15
    0.00 :   c7f39:  mov    $0x0,%edx
    0.00 :   c7f3e:  dec    %r12
    0.00 :   c7f41:  jne    c70e4 <std::sys::backtrace::__rust_begin_short_backtrace+0xf74>
    0.00 :   c7f47:  jmp    c845e <std::sys::backtrace::__rust_begin_short_backtrace+0x22ee>
    0.00 :   c7f4c:  lea    0x1(%r10),%r13
    0.00 :   c7f50:  cmp    %r11w,%r10w
    0.00 :   c7f54:  jae    c8080 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f10>
    0.00 :   c7f5a:  lea    0xb8(%r15),%rdi
    0.00 :   c7f61:  lea    (%r15,%r10,8),%rsi
    0.00 :   c7f65:  add    $0xb8,%rsi
    0.00 :   c7f6c:  lea    0x0(,%r13,8),%eax
    0.00 :   c7f74:  mov    %rax,0x10(%rsp)
    0.00 :   c7f79:  add    %rax,%rdi
    0.00 :   c7f7c:  mov    %r11,%r12
    0.00 :   c7f7f:  sub    %r10,%r12
    0.00 :   c7f82:  lea    0x0(,%r12,8),%rdx
    0.00 :   c7f8a:  mov    %rdx,0x30(%rsp)
    0.00 :   c7f8f:  mov    %r10,0x8(%rsp)
    0.00 :   c7f94:  call   *0xc9566(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c7f9a:  mov    0x8(%rsp),%rax
    0.00 :   c7f9f:  lea    0x0(,%rax,8),%eax
    0.00 :   c7fa6:  mov    %rax,0x38(%rsp)
    0.00 :   c7fab:  mov    0x150(%rsp),%rcx
    0.00 :   c7fb3:  mov    %rcx,0xb8(%r15,%rax,1)
    0.00 :   c7fbb:  mov    0x8(%rsp),%rbp
    0.00 :   c7fc0:  shl    $0x4,%ebp
    0.00 :   c7fc3:  lea    (%r15,%rbp,1),%rsi
    0.00 :   c7fc7:  mov    %r13d,%edi
    0.00 :   c7fca:  shl    $0x4,%edi
    0.00 :   c7fcd:  add    %r15,%rdi
    0.00 :   c7fd0:  shl    $0x4,%r12
    0.00 :   c7fd4:  mov    %r12,%rdx
    0.00 :   c7fd7:  mov    0xc9522(%rip),%r12        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   c7fde:  call   *%r12
    0.00 :   c7fe1:  mov    0x158(%rsp),%rax
    0.00 :   c7fe9:  mov    %rax,(%r15,%rbp,1)
    0.00 :   c7fed:  mov    0x40(%rsp),%rax
    0.00 :   c7ff2:  mov    %rax,0x8(%r15,%rbp,1)
    0.00 :   c7ff7:  mov    0x10(%rsp),%rax
    0.00 :   c7ffc:  lea    0x118(%r15,%rax,1),%rsi
    0.00 :   c8004:  mov    0x38(%rsp),%rax
    0.00 :   c8009:  lea    (%r15,%rax,1),%rdi
    0.00 :   c800d:  add    $0x128,%rdi
    0.00 :   c8014:  mov    0x30(%rsp),%rdx
    0.00 :   c8019:  call   *%r12
    0.00 :   c801c:  mov    0x48(%rsp),%r11
    0.00 :   c8021:  mov    0x88(%rsp),%rsi
    0.00 :   c8029:  mov    0x8(%rsp),%r10
    0.00 :   c802e:  jmp    c8097 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f27>
    0.00 :   c8030:  mov    $0xb,%r12d
    0.00 :   c8036:  test   %r15d,%r15d
    0.00 :   c8039:  js     c8040 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ed0>
    0.00 :   c803b:  mov    %r15d,%edi
    0.00 :   c803e:  call   *%rbx
    0.00 :   c8040:  mov    %r12,0x90(%rsp)
    0.00 :   c8048:  mov    0x220(%rsp),%rax
    0.00 :   c8050:  mov    %rax,0x98(%rsp)
    0.00 :   c8058:  mov    0x228(%rsp),%rax
    0.00 :   c8060:  mov    %rax,0xa0(%rsp)
    0.00 :   c8068:  lea    0x50(%rsp),%rdi
    0.00 :   c806d:  lea    0x90(%rsp),%rsi
    0.00 :   c8075:  call   *0xc9ee5(%rip)        # 191f60 <_DYNAMIC+0x11a0>
    0.00 :   c807b:  jmp    c7635 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c8080:  mov    %r8,0xb8(%r15,%r10,8)
    0.00 :   c8088:  mov    %r10d,%eax
    0.00 :   c808b:  shl    $0x4,%eax
    0.00 :   c808e:  mov    %rdi,(%r15,%rax,1)
    0.00 :   c8092:  mov    %rbp,0x8(%r15,%rax,1)
    0.00 :   c8097:  mov    0xe8(%rsp),%rbp
    0.00 :   c809f:  mov    0x148(%rsp),%r12
    0.00 :   c80a7:  lea    0x1(%r11),%ecx
    0.00 :   c80ab:  lea    0x2(%r11),%rax
    0.00 :   c80af:  mov    %rsi,0x120(%r15,%r10,8)
    0.00 :   c80b7:  mov    %cx,0x112(%r15)
    0.00 :   c80bf:  cmp    %eax,%r13d
    0.00 :   c80c2:  jae    c7f29 <std::sys::backtrace::__rust_begin_short_backtrace+0x1db9>
    0.00 :   c80c8:  mov    %r11d,%ecx
    0.00 :   c80cb:  sub    %r10d,%ecx
    0.00 :   c80ce:  inc    %ecx
    0.00 :   c80d0:  and    $0x3,%ecx
    0.00 :   c80d3:  je     c8109 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f99>
    0.00 :   c80d5:  mov    0x20(%rsp),%r9
    0.00 :   c80da:  lea    (%r9,%r10,8),%rsi
    0.00 :   c80de:  add    $0x120,%rsi
    0.00 :   c80e5:  xor    %edx,%edx
    0.00 :   c80e7:  mov    (%rsi,%rdx,8),%rdi
    0.00 :   c80eb:  mov    %r9,0xb0(%rdi)
    0.00 :   c80f2:  lea    (%rdx,%r13,1),%r8d
    0.00 :   c80f6:  mov    %r8w,0x110(%rdi)
    0.00 :   c80fe:  inc    %rdx
    0.00 :   c8101:  cmp    %rdx,%rcx
    0.00 :   c8104:  jne    c80e7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f77>
    0.00 :   c8106:  add    %rdx,%r13
    0.00 :   c8109:  sub    %r10,%r11
    0.00 :   c810c:  cmp    $0x3,%r11d
    0.00 :   c8110:  mov    0x20(%rsp),%rsi
    0.00 :   c8115:  jb     c7f29 <std::sys::backtrace::__rust_begin_short_backtrace+0x1db9>
    0.00 :   c811b:  mov    0x118(%rsi,%r13,8),%rcx
    0.00 :   c8123:  mov    %rsi,0xb0(%rcx)
    0.00 :   c812a:  mov    %r13w,0x110(%rcx)
    0.00 :   c8132:  mov    0x120(%rsi,%r13,8),%rcx
    0.00 :   c813a:  mov    %rsi,0xb0(%rcx)
    0.00 :   c8141:  lea    0x1(%r13),%edx
    0.00 :   c8145:  mov    %dx,0x110(%rcx)
    0.00 :   c814c:  mov    0x128(%rsi,%r13,8),%rcx
    0.00 :   c8154:  mov    %rsi,0xb0(%rcx)
    0.00 :   c815b:  lea    0x2(%r13),%edx
    0.00 :   c815f:  mov    %dx,0x110(%rcx)
    0.00 :   c8166:  mov    0x130(%rsi,%r13,8),%rcx
    0.00 :   c816e:  mov    %rsi,0xb0(%rcx)
    0.00 :   c8175:  lea    0x3(%r13),%edx
    0.00 :   c8179:  mov    %dx,0x110(%rcx)
    0.00 :   c8180:  add    $0x4,%r13
    0.00 :   c8184:  cmp    %rax,%r13
    0.00 :   c8187:  jne    c811b <std::sys::backtrace::__rust_begin_short_backtrace+0x1fab>
    0.00 :   c8189:  jmp    c7f29 <std::sys::backtrace::__rust_begin_short_backtrace+0x1db9>
    0.00 :   c818e:  mov    %r8,0x48(%rsp)
    0.00 :   c8193:  lea    0x120(%rsp),%rdi
    0.00 :   c819b:  lea    0x298(%rsp),%rsi
    0.00 :   c81a3:  mov    0xc9dbe(%rip),%rdx        # 191f68 <_DYNAMIC+0x11a8>
    0.00 :   c81aa:  call   *0xc9dc0(%rip)        # 191f70 <_DYNAMIC+0x11b0>
    0.00 :   c81b0:  cmpb   $0xd,0x120(%rsp)
    0.00 :   c81b8:  lea    0x120(%rsp),%rsi
    0.00 :   c81c0:  jne    c7449 <std::sys::backtrace::__rust_begin_short_backtrace+0x12d9>
    0.00 :   c81c6:  mov    0x128(%rsp),%rax
    0.00 :   c81ce:  mov    %rax,0xf0(%rsp)
    0.00 :   c81d6:  mov    0x48(%rsp),%rax
    0.00 :   c81db:  cmpb   $0x2,0xe(%rax)
    0.00 :   c81df:  je     c844c <std::sys::backtrace::__rust_begin_short_backtrace+0x22dc>
    0.00 :   c81e5:  lea    0x90(%rsp),%rdi
    0.00 :   c81ed:  call   *0xc9d85(%rip)        # 191f78 <_DYNAMIC+0x11b8>
    0.00 :   c81f3:  mov    0x90(%rsp),%rax
    0.00 :   c81fb:  mov    %rax,0x40(%rsp)
    0.00 :   c8200:  mov    0x98(%rsp),%rax
    0.00 :   c8208:  mov    %rax,0x38(%rsp)
    0.00 :   c820d:  mov    0xa0(%rsp),%rax
    0.00 :   c8215:  mov    %rax,0x88(%rsp)
    0.00 :   c821d:  test   %r15d,%r15d
    0.00 :   c8220:  js     c8227 <std::sys::backtrace::__rust_begin_short_backtrace+0x20b7>
    0.00 :   c8222:  mov    %r15d,%edi
    0.00 :   c8225:  call   *%rbx
    0.00 :   c8227:  cmpb   $0xd,0x40(%rsp)
    0.00 :   c822c:  jne    c82f5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2185>
    0.00 :   c8232:  mov    0x20(%rsp),%rcx
    0.00 :   c8237:  mov    0x48(%rsp),%r8
    0.00 :   c823c:  mov    0xf0(%rsp),%r9
    0.00 :   c8244:  mov    0x38(%rsp),%rsi
    0.00 :   c8249:  jmp    c73b5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1245>
    0.00 :   c824e:  mov    %r15,0x20(%rsp)
    0.00 :   c8253:  mov    %r9,0xf0(%rsp)
    0.00 :   c825b:  mov    %r8,%r15
    0.00 :   c825e:  movswq %ax,%rdi
    0.00 :   c8262:  movabs $0xffffffff00000000,%rax
    0.00 :   c826c:  imul   %rax,%rdi
    0.00 :   c8270:  or     $0x2,%rdi
    0.00 :   c8274:  call   *0xc9cde(%rip)        # 191f58 <_DYNAMIC+0x1198>
    0.00 :   c827a:  cmp    $0x4,%dl
    0.00 :   c827d:  jne    c8337 <std::sys::backtrace::__rust_begin_short_backtrace+0x21c7>
    0.00 :   c8283:  mov    0x228(%rsp),%rax
    0.00 :   c828b:  mov    %rax,0x88(%rsp)
    0.00 :   c8293:  mov    0x220(%rsp),%rax
    0.00 :   c829b:  mov    %rax,0x38(%rsp)
    0.00 :   c82a0:  jmp    c82fa <std::sys::backtrace::__rust_begin_short_backtrace+0x218a>
    0.00 :   c82a2:  lea    0x120(%rsp),%rdi
    0.00 :   c82aa:  lea    0x298(%rsp),%rsi
    0.00 :   c82b2:  mov    0xc9caf(%rip),%rdx        # 191f68 <_DYNAMIC+0x11a8>
    0.00 :   c82b9:  call   *0xc9cb1(%rip)        # 191f70 <_DYNAMIC+0x11b0>
    0.00 :   c82bf:  cmpb   $0xd,0x120(%rsp)
    0.00 :   c82c7:  jne    c8434 <std::sys::backtrace::__rust_begin_short_backtrace+0x22c4>
    0.00 :   c82cd:  mov    0x128(%rsp),%rax
    0.00 :   c82d5:  mov    %rax,0x30(%rsp)
    0.00 :   c82da:  mov    0x268(%rsp),%r12
    0.00 :   c82e2:  cmp    0x258(%rsp),%r12
    0.00 :   c82ea:  je     c74e7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1377>
    0.00 :   c82f0:  jmp    c74f5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1385>
    0.00 :   c82f5:  mov    0x40(%rsp),%r15
    0.00 :   c82fa:  mov    %r15,0x90(%rsp)
    0.00 :   c8302:  mov    0x38(%rsp),%rax
    0.00 :   c8307:  mov    %rax,0x98(%rsp)
    0.00 :   c830f:  mov    0x88(%rsp),%rax
    0.00 :   c8317:  mov    %rax,0xa0(%rsp)
    0.00 :   c831f:  lea    0x50(%rsp),%rdi
    0.00 :   c8324:  lea    0x90(%rsp),%rsi
    0.00 :   c832c:  call   *0xc9c2e(%rip)        # 191f60 <_DYNAMIC+0x11a0>
    0.00 :   c8332:  jmp    c7635 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c8337:  mov    %r15,0x90(%rsp)
    0.00 :   c833f:  mov    0x220(%rsp),%rcx
    0.00 :   c8347:  mov    %rcx,0x98(%rsp)
    0.00 :   c834f:  mov    0x228(%rsp),%rcx
    0.00 :   c8357:  mov    %rcx,0xa0(%rsp)
    0.00 :   c835f:  mov    %r12d,0xa8(%rsp)
    0.00 :   c8367:  cmp    $0x3,%dl
    0.00 :   c836a:  mov    0xf0(%rsp),%r9
    0.00 :   c8372:  mov    0x20(%rsp),%r15
    0.00 :   c8377:  je     c7426 <std::sys::backtrace::__rust_begin_short_backtrace+0x12b6>
    0.00 :   c837d:  mov    %r9,%rcx
    0.00 :   c8380:  movzbl %dl,%r9d
    0.00 :   c8384:  lea    0x50(%rsp),%rdi
    0.00 :   c8389:  lea    0x90(%rsp),%rsi
    0.00 :   c8391:  mov    %rcx,%rdx
    0.00 :   c8394:  mov    %r15,%rcx
    0.00 :   c8397:  mov    %rax,%r8
    0.00 :   c839a:  call   *0xc9be0(%rip)        # 191f80 <_DYNAMIC+0x11c0>
    0.00 :   c83a0:  jmp    c7635 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c83a5:  mov    %r8,%r15
    0.00 :   c83a8:  movswq %ax,%rdi
    0.00 :   c83ac:  movabs $0xffffffff00000000,%rax
    0.00 :   c83b6:  imul   %rax,%rdi
    0.00 :   c83ba:  or     $0x2,%rdi
    0.00 :   c83be:  call   *0xc9b94(%rip)        # 191f58 <_DYNAMIC+0x1198>
    0.00 :   c83c4:  cmp    $0x4,%dl
    0.00 :   c83c7:  je     c8040 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ed0>
    0.00 :   c83cd:  mov    %r12,0x90(%rsp)
    0.00 :   c83d5:  mov    0x220(%rsp),%rcx
    0.00 :   c83dd:  mov    %rcx,0x98(%rsp)
    0.00 :   c83e5:  mov    0x228(%rsp),%rcx
    0.00 :   c83ed:  mov    %rcx,0xa0(%rsp)
    0.00 :   c83f5:  mov    0x10(%rsp),%rcx
    0.00 :   c83fa:  mov    %ecx,0xa8(%rsp)
    0.00 :   c8401:  cmp    $0x3,%dl
    0.00 :   c8404:  mov    %r15,%r8
    0.00 :   c8407:  je     c75e2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1472>
    0.00 :   c840d:  movzbl %dl,%r9d
    0.00 :   c8411:  lea    0x50(%rsp),%rdi
    0.00 :   c8416:  lea    0x90(%rsp),%rsi
    0.00 :   c841e:  mov    0x30(%rsp),%rdx
    0.00 :   c8423:  mov    %r8,%rcx
    0.00 :   c8426:  mov    %rax,%r8
    0.00 :   c8429:  call   *0xc9b51(%rip)        # 191f80 <_DYNAMIC+0x11c0>
    0.00 :   c842f:  jmp    c7635 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c5>
    0.00 :   c8434:  lea    0x50(%rsp),%rdi
    0.00 :   c8439:  lea    0x120(%rsp),%rsi
    0.00 :   c8441:  call   *0xc9b19(%rip)        # 191f60 <_DYNAMIC+0x11a0>
    0.00 :   c8447:  jmp    c762b <std::sys::backtrace::__rust_begin_short_backtrace+0x14bb>
    0.00 :   c844c:  mov    0x48(%rsp),%r8
    0.00 :   c8451:  mov    0xf0(%rsp),%r9
    0.00 :   c8459:  jmp    c739b <std::sys::backtrace::__rust_begin_short_backtrace+0x122b>
    0.00 :   c845e:  mov    0x160(%rsp),%r15
    0.00 :   c8466:  mov    0x230(%rsp),%r14
    0.00 :   c846e:  mov    0x110(%rsp),%rax
    0.00 :   c8476:  mov    0x80(%rsp),%rcx
    0.00 :   c847e:  mov    %rax,0x70(%rcx)
    0.00 :   c8482:  cmpb   $0x0,0x168(%rsp)
    0.00 :   c848a:  jne    c84a9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2339>
    0.00 :   c848c:  mov    0xc8ebd(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c8493:  mov    (%rax),%rax
    0.00 :   c8496:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c84a0:  test   %rcx,%rax
    0.00 :   c84a3:  jne    c879f <std::sys::backtrace::__rust_begin_short_backtrace+0x262f>
    0.00 :   c84a9:  xor    %eax,%eax
    0.00 :   c84ab:  xchg   %eax,(%r15)
    0.00 :   c84ae:  cmp    $0x2,%eax
    0.00 :   c84b1:  je     c8780 <std::sys::backtrace::__rust_begin_short_backtrace+0x2610>
    0.00 :   c84b7:  lea    0x90(%rsp),%rdi
    0.00 :   c84bf:  lea    0x248(%rsp),%rsi
    0.00 :   c84c7:  lea    0x330(%rsp),%rdx
    0.00 :   c84cf:  xor    %ecx,%ecx
    0.00 :   c84d1:  mov    $0x5f5e100,%r8d
    0.00 :   c84d7:  call   *0xc9aab(%rip)        # 191f88 <_DYNAMIC+0x11c8>
    0.00 :   c84dd:  movabs $0x7fffffffffffffff,%rax
    0.00 :   c84e7:  add    $0x2,%rax
    0.00 :   c84eb:  cmp    %rax,0x90(%rsp)
    0.00 :   c84f3:  jne    c8535 <std::sys::backtrace::__rust_begin_short_backtrace+0x23c5>
    0.00 :   c84f5:  cmpb   $0x0,0x98(%rsp)
    0.00 :   c84fd:  jne    c8d64 <std::sys::backtrace::__rust_begin_short_backtrace+0x2bf4>
    0.00 :   c8503:  mov    0xa0(%rsp),%r15
    0.00 :   c850b:  mov    %r15,%rdi
    0.00 :   c850e:  call   c43f0 <<std::io::error::Error>::kind>
    0.00 :   c8513:  cmp    $0x23,%al
    0.00 :   c8515:  jne    c8d64 <std::sys::backtrace::__rust_begin_short_backtrace+0x2bf4>
    0.00 :   c851b:  mov    %r15,0x50(%rsp)
    0.00 :   c8520:  lea    0x50(%rsp),%rdi
    0.00 :   c8525:  call   d7530 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10013882635303053058>
    0.00 :   c852a:  mov    $0x1,%r15d
    0.00 :   c8530:  jmp    c6a62 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f2>
    0.00 :   c8535:  mov    0xb0(%rsp),%rax
    0.00 :   c853d:  mov    %rax,0x140(%rsp)
    0.00 :   c8545:  movdqu 0x90(%rsp),%xmm0
    0.00 :   c854e:  movups 0xa0(%rsp),%xmm1
    0.00 :   c8556:  movaps %xmm1,0x130(%rsp)
    0.00 :   c855e:  movdqa %xmm0,0x120(%rsp)
    0.00 :   c8567:  mov    0x340(%rsp),%r14
    0.00 :   c856f:  test   %r14,%r14
    0.00 :   c8572:  mov    $0x1,%r15d
    0.00 :   c8578:  je     c8747 <std::sys::backtrace::__rust_begin_short_backtrace+0x25d7>
    0.00 :   c857e:  mov    0x338(%rsp),%r13
    0.00 :   c8586:  shl    $0x4,%r14
    0.00 :   c858a:  add    %r13,%r14
    0.00 :   c858d:  jmp    c859c <std::sys::backtrace::__rust_begin_short_backtrace+0x242c>
    0.00 :   c858f:  add    $0x10,%r13
    0.00 :   c8593:  cmp    %r14,%r13
    0.00 :   c8596:  je     c8747 <std::sys::backtrace::__rust_begin_short_backtrace+0x25d7>
    0.00 :   c859c:  testb  $0x1,0x0(%r13)
    0.00 :   c85a1:  jne    c858f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c85a3:  mov    $0x1,%ecx
    0.00 :   c85a8:  mov    0x8(%r13),%r15
    0.00 :   c85ac:  xor    %eax,%eax
    0.00 :   c85ae:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   c85b3:  jne    c86c7 <std::sys::backtrace::__rust_begin_short_backtrace+0x2557>
    0.00 :   c85b9:  mov    0xc8d90(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c85c0:  mov    (%rax),%rax
    0.00 :   c85c3:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c85cd:  test   %rcx,%rax
    0.00 :   c85d0:  jne    c86d5 <std::sys::backtrace::__rust_begin_short_backtrace+0x2565>
    0.00 :   c85d6:  xor    %r12d,%r12d
    0.00 :   c85d9:  mov    0x80(%rsp),%rax
    0.00 :   c85e1:  movzbl 0x24(%rax),%eax
    0.00 :   c85e5:  lea    0x50(%rsp),%rdi
    0.00 :   c85ea:  mov    0x3f8(%rsp),%rsi
    0.00 :   c85f2:  mov    %r15,%rdx
    0.00 :   c85f5:  call   e2c90 <alloc::collections::btree::map::BTreeMap<K,V,A>::remove>
    0.00 :   c85fa:  test   %r12b,%r12b
    0.00 :   c85fd:  mov    $0x1,%r15d
    0.00 :   c8603:  jne    c8622 <std::sys::backtrace::__rust_begin_short_backtrace+0x24b2>
    0.00 :   c8605:  mov    0xc8d44(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c860c:  mov    (%rax),%rax
    0.00 :   c860f:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c8619:  test   %rcx,%rax
    0.00 :   c861c:  jne    c871a <std::sys::backtrace::__rust_begin_short_backtrace+0x25aa>
    0.00 :   c8622:  xor    %eax,%eax
    0.00 :   c8624:  xchg   %eax,0x0(%rbp)
    0.00 :   c8627:  cmp    $0x2,%eax
    0.00 :   c862a:  je     c86ef <std::sys::backtrace::__rust_begin_short_backtrace+0x257f>
    0.00 :   c8630:  cmpq   $0x0,0x50(%rsp)
    0.00 :   c8636:  je     c858f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c863c:  movdqu 0x50(%rsp),%xmm0
    0.00 :   c8642:  movups 0x60(%rsp),%xmm1
    0.00 :   c8647:  movaps %xmm1,0xa0(%rsp)
    0.00 :   c864f:  mov    0x70(%rsp),%rax
    0.00 :   c8654:  mov    %rax,0xb0(%rsp)
    0.00 :   c865c:  movdqa %xmm0,0x90(%rsp)
    0.00 :   c8665:  mov    0xa0(%rsp),%rsi
    0.00 :   c866d:  mov    0xa8(%rsp),%rdx
    0.00 :   c8675:  lea    0x98(%rsp),%rdi
    0.00 :   c867d:  call   *0xc990d(%rip)        # 191f90 <_DYNAMIC+0x11d0>
    0.00 :   c8683:  mov    0x90(%rsp),%rax
    0.00 :   c868b:  lock decq (%rax)
    0.00 :   c868f:  jne    c869f <std::sys::backtrace::__rust_begin_short_backtrace+0x252f>
    0.00 :   c8691:  lea    0x90(%rsp),%rdi
    0.00 :   c8699:  call   *0xc98f9(%rip)        # 191f98 <_DYNAMIC+0x11d8>
    0.00 :   c869f:  mov    0x98(%rsp),%rdi
    0.00 :   c86a7:  cmp    $0xffffffffffffffff,%rdi
    0.00 :   c86ab:  je     c858f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c86b1:  lock decq 0x8(%rdi)
    0.00 :   c86b6:  jne    c858f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c86bc:  call   *0xc892e(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c86c2:  jmp    c858f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c86c7:  mov    %rbp,%rdi
    0.00 :   c86ca:  call   *0xc8cf8(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   c86d0:  jmp    c85b9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2449>
    0.00 :   c86d5:  call   *0xc8c95(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c86db:  mov    %eax,%r12d
    0.00 :   c86de:  xor    $0x1,%r12b
    0.00 :   c86e2:  mov    0xe8(%rsp),%rbp
    0.00 :   c86ea:  jmp    c85d9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2469>
    0.00 :   c86ef:  mov    $0xca,%edi
    0.00 :   c86f4:  mov    %rbp,%rsi
    0.00 :   c86f7:  mov    $0x81,%edx
    0.00 :   c86fc:  mov    $0x1,%ecx
    0.00 :   c8701:  xor    %eax,%eax
    0.00 :   c8703:  call   *0xc8c77(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   c8709:  cmpq   $0x0,0x50(%rsp)
    0.00 :   c870f:  jne    c863c <std::sys::backtrace::__rust_begin_short_backtrace+0x24cc>
    0.00 :   c8715:  jmp    c858f <std::sys::backtrace::__rust_begin_short_backtrace+0x241f>
    0.00 :   c871a:  call   *0xc8c50(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c8720:  test   %al,%al
    0.00 :   c8722:  mov    0xe8(%rsp),%rbp
    0.00 :   c872a:  mov    $0x1,%r15d
    0.00 :   c8730:  jne    c8622 <std::sys::backtrace::__rust_begin_short_backtrace+0x24b2>
    0.00 :   c8736:  mov    0x80(%rsp),%rax
    0.00 :   c873e:  movb   $0x1,0x24(%rax)
    0.00 :   c8742:  jmp    c8622 <std::sys::backtrace::__rust_begin_short_backtrace+0x24b2>
    0.00 :   c8747:  mov    0x120(%rsp),%rax
    0.00 :   c874f:  mov    0x230(%rsp),%r14
    0.00 :   c8757:  cmp    %r14,%rax
    0.00 :   c875a:  je     c6a62 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f2>
    0.00 :   c8760:  jmp    c8e19 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ca9>
    0.00 :   c8765:  mov    %rbp,%rdi
    0.00 :   c8768:  call   *0xc8c5a(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   c876e:  jmp    c6a70 <std::sys::backtrace::__rust_begin_short_backtrace+0x900>
    0.00 :   c8773:  call   *0xc8bf7(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c8779:  xor    $0x1,%al
    0.00 :   c877b:  jmp    c6a8f <std::sys::backtrace::__rust_begin_short_backtrace+0x91f>
    0.00 :   c8780:  mov    $0xca,%edi
    0.00 :   c8785:  mov    %r15,%rsi
    0.00 :   c8788:  mov    $0x81,%edx
    0.00 :   c878d:  mov    $0x1,%ecx
    0.00 :   c8792:  xor    %eax,%eax
    0.00 :   c8794:  call   *0xc8be6(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   c879a:  jmp    c84b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x2347>
    0.00 :   c879f:  call   *0xc8bcb(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c87a5:  test   %al,%al
    0.00 :   c87a7:  jne    c84a9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2339>
    0.00 :   c87ad:  movb   $0x1,0x4(%r15)
    0.00 :   c87b2:  jmp    c84a9 <std::sys::backtrace::__rust_begin_short_backtrace+0x2339>
    0.00 :   c87b7:  cmp    %rbx,%rax
    0.00 :   c87ba:  jne    c87f8 <std::sys::backtrace::__rust_begin_short_backtrace+0x2688>
    0.00 :   c87bc:  mov    0x250(%rsp),%rax
    0.00 :   c87c4:  lock decq (%rax)
    0.00 :   c87c8:  jne    c8805 <std::sys::backtrace::__rust_begin_short_backtrace+0x2695>
    0.00 :   c87ca:  lea    0x250(%rsp),%rdi
    0.00 :   c87d2:  call   *0xc9770(%rip)        # 191f48 <_DYNAMIC+0x1188>
    0.00 :   c87d8:  jmp    c8805 <std::sys::backtrace::__rust_begin_short_backtrace+0x2695>
    0.00 :   c87da:  mov    %r13d,%edx
    0.00 :   c87dd:  shr    $0x8,%edx
    0.00 :   c87e0:  mov    %r13d,%ecx
    0.00 :   c87e3:  and    $0xffff0000,%ecx
    0.00 :   c87e9:  movzbl %r13b,%eax
    0.00 :   c87ed:  mov    $0x5,%r13b
    0.00 :   c87f0:  mov    %r15,%rsi
    0.00 :   c87f3:  jmp    c88ac <std::sys::backtrace::__rust_begin_short_backtrace+0x273c>
    0.00 :   c87f8:  lea    0x248(%rsp),%rdi
    0.00 :   c8800:  call   d75c0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10013882635303053058>
    0.00 :   c8805:  mov    0x20(%rsp),%rdi
    0.00 :   c880a:  call   *0xc87e0(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c8810:  mov    0x480(%rsp),%edi
    0.00 :   c8817:  call   *0xc8dc3(%rip)        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c881d:  mov    0x418(%rsp),%r15
    0.00 :   c8825:  mov    0x420(%rsp),%rbx
    0.00 :   c882d:  test   %rbx,%rbx
    0.00 :   c8830:  je     c8864 <std::sys::backtrace::__rust_begin_short_backtrace+0x26f4>
    0.00 :   c8832:  lea    0xe(%r15),%r14
    0.00 :   c8836:  mov    0xc8da3(%rip),%r12        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c883d:  jmp    c8848 <std::sys::backtrace::__rust_begin_short_backtrace+0x26d8>
    0.00 :   c883f:  add    $0x18,%r14
    0.00 :   c8843:  dec    %rbx
    0.00 :   c8846:  je     c8864 <std::sys::backtrace::__rust_begin_short_backtrace+0x26f4>
    0.00 :   c8848:  mov    -0x6(%r14),%edi
    0.00 :   c884c:  cmpb   $0x2,(%r14)
    0.00 :   c8850:  setne  %al
    0.00 :   c8853:  test   %edi,%edi
    0.00 :   c8855:  setns  %cl
    0.00 :   c8858:  and    %al,%cl
    0.00 :   c885a:  cmp    $0x1,%cl
    0.00 :   c885d:  jne    c883f <std::sys::backtrace::__rust_begin_short_backtrace+0x26cf>
    0.00 :   c885f:  call   *%r12
    0.00 :   c8862:  jmp    c883f <std::sys::backtrace::__rust_begin_short_backtrace+0x26cf>
    0.00 :   c8864:  cmpq   $0x0,0x410(%rsp)
    0.00 :   c886d:  je     c8878 <std::sys::backtrace::__rust_begin_short_backtrace+0x2708>
    0.00 :   c886f:  mov    %r15,%rdi
    0.00 :   c8872:  call   *0xc8778(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c8878:  mov    0x448(%rsp),%rax
    0.00 :   c8880:  lock decq (%rax)
    0.00 :   c8884:  mov    0x80(%rsp),%rbx
    0.00 :   c888c:  jne    c8d2c <std::sys::backtrace::__rust_begin_short_backtrace+0x2bbc>
    0.00 :   c8892:  lea    0x448(%rsp),%rdi
    0.00 :   c889a:  call   *0xc96b0(%rip)        # 191f50 <_DYNAMIC+0x1190>
    0.00 :   c88a0:  jmp    c8d2c <std::sys::backtrace::__rust_begin_short_backtrace+0x2bbc>
    0.00 :   c88a5:  xor    %eax,%eax
    0.00 :   c88a7:  mov    %r15,%rsi
    0.00 :   c88aa:  xor    %ecx,%ecx
    0.00 :   c88ac:  or     %rax,%rcx
    0.00 :   c88af:  movzbl %dl,%eax
    0.00 :   c88b2:  shl    $0x8,%eax
    0.00 :   c88b5:  or     %rcx,%rax
    0.00 :   c88b8:  mov    %r13b,0x90(%rsp)
    0.00 :   c88c0:  movb   $0x0,0x97(%rsp)
    0.00 :   c88c8:  movw   $0x0,0x95(%rsp)
    0.00 :   c88d2:  movl   $0x0,0x91(%rsp)
    0.00 :   c88dd:  lea    0x98(%rsp),%r14
    0.00 :   c88e5:  mov    %rsi,0x98(%rsp)
    0.00 :   c88ed:  mov    %rax,0xa0(%rsp)
    0.00 :   c88f5:  mov    %r12,0xa8(%rsp)
    0.00 :   c88fd:  mov    %r15,0xb0(%rsp)
    0.00 :   c8905:  movq   $0x0,0x120(%rsp)
    0.00 :   c8911:  movq   $0x1,0x128(%rsp)
    0.00 :   c891d:  movq   $0x0,0x130(%rsp)
    0.00 :   c8929:  movq   $0x60000020,0x60(%rsp)
    0.00 :   c8932:  lea    0x120(%rsp),%rax
    0.00 :   c893a:  mov    %rax,0x50(%rsp)
    0.00 :   c893f:  lea    0xc3c92(%rip),%rax        # 18c5d8 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0xe8>
    0.00 :   c8946:  mov    %rax,0x58(%rsp)
    0.00 :   c894b:  lea    0x90(%rsp),%rdi
    0.00 :   c8953:  lea    0x50(%rsp),%rsi
    0.00 :   c8958:  call   *0xc9642(%rip)        # 191fa0 <_DYNAMIC+0x11e0>
    0.00 :   c895e:  test   %al,%al
    0.00 :   c8960:  jne    c8f9a <std::sys::backtrace::__rust_begin_short_backtrace+0x2e2a>
    0.00 :   c8966:  mov    0x120(%rsp),%r15
    0.00 :   c896e:  movdqu 0x128(%rsp),%xmm0
    0.00 :   c8977:  movdqa %xmm0,0x20(%rsp)
    0.00 :   c897d:  cmp    $0x1,%r13b
    0.00 :   c8981:  ja     c898b <std::sys::backtrace::__rust_begin_short_backtrace+0x281b>
    0.00 :   c8983:  mov    %r14,%rdi
    0.00 :   c8986:  call   d7530 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10013882635303053058>
    0.00 :   c898b:  cmpq   $0x0,0x8(%rsp)
    0.00 :   c8991:  je     c899e <std::sys::backtrace::__rust_begin_short_backtrace+0x282e>
    0.00 :   c8993:  mov    0x10(%rsp),%rdi
    0.00 :   c8998:  call   *0xc8652(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c899e:  mov    %r15,%r14
    0.00 :   c89a1:  mov    0x160(%rsp),%r15
    0.00 :   c89a9:  cmpb   $0x0,0x168(%rsp)
    0.00 :   c89b1:  jne    c89d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2860>
    0.00 :   c89b3:  mov    0xc8996(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c89ba:  mov    (%rax),%rax
    0.00 :   c89bd:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c89c7:  test   %rcx,%rax
    0.00 :   c89ca:  jne    c8fc4 <std::sys::backtrace::__rust_begin_short_backtrace+0x2e54>
    0.00 :   c89d0:  xor    %eax,%eax
    0.00 :   c89d2:  xchg   %eax,(%r15)
    0.00 :   c89d5:  cmp    $0x2,%eax
    0.00 :   c89d8:  je     c8f7b <std::sys::backtrace::__rust_begin_short_backtrace+0x2e0b>
    0.00 :   c89de:  lea    0x100(%rsp),%rdi
    0.00 :   c89e6:  call   d4f70 <core::ptr::drop_in_place<alloc::collections::btree::map::BTreeMap<u64,zio::registration::Registration>>>
    0.00 :   c89eb:  mov    %r14,%rax
    0.00 :   c89ee:  neg    %rax
    0.00 :   c89f1:  jo     c8c54 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ae4>
    0.00 :   c89f7:  movabs $0x8000000000000001,%rax
    0.00 :   c8a01:  cmp    %rax,%r14
    0.00 :   c8a04:  jne    c8a61 <std::sys::backtrace::__rust_begin_short_backtrace+0x28f1>
    0.00 :   c8a06:  movdqa 0x20(%rsp),%xmm0
    0.00 :   c8a0c:  movq   %xmm0,%rsi
    0.00 :   c8a11:  pshufd $0xee,%xmm0,%xmm0
    0.00 :   c8a16:  movq   %xmm0,%rdx
    0.00 :   c8a1b:  mov    $0x1,%bpl
    0.00 :   c8a1e:  lea    0x198(%rsp),%rdi
    0.00 :   c8a26:  call   *0xc94ec(%rip)        # 191f18 <_DYNAMIC+0x1158>
    0.00 :   c8a2c:  mov    0x80(%rsp),%r13
    0.00 :   c8a34:  add    $0x10,%r13
    0.00 :   c8a38:  mov    0x1a0(%rsp),%r14
    0.00 :   c8a40:  mov    0x1a8(%rsp),%r12
    0.00 :   c8a48:  test   %r12,%r12
    0.00 :   c8a4b:  jns    c8a99 <std::sys::backtrace::__rust_begin_short_backtrace+0x2929>
    0.00 :   c8a4d:  xor    %r15d,%r15d
    0.00 :   c8a50:  mov    %r15,%rdi
    0.00 :   c8a53:  mov    %r12,%rsi
    0.00 :   c8a56:  call   *0xc855c(%rip)        # 190fb8 <_DYNAMIC+0x1f8>
    0.00 :   c8a5c:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8a61:  mov    0x80(%rsp),%rdi
    0.00 :   c8a69:  add    $0x10,%rdi
    0.00 :   c8a6d:  mov    %r14,0x198(%rsp)
    0.00 :   c8a75:  movdqa 0x20(%rsp),%xmm0
    0.00 :   c8a7b:  movdqu %xmm0,0x1a0(%rsp)
    0.00 :   c8a84:  mov    $0x1,%bpl
    0.00 :   c8a87:  lea    0x198(%rsp),%rsi
    0.00 :   c8a8f:  call   12fe40 <vthread::readiness::Inner::close>
    0.00 :   c8a94:  jmp    c8c54 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ae4>
    0.00 :   c8a99:  je     c8c13 <std::sys::backtrace::__rust_begin_short_backtrace+0x2aa3>
    0.00 :   c8a9f:  mov    $0x1,%r15d
    0.00 :   c8aa5:  mov    $0x1,%esi
    0.00 :   c8aaa:  mov    %r12,%rdi
    0.00 :   c8aad:  call   527c0 <__rustc::__rust_alloc>
    0.00 :   c8ab2:  test   %rax,%rax
    0.00 :   c8ab5:  je     c8a50 <std::sys::backtrace::__rust_begin_short_backtrace+0x28e0>
    0.00 :   c8ab7:  mov    %rax,%rbp
    0.00 :   c8aba:  mov    %rax,%rdi
    0.00 :   c8abd:  mov    %r14,%rsi
    0.00 :   c8ac0:  mov    %r12,%rdx
    0.00 :   c8ac3:  call   *0xc850f(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   c8ac9:  jmp    c8c18 <std::sys::backtrace::__rust_begin_short_backtrace+0x2aa8>
    0.00 :   c8ace:  movq   $0x0,0x50(%rsp)
    0.00 :   c8ad7:  movb   $0x4,0x68(%rsp)
    0.00 :   c8adc:  jmp    c8afb <std::sys::backtrace::__rust_begin_short_backtrace+0x298b>
    0.00 :   c8ade:  mov    0x1a0(%rsp),%rax
    0.00 :   c8ae6:  movq   $0x0,0x50(%rsp)
    0.00 :   c8aef:  movw   $0x300,0x68(%rsp)
    0.00 :   c8af6:  mov    %rax,0x70(%rsp)
    0.00 :   c8afb:  mov    0x50(%rsp),%rax
    0.00 :   c8b00:  mov    0x58(%rsp),%rcx
    0.00 :   c8b05:  mov    0x60(%rsp),%rdx
    0.00 :   c8b0a:  movzbl 0x68(%rsp),%esi
    0.00 :   c8b0f:  mov    0x69(%rsp),%edi
    0.00 :   c8b13:  movzwl 0x6d(%rsp),%r8d
    0.00 :   c8b19:  movzbl 0x6f(%rsp),%r9d
    0.00 :   c8b1f:  mov    0x70(%rsp),%r10
    0.00 :   c8b24:  mov    %r10,0xb0(%rsp)
    0.00 :   c8b2c:  mov    0x78(%rsp),%r10
    0.00 :   c8b31:  mov    %r10,0xb8(%rsp)
    0.00 :   c8b39:  mov    %rdx,0xa0(%rsp)
    0.00 :   c8b41:  mov    %sil,0xa8(%rsp)
    0.00 :   c8b49:  mov    %edi,0xa9(%rsp)
    0.00 :   c8b50:  mov    %r8w,0xad(%rsp)
    0.00 :   c8b59:  mov    %r9b,0xaf(%rsp)
    0.00 :   c8b61:  mov    %rax,0x90(%rsp)
    0.00 :   c8b69:  mov    %rcx,0x98(%rsp)
    0.00 :   c8b71:  movq   $0x0,0x180(%rsp)
    0.00 :   c8b7d:  movq   $0x1,0x188(%rsp)
    0.00 :   c8b89:  movq   $0x0,0x190(%rsp)
    0.00 :   c8b95:  movq   $0x60000020,0x130(%rsp)
    0.00 :   c8ba1:  lea    0x180(%rsp),%rax
    0.00 :   c8ba9:  mov    %rax,0x120(%rsp)
    0.00 :   c8bb1:  lea    0xc3a20(%rip),%rax        # 18c5d8 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0xe8>
    0.00 :   c8bb8:  mov    %rax,0x128(%rsp)
    0.00 :   c8bc0:  lea    0xa8(%rsp),%rdi
    0.00 :   c8bc8:  lea    0x120(%rsp),%rsi
    0.00 :   c8bd0:  call   *0xc93ca(%rip)        # 191fa0 <_DYNAMIC+0x11e0>
    0.00 :   c8bd6:  test   %al,%al
    0.00 :   c8bd8:  jne    c901f <std::sys::backtrace::__rust_begin_short_backtrace+0x2eaf>
    0.00 :   c8bde:  mov    0x180(%rsp),%r14
    0.00 :   c8be6:  movups 0x188(%rsp),%xmm0
    0.00 :   c8bee:  movaps %xmm0,0x20(%rsp)
    0.00 :   c8bf3:  cmpb   $0x1,0xa8(%rsp)
    0.00 :   c8bfb:  ja     c89a1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2831>
    0.00 :   c8c01:  lea    0xb0(%rsp),%rdi
    0.00 :   c8c09:  call   d7530 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10013882635303053058>
    0.00 :   c8c0e:  jmp    c89a1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2831>
    0.00 :   c8c13:  mov    $0x1,%ebp
    0.00 :   c8c18:  mov    %r12,0x488(%rsp)
    0.00 :   c8c20:  mov    %rbp,0x490(%rsp)
    0.00 :   c8c28:  mov    %r12,0x498(%rsp)
    0.00 :   c8c30:  lea    0x488(%rsp),%rsi
    0.00 :   c8c38:  mov    %r13,%rdi
    0.00 :   c8c3b:  call   12fe40 <vthread::readiness::Inner::close>
    0.00 :   c8c40:  cmpq   $0x0,0x198(%rsp)
    0.00 :   c8c49:  je     c8c54 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ae4>
    0.00 :   c8c4b:  mov    %r14,%rdi
    0.00 :   c8c4e:  call   *0xc839c(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c8c54:  lea    0x198(%rsp),%rdi
    0.00 :   c8c5c:  lea    0x248(%rsp),%rsi
    0.00 :   c8c64:  mov    $0x88,%edx
    0.00 :   c8c69:  call   *0xc8369(%rip)        # 190fd8 <memcpy@GLIBC_2.14>
    0.00 :   c8c6f:  mov    0x218(%rsp),%edi
    0.00 :   c8c76:  call   *0xc8964(%rip)        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c8c7c:  mov    0x1b0(%rsp),%r15
    0.00 :   c8c84:  mov    0x1b8(%rsp),%r14
    0.00 :   c8c8c:  test   %r14,%r14
    0.00 :   c8c8f:  je     c8cbd <std::sys::backtrace::__rust_begin_short_backtrace+0x2b4d>
    0.00 :   c8c91:  lea    0xe(%r15),%r12
    0.00 :   c8c95:  jmp    c8ca0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2b30>
    0.00 :   c8c97:  add    $0x18,%r12
    0.00 :   c8c9b:  dec    %r14
    0.00 :   c8c9e:  je     c8cbd <std::sys::backtrace::__rust_begin_short_backtrace+0x2b4d>
    0.00 :   c8ca0:  mov    -0x6(%r12),%edi
    0.00 :   c8ca5:  cmpb   $0x2,(%r12)
    0.00 :   c8caa:  setne  %al
    0.00 :   c8cad:  test   %edi,%edi
    0.00 :   c8caf:  setns  %cl
    0.00 :   c8cb2:  and    %al,%cl
    0.00 :   c8cb4:  cmp    $0x1,%cl
    0.00 :   c8cb7:  jne    c8c97 <std::sys::backtrace::__rust_begin_short_backtrace+0x2b27>
    0.00 :   c8cb9:  call   *%rbx
    0.00 :   c8cbb:  jmp    c8c97 <std::sys::backtrace::__rust_begin_short_backtrace+0x2b27>
    0.00 :   c8cbd:  cmpq   $0x0,0x1a8(%rsp)
    0.00 :   c8cc6:  je     c8cd1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2b61>
    0.00 :   c8cc8:  mov    %r15,%rdi
    0.00 :   c8ccb:  call   *0xc831f(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c8cd1:  mov    0x1e0(%rsp),%rax
    0.00 :   c8cd9:  lock decq (%rax)
    0.00 :   c8cdd:  jne    c8cef <std::sys::backtrace::__rust_begin_short_backtrace+0x2b7f>
    0.00 :   c8cdf:  lea    0x1e0(%rsp),%rdi
    0.00 :   c8ce7:  xor    %ebp,%ebp
    0.00 :   c8ce9:  call   *0xc9261(%rip)        # 191f50 <_DYNAMIC+0x1190>
    0.00 :   c8cef:  mov    0x80(%rsp),%rbx
    0.00 :   c8cf7:  movq   $0x0,0x70(%rbx)
    0.00 :   c8cff:  cmpq   $0x0,0x330(%rsp)
    0.00 :   c8d08:  je     c8d18 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ba8>
    0.00 :   c8d0a:  mov    0x338(%rsp),%rdi
    0.00 :   c8d12:  call   *0xc82d8(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c8d18:  lock decq (%rbx)
    0.00 :   c8d1c:  jne    c8d2c <std::sys::backtrace::__rust_begin_short_backtrace+0x2bbc>
    0.00 :   c8d1e:  lea    0x328(%rsp),%rdi
    0.00 :   c8d26:  call   *0xc921c(%rip)        # 191f48 <_DYNAMIC+0x1188>
    0.00 :   c8d2c:  mov    0x3e0(%rsp),%rax
    0.00 :   c8d34:  cmp    %rax,0x3e8(%rsp)
    0.00 :   c8d3c:  je     c6360 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c8d42:  lock decq (%rbx)
    0.00 :   c8d46:  jne    c6360 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c8d4c:  lea    0x320(%rsp),%rdi
    0.00 :   c8d54:  call   *0xc91ee(%rip)        # 191f48 <_DYNAMIC+0x1188>
    0.00 :   c8d5a:  jmp    c6360 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   c8d5f:  jmp    c89a1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2831>
    0.00 :   c8d64:  lea    0x98(%rsp),%rcx
    0.00 :   c8d6c:  mov    0x10(%rcx),%rax
    0.00 :   c8d70:  mov    %rax,0x170(%rsp)
    0.00 :   c8d78:  movups (%rcx),%xmm0
    0.00 :   c8d7b:  movaps %xmm0,0x160(%rsp)
    0.00 :   c8d83:  movq   $0x0,0x180(%rsp)
    0.00 :   c8d8f:  movq   $0x1,0x188(%rsp)
    0.00 :   c8d9b:  movq   $0x0,0x190(%rsp)
    0.00 :   c8da7:  movq   $0x60000020,0x60(%rsp)
    0.00 :   c8db0:  lea    0x180(%rsp),%rax
    0.00 :   c8db8:  mov    %rax,0x50(%rsp)
    0.00 :   c8dbd:  lea    0xc3814(%rip),%rax        # 18c5d8 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0xe8>
    0.00 :   c8dc4:  mov    %rax,0x58(%rsp)
    0.00 :   c8dc9:  lea    0x160(%rsp),%rdi
    0.00 :   c8dd1:  lea    0x50(%rsp),%rsi
    0.00 :   c8dd6:  call   *0xc91c4(%rip)        # 191fa0 <_DYNAMIC+0x11e0>
    0.00 :   c8ddc:  test   %al,%al
    0.00 :   c8dde:  jne    c9105 <std::sys::backtrace::__rust_begin_short_backtrace+0x2f95>
    0.00 :   c8de4:  mov    0x180(%rsp),%r14
    0.00 :   c8dec:  movups 0x188(%rsp),%xmm0
    0.00 :   c8df4:  movaps %xmm0,0x20(%rsp)
    0.00 :   c8df9:  cmpb   $0x1,0x160(%rsp)
    0.00 :   c8e01:  ja     c89de <std::sys::backtrace::__rust_begin_short_backtrace+0x286e>
    0.00 :   c8e07:  lea    0x168(%rsp),%rdi
    0.00 :   c8e0f:  call   d7530 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10013882635303053058>
    0.00 :   c8e14:  jmp    c89de <std::sys::backtrace::__rust_begin_short_backtrace+0x286e>
    0.00 :   c8e19:  mov    %rax,0x90(%rsp)
    0.00 :   c8e21:  lea    0x128(%rsp),%rax
    0.00 :   c8e29:  movups (%rax),%xmm0
    0.00 :   c8e2c:  movups 0x10(%rax),%xmm1
    0.00 :   c8e30:  movups %xmm0,0x98(%rsp)
    0.00 :   c8e38:  movups %xmm1,0xa8(%rsp)
    0.00 :   c8e40:  lea    0x50(%rsp),%rdi
    0.00 :   c8e45:  lea    0x90(%rsp),%rsi
    0.00 :   c8e4d:  call   d36a0 <<T as alloc::string::SpecToString>::spec_to_string>
    0.00 :   c8e52:  mov    0x50(%rsp),%r14
    0.00 :   c8e57:  movups 0x58(%rsp),%xmm0
    0.00 :   c8e5c:  movaps %xmm0,0x20(%rsp)
    0.00 :   c8e61:  lea    0x90(%rsp),%rdi
    0.00 :   c8e69:  call   da080 <core::ptr::drop_in_place<zio::error::recovery::RecoveryFailure>>
    0.00 :   c8e6e:  jmp    c89de <std::sys::backtrace::__rust_begin_short_backtrace+0x286e>
    0.00 :   c8e73:  lea    0xc3cfe(%rip),%rcx        # 18cb78 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x518>
    0.00 :   c8e7a:  mov    $0xb,%edx
    0.00 :   c8e7f:  xor    %edi,%edi
    0.00 :   c8e81:  mov    %r15,%rsi
    0.00 :   c8e84:  call   *0xc8296(%rip)        # 191120 <_DYNAMIC+0x360>
    0.00 :   c8e8a:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8e8f:  lea    0xc3cfa(%rip),%rcx        # 18cb90 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x530>
    0.00 :   c8e96:  mov    %rdx,%rsi
    0.00 :   c8e99:  mov    $0xc,%edx
    0.00 :   c8e9e:  xor    %edi,%edi
    0.00 :   c8ea0:  call   *0xc827a(%rip)        # 191120 <_DYNAMIC+0x360>
    0.00 :   c8ea6:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8eab:  mov    $0x8,%edi
    0.00 :   c8eb0:  mov    %r15,%rsi
    0.00 :   c8eb3:  call   *0xc8177(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   c8eb9:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8ebe:  mov    $0x35,%esi
    0.00 :   c8ec3:  lea    -0xab70f(%rip),%rax        # 1d7bb <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x453>
    0.00 :   c8eca:  mov    %rax,0x308(%rsp)
    0.00 :   c8ed2:  lea    0xc3ccf(%rip),%rax        # 18cba8 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x548>
    0.00 :   c8ed9:  mov    %rax,0x310(%rsp)
    0.00 :   c8ee1:  mov    0x308(%rsp),%rdi
    0.00 :   c8ee9:  mov    0x310(%rsp),%rdx
    0.00 :   c8ef1:  call   *0xc81e9(%rip)        # 1910e0 <_DYNAMIC+0x320>
    0.00 :   c8ef7:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8efc:  lea    -0xab770(%rip),%rdi        # 1d793 <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x42b>
    0.00 :   c8f03:  lea    0xc3c56(%rip),%rdx        # 18cb60 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x500>
    0.00 :   c8f0a:  mov    $0x28,%esi
    0.00 :   c8f0f:  call   *0xc81cb(%rip)        # 1910e0 <_DYNAMIC+0x320>
    0.00 :   c8f15:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8f1a:  lea    0x1a8(%rsp),%r15
    0.00 :   c8f22:  mov    $0x8,%edi
    0.00 :   c8f27:  mov    $0x78,%esi
    0.00 :   c8f2c:  call   *0xc80fe(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   c8f32:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8f37:  lea    -0xab7cc(%rip),%rdi        # 1d772 <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x40a>
    0.00 :   c8f3e:  lea    0xc3c03(%rip),%rdx        # 18cb48 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x4e8>
    0.00 :   c8f45:  mov    $0x21,%esi
    0.00 :   c8f4a:  call   *0xc8190(%rip)        # 1910e0 <_DYNAMIC+0x320>
    0.00 :   c8f50:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8f55:  mov    $0xb,%r13b
    0.00 :   c8f58:  xor    %eax,%eax
    0.00 :   c8f5a:  jmp    c88aa <std::sys::backtrace::__rust_begin_short_backtrace+0x273a>
    0.00 :   c8f5f:  lea    0xc3c12(%rip),%rcx        # 18cb78 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x518>
    0.00 :   c8f66:  mov    $0xb,%edx
    0.00 :   c8f6b:  xor    %edi,%edi
    0.00 :   c8f6d:  mov    %r15,%rsi
    0.00 :   c8f70:  call   *0xc81aa(%rip)        # 191120 <_DYNAMIC+0x360>
    0.00 :   c8f76:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8f7b:  mov    $0xca,%edi
    0.00 :   c8f80:  mov    %r15,%rsi
    0.00 :   c8f83:  mov    $0x81,%edx
    0.00 :   c8f88:  mov    $0x1,%ecx
    0.00 :   c8f8d:  xor    %eax,%eax
    0.00 :   c8f8f:  call   *0xc83eb(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   c8f95:  jmp    c89de <std::sys::backtrace::__rust_begin_short_backtrace+0x286e>
    0.00 :   c8f9a:  lea    -0xabbc6(%rip),%rdi        # 1d3db <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x73>
    0.00 :   c8fa1:  lea    0xc36d8(%rip),%rcx        # 18c680 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x20>
    0.00 :   c8fa8:  lea    0xc3659(%rip),%r8        # 18c608 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0x118>
    0.00 :   c8faf:  lea    0x1f(%rsp),%rdx
    0.00 :   c8fb4:  mov    $0x37,%esi
    0.00 :   c8fb9:  call   *0xc8069(%rip)        # 191028 <_DYNAMIC+0x268>
    0.00 :   c8fbf:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8fc4:  call   *0xc83a6(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c8fca:  test   %al,%al
    0.00 :   c8fcc:  jne    c89d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2860>
    0.00 :   c8fd2:  movb   $0x1,0x4(%r15)
    0.00 :   c8fd7:  jmp    c89d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x2860>
    0.00 :   c8fdc:  lea    0xc3aed(%rip),%rdi        # 18cad0 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x470>
    0.00 :   c8fe3:  call   *0xc81cf(%rip)        # 1911b8 <_DYNAMIC+0x3f8>
    0.00 :   c8fe9:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c8fee:  mov    $0x8,%edi
    0.00 :   c8ff3:  mov    $0x178,%esi
    0.00 :   c8ff8:  call   *0xc8032(%rip)        # 191030 <_DYNAMIC+0x270>
    0.00 :   c8ffe:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c9003:  lea    0xc3b0e(%rip),%rdi        # 18cb18 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x4b8>
    0.00 :   c900a:  call   *0xc81a8(%rip)        # 1911b8 <_DYNAMIC+0x3f8>
    0.00 :   c9010:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c9015:  mov    $0x30,%esi
    0.00 :   c901a:  jmp    c8ee1 <std::sys::backtrace::__rust_begin_short_backtrace+0x2d71>
    0.00 :   c901f:  lea    -0xabc4b(%rip),%rdi        # 1d3db <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x73>
    0.00 :   c9026:  lea    0xc3653(%rip),%rcx        # 18c680 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x20>
    0.00 :   c902d:  lea    0xc35d4(%rip),%r8        # 18c608 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0x118>
    0.00 :   c9034:  lea    0x1f(%rsp),%rdx
    0.00 :   c9039:  mov    $0x37,%esi
    0.00 :   c903e:  call   *0xc7fe4(%rip)        # 191028 <_DYNAMIC+0x268>
    0.00 :   c9044:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c9049:  lea    0xc3c48(%rip),%rdi        # 18cc98 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x638>
    0.00 :   c9050:  call   *0xc8162(%rip)        # 1911b8 <_DYNAMIC+0x3f8>
    0.00 :   c9056:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c905b:  mov    0x38(%rsp),%rax
    0.00 :   c9060:  mov    %rax,0x90(%rsp)
    0.00 :   c9068:  mov    0x30(%rsp),%eax
    0.00 :   c906c:  mov    %al,0x98(%rsp)
    0.00 :   c9073:  test   %al,%al
    0.00 :   c9075:  je     c9168 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ff8>
    0.00 :   c907b:  movzbl 0x30(%rsp),%eax
    0.00 :   c9080:  cmp    $0x1,%eax
    0.00 :   c9083:  jne    c90c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x2f56>
    0.00 :   c9085:  cmpl   $0xffffffff,0x10(%rbp)
    0.00 :   c9089:  je     c912c <std::sys::backtrace::__rust_begin_short_backtrace+0x2fbc>
    0.00 :   c908f:  mov    0x8(%rbp),%edi
    0.00 :   c9092:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c9096:  setne  %al
    0.00 :   c9099:  test   %edi,%edi
    0.00 :   c909b:  setns  %cl
    0.00 :   c909e:  and    %al,%cl
    0.00 :   c90a0:  cmp    $0x1,%cl
    0.00 :   c90a3:  jne    c90ab <std::sys::backtrace::__rust_begin_short_backtrace+0x2f3b>
    0.00 :   c90a5:  call   *0xc8535(%rip)        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c90ab:  movb   $0x2,0xe(%rbp)
    0.00 :   c90af:  mov    0x280(%rsp),%eax
    0.00 :   c90b6:  mov    %eax,0x14(%rbp)
    0.00 :   c90b9:  mov    %r13d,0x280(%rsp)
    0.00 :   c90c1:  jmp    c9168 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ff8>
    0.00 :   c90c6:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c90ca:  jne    c90ff <std::sys::backtrace::__rust_begin_short_backtrace+0x2f8f>
    0.00 :   c90cc:  lea    0x90(%rsp),%rdi
    0.00 :   c90d4:  call   d7530 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10013882635303053058>
    0.00 :   c90d9:  mov    $0xb,%r13b
    0.00 :   c90dc:  jmp    c916b <std::sys::backtrace::__rust_begin_short_backtrace+0x2ffb>
    0.00 :   c90e1:  lea    -0xaa292(%rip),%rdi        # 1ee56 <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058+0x2e1>
    0.00 :   c90e8:  lea    0xc5161(%rip),%rdx        # 18e250 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x360>
    0.00 :   c90ef:  mov    $0xd,%esi
    0.00 :   c90f4:  call   *0xc80ee(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   c90fa:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c90ff:  movb   $0x2,0xd(%rbp)
    0.00 :   c9103:  jmp    c9168 <std::sys::backtrace::__rust_begin_short_backtrace+0x2ff8>
    0.00 :   c9105:  lea    -0xabd31(%rip),%rdi        # 1d3db <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0x73>
    0.00 :   c910c:  lea    0xc356d(%rip),%rcx        # 18c680 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x20>
    0.00 :   c9113:  lea    0xc34ee(%rip),%r8        # 18c608 <anon.cccb389264607a2d4c2b49e143c9c1b6.154.llvm.10013882635303053058+0x118>
    0.00 :   c911a:  lea    0x1f(%rsp),%rdx
    0.00 :   c911f:  mov    $0x37,%esi
    0.00 :   c9124:  call   *0xc7efe(%rip)        # 191028 <_DYNAMIC+0x268>
    0.00 :   c912a:  jmp    c9190 <std::sys::backtrace::__rust_begin_short_backtrace+0x3020>
    0.00 :   c912c:  mov    0x278(%rsp),%r14
    0.00 :   c9134:  inc    %r14
    0.00 :   c9137:  je     c90cc <std::sys::backtrace::__rust_begin_short_backtrace+0x2f5c>
    0.00 :   c9139:  mov    0x8(%rbp),%edi
    0.00 :   c913c:  cmpb   $0x2,0xe(%rbp)
    0.00 :   c9140:  setne  %al
    0.00 :   c9143:  test   %edi,%edi
    0.00 :   c9145:  setns  %cl
    0.00 :   c9148:  and    %al,%cl
    0.00 :   c914a:  cmp    $0x1,%cl
    0.00 :   c914d:  jne    c9155 <std::sys::backtrace::__rust_begin_short_backtrace+0x2fe5>
    0.00 :   c914f:  call   *0xc848b(%rip)        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c9155:  movb   $0x2,0xe(%rbp)
    0.00 :   c9159:  movl   $0xffffffff,0x14(%rbp)
    0.00 :   c9160:  mov    %r14,0x278(%rsp)
    0.00 :   c9168:  mov    $0x1,%r13b
    0.00 :   c916b:  mov    $0x5,%eax
    0.00 :   c9170:  xor    %ecx,%ecx
    0.00 :   c9172:  mov    0x30(%rsp),%edx
    0.00 :   c9176:  mov    0x38(%rsp),%rsi
    0.00 :   c917b:  jmp    c88ac <std::sys::backtrace::__rust_begin_short_backtrace+0x273c>
    0.00 :   c9180:  mov    $0x8,%edi
    0.00 :   c9185:  mov    $0x20,%esi
    0.00 :   c918a:  call   *0xc7e28(%rip)        # 190fb8 <_DYNAMIC+0x1f8>
    0.00 :   c9190:  ud2
    0.00 :   c9192:  jmp    c91e6 <std::sys::backtrace::__rust_begin_short_backtrace+0x3076>
    0.00 :   c9194:  jmp    c91fe <std::sys::backtrace::__rust_begin_short_backtrace+0x308e>
    0.00 :   c9196:  mov    %rax,%rbp
    0.00 :   c9199:  cmpq   $0x0,0x50(%rsp)
    0.00 :   c919f:  je     c9288 <std::sys::backtrace::__rust_begin_short_backtrace+0x3118>
    0.00 :   c91a5:  jmp    c922d <std::sys::backtrace::__rust_begin_short_backtrace+0x30bd>
    0.00 :   c91aa:  mov    %rax,%rbp
    0.00 :   c91ad:  jmp    c9288 <std::sys::backtrace::__rust_begin_short_backtrace+0x3118>
    0.00 :   c91b2:  jmp    c91e6 <std::sys::backtrace::__rust_begin_short_backtrace+0x3076>
    0.00 :   c91b4:  jmp    c91e6 <std::sys::backtrace::__rust_begin_short_backtrace+0x3076>
    0.00 :   c91b6:  mov    %rax,%rbp
    0.00 :   c91b9:  lea    0x90(%rsp),%rdi
    0.00 :   c91c1:  call   da080 <core::ptr::drop_in_place<zio::error::recovery::RecoveryFailure>>
    0.00 :   c91c6:  jmp    c9478 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c91cb:  jmp    c91fe <std::sys::backtrace::__rust_begin_short_backtrace+0x308e>
    0.00 :   c91cd:  mov    %rax,%rbp
    0.00 :   c91d0:  jmp    c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c91d5:  jmp    c91e6 <std::sys::backtrace::__rust_begin_short_backtrace+0x3076>
    0.00 :   c91d7:  mov    %rax,%r13
    0.00 :   c91da:  jmp    c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c91df:  mov    %rax,%r13
    0.00 :   c91e2:  jmp    c9254 <std::sys::backtrace::__rust_begin_short_backtrace+0x30e4>
    0.00 :   c91e4:  jmp    c91fe <std::sys::backtrace::__rust_begin_short_backtrace+0x308e>
    0.00 :   c91e6:  mov    %rax,%rbp
    0.00 :   c91e9:  jmp    c9478 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c91ee:  mov    %rax,%rbp
    0.00 :   c91f1:  jmp    c9485 <std::sys::backtrace::__rust_begin_short_backtrace+0x3315>
    0.00 :   c91f6:  mov    %rax,%r13
    0.00 :   c91f9:  jmp    c9500 <std::sys::backtrace::__rust_begin_short_backtrace+0x3390>
    0.00 :   c91fe:  mov    %rax,%rbp
    0.00 :   c9201:  test   %r15d,%r15d
    0.00 :   c9204:  js     c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c920a:  mov    %r15d,%edi
    0.00 :   c920d:  call   *0xc83cd(%rip)        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c9213:  jmp    c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c9218:  mov    %rax,%rbp
    0.00 :   c921b:  jmp    c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c9220:  mov    %rax,%r13
    0.00 :   c9223:  mov    $0x1,%bl
    0.00 :   c9225:  jmp    c93e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3270>
    0.00 :   c922a:  mov    %rax,%rbp
    0.00 :   c922d:  lea    0x50(%rsp),%rdi
    0.00 :   c9232:  call   d8010 <core::ptr::drop_in_place<vthread::readiness::Entry>>
    0.00 :   c9237:  jmp    c9288 <std::sys::backtrace::__rust_begin_short_backtrace+0x3118>
    0.00 :   c9239:  mov    %rax,%r13
    0.00 :   c923c:  mov    0x20(%rsp),%rdi
    0.00 :   c9241:  call   *0xc7da9(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c9247:  lea    0x400(%rsp),%rdi
    0.00 :   c924f:  call   d7340 <core::ptr::drop_in_place<zio::poll::Poll>>
    0.00 :   c9254:  mov    0x80(%rsp),%rax
    0.00 :   c925c:  lock decq (%rax)
    0.00 :   c9260:  jne    c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9266:  lea    0x320(%rsp),%rdi
    0.00 :   c926e:  call   *0xc8cd4(%rip)        # 191f48 <_DYNAMIC+0x1188>
    0.00 :   c9274:  jmp    c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9279:  mov    %rbp,%rdi
    0.00 :   c927c:  mov    %rax,%rbp
    0.00 :   c927f:  movzbl %r12b,%esi
    0.00 :   c9283:  call   d4e30 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::thread_failure::ThreadFailures>>>
    0.00 :   c9288:  lea    0x120(%rsp),%rdi
    0.00 :   c9290:  call   d8cd0 <core::ptr::drop_in_place<zio::wait_report::WaitReport>>
    0.00 :   c9295:  jmp    c9478 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c929a:  jmp    c93c1 <std::sys::backtrace::__rust_begin_short_backtrace+0x3251>
    0.00 :   c929f:  mov    %rax,%r13
    0.00 :   c92a2:  mov    $0x1,%bl
    0.00 :   c92a4:  jmp    c93eb <std::sys::backtrace::__rust_begin_short_backtrace+0x327b>
    0.00 :   c92a9:  mov    %rax,%rbp
    0.00 :   c92ac:  cmpq   $0x0,0x180(%rsp)
    0.00 :   c92b5:  je     c92c5 <std::sys::backtrace::__rust_begin_short_backtrace+0x3155>
    0.00 :   c92b7:  mov    0x188(%rsp),%rdi
    0.00 :   c92bf:  call   *0xc7d2b(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c92c5:  cmpb   $0x1,0x160(%rsp)
    0.00 :   c92cd:  ja     c9478 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c92d3:  lea    0x168(%rsp),%rdi
    0.00 :   c92db:  call   d7530 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10013882635303053058>
    0.00 :   c92e0:  jmp    c9478 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c92e5:  mov    %rax,%rbp
    0.00 :   c92e8:  cmpq   $0x0,0x50(%rsp)
    0.00 :   c92ee:  je     c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c92f4:  mov    0x58(%rsp),%rdi
    0.00 :   c92f9:  jmp    c943d <std::sys::backtrace::__rust_begin_short_backtrace+0x32cd>
    0.00 :   c92fe:  ud2
    0.00 :   c9300:  mov    %rax,%rbp
    0.00 :   c9303:  cmpq   $0x0,0x180(%rsp)
    0.00 :   c930c:  je     c931c <std::sys::backtrace::__rust_begin_short_backtrace+0x31ac>
    0.00 :   c930e:  mov    0x188(%rsp),%rdi
    0.00 :   c9316:  call   *0xc7cd4(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c931c:  cmpb   $0x1,0xa8(%rsp)
    0.00 :   c9324:  ja     c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c932a:  lea    0xb0(%rsp),%rdi
    0.00 :   c9332:  call   d7530 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10013882635303053058>
    0.00 :   c9337:  jmp    c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c933c:  call   *0xc7ebe(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   c9342:  mov    %rax,%r13
    0.00 :   c9345:  cmp    $0xffffffffffffffff,%r12
    0.00 :   c9349:  je     c935c <std::sys::backtrace::__rust_begin_short_backtrace+0x31ec>
    0.00 :   c934b:  lock decq 0x8(%r12)
    0.00 :   c9351:  jne    c935c <std::sys::backtrace::__rust_begin_short_backtrace+0x31ec>
    0.00 :   c9353:  mov    %r12,%rdi
    0.00 :   c9356:  call   *0xc7c94(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c935c:  mov    (%rbx),%rdi
    0.00 :   c935f:  mov    0x8(%rbx),%rsi
    0.00 :   c9363:  call   d6090 <core::ptr::drop_in_place<std::sync::mpsc::SyncSender<core::result::Result<alloc::sync::Arc<vthread::readiness::Inner>,vthread::error::Error>>>>
    0.00 :   c9368:  jmp    c95a1 <std::sys::backtrace::__rust_begin_short_backtrace+0x3431>
    0.00 :   c936d:  call   *0xc7e8d(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   c9373:  mov    %r15,%rdi
    0.00 :   c9376:  call   *0xc7c74(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c937c:  ud2
    0.00 :   c937e:  ud2
    0.00 :   c9380:  mov    %rax,%r13
    0.00 :   c9383:  jmp    c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9388:  mov    %rax,%rbp
    0.00 :   c938b:  cmpq   $0x0,0x120(%rsp)
    0.00 :   c9394:  je     c93a4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3234>
    0.00 :   c9396:  mov    0x128(%rsp),%rdi
    0.00 :   c939e:  call   *0xc7c4c(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c93a4:  cmp    $0x1,%r13b
    0.00 :   c93a8:  ja     c93c4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3254>
    0.00 :   c93aa:  mov    %r14,%rdi
    0.00 :   c93ad:  call   d7530 <_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17hf1011eac274d9e3fE.llvm.10013882635303053058>
    0.00 :   c93b2:  jmp    c93c4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3254>
    0.00 :   c93b4:  call   *0xc7e46(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   c93ba:  mov    %rax,%r13
    0.00 :   c93bd:  jmp    c9400 <std::sys::backtrace::__rust_begin_short_backtrace+0x3290>
    0.00 :   c93bf:  jmp    c9437 <std::sys::backtrace::__rust_begin_short_backtrace+0x32c7>
    0.00 :   c93c1:  mov    %rax,%rbp
    0.00 :   c93c4:  cmpq   $0x0,0x8(%rsp)
    0.00 :   c93ca:  je     c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c93cc:  mov    0x10(%rsp),%rdi
    0.00 :   c93d1:  jmp    c943d <std::sys::backtrace::__rust_begin_short_backtrace+0x32cd>
    0.00 :   c93d3:  mov    %rax,%r13
    0.00 :   c93d6:  mov    %r15,%rdi
    0.00 :   c93d9:  call   d8040 <core::ptr::drop_in_place<vthread::readiness::Inner>>
    0.00 :   c93de:  xor    %ebx,%ebx
    0.00 :   c93e0:  mov    0x20(%rsp),%rdi
    0.00 :   c93e5:  call   *0xc7c05(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c93eb:  lea    0x248(%rsp),%rdi
    0.00 :   c93f3:  call   d7340 <core::ptr::drop_in_place<zio::poll::Poll>>
    0.00 :   c93f8:  test   %bl,%bl
    0.00 :   c93fa:  je     c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9400:  cmp    $0xffffffffffffffff,%r12
    0.00 :   c9404:  je     c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c940a:  lock decq 0x8(%r12)
    0.00 :   c9410:  jne    c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9416:  mov    %r12,%rdi
    0.00 :   c9419:  call   *0xc7bd1(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c941f:  jmp    c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c9424:  call   *0xc7dd6(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   c942a:  call   *0xc7dd0(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   c9430:  jmp    c9437 <std::sys::backtrace::__rust_begin_short_backtrace+0x32c7>
    0.00 :   c9432:  mov    %rax,%rbp
    0.00 :   c9435:  jmp    c9443 <std::sys::backtrace::__rust_begin_short_backtrace+0x32d3>
    0.00 :   c9437:  mov    %rax,%rbp
    0.00 :   c943a:  mov    %r12,%rdi
    0.00 :   c943d:  call   *0xc7bad(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c9443:  mov    0x160(%rsp),%r15
    0.00 :   c944b:  cmpb   $0x0,0x168(%rsp)
    0.00 :   c9453:  jne    c946e <std::sys::backtrace::__rust_begin_short_backtrace+0x32fe>
    0.00 :   c9455:  mov    0xc7ef4(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c945c:  mov    (%rax),%rax
    0.00 :   c945f:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   c9469:  test   %rcx,%rax
    0.00 :   c946c:  jne    c94cf <std::sys::backtrace::__rust_begin_short_backtrace+0x335f>
    0.00 :   c946e:  xor    %eax,%eax
    0.00 :   c9470:  xchg   %eax,(%r15)
    0.00 :   c9473:  cmp    $0x2,%eax
    0.00 :   c9476:  je     c94b3 <std::sys::backtrace::__rust_begin_short_backtrace+0x3343>
    0.00 :   c9478:  lea    0x100(%rsp),%rdi
    0.00 :   c9480:  call   d4f70 <core::ptr::drop_in_place<alloc::collections::btree::map::BTreeMap<u64,zio::registration::Registration>>>
    0.00 :   c9485:  mov    %rbp,%rdi
    0.00 :   c9488:  call   *0xc834a(%rip)        # 1917d8 <_DYNAMIC+0xa18>
    0.00 :   c948e:  mov    %rax,%rsi
    0.00 :   c9491:  mov    0xc7eb8(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   c9498:  lock decq (%rax)
    0.00 :   c949c:  decq   %fs:0xffffffffffffff70
    0.00 :   c94a5:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   c94ae:  jmp    c8a1b <std::sys::backtrace::__rust_begin_short_backtrace+0x28ab>
    0.00 :   c94b3:  mov    $0xca,%edi
    0.00 :   c94b8:  mov    %r15,%rsi
    0.00 :   c94bb:  mov    $0x81,%edx
    0.00 :   c94c0:  mov    $0x1,%ecx
    0.00 :   c94c5:  xor    %eax,%eax
    0.00 :   c94c7:  call   *0xc7eb3(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   c94cd:  jmp    c9478 <std::sys::backtrace::__rust_begin_short_backtrace+0x3308>
    0.00 :   c94cf:  call   *0xc7e9b(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   c94d5:  test   %al,%al
    0.00 :   c94d7:  jne    c946e <std::sys::backtrace::__rust_begin_short_backtrace+0x32fe>
    0.00 :   c94d9:  movb   $0x1,0x4(%r15)
    0.00 :   c94de:  jmp    c946e <std::sys::backtrace::__rust_begin_short_backtrace+0x32fe>
    0.00 :   c94e0:  call   *0xc7d1a(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   c94e6:  mov    %rax,%r13
    0.00 :   c94e9:  mov    $0x1,%bpl
    0.00 :   c94ec:  cmpq   $0x0,0x198(%rsp)
    0.00 :   c94f5:  je     c9500 <std::sys::backtrace::__rust_begin_short_backtrace+0x3390>
    0.00 :   c94f7:  mov    %r14,%rdi
    0.00 :   c94fa:  call   *0xc7af0(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c9500:  cmpq   $0x0,0x330(%rsp)
    0.00 :   c9509:  je     c9519 <std::sys::backtrace::__rust_begin_short_backtrace+0x33a9>
    0.00 :   c950b:  mov    0x338(%rsp),%rdi
    0.00 :   c9513:  call   *0xc7ad7(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c9519:  test   %bpl,%bpl
    0.00 :   c951c:  je     c9570 <std::sys::backtrace::__rust_begin_short_backtrace+0x3400>
    0.00 :   c951e:  mov    0x2c8(%rsp),%edi
    0.00 :   c9525:  call   *0xc80b5(%rip)        # 1915e0 <close@GLIBC_2.2.5>
    0.00 :   c952b:  mov    0x260(%rsp),%r15
    0.00 :   c9533:  mov    0x268(%rsp),%r14
    0.00 :   c953b:  test   %r14,%r14
    0.00 :   c953e:  jne    c95a9 <std::sys::backtrace::__rust_begin_short_backtrace+0x3439>
    0.00 :   c9540:  cmpq   $0x0,0x258(%rsp)
    0.00 :   c9549:  je     c9554 <std::sys::backtrace::__rust_begin_short_backtrace+0x33e4>
    0.00 :   c954b:  mov    %r15,%rdi
    0.00 :   c954e:  call   *0xc7a9c(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   c9554:  mov    0x290(%rsp),%rax
    0.00 :   c955c:  lock decq (%rax)
    0.00 :   c9560:  jne    c9570 <std::sys::backtrace::__rust_begin_short_backtrace+0x3400>
    0.00 :   c9562:  lea    0x290(%rsp),%rdi
    0.00 :   c956a:  call   *0xc89e0(%rip)        # 191f50 <_DYNAMIC+0x1190>
    0.00 :   c9570:  mov    0x80(%rsp),%rax
    0.00 :   c9578:  lock decq (%rax)
    0.00 :   c957c:  jne    c958c <std::sys::backtrace::__rust_begin_short_backtrace+0x341c>
    0.00 :   c957e:  lea    0x328(%rsp),%rdi
    0.00 :   c9586:  call   *0xc89bc(%rip)        # 191f48 <_DYNAMIC+0x1188>
    0.00 :   c958c:  mov    0x238(%rsp),%rdi
    0.00 :   c9594:  mov    0x240(%rsp),%rsi
    0.00 :   c959c:  call   d6090 <core::ptr::drop_in_place<std::sync::mpsc::SyncSender<core::result::Result<alloc::sync::Arc<vthread::readiness::Inner>,vthread::error::Error>>>>
    0.00 :   c95a1:  mov    %r13,%rdi
    0.00 :   c95a4:  call   186a90 <_Unwind_Resume@plt>
    0.00 :   c95a9:  lea    0xe(%r15),%r12
    0.00 :   c95ad:  jmp    c95bd <std::sys::backtrace::__rust_begin_short_backtrace+0x344d>
    0.00 :   c95af:  nop
    0.00 :   c95b0:  add    $0x18,%r12
    0.00 :   c95b4:  dec    %r14
    0.00 :   c95b7:  je     c9540 <std::sys::backtrace::__rust_begin_short_backtrace+0x33d0>
    0.00 :   c95bd:  mov    -0x6(%r12),%edi
    0.00 :   c95c2:  cmpb   $0x2,(%r12)
    0.00 :   c95c7:  setne  %al
    0.00 :   c95ca:  test   %edi,%edi
    0.00 :   c95cc:  setns  %cl
    0.00 :   c95cf:  and    %al,%cl
    0.00 :   c95d1:  cmp    $0x1,%cl
    0.00 :   c95d4:  jne    c95b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3440>
    0.00 :   c95d6:  call   *%rbx
    0.00 :   c95d8:  jmp    c95b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3440>
    0.00 :   c95da:  call   *0xc7c20(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   c95e0:  call   *0xc7c1a(%rip)        # 191200 <_DYNAMIC+0x440>
 Percent |	Source code & Disassembly of baseline-benchmark for cycles:u (3 samples, percent: global period)
----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000cc1f0 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   cc1f0:  push   %rbp
    0.00 :   cc1f1:  push   %r15
    0.00 :   cc1f3:  push   %r14
    0.00 :   cc1f5:  push   %r13
    0.00 :   cc1f7:  push   %r12
    0.00 :   cc1f9:  push   %rbx
    0.00 :   cc1fa:  sub    $0xc8,%rsp
    0.00 :   cc201:  mov    %rdi,0x78(%rsp)
    0.00 :   cc206:  mov    (%rdi),%rbp
    0.00 :   cc209:  mov    0x8(%rdi),%rax
    0.00 :   cc20d:  mov    %rax,0x8(%rsp)
    0.00 :   cc212:  test   %rbp,%rbp
    0.00 :   cc215:  mov    %rbp,0x10(%rsp)
    0.00 :   cc21a:  je     cc576 <std::sys::backtrace::__rust_begin_short_backtrace+0x386>
    0.00 :   cc220:  cmp    $0x1,%ebp
    0.00 :   cc223:  jne    cc90e <std::sys::backtrace::__rust_begin_short_backtrace+0x71e>
    0.00 :   cc229:  movl   $0x3b9aca00,0x88(%rsp)
    0.00 :   cc234:  mov    %fs:0x0,%r14
    0.00 :   cc23d:  lea    -0x68(%r14),%r14
    0.00 :   cc244:  xorps  %xmm0,%xmm0
    0.00 :   cc247:  movaps %xmm0,0x30(%rsp)
    0.00 :   cc24c:  movaps %xmm0,0x20(%rsp)
    0.00 :   cc251:  movq   $0x0,0x40(%rsp)
    0.00 :   cc25a:  xor    %eax,%eax
    0.00 :   cc25c:  jmp    cc26a <std::sys::backtrace::__rust_begin_short_backtrace+0x7a>
    0.00 :   cc25e:  xchg   %ax,%ax
    0.00 :   cc260:  call   *0xc52ba(%rip)        # 191520 <sched_yield@GLIBC_2.2.5>
    0.00 :   cc266:  inc    %ebx
    0.00 :   cc268:  mov    %ebx,%eax
    0.00 :   cc26a:  mov    %eax,%ebx
    0.00 :   cc26c:  mov    0x8(%rsp),%rcx
    0.00 :   cc271:  mov    (%rcx),%rax
    0.00 :   cc274:  mov    0x8(%rcx),%r12
    0.00 :   cc278:  mov    %rax,%rcx
    0.00 :   cc27b:  shr    %rcx
    0.00 :   cc27e:  mov    %ecx,%r15d
    0.00 :   cc281:  and    $0x1f,%r15d
    0.00 :   cc285:  cmp    $0x1f,%r15
    0.00 :   cc289:  jne    cc2e0 <std::sys::backtrace::__rust_begin_short_backtrace+0xf0>
    0.00 :   cc28b:  cmp    $0x7,%ebx
    0.00 :   cc28e:  jae    cc260 <std::sys::backtrace::__rust_begin_short_backtrace+0x70>
    0.00 :   cc290:  test   %ebx,%ebx
    0.00 :   cc292:  je     cc266 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc294:  mov    %ebx,%ecx
    0.00 :   cc296:  imul   %ebx,%ecx
    0.00 :   cc299:  mov    %ecx,%eax
    0.00 :   cc29b:  and    $0x5,%eax
    0.00 :   cc29e:  cmp    $0x8,%ecx
    0.00 :   cc2a1:  jb     cc2d0 <std::sys::backtrace::__rust_begin_short_backtrace+0xe0>
    0.00 :   cc2a3:  and    $0x38,%ecx
    0.00 :   cc2a6:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cc2b0:  pause
    0.00 :   cc2b2:  pause
    0.00 :   cc2b4:  pause
    0.00 :   cc2b6:  pause
    0.00 :   cc2b8:  pause
    0.00 :   cc2ba:  pause
    0.00 :   cc2bc:  pause
    0.00 :   cc2be:  pause
    0.00 :   cc2c0:  add    $0xfffffff8,%ecx
    0.00 :   cc2c3:  jne    cc2b0 <std::sys::backtrace::__rust_begin_short_backtrace+0xc0>
    0.00 :   cc2c5:  test   %eax,%eax
    0.00 :   cc2c7:  je     cc266 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc2c9:  nopl   0x0(%rax)
    0.00 :   cc2d0:  pause
    0.00 :   cc2d2:  dec    %eax
    0.00 :   cc2d4:  jne    cc2d0 <std::sys::backtrace::__rust_begin_short_backtrace+0xe0>
    0.00 :   cc2d6:  jmp    cc266 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc2d8:  nopl   0x0(%rax,%rax,1)
    0.00 :   cc2e0:  lea    0x2(%rax),%r13
    0.00 :   cc2e4:  test   $0x1,%al
    0.00 :   cc2e6:  jne    cc318 <std::sys::backtrace::__rust_begin_short_backtrace+0x128>
    0.00 :   cc2e8:  lock orl $0x0,-0x40(%rsp)
    0.00 :   cc2ee:  mov    0x8(%rsp),%rdx
    0.00 :   cc2f3:  mov    0x80(%rdx),%rdx
    0.00 :   cc2fa:  mov    %rdx,%rsi
    0.00 :   cc2fd:  shr    %rsi
    0.00 :   cc300:  cmp    %rsi,%rcx
    0.00 :   cc303:  je     cc3e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1f0>
    0.00 :   cc309:  xor    %rax,%rdx
    0.00 :   cc30c:  xor    %ecx,%ecx
    0.00 :   cc30e:  cmp    $0x40,%rdx
    0.00 :   cc312:  setae  %cl
    0.00 :   cc315:  or     %rcx,%r13
    0.00 :   cc318:  test   %r12,%r12
    0.00 :   cc31b:  je     cc38b <std::sys::backtrace::__rust_begin_short_backtrace+0x19b>
    0.00 :   cc31d:  mov    0x8(%rsp),%rcx
    0.00 :   cc322:  lock cmpxchg %r13,(%rcx)
    0.00 :   cc327:  je     ccb55 <std::sys::backtrace::__rust_begin_short_backtrace+0x965>
    0.00 :   cc32d:  cmp    $0x6,%ebx
    0.00 :   cc330:  mov    $0x6,%ecx
    0.00 :   cc335:  cmovb  %ebx,%ecx
    0.00 :   cc338:  mov    $0x1,%eax
    0.00 :   cc33d:  test   %ebx,%ebx
    0.00 :   cc33f:  je     cc26a <std::sys::backtrace::__rust_begin_short_backtrace+0x7a>
    0.00 :   cc345:  imul   %ecx,%ecx
    0.00 :   cc348:  mov    %ecx,%eax
    0.00 :   cc34a:  and    $0x5,%eax
    0.00 :   cc34d:  cmp    $0x8,%ecx
    0.00 :   cc350:  jb     cc380 <std::sys::backtrace::__rust_begin_short_backtrace+0x190>
    0.00 :   cc352:  and    $0x38,%ecx
    0.00 :   cc355:  data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cc360:  pause
    0.00 :   cc362:  pause
    0.00 :   cc364:  pause
    0.00 :   cc366:  pause
    0.00 :   cc368:  pause
    0.00 :   cc36a:  pause
    0.00 :   cc36c:  pause
    0.00 :   cc36e:  pause
    0.00 :   cc370:  add    $0xfffffff8,%ecx
    0.00 :   cc373:  jne    cc360 <std::sys::backtrace::__rust_begin_short_backtrace+0x170>
    0.00 :   cc375:  test   %eax,%eax
    0.00 :   cc377:  je     cc266 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc37d:  nopl   (%rax)
    0.00 :   cc380:  pause
    0.00 :   cc382:  dec    %eax
    0.00 :   cc384:  jne    cc380 <std::sys::backtrace::__rust_begin_short_backtrace+0x190>
    0.00 :   cc386:  jmp    cc266 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc38b:  cmp    $0x7,%ebx
    0.00 :   cc38e:  jae    cc260 <std::sys::backtrace::__rust_begin_short_backtrace+0x70>
    0.00 :   cc394:  test   %ebx,%ebx
    0.00 :   cc396:  je     cc266 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc39c:  mov    %ebx,%ecx
    0.00 :   cc39e:  imul   %ebx,%ecx
    0.00 :   cc3a1:  mov    %ecx,%eax
    0.00 :   cc3a3:  and    $0x5,%eax
    0.00 :   cc3a6:  cmp    $0x8,%ecx
    0.00 :   cc3a9:  jb     cc3d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1e0>
    0.00 :   cc3ab:  and    $0x38,%ecx
    0.00 :   cc3ae:  xchg   %ax,%ax
    0.00 :   cc3b0:  pause
    0.00 :   cc3b2:  pause
    0.00 :   cc3b4:  pause
    0.00 :   cc3b6:  pause
    0.00 :   cc3b8:  pause
    0.00 :   cc3ba:  pause
    0.00 :   cc3bc:  pause
    0.00 :   cc3be:  pause
    0.00 :   cc3c0:  add    $0xfffffff8,%ecx
    0.00 :   cc3c3:  jne    cc3b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c0>
    0.00 :   cc3c5:  test   %eax,%eax
    0.00 :   cc3c7:  je     cc266 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc3cd:  nopl   (%rax)
    0.00 :   cc3d0:  pause
    0.00 :   cc3d2:  dec    %eax
    0.00 :   cc3d4:  jne    cc3d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1e0>
    0.00 :   cc3d6:  jmp    cc266 <std::sys::backtrace::__rust_begin_short_backtrace+0x76>
    0.00 :   cc3db:  nopl   0x0(%rax,%rax,1)
    0.00 :   cc3e0:  test   $0x1,%dl
    0.00 :   cc3e3:  jne    cd45f <std::sys::backtrace::__rust_begin_short_backtrace+0x126f>
    0.00 :   cc3e9:  mov    0x88(%rsp),%ebx
    0.00 :   cc3f0:  cmp    $0x3b9aca00,%ebx
    0.00 :   cc3f6:  je     cc421 <std::sys::backtrace::__rust_begin_short_backtrace+0x231>
    0.00 :   cc3f8:  mov    0x80(%rsp),%r15
    0.00 :   cc400:  mov    $0x1,%edi
    0.00 :   cc405:  call   a12d0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   cc40a:  cmp    %r15,%rax
    0.00 :   cc40d:  jne    cc418 <std::sys::backtrace::__rust_begin_short_backtrace+0x228>
    0.00 :   cc40f:  cmp    %ebx,%edx
    0.00 :   cc411:  jb     cc421 <std::sys::backtrace::__rust_begin_short_backtrace+0x231>
    0.00 :   cc413:  jmp    cd4d8 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e8>
    0.00 :   cc418:  cmp    %r15,%rax
    0.00 :   cc41b:  jge    cd4d8 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e8>
    0.00 :   cc421:  lea    0x20(%rsp),%rax
    0.00 :   cc426:  mov    %rax,0x90(%rsp)
    0.00 :   cc42e:  mov    0x8(%rsp),%rax
    0.00 :   cc433:  mov    %rax,0x98(%rsp)
    0.00 :   cc43b:  lea    0x80(%rsp),%rax
    0.00 :   cc443:  mov    %rax,0xa0(%rsp)
    0.00 :   cc44b:  mov    $0xffffffffffffff98,%rax
    0.00 :   cc452:  cmpb   $0x1,%fs:0x8(%rax)
    0.00 :   cc457:  mov    %r14,%r15
    0.00 :   cc45a:  jne    cc4ee <std::sys::backtrace::__rust_begin_short_backtrace+0x2fe>
    0.00 :   cc460:  mov    (%r15),%r12
    0.00 :   cc463:  movq   $0x0,(%r15)
    0.00 :   cc46a:  test   %r12,%r12
    0.00 :   cc46d:  je     cc514 <std::sys::backtrace::__rust_begin_short_backtrace+0x324>
    0.00 :   cc473:  mov    %r12,0x18(%rsp)
    0.00 :   cc478:  movq   $0x0,0x18(%r12)
    0.00 :   cc481:  movq   $0x0,0x20(%r12)
    0.00 :   cc48a:  movq   $0x0,0x90(%rsp)
    0.00 :   cc496:  lea    0x20(%rsp),%rax
    0.00 :   cc49b:  mov    %rax,0x50(%rsp)
    0.00 :   cc4a0:  lea    0x98(%rsp),%rax
    0.00 :   cc4a8:  movups (%rax),%xmm0
    0.00 :   cc4ab:  lea    0x58(%rsp),%rax
    0.00 :   cc4b0:  movups %xmm0,(%rax)
    0.00 :   cc4b3:  lea    0x50(%rsp),%rdi
    0.00 :   cc4b8:  mov    %r12,%rsi
    0.00 :   cc4bb:  call   cf550 <std::sync::mpmc::list::Channel<T>::recv::{{closure}}>
    0.00 :   cc4c0:  mov    (%r15),%rax
    0.00 :   cc4c3:  mov    %rax,0x50(%rsp)
    0.00 :   cc4c8:  mov    %r12,(%r15)
    0.00 :   cc4cb:  test   %rax,%rax
    0.00 :   cc4ce:  je     cc25a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc4d4:  lock decq (%rax)
    0.00 :   cc4d8:  jne    cc25a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc4de:  lea    0x50(%rsp),%rdi
    0.00 :   cc4e3:  call   *0xc5a07(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cc4e9:  jmp    cc25a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc4ee:  mov    %r14,%rdi
    0.00 :   cc4f1:  call   c5fe0 <std::sys::thread_local::native::lazy::Storage<T,D>::get_or_init_slow>
    0.00 :   cc4f6:  mov    %rax,%r15
    0.00 :   cc4f9:  test   %rax,%rax
    0.00 :   cc4fc:  jne    cc460 <std::sys::backtrace::__rust_begin_short_backtrace+0x270>
    0.00 :   cc502:  lea    0x90(%rsp),%rdi
    0.00 :   cc50a:  call   d15b0 <std::sync::mpmc::context::Context::with::{{closure}}>
    0.00 :   cc50f:  jmp    cc25a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc514:  call   *0xc5606(%rip)        # 191b20 <_DYNAMIC+0xd60>
    0.00 :   cc51a:  mov    %rax,%r15
    0.00 :   cc51d:  mov    %rax,0x18(%rsp)
    0.00 :   cc522:  movq   $0x0,0x90(%rsp)
    0.00 :   cc52e:  lea    0x20(%rsp),%rax
    0.00 :   cc533:  mov    %rax,0x50(%rsp)
    0.00 :   cc538:  mov    0x8(%rsp),%rax
    0.00 :   cc53d:  mov    %rax,0x58(%rsp)
    0.00 :   cc542:  lea    0x80(%rsp),%rax
    0.00 :   cc54a:  mov    %rax,0x60(%rsp)
    0.00 :   cc54f:  lea    0x50(%rsp),%rdi
    0.00 :   cc554:  mov    %r15,%rsi
    0.00 :   cc557:  call   cf550 <std::sync::mpmc::list::Channel<T>::recv::{{closure}}>
    0.00 :   cc55c:  lock decq (%r15)
    0.00 :   cc560:  jne    cc25a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc566:  lea    0x18(%rsp),%rdi
    0.00 :   cc56b:  call   *0xc597f(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cc571:  jmp    cc25a <std::sys::backtrace::__rust_begin_short_backtrace+0x6a>
    0.00 :   cc576:  movl   $0x3b9aca00,0x88(%rsp)
    0.00 :   cc581:  mov    %fs:0x0,%r12
    0.00 :   cc58a:  add    $0xffffffffffffff98,%r12
    0.00 :   cc591:  xorps  %xmm0,%xmm0
    0.00 :   cc594:  movaps %xmm0,0x30(%rsp)
    0.00 :   cc599:  movaps %xmm0,0x20(%rsp)
    0.00 :   cc59e:  movq   $0x0,0x40(%rsp)
    0.00 :   cc5a7:  lea    0x80(%rsp),%r15
    0.00 :   cc5af:  mov    0xc556a(%rip),%rbx        # 191b20 <_DYNAMIC+0xd60>
    0.00 :   cc5b6:  mov    0xc4f63(%rip),%r13        # 191520 <sched_yield@GLIBC_2.2.5>
    0.00 :   cc5bd:  xor    %eax,%eax
    0.00 :   cc5bf:  jmp    cc5d4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e4>
    0.00 :   cc5c1:  call   *%r13
    0.00 :   cc5c4:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cc5d0:  inc    %ebp
    0.00 :   cc5d2:  mov    %ebp,%eax
    0.00 :   cc5d4:  mov    %eax,%ebp
    0.00 :   cc5d6:  mov    0x8(%rsp),%r9
    0.00 :   cc5db:  mov    (%r9),%rcx
    0.00 :   cc5de:  mov    0x190(%r9),%rdx
    0.00 :   cc5e5:  mov    0x198(%r9),%rsi
    0.00 :   cc5ec:  dec    %rdx
    0.00 :   cc5ef:  xor    %eax,%eax
    0.00 :   cc5f1:  sub    0x188(%r9),%rax
    0.00 :   cc5f8:  and    %rcx,%rdx
    0.00 :   cc5fb:  mov    (%rsi,%rdx,8),%rdi
    0.00 :   cc5ff:  lea    0x1(%rcx),%r8
    0.00 :   cc603:  cmp    %rdi,%r8
    0.00 :   cc606:  jne    cc690 <std::sys::backtrace::__rust_begin_short_backtrace+0x4a0>
    0.00 :   cc60c:  lea    0x1(%rdx),%r8
    0.00 :   cc610:  cmp    0x180(%r9),%r8
    0.00 :   cc617:  jb     cc626 <std::sys::backtrace::__rust_begin_short_backtrace+0x436>
    0.00 :   cc619:  and    %rcx,%rax
    0.00 :   cc61c:  add    0x188(%r9),%rax
    0.00 :   cc623:  mov    %rax,%rdi
    0.00 :   cc626:  mov    %rcx,%rax
    0.00 :   cc629:  lock cmpxchg %rdi,(%r9)
    0.00 :   cc62e:  je     ccb1d <std::sys::backtrace::__rust_begin_short_backtrace+0x92d>
    0.00 :   cc634:  cmp    $0x6,%ebp
    0.00 :   cc637:  mov    $0x6,%ecx
    0.00 :   cc63c:  cmovb  %ebp,%ecx
    0.00 :   cc63f:  mov    $0x1,%eax
    0.00 :   cc644:  test   %ebp,%ebp
    0.00 :   cc646:  je     cc5d4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e4>
    0.00 :   cc648:  imul   %ecx,%ecx
    0.00 :   cc64b:  mov    %ecx,%eax
    0.00 :   cc64d:  and    $0x5,%eax
    0.00 :   cc650:  cmp    $0x8,%ecx
    0.00 :   cc653:  jb     cc680 <std::sys::backtrace::__rust_begin_short_backtrace+0x490>
    0.00 :   cc655:  and    $0x38,%ecx
    0.00 :   cc658:  nopl   0x0(%rax,%rax,1)
    0.00 :   cc660:  pause
    0.00 :   cc662:  pause
    0.00 :   cc664:  pause
    0.00 :   cc666:  pause
    0.00 :   cc668:  pause
    0.00 :   cc66a:  pause
    0.00 :   cc66c:  pause
    0.00 :   cc66e:  pause
    0.00 :   cc670:  add    $0xfffffff8,%ecx
    0.00 :   cc673:  jne    cc660 <std::sys::backtrace::__rust_begin_short_backtrace+0x470>
    0.00 :   cc675:  test   %eax,%eax
    0.00 :   cc677:  je     cc5d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   cc67d:  nopl   (%rax)
    0.00 :   cc680:  pause
    0.00 :   cc682:  dec    %eax
    0.00 :   cc684:  jne    cc680 <std::sys::backtrace::__rust_begin_short_backtrace+0x490>
    0.00 :   cc686:  jmp    cc5d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   cc68b:  nopl   0x0(%rax,%rax,1)
    0.00 :   cc690:  cmp    %rcx,%rdi
    0.00 :   cc693:  jne    cc720 <std::sys::backtrace::__rust_begin_short_backtrace+0x530>
    0.00 :   cc699:  lock orl $0x0,-0x40(%rsp)
    0.00 :   cc69f:  mov    0x8(%rsp),%rdx
    0.00 :   cc6a4:  mov    0x80(%rdx),%rax
    0.00 :   cc6ab:  mov    0x190(%rdx),%rdx
    0.00 :   cc6b2:  mov    %rdx,%rsi
    0.00 :   cc6b5:  not    %rsi
    0.00 :   cc6b8:  and    %rax,%rsi
    0.00 :   cc6bb:  cmp    %rcx,%rsi
    0.00 :   cc6be:  je     cc77b <std::sys::backtrace::__rust_begin_short_backtrace+0x58b>
    0.00 :   cc6c4:  cmp    $0x6,%ebp
    0.00 :   cc6c7:  mov    $0x6,%ecx
    0.00 :   cc6cc:  cmovb  %ebp,%ecx
    0.00 :   cc6cf:  mov    $0x1,%eax
    0.00 :   cc6d4:  test   %ebp,%ebp
    0.00 :   cc6d6:  je     cc5d4 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e4>
    0.00 :   cc6dc:  imul   %ecx,%ecx
    0.00 :   cc6df:  mov    %ecx,%eax
    0.00 :   cc6e1:  and    $0x5,%eax
    0.00 :   cc6e4:  cmp    $0x8,%ecx
    0.00 :   cc6e7:  jb     cc710 <std::sys::backtrace::__rust_begin_short_backtrace+0x520>
    0.00 :   cc6e9:  and    $0x38,%ecx
    0.00 :   cc6ec:  nopl   0x0(%rax)
    0.00 :   cc6f0:  pause
    0.00 :   cc6f2:  pause
    0.00 :   cc6f4:  pause
    0.00 :   cc6f6:  pause
    0.00 :   cc6f8:  pause
    0.00 :   cc6fa:  pause
    0.00 :   cc6fc:  pause
    0.00 :   cc6fe:  pause
    0.00 :   cc700:  add    $0xfffffff8,%ecx
    0.00 :   cc703:  jne    cc6f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x500>
    0.00 :   cc705:  test   %eax,%eax
    0.00 :   cc707:  je     cc5d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   cc70d:  nopl   (%rax)
    0.00 :   cc710:  pause
    0.00 :   cc712:  dec    %eax
    0.00 :   cc714:  jne    cc710 <std::sys::backtrace::__rust_begin_short_backtrace+0x520>
    0.00 :   cc716:  jmp    cc5d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   cc71b:  nopl   0x0(%rax,%rax,1)
    0.00 :   cc720:  cmp    $0x7,%ebp
    0.00 :   cc723:  jae    cc5c1 <std::sys::backtrace::__rust_begin_short_backtrace+0x3d1>
    0.00 :   cc729:  test   %ebp,%ebp
    0.00 :   cc72b:  je     cc5d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   cc731:  mov    %ebp,%ecx
    0.00 :   cc733:  imul   %ebp,%ecx
    0.00 :   cc736:  mov    %ecx,%eax
    0.00 :   cc738:  and    $0x5,%eax
    0.00 :   cc73b:  cmp    $0x8,%ecx
    0.00 :   cc73e:  jb     cc770 <std::sys::backtrace::__rust_begin_short_backtrace+0x580>
    0.00 :   cc740:  and    $0x38,%ecx
    0.00 :   cc743:  data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cc750:  pause
    0.00 :   cc752:  pause
    0.00 :   cc754:  pause
    0.00 :   cc756:  pause
    0.00 :   cc758:  pause
    0.00 :   cc75a:  pause
    0.00 :   cc75c:  pause
    0.00 :   cc75e:  pause
    0.00 :   cc760:  add    $0xfffffff8,%ecx
    0.00 :   cc763:  jne    cc750 <std::sys::backtrace::__rust_begin_short_backtrace+0x560>
    0.00 :   cc765:  test   %eax,%eax
    0.00 :   cc767:  je     cc5d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   cc76d:  nopl   (%rax)
    0.00 :   cc770:  pause
    0.00 :   cc772:  dec    %eax
    0.00 :   cc774:  jne    cc770 <std::sys::backtrace::__rust_begin_short_backtrace+0x580>
    0.00 :   cc776:  jmp    cc5d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x3e0>
    0.00 :   cc77b:  test   %rax,%rdx
    0.00 :   cc77e:  jne    cd45f <std::sys::backtrace::__rust_begin_short_backtrace+0x126f>
    0.00 :   cc784:  mov    0x88(%rsp),%ebp
    0.00 :   cc78b:  cmp    $0x3b9aca00,%ebp
    0.00 :   cc791:  je     cc7c5 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d5>
    0.00 :   cc793:  mov    %r15,%r14
    0.00 :   cc796:  mov    0x80(%rsp),%r15
    0.00 :   cc79e:  mov    $0x1,%edi
    0.00 :   cc7a3:  call   a12d0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   cc7a8:  cmp    %r15,%rax
    0.00 :   cc7ab:  jne    cc7b9 <std::sys::backtrace::__rust_begin_short_backtrace+0x5c9>
    0.00 :   cc7ad:  cmp    %ebp,%edx
    0.00 :   cc7af:  mov    %r14,%r15
    0.00 :   cc7b2:  jb     cc7c5 <std::sys::backtrace::__rust_begin_short_backtrace+0x5d5>
    0.00 :   cc7b4:  jmp    cd4d8 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e8>
    0.00 :   cc7b9:  cmp    %r15,%rax
    0.00 :   cc7bc:  mov    %r14,%r15
    0.00 :   cc7bf:  jge    cd4d8 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e8>
    0.00 :   cc7c5:  lea    0x20(%rsp),%rax
    0.00 :   cc7ca:  mov    %rax,0x90(%rsp)
    0.00 :   cc7d2:  mov    0x8(%rsp),%rax
    0.00 :   cc7d7:  mov    %rax,0x98(%rsp)
    0.00 :   cc7df:  mov    %r15,%r14
    0.00 :   cc7e2:  mov    %r15,0xa0(%rsp)
    0.00 :   cc7ea:  mov    $0xffffffffffffff98,%rax
    0.00 :   cc7f1:  cmpb   $0x1,%fs:0x8(%rax)
    0.00 :   cc7f6:  mov    %r12,%r15
    0.00 :   cc7f9:  jne    cc88e <std::sys::backtrace::__rust_begin_short_backtrace+0x69e>
    0.00 :   cc7ff:  mov    (%r15),%rbp
    0.00 :   cc802:  movq   $0x0,(%r15)
    0.00 :   cc809:  test   %rbp,%rbp
    0.00 :   cc80c:  je     cc8b1 <std::sys::backtrace::__rust_begin_short_backtrace+0x6c1>
    0.00 :   cc812:  mov    %rbp,0x18(%rsp)
    0.00 :   cc817:  movq   $0x0,0x18(%rbp)
    0.00 :   cc81f:  movq   $0x0,0x20(%rbp)
    0.00 :   cc827:  movq   $0x0,0x90(%rsp)
    0.00 :   cc833:  lea    0x20(%rsp),%rax
    0.00 :   cc838:  mov    %rax,0x50(%rsp)
    0.00 :   cc83d:  lea    0x98(%rsp),%rax
    0.00 :   cc845:  movups (%rax),%xmm0
    0.00 :   cc848:  lea    0x58(%rsp),%rax
    0.00 :   cc84d:  movups %xmm0,(%rax)
    0.00 :   cc850:  lea    0x50(%rsp),%rdi
    0.00 :   cc855:  mov    %rbp,%rsi
    0.00 :   cc858:  call   d0ce0 <std::sync::mpmc::array::Channel<T>::recv::{{closure}}>
    0.00 :   cc85d:  mov    (%r15),%rax
    0.00 :   cc860:  mov    %rax,0x50(%rsp)
    0.00 :   cc865:  mov    %rbp,(%r15)
    0.00 :   cc868:  test   %rax,%rax
    0.00 :   cc86b:  je     cc906 <std::sys::backtrace::__rust_begin_short_backtrace+0x716>
    0.00 :   cc871:  lock decq (%rax)
    0.00 :   cc875:  jne    cc906 <std::sys::backtrace::__rust_begin_short_backtrace+0x716>
    0.00 :   cc87b:  lea    0x50(%rsp),%rdi
    0.00 :   cc880:  call   *0xc566a(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cc886:  mov    %r14,%r15
    0.00 :   cc889:  jmp    cc5bd <std::sys::backtrace::__rust_begin_short_backtrace+0x3cd>
    0.00 :   cc88e:  mov    %r12,%rdi
    0.00 :   cc891:  call   c5fe0 <std::sys::thread_local::native::lazy::Storage<T,D>::get_or_init_slow>
    0.00 :   cc896:  mov    %rax,%r15
    0.00 :   cc899:  test   %rax,%rax
    0.00 :   cc89c:  jne    cc7ff <std::sys::backtrace::__rust_begin_short_backtrace+0x60f>
    0.00 :   cc8a2:  lea    0x90(%rsp),%rdi
    0.00 :   cc8aa:  call   d1470 <std::sync::mpmc::context::Context::with::{{closure}}>
    0.00 :   cc8af:  jmp    cc906 <std::sys::backtrace::__rust_begin_short_backtrace+0x716>
    0.00 :   cc8b1:  call   *%rbx
    0.00 :   cc8b3:  mov    %rax,%r15
    0.00 :   cc8b6:  mov    %rax,0x18(%rsp)
    0.00 :   cc8bb:  movq   $0x0,0x90(%rsp)
    0.00 :   cc8c7:  lea    0x20(%rsp),%rax
    0.00 :   cc8cc:  mov    %rax,0x50(%rsp)
    0.00 :   cc8d1:  mov    0x8(%rsp),%rax
    0.00 :   cc8d6:  mov    %rax,0x58(%rsp)
    0.00 :   cc8db:  mov    %r14,0x60(%rsp)
    0.00 :   cc8e0:  lea    0x50(%rsp),%rdi
    0.00 :   cc8e5:  mov    %r15,%rsi
    0.00 :   cc8e8:  call   d0ce0 <std::sync::mpmc::array::Channel<T>::recv::{{closure}}>
    0.00 :   cc8ed:  lock decq (%r15)
    0.00 :   cc8f1:  jne    cc906 <std::sys::backtrace::__rust_begin_short_backtrace+0x716>
    0.00 :   cc8f3:  lea    0x18(%rsp),%rdi
    0.00 :   cc8f8:  call   *0xc55f2(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cc8fe:  mov    %r14,%r15
    0.00 :   cc901:  jmp    cc5bd <std::sys::backtrace::__rust_begin_short_backtrace+0x3cd>
    0.00 :   cc906:  mov    %r14,%r15
    0.00 :   cc909:  jmp    cc5bd <std::sys::backtrace::__rust_begin_short_backtrace+0x3cd>
    0.00 :   cc90e:  movl   $0x3b9aca00,0x88(%rsp)
    0.00 :   cc919:  xorps  %xmm0,%xmm0
    0.00 :   cc91c:  movaps %xmm0,0xa0(%rsp)
    0.00 :   cc924:  movaps %xmm0,0x90(%rsp)
    0.00 :   cc92c:  movq   $0x0,0xb0(%rsp)
    0.00 :   cc938:  mov    $0x1,%ecx
    0.00 :   cc93d:  xor    %eax,%eax
    0.00 :   cc93f:  mov    0x8(%rsp),%rdx
    0.00 :   cc944:  lock cmpxchg %ecx,(%rdx)
    0.00 :   cc948:  jne    cd4df <std::sys::backtrace::__rust_begin_short_backtrace+0x12ef>
    0.00 :   cc94e:  mov    0xc49fb(%rip),%r14        # 191350 <_DYNAMIC+0x590>
    0.00 :   cc955:  mov    (%r14),%rax
    0.00 :   cc958:  shl    %rax
    0.00 :   cc95b:  test   %rax,%rax
    0.00 :   cc95e:  jne    cd4ef <std::sys::backtrace::__rust_begin_short_backtrace+0x12ff>
    0.00 :   cc964:  xor    %ebp,%ebp
    0.00 :   cc966:  mov    0x8(%rsp),%rcx
    0.00 :   cc96b:  movzbl 0x4(%rcx),%eax
    0.00 :   cc96f:  test   %al,%al
    0.00 :   cc971:  jne    cd512 <std::sys::backtrace::__rust_begin_short_backtrace+0x1322>
    0.00 :   cc977:  movabs $0x7fffffffffffffff,%r9
    0.00 :   cc981:  mov    0x18(%rcx),%rax
    0.00 :   cc985:  test   %rax,%rax
    0.00 :   cc988:  je     cd1c4 <std::sys::backtrace::__rust_begin_short_backtrace+0xfd4>
    0.00 :   cc98e:  mov    %fs:0x0,%rcx
    0.00 :   cc997:  lea    -0x170(%rcx),%rcx
    0.00 :   cc99e:  mov    0x8(%rsp),%rdx
    0.00 :   cc9a3:  mov    0x10(%rdx),%rdx
    0.00 :   cc9a7:  shl    $0x3,%rax
    0.00 :   cc9ab:  lea    (%rax,%rax,2),%rsi
    0.00 :   cc9af:  mov    $0x1,%ebx
    0.00 :   cc9b4:  xor    %r13d,%r13d
    0.00 :   cc9b7:  jmp    cc9d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e0>
    0.00 :   cc9b9:  nopl   0x0(%rax)
    0.00 :   cc9c0:  add    $0x18,%r13
    0.00 :   cc9c4:  inc    %rbx
    0.00 :   cc9c7:  cmp    %r13,%rsi
    0.00 :   cc9ca:  je     cd1c4 <std::sys::backtrace::__rust_begin_short_backtrace+0xfd4>
    0.00 :   cc9d0:  mov    (%rdx,%r13,1),%rdi
    0.00 :   cc9d4:  cmp    %rcx,0x28(%rdi)
    0.00 :   cc9d8:  je     cc9c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x7d0>
    0.00 :   cc9da:  mov    0x8(%rdx,%r13,1),%r8
    0.00 :   cc9df:  xor    %eax,%eax
    0.00 :   cc9e1:  lock cmpxchg %r8,0x18(%rdi)
    0.00 :   cc9e7:  jne    cc9c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x7d0>
    0.00 :   cc9e9:  mov    0x10(%rdx,%r13,1),%rax
    0.00 :   cc9ee:  test   %rax,%rax
    0.00 :   cc9f1:  je     cc9f7 <std::sys::backtrace::__rust_begin_short_backtrace+0x807>
    0.00 :   cc9f3:  mov    %rax,0x20(%rdi)
    0.00 :   cc9f7:  lea    -0x1(%rbx),%r15
    0.00 :   cc9fb:  mov    0x10(%rdi),%rsi
    0.00 :   cc9ff:  mov    $0x1,%eax
    0.00 :   cca04:  xchg   %eax,0x28(%rsi)
    0.00 :   cca07:  cmp    $0xffffffff,%eax
    0.00 :   cca0a:  jne    cca27 <std::sys::backtrace::__rust_begin_short_backtrace+0x837>
    0.00 :   cca0c:  add    $0x28,%rsi
    0.00 :   cca10:  mov    $0xca,%edi
    0.00 :   cca15:  mov    $0x81,%edx
    0.00 :   cca1a:  mov    $0x1,%ecx
    0.00 :   cca1f:  xor    %eax,%eax
    0.00 :   cca21:  call   *0xc4959(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cca27:  mov    0x8(%rsp),%r14
    0.00 :   cca2c:  mov    0x18(%r14),%r12
    0.00 :   cca30:  mov    %r15,0xc0(%rsp)
    0.00 :   cca38:  cmp    %r12,%r15
    0.00 :   cca3b:  jae    cdd0e <std::sys::backtrace::__rust_begin_short_backtrace+0x1b1e>
    0.00 :   cca41:  mov    0x10(%r14),%rax
    0.00 :   cca45:  lea    (%rax,%r13,1),%rdi
    0.00 :   cca49:  mov    (%rax,%r13,1),%r15
    0.00 :   cca4d:  movups 0x8(%rax,%r13,1),%xmm0
    0.00 :   cca53:  movaps %xmm0,0x50(%rsp)
    0.00 :   cca58:  lea    (%rax,%r13,1),%rsi
    0.00 :   cca5c:  add    $0x18,%rsi
    0.00 :   cca60:  mov    %r12,%rax
    0.00 :   cca63:  sub    %rbx,%rax
    0.00 :   cca66:  shl    $0x3,%rax
    0.00 :   cca6a:  lea    (%rax,%rax,2),%rdx
    0.00 :   cca6e:  call   *0xc4a8c(%rip)        # 191500 <memmove@GLIBC_2.2.5>
    0.00 :   cca74:  dec    %r12
    0.00 :   cca77:  mov    %r12,0x18(%r14)
    0.00 :   cca7b:  test   %r15,%r15
    0.00 :   cca7e:  je     cdd0e <std::sys::backtrace::__rust_begin_short_backtrace+0x1b1e>
    0.00 :   cca84:  mov    %r15,%r14
    0.00 :   cca87:  movaps 0x50(%rsp),%xmm0
    0.00 :   cca8c:  movups %xmm0,0x28(%rsp)
    0.00 :   cca91:  mov    %r15,0x20(%rsp)
    0.00 :   cca96:  mov    0x30(%rsp),%rax
    0.00 :   cca9b:  mov    %rax,0xb0(%rsp)
    0.00 :   ccaa3:  test   %bpl,%bpl
    0.00 :   ccaa6:  mov    0xc48a3(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   ccaad:  jne    ccac5 <std::sys::backtrace::__rust_begin_short_backtrace+0x8d5>
    0.00 :   ccaaf:  mov    (%rax),%rax
    0.00 :   ccab2:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   ccabc:  test   %rcx,%rax
    0.00 :   ccabf:  jne    cdbba <std::sys::backtrace::__rust_begin_short_backtrace+0x19ca>
    0.00 :   ccac5:  xor    %eax,%eax
    0.00 :   ccac7:  mov    0x8(%rsp),%rsi
    0.00 :   ccacc:  xchg   %eax,(%rsi)
    0.00 :   ccace:  cmp    $0x2,%eax
    0.00 :   ccad1:  je     cd5bf <std::sys::backtrace::__rust_begin_short_backtrace+0x13cf>
    0.00 :   ccad7:  mov    0xb0(%rsp),%r12
    0.00 :   ccadf:  test   %r12,%r12
    0.00 :   ccae2:  je     cd5e7 <std::sys::backtrace::__rust_begin_short_backtrace+0x13f7>
    0.00 :   ccae8:  cmpb   $0x0,(%r12)
    0.00 :   ccaed:  je     cd428 <std::sys::backtrace::__rust_begin_short_backtrace+0x1238>
    0.00 :   ccaf3:  cmpb   $0x0,0x2(%r12)
    0.00 :   ccaf9:  movb   $0x0,0x2(%r12)
    0.00 :   ccaff:  je     cdcf6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b06>
    0.00 :   ccb05:  movb   $0x1,0x1(%r12)
    0.00 :   ccb0b:  mov    $0x2,%bpl
    0.00 :   ccb0e:  lock decq (%r14)
    0.00 :   ccb12:  je     cd5f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1400>
    0.00 :   ccb18:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccb1d:  lea    (%rsi,%rdx,8),%rax
    0.00 :   ccb21:  mov    %rax,0x20(%rsp)
    0.00 :   ccb26:  mov    0x8(%rsp),%rax
    0.00 :   ccb2b:  add    0x188(%rax),%rcx
    0.00 :   ccb32:  mov    %rcx,0x28(%rsp)
    0.00 :   ccb37:  mov    %rcx,(%rsi,%rdx,8)
    0.00 :   ccb3b:  lea    0x100(%rax),%rdi
    0.00 :   ccb42:  mov    $0x1,%r12b
    0.00 :   ccb45:  mov    $0x2,%bpl
    0.00 :   ccb48:  mov    $0x1,%r13b
    0.00 :   ccb4b:  call   c3ea0 <<std::sync::mpmc::waker::SyncWaker>::notify>
    0.00 :   ccb50:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccb55:  cmp    $0x1e,%r15d
    0.00 :   ccb59:  jne    ccb8b <std::sys::backtrace::__rust_begin_short_backtrace+0x99b>
    0.00 :   ccb5b:  mov    (%r12),%rax
    0.00 :   ccb5f:  test   %rax,%rax
    0.00 :   ccb62:  je     cd3b3 <std::sys::backtrace::__rust_begin_short_backtrace+0x11c3>
    0.00 :   ccb68:  and    $0xfffffffffffffffe,%r13
    0.00 :   ccb6c:  mov    (%rax),%rcx
    0.00 :   ccb6f:  xor    %edx,%edx
    0.00 :   ccb71:  test   %rcx,%rcx
    0.00 :   ccb74:  setne  %dl
    0.00 :   ccb77:  lea    (%rdx,%r13,1),%rcx
    0.00 :   ccb7b:  add    $0x2,%rcx
    0.00 :   ccb7f:  mov    0x8(%rsp),%rdx
    0.00 :   ccb84:  mov    %rax,0x8(%rdx)
    0.00 :   ccb88:  mov    %rcx,(%rdx)
    0.00 :   ccb8b:  mov    %r12,0x30(%rsp)
    0.00 :   ccb90:  mov    %r15,0x38(%rsp)
    0.00 :   ccb95:  mov    0x8(%r12,%r15,8),%rax
    0.00 :   ccb9a:  test   $0x1,%al
    0.00 :   ccb9c:  jne    ccc18 <std::sys::backtrace::__rust_begin_short_backtrace+0xa28>
    0.00 :   ccb9e:  xor    %ebx,%ebx
    0.00 :   ccba0:  xor    %r13d,%r13d
    0.00 :   ccba3:  jmp    ccbcd <std::sys::backtrace::__rust_begin_short_backtrace+0x9dd>
    0.00 :   ccba5:  data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   ccbb0:  call   *0xc496a(%rip)        # 191520 <sched_yield@GLIBC_2.2.5>
    0.00 :   ccbb6:  lea    0x1(,%r13,2),%eax
    0.00 :   ccbbe:  inc    %r13d
    0.00 :   ccbc1:  mov    0x8(%r12,%r15,8),%rcx
    0.00 :   ccbc6:  add    %eax,%ebx
    0.00 :   ccbc8:  test   $0x1,%cl
    0.00 :   ccbcb:  jne    ccc18 <std::sys::backtrace::__rust_begin_short_backtrace+0xa28>
    0.00 :   ccbcd:  cmp    $0x7,%r13d
    0.00 :   ccbd1:  jae    ccbb0 <std::sys::backtrace::__rust_begin_short_backtrace+0x9c0>
    0.00 :   ccbd3:  test   %r13d,%r13d
    0.00 :   ccbd6:  je     ccbb6 <std::sys::backtrace::__rust_begin_short_backtrace+0x9c6>
    0.00 :   ccbd8:  lea    -0x1(%rbx),%ecx
    0.00 :   ccbdb:  mov    %ebx,%eax
    0.00 :   ccbdd:  and    $0x7,%eax
    0.00 :   ccbe0:  cmp    $0x7,%ecx
    0.00 :   ccbe3:  jb     ccc10 <std::sys::backtrace::__rust_begin_short_backtrace+0xa20>
    0.00 :   ccbe5:  mov    %ebx,%ecx
    0.00 :   ccbe7:  and    $0xfffffff8,%ecx
    0.00 :   ccbea:  nopw   0x0(%rax,%rax,1)
    0.00 :   ccbf0:  pause
    0.00 :   ccbf2:  pause
    0.00 :   ccbf4:  pause
    0.00 :   ccbf6:  pause
    0.00 :   ccbf8:  pause
    0.00 :   ccbfa:  pause
    0.00 :   ccbfc:  pause
    0.00 :   ccbfe:  pause
    0.00 :   ccc00:  add    $0xfffffff8,%ecx
    0.00 :   ccc03:  jne    ccbf0 <std::sys::backtrace::__rust_begin_short_backtrace+0xa00>
    0.00 :   ccc05:  test   %eax,%eax
    0.00 :   ccc07:  je     ccbb6 <std::sys::backtrace::__rust_begin_short_backtrace+0x9c6>
    0.00 :   ccc09:  nopl   0x0(%rax)
    0.00 :   ccc10:  pause
    0.00 :   ccc12:  dec    %eax
    0.00 :   ccc14:  jne    ccc10 <std::sys::backtrace::__rust_begin_short_backtrace+0xa20>
    0.00 :   ccc16:  jmp    ccbb6 <std::sys::backtrace::__rust_begin_short_backtrace+0x9c6>
    0.00 :   ccc18:  lea    0x1(%r15),%rcx
    0.00 :   ccc1c:  cmp    $0x1f,%rcx
    0.00 :   ccc20:  jne    cd208 <std::sys::backtrace::__rust_begin_short_backtrace+0x1018>
    0.00 :   ccc26:  mov    0x8(%r12),%rax
    0.00 :   ccc2b:  test   $0x2,%al
    0.00 :   ccc2d:  jne    ccc5b <std::sys::backtrace::__rust_begin_short_backtrace+0xa6b>
    0.00 :   ccc2f:  mov    0x8(%r12),%rax
    0.00 :   ccc34:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   ccc40:  mov    %rax,%rcx
    0.00 :   ccc43:  or     $0x4,%rcx
    0.00 :   ccc47:  lock cmpxchg %rcx,0x8(%r12)
    0.00 :   ccc4e:  jne    ccc40 <std::sys::backtrace::__rust_begin_short_backtrace+0xa50>
    0.00 :   ccc50:  mov    $0x2,%bpl
    0.00 :   ccc53:  test   $0x2,%al
    0.00 :   ccc55:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccc5b:  mov    0x10(%r12),%rax
    0.00 :   ccc60:  test   $0x2,%al
    0.00 :   ccc62:  jne    ccc8b <std::sys::backtrace::__rust_begin_short_backtrace+0xa9b>
    0.00 :   ccc64:  mov    0x10(%r12),%rax
    0.00 :   ccc69:  nopl   0x0(%rax)
    0.00 :   ccc70:  mov    %rax,%rcx
    0.00 :   ccc73:  or     $0x4,%rcx
    0.00 :   ccc77:  lock cmpxchg %rcx,0x10(%r12)
    0.00 :   ccc7e:  jne    ccc70 <std::sys::backtrace::__rust_begin_short_backtrace+0xa80>
    0.00 :   ccc80:  mov    $0x2,%bpl
    0.00 :   ccc83:  test   $0x2,%al
    0.00 :   ccc85:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccc8b:  mov    0x18(%r12),%rax
    0.00 :   ccc90:  test   $0x2,%al
    0.00 :   ccc92:  jne    cccbb <std::sys::backtrace::__rust_begin_short_backtrace+0xacb>
    0.00 :   ccc94:  mov    0x18(%r12),%rax
    0.00 :   ccc99:  nopl   0x0(%rax)
    0.00 :   ccca0:  mov    %rax,%rcx
    0.00 :   ccca3:  or     $0x4,%rcx
    0.00 :   ccca7:  lock cmpxchg %rcx,0x18(%r12)
    0.00 :   cccae:  jne    ccca0 <std::sys::backtrace::__rust_begin_short_backtrace+0xab0>
    0.00 :   cccb0:  mov    $0x2,%bpl
    0.00 :   cccb3:  test   $0x2,%al
    0.00 :   cccb5:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cccbb:  mov    0x20(%r12),%rax
    0.00 :   cccc0:  test   $0x2,%al
    0.00 :   cccc2:  jne    ccceb <std::sys::backtrace::__rust_begin_short_backtrace+0xafb>
    0.00 :   cccc4:  mov    0x20(%r12),%rax
    0.00 :   cccc9:  nopl   0x0(%rax)
    0.00 :   cccd0:  mov    %rax,%rcx
    0.00 :   cccd3:  or     $0x4,%rcx
    0.00 :   cccd7:  lock cmpxchg %rcx,0x20(%r12)
    0.00 :   cccde:  jne    cccd0 <std::sys::backtrace::__rust_begin_short_backtrace+0xae0>
    0.00 :   ccce0:  mov    $0x2,%bpl
    0.00 :   ccce3:  test   $0x2,%al
    0.00 :   ccce5:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccceb:  mov    0x28(%r12),%rax
    0.00 :   cccf0:  test   $0x2,%al
    0.00 :   cccf2:  jne    ccd1b <std::sys::backtrace::__rust_begin_short_backtrace+0xb2b>
    0.00 :   cccf4:  mov    0x28(%r12),%rax
    0.00 :   cccf9:  nopl   0x0(%rax)
    0.00 :   ccd00:  mov    %rax,%rcx
    0.00 :   ccd03:  or     $0x4,%rcx
    0.00 :   ccd07:  lock cmpxchg %rcx,0x28(%r12)
    0.00 :   ccd0e:  jne    ccd00 <std::sys::backtrace::__rust_begin_short_backtrace+0xb10>
    0.00 :   ccd10:  mov    $0x2,%bpl
    0.00 :   ccd13:  test   $0x2,%al
    0.00 :   ccd15:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccd1b:  mov    0x30(%r12),%rax
    0.00 :   ccd20:  test   $0x2,%al
    0.00 :   ccd22:  jne    ccd4b <std::sys::backtrace::__rust_begin_short_backtrace+0xb5b>
    0.00 :   ccd24:  mov    0x30(%r12),%rax
    0.00 :   ccd29:  nopl   0x0(%rax)
    0.00 :   ccd30:  mov    %rax,%rcx
    0.00 :   ccd33:  or     $0x4,%rcx
    0.00 :   ccd37:  lock cmpxchg %rcx,0x30(%r12)
    0.00 :   ccd3e:  jne    ccd30 <std::sys::backtrace::__rust_begin_short_backtrace+0xb40>
    0.00 :   ccd40:  mov    $0x2,%bpl
    0.00 :   ccd43:  test   $0x2,%al
    0.00 :   ccd45:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccd4b:  mov    0x38(%r12),%rax
    0.00 :   ccd50:  test   $0x2,%al
    0.00 :   ccd52:  jne    ccd7b <std::sys::backtrace::__rust_begin_short_backtrace+0xb8b>
    0.00 :   ccd54:  mov    0x38(%r12),%rax
    0.00 :   ccd59:  nopl   0x0(%rax)
    0.00 :   ccd60:  mov    %rax,%rcx
    0.00 :   ccd63:  or     $0x4,%rcx
    0.00 :   ccd67:  lock cmpxchg %rcx,0x38(%r12)
    0.00 :   ccd6e:  jne    ccd60 <std::sys::backtrace::__rust_begin_short_backtrace+0xb70>
    0.00 :   ccd70:  mov    $0x2,%bpl
    0.00 :   ccd73:  test   $0x2,%al
    0.00 :   ccd75:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccd7b:  mov    0x40(%r12),%rax
    0.00 :   ccd80:  test   $0x2,%al
    0.00 :   ccd82:  jne    ccdab <std::sys::backtrace::__rust_begin_short_backtrace+0xbbb>
    0.00 :   ccd84:  mov    0x40(%r12),%rax
    0.00 :   ccd89:  nopl   0x0(%rax)
    0.00 :   ccd90:  mov    %rax,%rcx
    0.00 :   ccd93:  or     $0x4,%rcx
    0.00 :   ccd97:  lock cmpxchg %rcx,0x40(%r12)
    0.00 :   ccd9e:  jne    ccd90 <std::sys::backtrace::__rust_begin_short_backtrace+0xba0>
    0.00 :   ccda0:  mov    $0x2,%bpl
    0.00 :   ccda3:  test   $0x2,%al
    0.00 :   ccda5:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccdab:  mov    0x48(%r12),%rax
    0.00 :   ccdb0:  test   $0x2,%al
    0.00 :   ccdb2:  jne    ccddb <std::sys::backtrace::__rust_begin_short_backtrace+0xbeb>
    0.00 :   ccdb4:  mov    0x48(%r12),%rax
    0.00 :   ccdb9:  nopl   0x0(%rax)
    0.00 :   ccdc0:  mov    %rax,%rcx
    0.00 :   ccdc3:  or     $0x4,%rcx
    0.00 :   ccdc7:  lock cmpxchg %rcx,0x48(%r12)
    0.00 :   ccdce:  jne    ccdc0 <std::sys::backtrace::__rust_begin_short_backtrace+0xbd0>
    0.00 :   ccdd0:  mov    $0x2,%bpl
    0.00 :   ccdd3:  test   $0x2,%al
    0.00 :   ccdd5:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccddb:  mov    0x50(%r12),%rax
    0.00 :   ccde0:  test   $0x2,%al
    0.00 :   ccde2:  jne    cce04 <std::sys::backtrace::__rust_begin_short_backtrace+0xc14>
    0.00 :   ccde4:  mov    0x50(%r12),%rax
    0.00 :   ccde9:  mov    %rax,%rcx
    0.00 :   ccdec:  or     $0x4,%rcx
    0.00 :   ccdf0:  lock cmpxchg %rcx,0x50(%r12)
    0.00 :   ccdf7:  jne    ccde9 <std::sys::backtrace::__rust_begin_short_backtrace+0xbf9>
    0.00 :   ccdf9:  mov    $0x2,%bpl
    0.00 :   ccdfc:  test   $0x2,%al
    0.00 :   ccdfe:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cce04:  mov    0x58(%r12),%rax
    0.00 :   cce09:  test   $0x2,%al
    0.00 :   cce0b:  jne    cce2d <std::sys::backtrace::__rust_begin_short_backtrace+0xc3d>
    0.00 :   cce0d:  mov    0x58(%r12),%rax
    0.00 :   cce12:  mov    %rax,%rcx
    0.00 :   cce15:  or     $0x4,%rcx
    0.00 :   cce19:  lock cmpxchg %rcx,0x58(%r12)
    0.00 :   cce20:  jne    cce12 <std::sys::backtrace::__rust_begin_short_backtrace+0xc22>
    0.00 :   cce22:  mov    $0x2,%bpl
    0.00 :   cce25:  test   $0x2,%al
    0.00 :   cce27:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cce2d:  mov    0x60(%r12),%rax
    0.00 :   cce32:  test   $0x2,%al
    0.00 :   cce34:  jne    cce56 <std::sys::backtrace::__rust_begin_short_backtrace+0xc66>
    0.00 :   cce36:  mov    0x60(%r12),%rax
    0.00 :   cce3b:  mov    %rax,%rcx
    0.00 :   cce3e:  or     $0x4,%rcx
    0.00 :   cce42:  lock cmpxchg %rcx,0x60(%r12)
    0.00 :   cce49:  jne    cce3b <std::sys::backtrace::__rust_begin_short_backtrace+0xc4b>
    0.00 :   cce4b:  mov    $0x2,%bpl
    0.00 :   cce4e:  test   $0x2,%al
    0.00 :   cce50:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cce56:  mov    0x68(%r12),%rax
    0.00 :   cce5b:  test   $0x2,%al
    0.00 :   cce5d:  jne    cce7f <std::sys::backtrace::__rust_begin_short_backtrace+0xc8f>
    0.00 :   cce5f:  mov    0x68(%r12),%rax
    0.00 :   cce64:  mov    %rax,%rcx
    0.00 :   cce67:  or     $0x4,%rcx
    0.00 :   cce6b:  lock cmpxchg %rcx,0x68(%r12)
    0.00 :   cce72:  jne    cce64 <std::sys::backtrace::__rust_begin_short_backtrace+0xc74>
    0.00 :   cce74:  mov    $0x2,%bpl
    0.00 :   cce77:  test   $0x2,%al
    0.00 :   cce79:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cce7f:  mov    0x70(%r12),%rax
    0.00 :   cce84:  test   $0x2,%al
    0.00 :   cce86:  jne    ccea8 <std::sys::backtrace::__rust_begin_short_backtrace+0xcb8>
    0.00 :   cce88:  mov    0x70(%r12),%rax
    0.00 :   cce8d:  mov    %rax,%rcx
    0.00 :   cce90:  or     $0x4,%rcx
    0.00 :   cce94:  lock cmpxchg %rcx,0x70(%r12)
    0.00 :   cce9b:  jne    cce8d <std::sys::backtrace::__rust_begin_short_backtrace+0xc9d>
    0.00 :   cce9d:  mov    $0x2,%bpl
    0.00 :   ccea0:  test   $0x2,%al
    0.00 :   ccea2:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccea8:  mov    0x78(%r12),%rax
    0.00 :   ccead:  test   $0x2,%al
    0.00 :   cceaf:  jne    cced1 <std::sys::backtrace::__rust_begin_short_backtrace+0xce1>
    0.00 :   cceb1:  mov    0x78(%r12),%rax
    0.00 :   cceb6:  mov    %rax,%rcx
    0.00 :   cceb9:  or     $0x4,%rcx
    0.00 :   ccebd:  lock cmpxchg %rcx,0x78(%r12)
    0.00 :   ccec4:  jne    cceb6 <std::sys::backtrace::__rust_begin_short_backtrace+0xcc6>
    0.00 :   ccec6:  mov    $0x2,%bpl
    0.00 :   ccec9:  test   $0x2,%al
    0.00 :   ccecb:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cced1:  mov    0x80(%r12),%rax
    0.00 :   cced9:  test   $0x2,%al
    0.00 :   ccedb:  jne    ccf03 <std::sys::backtrace::__rust_begin_short_backtrace+0xd13>
    0.00 :   ccedd:  mov    0x80(%r12),%rax
    0.00 :   ccee5:  mov    %rax,%rcx
    0.00 :   ccee8:  or     $0x4,%rcx
    0.00 :   cceec:  lock cmpxchg %rcx,0x80(%r12)
    0.00 :   ccef6:  jne    ccee5 <std::sys::backtrace::__rust_begin_short_backtrace+0xcf5>
    0.00 :   ccef8:  mov    $0x2,%bpl
    0.00 :   ccefb:  test   $0x2,%al
    0.00 :   ccefd:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccf03:  mov    0x88(%r12),%rax
    0.00 :   ccf0b:  test   $0x2,%al
    0.00 :   ccf0d:  jne    ccf35 <std::sys::backtrace::__rust_begin_short_backtrace+0xd45>
    0.00 :   ccf0f:  mov    0x88(%r12),%rax
    0.00 :   ccf17:  mov    %rax,%rcx
    0.00 :   ccf1a:  or     $0x4,%rcx
    0.00 :   ccf1e:  lock cmpxchg %rcx,0x88(%r12)
    0.00 :   ccf28:  jne    ccf17 <std::sys::backtrace::__rust_begin_short_backtrace+0xd27>
    0.00 :   ccf2a:  mov    $0x2,%bpl
    0.00 :   ccf2d:  test   $0x2,%al
    0.00 :   ccf2f:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccf35:  mov    0x90(%r12),%rax
    0.00 :   ccf3d:  test   $0x2,%al
    0.00 :   ccf3f:  jne    ccf67 <std::sys::backtrace::__rust_begin_short_backtrace+0xd77>
    0.00 :   ccf41:  mov    0x90(%r12),%rax
    0.00 :   ccf49:  mov    %rax,%rcx
    0.00 :   ccf4c:  or     $0x4,%rcx
    0.00 :   ccf50:  lock cmpxchg %rcx,0x90(%r12)
    0.00 :   ccf5a:  jne    ccf49 <std::sys::backtrace::__rust_begin_short_backtrace+0xd59>
    0.00 :   ccf5c:  mov    $0x2,%bpl
    0.00 :   ccf5f:  test   $0x2,%al
    0.00 :   ccf61:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccf67:  mov    0x98(%r12),%rax
    0.00 :   ccf6f:  test   $0x2,%al
    0.00 :   ccf71:  jne    ccf99 <std::sys::backtrace::__rust_begin_short_backtrace+0xda9>
    0.00 :   ccf73:  mov    0x98(%r12),%rax
    0.00 :   ccf7b:  mov    %rax,%rcx
    0.00 :   ccf7e:  or     $0x4,%rcx
    0.00 :   ccf82:  lock cmpxchg %rcx,0x98(%r12)
    0.00 :   ccf8c:  jne    ccf7b <std::sys::backtrace::__rust_begin_short_backtrace+0xd8b>
    0.00 :   ccf8e:  mov    $0x2,%bpl
    0.00 :   ccf91:  test   $0x2,%al
    0.00 :   ccf93:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccf99:  mov    0xa0(%r12),%rax
    0.00 :   ccfa1:  test   $0x2,%al
    0.00 :   ccfa3:  jne    ccfcb <std::sys::backtrace::__rust_begin_short_backtrace+0xddb>
    0.00 :   ccfa5:  mov    0xa0(%r12),%rax
    0.00 :   ccfad:  mov    %rax,%rcx
    0.00 :   ccfb0:  or     $0x4,%rcx
    0.00 :   ccfb4:  lock cmpxchg %rcx,0xa0(%r12)
    0.00 :   ccfbe:  jne    ccfad <std::sys::backtrace::__rust_begin_short_backtrace+0xdbd>
    0.00 :   ccfc0:  mov    $0x2,%bpl
    0.00 :   ccfc3:  test   $0x2,%al
    0.00 :   ccfc5:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccfcb:  mov    0xa8(%r12),%rax
    0.00 :   ccfd3:  test   $0x2,%al
    0.00 :   ccfd5:  jne    ccffd <std::sys::backtrace::__rust_begin_short_backtrace+0xe0d>
    0.00 :   ccfd7:  mov    0xa8(%r12),%rax
    0.00 :   ccfdf:  mov    %rax,%rcx
    0.00 :   ccfe2:  or     $0x4,%rcx
    0.00 :   ccfe6:  lock cmpxchg %rcx,0xa8(%r12)
    0.00 :   ccff0:  jne    ccfdf <std::sys::backtrace::__rust_begin_short_backtrace+0xdef>
    0.00 :   ccff2:  mov    $0x2,%bpl
    0.00 :   ccff5:  test   $0x2,%al
    0.00 :   ccff7:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   ccffd:  mov    0xb0(%r12),%rax
    0.00 :   cd005:  test   $0x2,%al
    0.00 :   cd007:  jne    cd02f <std::sys::backtrace::__rust_begin_short_backtrace+0xe3f>
    0.00 :   cd009:  mov    0xb0(%r12),%rax
    0.00 :   cd011:  mov    %rax,%rcx
    0.00 :   cd014:  or     $0x4,%rcx
    0.00 :   cd018:  lock cmpxchg %rcx,0xb0(%r12)
    0.00 :   cd022:  jne    cd011 <std::sys::backtrace::__rust_begin_short_backtrace+0xe21>
    0.00 :   cd024:  mov    $0x2,%bpl
    0.00 :   cd027:  test   $0x2,%al
    0.00 :   cd029:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd02f:  mov    0xb8(%r12),%rax
    0.00 :   cd037:  test   $0x2,%al
    0.00 :   cd039:  jne    cd061 <std::sys::backtrace::__rust_begin_short_backtrace+0xe71>
    0.00 :   cd03b:  mov    0xb8(%r12),%rax
    0.00 :   cd043:  mov    %rax,%rcx
    0.00 :   cd046:  or     $0x4,%rcx
    0.00 :   cd04a:  lock cmpxchg %rcx,0xb8(%r12)
    0.00 :   cd054:  jne    cd043 <std::sys::backtrace::__rust_begin_short_backtrace+0xe53>
    0.00 :   cd056:  mov    $0x2,%bpl
    0.00 :   cd059:  test   $0x2,%al
    0.00 :   cd05b:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd061:  mov    0xc0(%r12),%rax
    0.00 :   cd069:  test   $0x2,%al
    0.00 :   cd06b:  jne    cd093 <std::sys::backtrace::__rust_begin_short_backtrace+0xea3>
    0.00 :   cd06d:  mov    0xc0(%r12),%rax
    0.00 :   cd075:  mov    %rax,%rcx
    0.00 :   cd078:  or     $0x4,%rcx
    0.00 :   cd07c:  lock cmpxchg %rcx,0xc0(%r12)
    0.00 :   cd086:  jne    cd075 <std::sys::backtrace::__rust_begin_short_backtrace+0xe85>
    0.00 :   cd088:  mov    $0x2,%bpl
    0.00 :   cd08b:  test   $0x2,%al
    0.00 :   cd08d:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd093:  mov    0xc8(%r12),%rax
    0.00 :   cd09b:  test   $0x2,%al
    0.00 :   cd09d:  jne    cd0c5 <std::sys::backtrace::__rust_begin_short_backtrace+0xed5>
    0.00 :   cd09f:  mov    0xc8(%r12),%rax
    0.00 :   cd0a7:  mov    %rax,%rcx
    0.00 :   cd0aa:  or     $0x4,%rcx
    0.00 :   cd0ae:  lock cmpxchg %rcx,0xc8(%r12)
    0.00 :   cd0b8:  jne    cd0a7 <std::sys::backtrace::__rust_begin_short_backtrace+0xeb7>
    0.00 :   cd0ba:  mov    $0x2,%bpl
    0.00 :   cd0bd:  test   $0x2,%al
    0.00 :   cd0bf:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd0c5:  mov    0xd0(%r12),%rax
    0.00 :   cd0cd:  test   $0x2,%al
    0.00 :   cd0cf:  jne    cd0f7 <std::sys::backtrace::__rust_begin_short_backtrace+0xf07>
    0.00 :   cd0d1:  mov    0xd0(%r12),%rax
    0.00 :   cd0d9:  mov    %rax,%rcx
    0.00 :   cd0dc:  or     $0x4,%rcx
    0.00 :   cd0e0:  lock cmpxchg %rcx,0xd0(%r12)
    0.00 :   cd0ea:  jne    cd0d9 <std::sys::backtrace::__rust_begin_short_backtrace+0xee9>
    0.00 :   cd0ec:  mov    $0x2,%bpl
    0.00 :   cd0ef:  test   $0x2,%al
    0.00 :   cd0f1:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd0f7:  mov    0xd8(%r12),%rax
    0.00 :   cd0ff:  test   $0x2,%al
    0.00 :   cd101:  jne    cd129 <std::sys::backtrace::__rust_begin_short_backtrace+0xf39>
    0.00 :   cd103:  mov    0xd8(%r12),%rax
    0.00 :   cd10b:  mov    %rax,%rcx
    0.00 :   cd10e:  or     $0x4,%rcx
    0.00 :   cd112:  lock cmpxchg %rcx,0xd8(%r12)
    0.00 :   cd11c:  jne    cd10b <std::sys::backtrace::__rust_begin_short_backtrace+0xf1b>
    0.00 :   cd11e:  mov    $0x2,%bpl
    0.00 :   cd121:  test   $0x2,%al
    0.00 :   cd123:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd129:  mov    0xe0(%r12),%rax
    0.00 :   cd131:  test   $0x2,%al
    0.00 :   cd133:  jne    cd15b <std::sys::backtrace::__rust_begin_short_backtrace+0xf6b>
    0.00 :   cd135:  mov    0xe0(%r12),%rax
    0.00 :   cd13d:  mov    %rax,%rcx
    0.00 :   cd140:  or     $0x4,%rcx
    0.00 :   cd144:  lock cmpxchg %rcx,0xe0(%r12)
    0.00 :   cd14e:  jne    cd13d <std::sys::backtrace::__rust_begin_short_backtrace+0xf4d>
    0.00 :   cd150:  mov    $0x2,%bpl
    0.00 :   cd153:  test   $0x2,%al
    0.00 :   cd155:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd15b:  mov    0xe8(%r12),%rax
    0.00 :   cd163:  test   $0x2,%al
    0.00 :   cd165:  jne    cd18d <std::sys::backtrace::__rust_begin_short_backtrace+0xf9d>
    0.00 :   cd167:  mov    0xe8(%r12),%rax
    0.00 :   cd16f:  mov    %rax,%rcx
    0.00 :   cd172:  or     $0x4,%rcx
    0.00 :   cd176:  lock cmpxchg %rcx,0xe8(%r12)
    0.00 :   cd180:  jne    cd16f <std::sys::backtrace::__rust_begin_short_backtrace+0xf7f>
    0.00 :   cd182:  mov    $0x2,%bpl
    0.00 :   cd185:  test   $0x2,%al
    0.00 :   cd187:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd18d:  mov    0xf0(%r12),%rax
    0.00 :   cd195:  test   $0x2,%al
    0.00 :   cd197:  jne    cd231 <std::sys::backtrace::__rust_begin_short_backtrace+0x1041>
    0.00 :   cd19d:  mov    0xf0(%r12),%rax
    0.00 :   cd1a5:  mov    %rax,%rcx
    0.00 :   cd1a8:  or     $0x4,%rcx
    0.00 :   cd1ac:  lock cmpxchg %rcx,0xf0(%r12)
    0.00 :   cd1b6:  jne    cd1a5 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb5>
    0.00 :   cd1b8:  mov    $0x2,%bpl
    0.00 :   cd1bb:  test   $0x2,%al
    0.00 :   cd1bd:  jne    cd231 <std::sys::backtrace::__rust_begin_short_backtrace+0x1041>
    0.00 :   cd1bf:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd1c4:  mov    0x8(%rsp),%rax
    0.00 :   cd1c9:  cmpb   $0x0,0x68(%rax)
    0.00 :   cd1cd:  je     cd289 <std::sys::backtrace::__rust_begin_short_backtrace+0x1099>
    0.00 :   cd1d3:  test   %bpl,%bpl
    0.00 :   cd1d6:  jne    cd1e4 <std::sys::backtrace::__rust_begin_short_backtrace+0xff4>
    0.00 :   cd1d8:  mov    (%r14),%rax
    0.00 :   cd1db:  test   %r9,%rax
    0.00 :   cd1de:  jne    cdb98 <std::sys::backtrace::__rust_begin_short_backtrace+0x19a8>
    0.00 :   cd1e4:  xor    %eax,%eax
    0.00 :   cd1e6:  mov    0x8(%rsp),%rcx
    0.00 :   cd1eb:  xchg   %eax,(%rcx)
    0.00 :   cd1ed:  mov    $0x1,%bpl
    0.00 :   cd1f0:  cmp    $0x2,%eax
    0.00 :   cd1f3:  jne    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd1f9:  mov    $0xca,%edi
    0.00 :   cd1fe:  mov    0x8(%rsp),%rsi
    0.00 :   cd203:  jmp    cd39c <std::sys::backtrace::__rust_begin_short_backtrace+0x11ac>
    0.00 :   cd208:  mov    0x8(%r12,%r15,8),%rax
    0.00 :   cd20d:  nopl   (%rax)
    0.00 :   cd210:  mov    %rax,%rdx
    0.00 :   cd213:  or     $0x2,%rdx
    0.00 :   cd217:  lock cmpxchg %rdx,0x8(%r12,%r15,8)
    0.00 :   cd21e:  jne    cd210 <std::sys::backtrace::__rust_begin_short_backtrace+0x1020>
    0.00 :   cd220:  mov    $0x2,%bpl
    0.00 :   cd223:  test   $0x4,%al
    0.00 :   cd225:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd22b:  cmp    $0x1c,%r15d
    0.00 :   cd22f:  jbe    cd259 <std::sys::backtrace::__rust_begin_short_backtrace+0x1069>
    0.00 :   cd231:  mov    %r12,%rdi
    0.00 :   cd234:  call   *0xc3db6(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cd23a:  mov    $0x2,%bpl
    0.00 :   cd23d:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd242:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cd250:  inc    %rcx
    0.00 :   cd253:  cmp    $0x1e,%rcx
    0.00 :   cd257:  je     cd231 <std::sys::backtrace::__rust_begin_short_backtrace+0x1041>
    0.00 :   cd259:  mov    0x8(%r12,%rcx,8),%rax
    0.00 :   cd25e:  test   $0x2,%al
    0.00 :   cd260:  jne    cd250 <std::sys::backtrace::__rust_begin_short_backtrace+0x1060>
    0.00 :   cd262:  mov    0x8(%r12,%rcx,8),%rax
    0.00 :   cd267:  nopw   0x0(%rax,%rax,1)
    0.00 :   cd270:  mov    %rax,%rdx
    0.00 :   cd273:  or     $0x4,%rdx
    0.00 :   cd277:  lock cmpxchg %rdx,0x8(%r12,%rcx,8)
    0.00 :   cd27e:  jne    cd270 <std::sys::backtrace::__rust_begin_short_backtrace+0x1080>
    0.00 :   cd280:  test   $0x2,%al
    0.00 :   cd282:  jne    cd250 <std::sys::backtrace::__rust_begin_short_backtrace+0x1060>
    0.00 :   cd284:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd289:  lea    0x90(%rsp),%rbx
    0.00 :   cd291:  mov    %rbx,0x50(%rsp)
    0.00 :   cd296:  lea    0x80(%rsp),%r13
    0.00 :   cd29e:  mov    %r13,0x58(%rsp)
    0.00 :   cd2a3:  mov    %rax,0x60(%rsp)
    0.00 :   cd2a8:  mov    %rax,0x68(%rsp)
    0.00 :   cd2ad:  mov    %bpl,0x70(%rsp)
    0.00 :   cd2b2:  mov    $0xffffffffffffff98,%rax
    0.00 :   cd2b9:  mov    %fs:0x0,%r15
    0.00 :   cd2c2:  add    %rax,%r15
    0.00 :   cd2c5:  cmpb   $0x1,%fs:0x8(%rax)
    0.00 :   cd2ca:  jne    cd546 <std::sys::backtrace::__rust_begin_short_backtrace+0x1356>
    0.00 :   cd2d0:  mov    (%r15),%r12
    0.00 :   cd2d3:  movq   $0x0,(%r15)
    0.00 :   cd2da:  test   %r12,%r12
    0.00 :   cd2dd:  je     cd56b <std::sys::backtrace::__rust_begin_short_backtrace+0x137b>
    0.00 :   cd2e3:  lea    0x71(%rsp),%rax
    0.00 :   cd2e8:  mov    %r12,0x18(%rsp)
    0.00 :   cd2ed:  movq   $0x0,0x18(%r12)
    0.00 :   cd2f6:  movq   $0x0,0x20(%r12)
    0.00 :   cd2ff:  movb   $0x2,0x70(%rsp)
    0.00 :   cd304:  movups 0x50(%rsp),%xmm0
    0.00 :   cd309:  movups 0x60(%rsp),%xmm1
    0.00 :   cd30e:  movaps %xmm0,0x20(%rsp)
    0.00 :   cd313:  movaps %xmm1,0x30(%rsp)
    0.00 :   cd318:  mov    %bpl,0x40(%rsp)
    0.00 :   cd31d:  mov    (%rax),%ecx
    0.00 :   cd31f:  mov    0x3(%rax),%eax
    0.00 :   cd322:  mov    %ecx,0x41(%rsp)
    0.00 :   cd326:  mov    %eax,0x44(%rsp)
    0.00 :   cd32a:  lea    0x20(%rsp),%rdi
    0.00 :   cd32f:  mov    %r12,%rsi
    0.00 :   cd332:  call   cf8c0 <std::sync::mpmc::zero::Channel<T>::recv::{{closure}}>
    0.00 :   cd337:  mov    %eax,%ebp
    0.00 :   cd339:  mov    (%r15),%rax
    0.00 :   cd33c:  mov    %rax,0x20(%rsp)
    0.00 :   cd341:  mov    %r12,(%r15)
    0.00 :   cd344:  test   %rax,%rax
    0.00 :   cd347:  je     cd35a <std::sys::backtrace::__rust_begin_short_backtrace+0x116a>
    0.00 :   cd349:  lock decq (%rax)
    0.00 :   cd34d:  jne    cd35a <std::sys::backtrace::__rust_begin_short_backtrace+0x116a>
    0.00 :   cd34f:  lea    0x20(%rsp),%rdi
    0.00 :   cd354:  call   *0xc4b96(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cd35a:  movzbl 0x70(%rsp),%eax
    0.00 :   cd35f:  cmp    $0x2,%al
    0.00 :   cd361:  je     cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd367:  mov    0x68(%rsp),%r15
    0.00 :   cd36c:  test   $0x1,%al
    0.00 :   cd36e:  jne    cd386 <std::sys::backtrace::__rust_begin_short_backtrace+0x1196>
    0.00 :   cd370:  mov    (%r14),%rax
    0.00 :   cd373:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cd37d:  test   %rcx,%rax
    0.00 :   cd380:  jne    cdbd6 <std::sys::backtrace::__rust_begin_short_backtrace+0x19e6>
    0.00 :   cd386:  xor    %eax,%eax
    0.00 :   cd388:  xchg   %eax,(%r15)
    0.00 :   cd38b:  cmp    $0x2,%eax
    0.00 :   cd38e:  jne    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd394:  mov    $0xca,%edi
    0.00 :   cd399:  mov    %r15,%rsi
    0.00 :   cd39c:  mov    $0x81,%edx
    0.00 :   cd3a1:  mov    $0x1,%ecx
    0.00 :   cd3a6:  xor    %eax,%eax
    0.00 :   cd3a8:  call   *0xc3fd2(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cd3ae:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd3b3:  xor    %ebx,%ebx
    0.00 :   cd3b5:  xor    %ebp,%ebp
    0.00 :   cd3b7:  jmp    cd3de <std::sys::backtrace::__rust_begin_short_backtrace+0x11ee>
    0.00 :   cd3b9:  nopl   0x0(%rax)
    0.00 :   cd3c0:  call   *0xc415a(%rip)        # 191520 <sched_yield@GLIBC_2.2.5>
    0.00 :   cd3c6:  lea    0x1(,%rbp,2),%ecx
    0.00 :   cd3cd:  inc    %ebp
    0.00 :   cd3cf:  mov    (%r12),%rax
    0.00 :   cd3d3:  add    %ecx,%ebx
    0.00 :   cd3d5:  test   %rax,%rax
    0.00 :   cd3d8:  jne    ccb68 <std::sys::backtrace::__rust_begin_short_backtrace+0x978>
    0.00 :   cd3de:  cmp    $0x7,%ebp
    0.00 :   cd3e1:  jae    cd3c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x11d0>
    0.00 :   cd3e3:  test   %ebp,%ebp
    0.00 :   cd3e5:  je     cd3c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x11d6>
    0.00 :   cd3e7:  lea    -0x1(%rbx),%ecx
    0.00 :   cd3ea:  mov    %ebx,%eax
    0.00 :   cd3ec:  and    $0x7,%eax
    0.00 :   cd3ef:  cmp    $0x7,%ecx
    0.00 :   cd3f2:  jb     cd420 <std::sys::backtrace::__rust_begin_short_backtrace+0x1230>
    0.00 :   cd3f4:  mov    %ebx,%ecx
    0.00 :   cd3f6:  and    $0xfffffff8,%ecx
    0.00 :   cd3f9:  nopl   0x0(%rax)
    0.00 :   cd400:  pause
    0.00 :   cd402:  pause
    0.00 :   cd404:  pause
    0.00 :   cd406:  pause
    0.00 :   cd408:  pause
    0.00 :   cd40a:  pause
    0.00 :   cd40c:  pause
    0.00 :   cd40e:  pause
    0.00 :   cd410:  add    $0xfffffff8,%ecx
    0.00 :   cd413:  jne    cd400 <std::sys::backtrace::__rust_begin_short_backtrace+0x1210>
    0.00 :   cd415:  test   %eax,%eax
    0.00 :   cd417:  je     cd3c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x11d6>
    0.00 :   cd419:  nopl   0x0(%rax)
    0.00 :   cd420:  pause
    0.00 :   cd422:  dec    %eax
    0.00 :   cd424:  jne    cd420 <std::sys::backtrace::__rust_begin_short_backtrace+0x1230>
    0.00 :   cd426:  jmp    cd3c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x11d6>
    0.00 :   cd428:  movzbl 0x1(%r12),%eax
    0.00 :   cd42e:  test   %al,%al
    0.00 :   cd430:  je     cd467 <std::sys::backtrace::__rust_begin_short_backtrace+0x1277>
    0.00 :   cd432:  cmpb   $0x0,0x2(%r12)
    0.00 :   cd438:  movb   $0x0,0x2(%r12)
    0.00 :   cd43e:  je     cdcff <std::sys::backtrace::__rust_begin_short_backtrace+0x1b0f>
    0.00 :   cd444:  mov    %r12,%rdi
    0.00 :   cd447:  call   *0xc3ba3(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cd44d:  mov    $0x2,%bpl
    0.00 :   cd450:  lock decq (%r14)
    0.00 :   cd454:  je     cd5f0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1400>
    0.00 :   cd45a:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd45f:  mov    $0x1,%bpl
    0.00 :   cd462:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd467:  xor    %ebx,%ebx
    0.00 :   cd469:  mov    0xc40b0(%rip),%r15        # 191520 <sched_yield@GLIBC_2.2.5>
    0.00 :   cd470:  xor    %ebp,%ebp
    0.00 :   cd472:  jmp    cd48c <std::sys::backtrace::__rust_begin_short_backtrace+0x129c>
    0.00 :   cd474:  call   *%r15
    0.00 :   cd477:  lea    0x1(,%rbp,2),%eax
    0.00 :   cd47e:  inc    %ebp
    0.00 :   cd480:  movzbl 0x1(%r12),%ecx
    0.00 :   cd486:  add    %eax,%ebx
    0.00 :   cd488:  test   %cl,%cl
    0.00 :   cd48a:  jne    cd432 <std::sys::backtrace::__rust_begin_short_backtrace+0x1242>
    0.00 :   cd48c:  cmp    $0x7,%ebp
    0.00 :   cd48f:  jae    cd474 <std::sys::backtrace::__rust_begin_short_backtrace+0x1284>
    0.00 :   cd491:  test   %ebp,%ebp
    0.00 :   cd493:  je     cd477 <std::sys::backtrace::__rust_begin_short_backtrace+0x1287>
    0.00 :   cd495:  lea    -0x1(%rbx),%ecx
    0.00 :   cd498:  mov    %ebx,%eax
    0.00 :   cd49a:  and    $0x7,%eax
    0.00 :   cd49d:  cmp    $0x7,%ecx
    0.00 :   cd4a0:  jb     cd4d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e0>
    0.00 :   cd4a2:  mov    %ebx,%ecx
    0.00 :   cd4a4:  and    $0xfffffff8,%ecx
    0.00 :   cd4a7:  nopw   0x0(%rax,%rax,1)
    0.00 :   cd4b0:  pause
    0.00 :   cd4b2:  pause
    0.00 :   cd4b4:  pause
    0.00 :   cd4b6:  pause
    0.00 :   cd4b8:  pause
    0.00 :   cd4ba:  pause
    0.00 :   cd4bc:  pause
    0.00 :   cd4be:  pause
    0.00 :   cd4c0:  add    $0xfffffff8,%ecx
    0.00 :   cd4c3:  jne    cd4b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x12c0>
    0.00 :   cd4c5:  test   %eax,%eax
    0.00 :   cd4c7:  je     cd477 <std::sys::backtrace::__rust_begin_short_backtrace+0x1287>
    0.00 :   cd4c9:  nopl   0x0(%rax)
    0.00 :   cd4d0:  pause
    0.00 :   cd4d2:  dec    %eax
    0.00 :   cd4d4:  jne    cd4d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x12e0>
    0.00 :   cd4d6:  jmp    cd477 <std::sys::backtrace::__rust_begin_short_backtrace+0x1287>
    0.00 :   cd4d8:  xor    %ebp,%ebp
    0.00 :   cd4da:  jmp    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd4df:  mov    0x8(%rsp),%rdi
    0.00 :   cd4e4:  call   *0xc3ede(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cd4ea:  jmp    cc94e <std::sys::backtrace::__rust_begin_short_backtrace+0x75e>
    0.00 :   cd4ef:  mov    $0x1,%r12b
    0.00 :   cd4f2:  mov    $0x1,%r13b
    0.00 :   cd4f5:  call   *0xc3e75(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cd4fb:  mov    %eax,%ebp
    0.00 :   cd4fd:  xor    $0x1,%bpl
    0.00 :   cd501:  mov    0x8(%rsp),%rcx
    0.00 :   cd506:  movzbl 0x4(%rcx),%eax
    0.00 :   cd50a:  test   %al,%al
    0.00 :   cd50c:  je     cc977 <std::sys::backtrace::__rust_begin_short_backtrace+0x787>
    0.00 :   cd512:  mov    %rcx,0x20(%rsp)
    0.00 :   cd517:  mov    %bpl,0x28(%rsp)
    0.00 :   cd51c:  lea    -0xb00e9(%rip),%rdi        # 1d43a <anon.cccb389264607a2d4c2b49e143c9c1b6.150.llvm.10013882635303053058+0xd2>
    0.00 :   cd523:  lea    0xbf196(%rip),%rcx        # 18c6c0 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x60>
    0.00 :   cd52a:  lea    0xbec4f(%rip),%r8        # 18c180 <anon.cccb389264607a2d4c2b49e143c9c1b6.75.llvm.10013882635303053058+0x180>
    0.00 :   cd531:  lea    0x20(%rsp),%rdx
    0.00 :   cd536:  mov    $0x2b,%esi
    0.00 :   cd53b:  call   *0xc3ae7(%rip)        # 191028 <_DYNAMIC+0x268>
    0.00 :   cd541:  jmp    cdd26 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b36>
    0.00 :   cd546:  mov    %r15,%rdi
    0.00 :   cd549:  call   c5fe0 <std::sys::thread_local::native::lazy::Storage<T,D>::get_or_init_slow>
    0.00 :   cd54e:  mov    %rax,%r15
    0.00 :   cd551:  test   %rax,%rax
    0.00 :   cd554:  jne    cd2d0 <std::sys::backtrace::__rust_begin_short_backtrace+0x10e0>
    0.00 :   cd55a:  lea    0x50(%rsp),%rdi
    0.00 :   cd55f:  call   d1500 <std::sync::mpmc::context::Context::with::{{closure}}>
    0.00 :   cd564:  mov    %eax,%ebp
    0.00 :   cd566:  jmp    cd35a <std::sys::backtrace::__rust_begin_short_backtrace+0x116a>
    0.00 :   cd56b:  call   *0xc45af(%rip)        # 191b20 <_DYNAMIC+0xd60>
    0.00 :   cd571:  mov    %rax,%r15
    0.00 :   cd574:  mov    %rax,0x18(%rsp)
    0.00 :   cd579:  movb   $0x2,0x70(%rsp)
    0.00 :   cd57e:  mov    %rbx,0x20(%rsp)
    0.00 :   cd583:  mov    %r13,0x28(%rsp)
    0.00 :   cd588:  mov    0x8(%rsp),%rax
    0.00 :   cd58d:  mov    %rax,0x30(%rsp)
    0.00 :   cd592:  mov    %rax,0x38(%rsp)
    0.00 :   cd597:  mov    %bpl,0x40(%rsp)
    0.00 :   cd59c:  lea    0x20(%rsp),%rdi
    0.00 :   cd5a1:  mov    %r15,%rsi
    0.00 :   cd5a4:  call   cf8c0 <std::sync::mpmc::zero::Channel<T>::recv::{{closure}}>
    0.00 :   cd5a9:  mov    %eax,%ebp
    0.00 :   cd5ab:  lock decq (%r15)
    0.00 :   cd5af:  jne    cd35a <std::sys::backtrace::__rust_begin_short_backtrace+0x116a>
    0.00 :   cd5b5:  lea    0x18(%rsp),%rdi
    0.00 :   cd5ba:  jmp    cd354 <std::sys::backtrace::__rust_begin_short_backtrace+0x1164>
    0.00 :   cd5bf:  mov    $0xca,%edi
    0.00 :   cd5c4:  mov    $0x81,%edx
    0.00 :   cd5c9:  mov    $0x1,%ecx
    0.00 :   cd5ce:  xor    %eax,%eax
    0.00 :   cd5d0:  call   *0xc3daa(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cd5d6:  mov    0xb0(%rsp),%r12
    0.00 :   cd5de:  test   %r12,%r12
    0.00 :   cd5e1:  jne    ccae8 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f8>
    0.00 :   cd5e7:  mov    $0x1,%bpl
    0.00 :   cd5ea:  lock decq (%r14)
    0.00 :   cd5ee:  jne    cd5fb <std::sys::backtrace::__rust_begin_short_backtrace+0x140b>
    0.00 :   cd5f0:  lea    0x20(%rsp),%rdi
    0.00 :   cd5f5:  call   *0xc48f5(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cd5fb:  cmp    $0x2,%bpl
    0.00 :   cd5ff:  jne    cd64d <std::sys::backtrace::__rust_begin_short_backtrace+0x145d>
    0.00 :   cd601:  mov    0x78(%rsp),%rax
    0.00 :   cd606:  mov    0x10(%rax),%rdi
    0.00 :   cd60a:  mov    $0x1,%r13b
    0.00 :   cd60d:  xor    %r12d,%r12d
    0.00 :   cd610:  mov    $0x4,%esi
    0.00 :   cd615:  call   102ae0 <vthread::worker_context::attach>
    0.00 :   cd61a:  mov    0x78(%rsp),%rax
    0.00 :   cd61f:  movups 0x18(%rax),%xmm0
    0.00 :   cd623:  movaps %xmm0,0x50(%rsp)
    0.00 :   cd628:  mov    0x28(%rax),%rax
    0.00 :   cd62c:  mov    %rax,0x60(%rsp)
    0.00 :   cd631:  mov    0x50(%rsp),%r12
    0.00 :   cd636:  mov    0x58(%rsp),%rbx
    0.00 :   cd63b:  lea    0x108(%r12),%r13
    0.00 :   cd643:  lea    0x168(%r12),%rbp
    0.00 :   cd64b:  jmp    cd6c3 <std::sys::backtrace::__rust_begin_short_backtrace+0x14d3>
    0.00 :   cd64d:  mov    0x10(%rsp),%rdi
    0.00 :   cd652:  mov    0x8(%rsp),%rsi
    0.00 :   cd657:  mov    0x78(%rsp),%r15
    0.00 :   cd65c:  call   da300 <core::ptr::drop_in_place<std::sync::mpsc::Receiver<()>>>
    0.00 :   cd661:  mov    0x10(%r15),%rdi
    0.00 :   cd665:  cmp    $0xffffffffffffffff,%rdi
    0.00 :   cd669:  je     cd678 <std::sys::backtrace::__rust_begin_short_backtrace+0x1488>
    0.00 :   cd66b:  lock decq 0x8(%rdi)
    0.00 :   cd670:  jne    cd678 <std::sys::backtrace::__rust_begin_short_backtrace+0x1488>
    0.00 :   cd672:  call   *0xc3978(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cd678:  lea    0x18(%r15),%rdi
    0.00 :   cd67c:  call   d5340 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   cd681:  mov    0x30(%r15),%rbx
    0.00 :   cd685:  jmp    cdabc <std::sys::backtrace::__rust_begin_short_backtrace+0x18cc>
    0.00 :   cd68a:  mov    $0xca,%edi
    0.00 :   cd68f:  mov    %rbp,%rsi
    0.00 :   cd692:  mov    $0x81,%edx
    0.00 :   cd697:  mov    $0x1,%ecx
    0.00 :   cd69c:  xor    %eax,%eax
    0.00 :   cd69e:  call   *0xc3cdc(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cd6a4:  test   %r13b,%r13b
    0.00 :   cd6a7:  jne    cd77b <std::sys::backtrace::__rust_begin_short_backtrace+0x158b>
    0.00 :   cd6ad:  nopl   (%rax)
    0.00 :   cd6b0:  mov    %r14,%r13
    0.00 :   cd6b3:  mov    %r14,%rdi
    0.00 :   cd6b6:  mov    %r15,%rsi
    0.00 :   cd6b9:  mov    $0x3b9aca00,%ecx
    0.00 :   cd6be:  call   117c70 <vthread::signal::Signal::wait>
    0.00 :   cd6c3:  mov    %r13,%r14
    0.00 :   cd6c6:  mov    0x0(%r13),%r15
    0.00 :   cd6ca:  movzbl 0x10(%rbx),%eax
    0.00 :   cd6ce:  test   %al,%al
    0.00 :   cd6d0:  je     cd6b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c0>
    0.00 :   cd6d2:  xor    %eax,%eax
    0.00 :   cd6d4:  mov    $0x1,%ecx
    0.00 :   cd6d9:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   cd6de:  jne    cd73d <std::sys::backtrace::__rust_begin_short_backtrace+0x154d>
    0.00 :   cd6e0:  mov    0xc3c69(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cd6e7:  mov    (%rax),%rax
    0.00 :   cd6ea:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cd6f4:  test   %rcx,%rax
    0.00 :   cd6f7:  jne    cd748 <std::sys::backtrace::__rust_begin_short_backtrace+0x1558>
    0.00 :   cd6f9:  movzbl 0x16c(%r12),%eax
    0.00 :   cd702:  movzbl 0x221(%r12),%r13d
    0.00 :   cd70b:  mov    0xc3c3e(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cd712:  mov    (%rax),%rax
    0.00 :   cd715:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cd71f:  test   %rcx,%rax
    0.00 :   cd722:  jne    cd766 <std::sys::backtrace::__rust_begin_short_backtrace+0x1576>
    0.00 :   cd724:  xor    %eax,%eax
    0.00 :   cd726:  xchg   %eax,0x0(%rbp)
    0.00 :   cd729:  cmp    $0x2,%eax
    0.00 :   cd72c:  je     cd68a <std::sys::backtrace::__rust_begin_short_backtrace+0x149a>
    0.00 :   cd732:  test   %r13b,%r13b
    0.00 :   cd735:  je     cd6b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x14c0>
    0.00 :   cd73b:  jmp    cd77b <std::sys::backtrace::__rust_begin_short_backtrace+0x158b>
    0.00 :   cd73d:  mov    %rbp,%rdi
    0.00 :   cd740:  call   *0xc3c82(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cd746:  jmp    cd6e0 <std::sys::backtrace::__rust_begin_short_backtrace+0x14f0>
    0.00 :   cd748:  call   *0xc3c22(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cd74e:  movzbl 0x16c(%r12),%ecx
    0.00 :   cd757:  movzbl 0x221(%r12),%r13d
    0.00 :   cd760:  test   %al,%al
    0.00 :   cd762:  jne    cd70b <std::sys::backtrace::__rust_begin_short_backtrace+0x151b>
    0.00 :   cd764:  jmp    cd724 <std::sys::backtrace::__rust_begin_short_backtrace+0x1534>
    0.00 :   cd766:  call   *0xc3c04(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cd76c:  test   %al,%al
    0.00 :   cd76e:  jne    cd724 <std::sys::backtrace::__rust_begin_short_backtrace+0x1534>
    0.00 :   cd770:  movb   $0x1,0x16c(%r12)
    0.00 :   cd779:  jmp    cd724 <std::sys::backtrace::__rust_begin_short_backtrace+0x1534>
    0.00 :   cd77b:  mov    $0x1,%ecx
    0.00 :   cd780:  xor    %eax,%eax
    0.00 :   cd782:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   cd787:  jne    cdb17 <std::sys::backtrace::__rust_begin_short_backtrace+0x1927>
    0.00 :   cd78d:  mov    0xc3bbc(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cd794:  mov    (%rax),%rax
    0.00 :   cd797:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cd7a1:  test   %rcx,%rax
    0.00 :   cd7a4:  jne    cdb25 <std::sys::backtrace::__rust_begin_short_backtrace+0x1935>
    0.00 :   cd7aa:  movzbl 0x16c(%r12),%eax
    0.00 :   cd7b3:  movzbl 0x221(%r12),%eax
    0.00 :   cd7bc:  cmp    $0x3,%al
    0.00 :   cd7be:  mov    $0x2,%ecx
    0.00 :   cd7c3:  cmovae %eax,%ecx
    0.00 :   cd7c6:  mov    %cl,0x221(%r12)
    0.00 :   cd7ce:  mov    0xc3b7b(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cd7d5:  mov    (%rax),%rax
    0.00 :   cd7d8:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cd7e2:  test   %rcx,%rax
    0.00 :   cd7e5:  jne    cdb7c <std::sys::backtrace::__rust_begin_short_backtrace+0x198c>
    0.00 :   cd7eb:  xor    %eax,%eax
    0.00 :   cd7ed:  xchg   %eax,0x0(%rbp)
    0.00 :   cd7f0:  cmp    $0x2,%eax
    0.00 :   cd7f3:  je     cdb5d <std::sys::backtrace::__rust_begin_short_backtrace+0x196d>
    0.00 :   cd7f9:  mov    %r14,%rdi
    0.00 :   cd7fc:  call   117f50 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10013882635303053058>
    0.00 :   cd801:  mov    0x60(%rsp),%rbx
    0.00 :   cd806:  mov    0x10(%rbx),%rdi
    0.00 :   cd80a:  lea    0x8(%r12),%r15
    0.00 :   cd80f:  jmp    cd822 <std::sys::backtrace::__rust_begin_short_backtrace+0x1632>
    0.00 :   cd811:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cd820:  pause
    0.00 :   cd822:  mov    (%r15),%rax
    0.00 :   cd825:  data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cd830:  cmp    $0xffffffffffffffff,%rax
    0.00 :   cd834:  je     cd820 <std::sys::backtrace::__rust_begin_short_backtrace+0x1630>
    0.00 :   cd836:  test   %rax,%rax
    0.00 :   cd839:  js     cdae1 <std::sys::backtrace::__rust_begin_short_backtrace+0x18f1>
    0.00 :   cd83f:  lea    0x1(%rax),%rcx
    0.00 :   cd843:  lock cmpxchg %rcx,(%r15)
    0.00 :   cd848:  jne    cd830 <std::sys::backtrace::__rust_begin_short_backtrace+0x1640>
    0.00 :   cd84a:  add    $0x10,%rdi
    0.00 :   cd84e:  mov    %r12,0x20(%rsp)
    0.00 :   cd853:  lea    0x20(%rsp),%rsi
    0.00 :   cd858:  xor    %edx,%edx
    0.00 :   cd85a:  call   12e5f0 <vthread::join_slot::JoinSlots::join_all>
    0.00 :   cd85f:  cmp    $0xffffffffffffffff,%r12
    0.00 :   cd863:  je     cd874 <std::sys::backtrace::__rust_begin_short_backtrace+0x1684>
    0.00 :   cd865:  lock decq (%r15)
    0.00 :   cd869:  jne    cd874 <std::sys::backtrace::__rust_begin_short_backtrace+0x1684>
    0.00 :   cd86b:  mov    %r12,%rdi
    0.00 :   cd86e:  call   *0xc377c(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cd874:  mov    0x10(%rbx),%rdi
    0.00 :   cd878:  add    $0x10,%rdi
    0.00 :   cd87c:  call   12e3c0 <vthread::join_slot::JoinSlots::joined>
    0.00 :   cd881:  test   %al,%al
    0.00 :   cd883:  je     cda90 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cd889:  mov    0x98(%r12),%rax
    0.00 :   cd891:  mov    0xa0(%r12),%rcx
    0.00 :   cd899:  shl    $0x3,%rcx
    0.00 :   cd89d:  xor    %edx,%edx
    0.00 :   cd89f:  jmp    cd8c4 <std::sys::backtrace::__rust_begin_short_backtrace+0x16d4>
    0.00 :   cd8a1:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cd8b0:  mov    0xd0(%rsi),%rsi
    0.00 :   cd8b7:  add    $0x8,%rdx
    0.00 :   cd8bb:  test   %rsi,%rsi
    0.00 :   cd8be:  jne    cda90 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cd8c4:  cmp    %rdx,%rcx
    0.00 :   cd8c7:  je     cd8fa <std::sys::backtrace::__rust_begin_short_backtrace+0x170a>
    0.00 :   cd8c9:  mov    (%rax,%rdx,1),%rsi
    0.00 :   cd8cd:  movzbl 0xe8(%rsi),%edi
    0.00 :   cd8d4:  test   %dil,%dil
    0.00 :   cd8d7:  je     cd8b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x16c0>
    0.00 :   cd8d9:  movzbl 0xe9(%rsi),%edi
    0.00 :   cd8e0:  test   %dil,%dil
    0.00 :   cd8e3:  je     cda90 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cd8e9:  movzbl 0xea(%rsi),%edi
    0.00 :   cd8f0:  test   %dil,%dil
    0.00 :   cd8f3:  jne    cd8b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x16c0>
    0.00 :   cd8f5:  jmp    cda90 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cd8fa:  mov    0x100(%r12),%eax
    0.00 :   cd902:  test   %eax,%eax
    0.00 :   cd904:  jne    cda90 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a0>
    0.00 :   cd90a:  mov    0xd8(%r12),%r15
    0.00 :   cd912:  mov    0xe8(%r12),%rdi
    0.00 :   cd91a:  call   12b490 <vthread::blocking::pool::Pool::stop>
    0.00 :   cd91f:  add    $0x10,%r15
    0.00 :   cd923:  movabs $0x7fffffffffffffff,%rax
    0.00 :   cd92d:  inc    %rax
    0.00 :   cd930:  mov    %rax,0x20(%rsp)
    0.00 :   cd935:  lea    0x20(%rsp),%rsi
    0.00 :   cd93a:  mov    %r15,%rdi
    0.00 :   cd93d:  call   12fe40 <vthread::readiness::Inner::close>
    0.00 :   cd942:  mov    $0x1,%ecx
    0.00 :   cd947:  xor    %eax,%eax
    0.00 :   cd949:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   cd94e:  jne    cdbf4 <std::sys::backtrace::__rust_begin_short_backtrace+0x1a04>
    0.00 :   cd954:  mov    0xc39f5(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cd95b:  mov    (%rax),%rax
    0.00 :   cd95e:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cd968:  test   %rcx,%rax
    0.00 :   cd96b:  jne    cdc02 <std::sys::backtrace::__rust_begin_short_backtrace+0x1a12>
    0.00 :   cd971:  movzbl 0x16c(%r12),%eax
    0.00 :   cd97a:  movzbl 0x221(%r12),%eax
    0.00 :   cd983:  cmp    $0x4,%al
    0.00 :   cd985:  mov    $0x3,%ecx
    0.00 :   cd98a:  cmovae %eax,%ecx
    0.00 :   cd98d:  mov    %cl,0x221(%r12)
    0.00 :   cd995:  mov    0xc39b4(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cd99c:  mov    (%rax),%rax
    0.00 :   cd99f:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cd9a9:  test   %rcx,%rax
    0.00 :   cd9ac:  jne    cdcbe <std::sys::backtrace::__rust_begin_short_backtrace+0x1ace>
    0.00 :   cd9b2:  xor    %eax,%eax
    0.00 :   cd9b4:  xchg   %eax,0x0(%rbp)
    0.00 :   cd9b7:  cmp    $0x2,%eax
    0.00 :   cd9ba:  je     cdc3a <std::sys::backtrace::__rust_begin_short_backtrace+0x1a4a>
    0.00 :   cd9c0:  mov    %r14,%rdi
    0.00 :   cd9c3:  call   117f50 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10013882635303053058>
    0.00 :   cd9c8:  mov    0xd8(%r12),%rsi
    0.00 :   cd9d0:  mov    0xe0(%r12),%rdi
    0.00 :   cd9d8:  add    $0x10,%rdi
    0.00 :   cd9dc:  add    $0x10,%rsi
    0.00 :   cd9e0:  mov    $0x3,%edx
    0.00 :   cd9e5:  call   12e5f0 <vthread::join_slot::JoinSlots::join_all>
    0.00 :   cd9ea:  mov    $0x1,%ecx
    0.00 :   cd9ef:  xor    %eax,%eax
    0.00 :   cd9f1:  lock cmpxchg %ecx,0x0(%rbp)
    0.00 :   cd9f6:  jne    cdc59 <std::sys::backtrace::__rust_begin_short_backtrace+0x1a69>
    0.00 :   cd9fc:  mov    0xc394d(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cda03:  mov    (%rax),%rax
    0.00 :   cda06:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cda10:  test   %rcx,%rax
    0.00 :   cda13:  jne    cdc67 <std::sys::backtrace::__rust_begin_short_backtrace+0x1a77>
    0.00 :   cda19:  movzbl 0x16c(%r12),%eax
    0.00 :   cda22:  movzbl 0x221(%r12),%eax
    0.00 :   cda2b:  cmp    $0x5,%al
    0.00 :   cda2d:  mov    $0x4,%ecx
    0.00 :   cda32:  cmovae %eax,%ecx
    0.00 :   cda35:  mov    %cl,0x221(%r12)
    0.00 :   cda3d:  mov    0xc390c(%rip),%rax        # 191350 <_DYNAMIC+0x590>
    0.00 :   cda44:  mov    (%rax),%rax
    0.00 :   cda47:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cda51:  test   %rcx,%rax
    0.00 :   cda54:  jne    cdcda <std::sys::backtrace::__rust_begin_short_backtrace+0x1aea>
    0.00 :   cda5a:  xor    %eax,%eax
    0.00 :   cda5c:  xchg   %eax,0x0(%rbp)
    0.00 :   cda5f:  cmp    $0x2,%eax
    0.00 :   cda62:  je     cdc9f <std::sys::backtrace::__rust_begin_short_backtrace+0x1aaf>
    0.00 :   cda68:  mov    %r14,%rdi
    0.00 :   cda6b:  call   117f50 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10013882635303053058>
    0.00 :   cda70:  mov    0xf0(%r12),%rdi
    0.00 :   cda78:  add    $0x10,%rdi
    0.00 :   cda7c:  add    $0xf8,%r12
    0.00 :   cda83:  mov    %r12,%rsi
    0.00 :   cda86:  mov    $0x2,%edx
    0.00 :   cda8b:  call   12e5f0 <vthread::join_slot::JoinSlots::join_all>
    0.00 :   cda90:  xor    %r12d,%r12d
    0.00 :   cda93:  lea    0x50(%rsp),%rdi
    0.00 :   cda98:  xor    %r13d,%r13d
    0.00 :   cda9b:  call   d5340 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   cdaa0:  mov    0x78(%rsp),%r15
    0.00 :   cdaa5:  mov    0x30(%r15),%rbx
    0.00 :   cdaa9:  movb   $0x1,0x38(%rbx)
    0.00 :   cdaad:  mov    0x10(%rsp),%rdi
    0.00 :   cdab2:  mov    0x8(%rsp),%rsi
    0.00 :   cdab7:  call   da300 <core::ptr::drop_in_place<std::sync::mpsc::Receiver<()>>>
    0.00 :   cdabc:  lock decq (%rbx)
    0.00 :   cdac0:  jne    cdacf <std::sys::backtrace::__rust_begin_short_backtrace+0x18df>
    0.00 :   cdac2:  add    $0x30,%r15
    0.00 :   cdac6:  mov    %r15,%rdi
    0.00 :   cdac9:  call   *0xc4529(%rip)        # 191ff8 <_DYNAMIC+0x1238>
    0.00 :   cdacf:  add    $0xc8,%rsp
    0.00 :   cdad6:  pop    %rbx
    0.00 :   cdad7:  pop    %r12
    0.00 :   cdad9:  pop    %r13
    0.00 :   cdadb:  pop    %r14
    0.00 :   cdadd:  pop    %r15
    0.00 :   cdadf:  pop    %rbp
    0.00 :   cdae0:  ret
    0.00 :   cdae1:  lea    0xbe458(%rip),%rax        # 18bf40 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x210>
    0.00 :   cdae8:  mov    %rax,0x20(%rsp)
    0.00 :   cdaed:  lea    0x5aec(%rip),%rax        # d35e0 <_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hb2a2ab9295a6d20aE.llvm.10013882635303053058>
    0.00 :   cdaf4:  mov    %rax,0x28(%rsp)
    0.00 :   cdaf9:  lea    -0xbb38b(%rip),%rdi        # 12775 <anon.48996dcd35f4b7aad43cb5fc1472ecbf.144.llvm.7041895458470441471>
    0.00 :   cdb00:  lea    0xbf209(%rip),%rdx        # 18cd10 <anon.cccb389264607a2d4c2b49e143c9c1b6.181.llvm.10013882635303053058+0x6b0>
    0.00 :   cdb07:  lea    0x20(%rsp),%rsi
    0.00 :   cdb0c:  call   *0xc3536(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   cdb12:  jmp    cdd26 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b36>
    0.00 :   cdb17:  mov    %rbp,%rdi
    0.00 :   cdb1a:  call   *0xc38a8(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cdb20:  jmp    cd78d <std::sys::backtrace::__rust_begin_short_backtrace+0x159d>
    0.00 :   cdb25:  call   *0xc3845(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdb2b:  movzbl 0x16c(%r12),%ecx
    0.00 :   cdb34:  movzbl 0x221(%r12),%ecx
    0.00 :   cdb3d:  cmp    $0x3,%cl
    0.00 :   cdb40:  mov    $0x2,%edx
    0.00 :   cdb45:  cmovae %ecx,%edx
    0.00 :   cdb48:  mov    %dl,0x221(%r12)
    0.00 :   cdb50:  test   %al,%al
    0.00 :   cdb52:  jne    cd7ce <std::sys::backtrace::__rust_begin_short_backtrace+0x15de>
    0.00 :   cdb58:  jmp    cd7eb <std::sys::backtrace::__rust_begin_short_backtrace+0x15fb>
    0.00 :   cdb5d:  mov    $0xca,%edi
    0.00 :   cdb62:  mov    %rbp,%rsi
    0.00 :   cdb65:  mov    $0x81,%edx
    0.00 :   cdb6a:  mov    $0x1,%ecx
    0.00 :   cdb6f:  xor    %eax,%eax
    0.00 :   cdb71:  call   *0xc3809(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cdb77:  jmp    cd7f9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1609>
    0.00 :   cdb7c:  call   *0xc37ee(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdb82:  test   %al,%al
    0.00 :   cdb84:  jne    cd7eb <std::sys::backtrace::__rust_begin_short_backtrace+0x15fb>
    0.00 :   cdb8a:  movb   $0x1,0x16c(%r12)
    0.00 :   cdb93:  jmp    cd7eb <std::sys::backtrace::__rust_begin_short_backtrace+0x15fb>
    0.00 :   cdb98:  mov    $0x1,%r12b
    0.00 :   cdb9b:  mov    $0x1,%r13b
    0.00 :   cdb9e:  call   *0xc37cc(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdba4:  test   %al,%al
    0.00 :   cdba6:  jne    cd1e4 <std::sys::backtrace::__rust_begin_short_backtrace+0xff4>
    0.00 :   cdbac:  mov    0x8(%rsp),%rax
    0.00 :   cdbb1:  movb   $0x1,0x4(%rax)
    0.00 :   cdbb5:  jmp    cd1e4 <std::sys::backtrace::__rust_begin_short_backtrace+0xff4>
    0.00 :   cdbba:  call   *0xc37b0(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdbc0:  test   %al,%al
    0.00 :   cdbc2:  jne    ccac5 <std::sys::backtrace::__rust_begin_short_backtrace+0x8d5>
    0.00 :   cdbc8:  mov    0x8(%rsp),%rax
    0.00 :   cdbcd:  movb   $0x1,0x4(%rax)
    0.00 :   cdbd1:  jmp    ccac5 <std::sys::backtrace::__rust_begin_short_backtrace+0x8d5>
    0.00 :   cdbd6:  mov    $0x1,%r12b
    0.00 :   cdbd9:  mov    $0x1,%r13b
    0.00 :   cdbdc:  call   *0xc378e(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdbe2:  test   %al,%al
    0.00 :   cdbe4:  jne    cd386 <std::sys::backtrace::__rust_begin_short_backtrace+0x1196>
    0.00 :   cdbea:  movb   $0x1,0x4(%r15)
    0.00 :   cdbef:  jmp    cd386 <std::sys::backtrace::__rust_begin_short_backtrace+0x1196>
    0.00 :   cdbf4:  mov    %rbp,%rdi
    0.00 :   cdbf7:  call   *0xc37cb(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cdbfd:  jmp    cd954 <std::sys::backtrace::__rust_begin_short_backtrace+0x1764>
    0.00 :   cdc02:  call   *0xc3768(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdc08:  movzbl 0x16c(%r12),%ecx
    0.00 :   cdc11:  movzbl 0x221(%r12),%ecx
    0.00 :   cdc1a:  cmp    $0x4,%cl
    0.00 :   cdc1d:  mov    $0x3,%edx
    0.00 :   cdc22:  cmovae %ecx,%edx
    0.00 :   cdc25:  mov    %dl,0x221(%r12)
    0.00 :   cdc2d:  test   %al,%al
    0.00 :   cdc2f:  jne    cd995 <std::sys::backtrace::__rust_begin_short_backtrace+0x17a5>
    0.00 :   cdc35:  jmp    cd9b2 <std::sys::backtrace::__rust_begin_short_backtrace+0x17c2>
    0.00 :   cdc3a:  mov    $0xca,%edi
    0.00 :   cdc3f:  mov    %rbp,%rsi
    0.00 :   cdc42:  mov    $0x81,%edx
    0.00 :   cdc47:  mov    $0x1,%ecx
    0.00 :   cdc4c:  xor    %eax,%eax
    0.00 :   cdc4e:  call   *0xc372c(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cdc54:  jmp    cd9c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x17d0>
    0.00 :   cdc59:  mov    %rbp,%rdi
    0.00 :   cdc5c:  call   *0xc3766(%rip)        # 1913c8 <_DYNAMIC+0x608>
    0.00 :   cdc62:  jmp    cd9fc <std::sys::backtrace::__rust_begin_short_backtrace+0x180c>
    0.00 :   cdc67:  call   *0xc3703(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdc6d:  movzbl 0x16c(%r12),%ecx
    0.00 :   cdc76:  movzbl 0x221(%r12),%ecx
    0.00 :   cdc7f:  cmp    $0x5,%cl
    0.00 :   cdc82:  mov    $0x4,%edx
    0.00 :   cdc87:  cmovae %ecx,%edx
    0.00 :   cdc8a:  mov    %dl,0x221(%r12)
    0.00 :   cdc92:  test   %al,%al
    0.00 :   cdc94:  jne    cda3d <std::sys::backtrace::__rust_begin_short_backtrace+0x184d>
    0.00 :   cdc9a:  jmp    cda5a <std::sys::backtrace::__rust_begin_short_backtrace+0x186a>
    0.00 :   cdc9f:  mov    $0xca,%edi
    0.00 :   cdca4:  mov    %rbp,%rsi
    0.00 :   cdca7:  mov    $0x81,%edx
    0.00 :   cdcac:  mov    $0x1,%ecx
    0.00 :   cdcb1:  xor    %eax,%eax
    0.00 :   cdcb3:  call   *0xc36c7(%rip)        # 191380 <syscall@GLIBC_2.2.5>
    0.00 :   cdcb9:  jmp    cda68 <std::sys::backtrace::__rust_begin_short_backtrace+0x1878>
    0.00 :   cdcbe:  call   *0xc36ac(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdcc4:  test   %al,%al
    0.00 :   cdcc6:  jne    cd9b2 <std::sys::backtrace::__rust_begin_short_backtrace+0x17c2>
    0.00 :   cdccc:  movb   $0x1,0x16c(%r12)
    0.00 :   cdcd5:  jmp    cd9b2 <std::sys::backtrace::__rust_begin_short_backtrace+0x17c2>
    0.00 :   cdcda:  call   *0xc3690(%rip)        # 191370 <_DYNAMIC+0x5b0>
    0.00 :   cdce0:  test   %al,%al
    0.00 :   cdce2:  jne    cda5a <std::sys::backtrace::__rust_begin_short_backtrace+0x186a>
    0.00 :   cdce8:  movb   $0x1,0x16c(%r12)
    0.00 :   cdcf1:  jmp    cda5a <std::sys::backtrace::__rust_begin_short_backtrace+0x186a>
    0.00 :   cdcf6:  lea    0xbe46b(%rip),%rdi        # 18c168 <anon.cccb389264607a2d4c2b49e143c9c1b6.75.llvm.10013882635303053058+0x168>
    0.00 :   cdcfd:  jmp    cdd06 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b16>
    0.00 :   cdcff:  lea    0xbe44a(%rip),%rdi        # 18c150 <anon.cccb389264607a2d4c2b49e143c9c1b6.75.llvm.10013882635303053058+0x150>
    0.00 :   cdd06:  call   *0xc34ac(%rip)        # 1911b8 <_DYNAMIC+0x3f8>
    0.00 :   cdd0c:  jmp    cdd26 <std::sys::backtrace::__rust_begin_short_backtrace+0x1b36>
    0.00 :   cdd0e:  lea    0xbe183(%rip),%rdx        # 18be98 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x168>
    0.00 :   cdd15:  mov    0xc0(%rsp),%rdi
    0.00 :   cdd1d:  mov    %r12,%rsi
    0.00 :   cdd20:  call   *0xc333a(%rip)        # 191060 <_DYNAMIC+0x2a0>
    0.00 :   cdd26:  ud2
    0.00 :   cdd28:  mov    %rax,%rbx
    0.00 :   cdd2b:  lock decq (%r15)
    0.00 :   cdd2f:  je     cdd95 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ba5>
    0.00 :   cdd31:  jmp    cdda0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1bb0>
    0.00 :   cdd33:  mov    %rax,%rbx
    0.00 :   cdd36:  jmp    cdda0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1bb0>
    0.00 :   cdd38:  mov    %rax,%rbx
    0.00 :   cdd3b:  lock decq (%r15)
    0.00 :   cdd3f:  jmp    cddcc <std::sys::backtrace::__rust_begin_short_backtrace+0x1bdc>
    0.00 :   cdd44:  mov    %rax,%rbx
    0.00 :   cdd47:  lock decq (%r15)
    0.00 :   cdd4b:  mov    $0x1,%r12b
    0.00 :   cdd4e:  je     cddf2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c02>
    0.00 :   cdd54:  jmp    cddfd <std::sys::backtrace::__rust_begin_short_backtrace+0x1c0d>
    0.00 :   cdd59:  mov    %rax,%rbx
    0.00 :   cdd5c:  movzbl %bpl,%esi
    0.00 :   cdd60:  mov    0x8(%rsp),%rdi
    0.00 :   cdd65:  call   dc8f0 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::control::State>>>
    0.00 :   cdd6a:  jmp    cdea8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1cb8>
    0.00 :   cdd6f:  call   *0xc348b(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cdd75:  mov    %rax,%rbx
    0.00 :   cdd78:  jmp    cdea8 <std::sys::backtrace::__rust_begin_short_backtrace+0x1cb8>
    0.00 :   cdd7d:  mov    %rax,%rbx
    0.00 :   cdd80:  mov    $0x1,%r12b
    0.00 :   cdd83:  mov    $0x1,%r13b
    0.00 :   cdd86:  jmp    cded3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ce3>
    0.00 :   cdd8b:  mov    %rax,%rbx
    0.00 :   cdd8e:  lock decq (%r12)
    0.00 :   cdd93:  jne    cdda0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1bb0>
    0.00 :   cdd95:  lea    0x18(%rsp),%rdi
    0.00 :   cdd9a:  call   *0xc4150(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cdda0:  mov    0x68(%rsp),%rdi
    0.00 :   cdda5:  mov    $0x1,%r12b
    0.00 :   cdda8:  mov    0x70(%rsp),%esi
    0.00 :   cddac:  call   d5870 <core::ptr::drop_in_place<core::option::Option<std::sync::poison::mutex::MutexGuard<vthread::control::State>>>>
    0.00 :   cddb1:  mov    $0x1,%r13b
    0.00 :   cddb4:  mov    0x10(%rsp),%rbp
    0.00 :   cddb9:  jmp    cded3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ce3>
    0.00 :   cddbe:  call   *0xc343c(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cddc4:  mov    %rax,%rbx
    0.00 :   cddc7:  lock decq 0x0(%rbp)
    0.00 :   cddcc:  mov    $0x1,%r12b
    0.00 :   cddcf:  jne    cdeab <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbb>
    0.00 :   cddd5:  lea    0x18(%rsp),%rdi
    0.00 :   cddda:  call   *0xc4110(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cdde0:  jmp    cdeab <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbb>
    0.00 :   cdde5:  mov    %rax,%rbx
    0.00 :   cdde8:  lock decq (%r12)
    0.00 :   cdded:  mov    $0x1,%r12b
    0.00 :   cddf0:  jne    cddfd <std::sys::backtrace::__rust_begin_short_backtrace+0x1c0d>
    0.00 :   cddf2:  lea    0x18(%rsp),%rdi
    0.00 :   cddf7:  call   *0xc40f3(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cddfd:  mov    $0x1,%r13b
    0.00 :   cde00:  jmp    cded3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ce3>
    0.00 :   cde05:  jmp    cde2c <std::sys::backtrace::__rust_begin_short_backtrace+0x1c3c>
    0.00 :   cde07:  mov    %rax,%rbx
    0.00 :   cde0a:  cmp    $0xffffffffffffffff,%r12
    0.00 :   cde0e:  je     cdebe <std::sys::backtrace::__rust_begin_short_backtrace+0x1cce>
    0.00 :   cde14:  lock decq (%r15)
    0.00 :   cde18:  jne    cdebe <std::sys::backtrace::__rust_begin_short_backtrace+0x1cce>
    0.00 :   cde1e:  mov    %r12,%rdi
    0.00 :   cde21:  call   *0xc31c9(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cde27:  jmp    cdebe <std::sys::backtrace::__rust_begin_short_backtrace+0x1cce>
    0.00 :   cde2c:  mov    %rax,%rbx
    0.00 :   cde2f:  jmp    cde59 <std::sys::backtrace::__rust_begin_short_backtrace+0x1c69>
    0.00 :   cde31:  mov    %rax,%rbx
    0.00 :   cde34:  mov    0x10(%r15),%rdi
    0.00 :   cde38:  cmp    $0xffffffffffffffff,%rdi
    0.00 :   cde3c:  je     cde4b <std::sys::backtrace::__rust_begin_short_backtrace+0x1c5b>
    0.00 :   cde3e:  lock decq 0x8(%rdi)
    0.00 :   cde43:  jne    cde4b <std::sys::backtrace::__rust_begin_short_backtrace+0x1c5b>
    0.00 :   cde45:  call   *0xc31a5(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cde4b:  mov    0x78(%rsp),%r15
    0.00 :   cde50:  lea    0x18(%r15),%rdi
    0.00 :   cde54:  call   d5340 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   cde59:  mov    0x30(%r15),%rax
    0.00 :   cde5d:  lock decq (%rax)
    0.00 :   cde61:  jne    cdf26 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d36>
    0.00 :   cde67:  mov    0x78(%rsp),%rdi
    0.00 :   cde6c:  add    $0x30,%rdi
    0.00 :   cde70:  call   *0xc4182(%rip)        # 191ff8 <_DYNAMIC+0x1238>
    0.00 :   cde76:  jmp    cdf26 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d36>
    0.00 :   cde7b:  mov    %rax,%rbx
    0.00 :   cde7e:  jmp    cdeae <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbe>
    0.00 :   cde80:  mov    %rax,%rbx
    0.00 :   cde83:  lock decq (%r14)
    0.00 :   cde87:  mov    $0x1,%r12b
    0.00 :   cde8a:  jne    cdeab <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbb>
    0.00 :   cde8c:  lea    0x20(%rsp),%rdi
    0.00 :   cde91:  call   *0xc4059(%rip)        # 191ef0 <_DYNAMIC+0x1130>
    0.00 :   cde97:  jmp    cdeab <std::sys::backtrace::__rust_begin_short_backtrace+0x1cbb>
    0.00 :   cde99:  jmp    cdebb <std::sys::backtrace::__rust_begin_short_backtrace+0x1ccb>
    0.00 :   cde9b:  mov    %rax,%rbx
    0.00 :   cde9e:  lea    0x20(%rsp),%rdi
    0.00 :   cdea3:  call   d5c80 <core::ptr::drop_in_place<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<std::sync::mpmc::zero::Inner>>>>
    0.00 :   cdea8:  mov    $0x1,%r12b
    0.00 :   cdeab:  mov    $0x1,%r13b
    0.00 :   cdeae:  mov    0x10(%rsp),%rbp
    0.00 :   cdeb3:  jmp    cded3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1ce3>
    0.00 :   cdeb5:  call   *0xc3345(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cdebb:  mov    %rax,%rbx
    0.00 :   cdebe:  lea    0x50(%rsp),%rdi
    0.00 :   cdec3:  call   d5340 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   cdec8:  mov    0x10(%rsp),%rbp
    0.00 :   cdecd:  xor    %r12d,%r12d
    0.00 :   cded0:  xor    %r13d,%r13d
    0.00 :   cded3:  mov    %rbp,%rdi
    0.00 :   cded6:  mov    0x8(%rsp),%rsi
    0.00 :   cdedb:  call   da300 <core::ptr::drop_in_place<std::sync::mpsc::Receiver<()>>>
    0.00 :   cdee0:  mov    0x78(%rsp),%r14
    0.00 :   cdee5:  test   %r12b,%r12b
    0.00 :   cdee8:  je     cdf01 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d11>
    0.00 :   cdeea:  mov    0x10(%r14),%rdi
    0.00 :   cdeee:  cmp    $0xffffffffffffffff,%rdi
    0.00 :   cdef2:  je     cdf01 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d11>
    0.00 :   cdef4:  lock decq 0x8(%rdi)
    0.00 :   cdef9:  jne    cdf01 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d11>
    0.00 :   cdefb:  call   *0xc30ef(%rip)        # 190ff0 <free@GLIBC_2.2.5>
    0.00 :   cdf01:  test   %r13b,%r13b
    0.00 :   cdf04:  je     cdf0f <std::sys::backtrace::__rust_begin_short_backtrace+0x1d1f>
    0.00 :   cdf06:  lea    0x18(%r14),%rdi
    0.00 :   cdf0a:  call   d5340 <core::ptr::drop_in_place<vthread::runtime::runtime_lifecycle::ShutdownDriver::new::{{closure}}>>
    0.00 :   cdf0f:  mov    0x30(%r14),%rax
    0.00 :   cdf13:  lock decq (%rax)
    0.00 :   cdf17:  jne    cdf26 <std::sys::backtrace::__rust_begin_short_backtrace+0x1d36>
    0.00 :   cdf19:  add    $0x30,%r14
    0.00 :   cdf1d:  mov    %r14,%rdi
    0.00 :   cdf20:  call   *0xc40d2(%rip)        # 191ff8 <_DYNAMIC+0x1238>
    0.00 :   cdf26:  mov    %rbx,%rdi
    0.00 :   cdf29:  call   186a90 <_Unwind_Resume@plt>
    0.00 :   cdf2e:  call   *0xc32cc(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   cdf34:  call   *0xc32c6(%rip)        # 191200 <_DYNAMIC+0x440>
