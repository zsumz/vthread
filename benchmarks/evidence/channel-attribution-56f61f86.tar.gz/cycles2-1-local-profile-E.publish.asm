 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (261 samples, percent: global period)
-----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3      Disassembly of section .text:
         :
         : 5      0000000000166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>:
         : 6      core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>:
    0.00 :   166da0: push   %r15
    0.00 :   166da2: push   %r14
    0.37 :   166da4: push   %r13
    0.00 :   166da6: push   %r12
    0.00 :   166da8: push   %rbx
    0.00 :   166da9: mov    %rdi,%rbx
    0.00 :   166dac: mov    (%rdi),%r13
    0.00 :   166daf: test   %r13,%r13
    0.00 :   166db2: je     166dea <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>+0x4a>
    0.00 :   166db4: lea    0x10(%r13),%rdi
    0.00 :   166db8: mov    0x8(%rbx),%rsi
    0.00 :   166dbc: mov    $0x1,%r12d
    0.00 :   166dc2: mov    %rbx,%r14
    0.00 :   166dc5: xor    %edx,%edx
    0.00 :   166dc7: xor    %ecx,%ecx
    0.00 :   166dc9: mov    $0x1,%r8d
    0.00 :   166dcf: call   10a310 <_ZN7vthread4wait11wait_select16enqueue_selected17h5a35090e1549dd93E.llvm.10657235172099788962>
    0.00 :   166dd4: lock decq 0x0(%r13)
   29.30 :   166dd9: jne    166dea <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>+0x4a>
    0.00 :   166ddb: mov    $0x1,%r12d
    0.00 :   166de1: mov    %rbx,%rdi
    0.00 :   166de4: call   *0x2c36e(%rip)        # 193158 <_DYNAMIC+0x1140>
    0.00 :   166dea: mov    0x10(%rbx),%r13
    0.00 :   166dee: test   %r13,%r13
    0.00 :   166df1: je     166e2a <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>+0x8a>
    0.00 :   166df3: lea    0x10(%rbx),%r14
    0.00 :   166df7: lea    0x10(%r13),%rdi
    0.00 :   166dfb: mov    0x18(%rbx),%rsi
    0.00 :   166dff: mov    $0x2,%r12d
    0.00 :   166e05: xor    %edx,%edx
    0.00 :   166e07: xor    %ecx,%ecx
    0.00 :   166e09: mov    $0x1,%r8d
    0.00 :   166e0f: call   10a310 <_ZN7vthread4wait11wait_select16enqueue_selected17h5a35090e1549dd93E.llvm.10657235172099788962>
    0.00 :   166e14: lock decq 0x0(%r13)
   70.33 :   166e19: jne    166e2a <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>+0x8a>
    0.00 :   166e1b: mov    $0x2,%r12d
    0.00 :   166e21: mov    %r14,%rdi
    0.00 :   166e24: call   *0x2c32e(%rip)        # 193158 <_DYNAMIC+0x1140>
    0.00 :   166e2a: pop    %rbx
    0.00 :   166e2b: pop    %r12
    0.00 :   166e2d: pop    %r13
    0.00 :   166e2f: pop    %r14
    0.00 :   166e31: pop    %r15
    0.00 :   166e33: ret
    0.00 :   166e34: mov    %rax,%r15
    0.00 :   166e37: jmp    166e4c <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>+0xac>
    0.00 :   166e39: mov    %rax,%r15
    0.00 :   166e3c: lock decq 0x0(%r13)
    0.00 :   166e41: jne    166e4c <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>+0xac>
    0.00 :   166e43: mov    %r14,%rdi
    0.00 :   166e46: call   *0x2c30c(%rip)        # 193158 <_DYNAMIC+0x1140>
    0.00 :   166e4c: cmp    $0x2,%r12d
    0.00 :   166e50: je     166e5e <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>+0xbe>
    0.00 :   166e52: add    $0x10,%rbx
    0.00 :   166e56: mov    %rbx,%rdi
    0.00 :   166e59: call   1661c0 <core::ptr::drop_in_place<core::option::Option<vthread::wait::wait_notification::NotificationPublication>>>
    0.00 :   166e5e: mov    %r15,%rdi
    0.00 :   166e61: call   187ca0 <_Unwind_Resume@plt>
    0.00 :   166e66: call   *0x2b5ec(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   166e6c: call   *0x2b5e6(%rip)        # 192458 <_DYNAMIC+0x440>
