 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (408 samples, percent: global period)
-----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3      Disassembly of section .text:
         :
         : 5      00000000001751c0 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv>:
         : 6      vthread::channel::core::<impl vthread::channel::Core<T>>::recv:
    0.00 :   1751c0: push   %rbp
    0.00 :   1751c1: push   %r15
    0.00 :   1751c3: push   %r14
    0.00 :   1751c5: push   %r13
    0.00 :   1751c7: push   %r12
    0.00 :   1751c9: push   %rbx
    0.00 :   1751ca: sub    $0xe8,%rsp
    0.00 :   1751d1: mov    %rsi,%r14
    0.00 :   1751d4: mov    %rdi,%rbx
    0.00 :   1751d7: movabs $0x8000000000000022,%rbp
    0.00 :   1751e1: lea    0x48(%rsp),%rdi
    0.00 :   1751e6: call   177080 <vthread::context::check_current>
    0.00 :   1751eb: cmp    %rbp,0x48(%rsp)
    0.00 :   1751f0: jne    1754dd <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x31d>
    0.00 :   1751f6: mov    %rbx,0x8(%rsp)
    0.00 :   1751fb: movq   $0x11,0x10(%rsp)
    0.00 :   175204: mov    %r14,0xb8(%rsp)
    0.00 :   17520c: movw   $0x1,0xc0(%rsp)
    0.00 :   175216: movq   $0x0,0xa8(%rsp)
    0.00 :   175222: mov    $0x1,%r15b
    0.00 :   175225: lea    -0x7(%rbp),%rax
    0.00 :   175229: mov    %rax,0xc8(%rsp)
    0.00 :   175231: lea    0x88(%rsp),%r12
    0.00 :   175239: lea    0xa8(%rsp),%r13
    0.00 :   175241: jmp    17527a <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0xba>
    0.00 :   175243: data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   175250: mov    0x40(%rsp),%rax
    0.00 :   175255: mov    %rax,0x20(%rsp)
    0.16 :   17525a: movaps 0x30(%rsp),%xmm0
    3.12 :   17525f: movaps %xmm0,0x10(%rsp)
    0.00 :   175264: mov    %r12,0xd0(%rsp)
    0.00 :   17526c: mov    $0x1,%r15b
    0.00 :   17526f: mov    %rbx,%r12
    0.00 :   175272: mov    %r12,%rdi
    0.00 :   175275: call   166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>
    0.00 :   17527a: movq   $0x0,0x88(%rsp)
    0.00 :   175286: movq   $0x0,0x98(%rsp)
    0.00 :   175292: xor    %eax,%eax
    0.00 :   175294: lock cmpxchg %r15b,0x78(%r14)
    9.01 :   17529a: jne    1754aa <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2ea>
    0.00 :   1752a0: cmpq   $0x0,0x18(%r14)
    0.00 :   1752a5: je     1752c1 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x101>
    0.00 :   1752a7: mov    %r13,%rdi
    0.00 :   1752aa: mov    %r14,%rsi
    0.00 :   1752ad: call   176f40 <vthread::channel::wait::Ticket<T>::take_turn>
    0.00 :   1752b2: test   %al,%al
    0.00 :   1752b4: jne    175554 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x394>
    0.00 :   1752ba: cmpq   $0x0,0x18(%r14)
    0.00 :   1752bf: jne    1752d7 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x117>
    0.00 :   1752c1: cmpb   $0x0,0x70(%r14)
    1.49 :   1752c6: jne    175505 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x345>
    0.00 :   1752cc: cmpq   $0x0,0x60(%r14)
    0.00 :   1752d1: je     175505 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x345>
    0.00 :   1752d7: cmpl   $0x11,0x10(%rsp)
    0.00 :   1752dc: jne    1753c0 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x200>
    0.00 :   1752e2: mov    %r12,%rbx
    0.00 :   1752e5: movb   $0x0,0x78(%r14)
    0.00 :   1752ea: call   *0x1e110(%rip)        # 193400 <_DYNAMIC+0x13e8>
    0.00 :   1752f0: mov    %rax,%r15
    0.00 :   1752f3: lea    -0x7(%rbp),%rax
    0.00 :   1752f7: mov    %rax,0x48(%rsp)
    0.00 :   1752fc: cmp    $0x2,%r15
    0.00 :   175300: je     17551b <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x35b>
    0.00 :   175306: mov    %rdx,%r12
    0.00 :   175309: lea    0x48(%rsp),%rdi
    0.00 :   17530e: call   d7ad0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10657235172099788962>
    0.00 :   175313: test   $0x1,%r15b
    0.00 :   175317: jne    17551b <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x35b>
    0.00 :   17531d: mov    0x10(%r12),%rax
    0.00 :   175322: mov    0x38(%rax),%rax
    0.00 :   175326: mov    0x20(%rax),%rdx
    0.00 :   17532a: mov    0x28(%rax),%rcx
    0.00 :   17532e: movq   $0x9,0x20(%rax)
    0.00 :   175336: mov    %rdx,0xd8(%rsp)
    0.00 :   17533e: mov    %rdx,0x30(%rsp)
    0.00 :   175343: mov    %rcx,0xe0(%rsp)
    0.00 :   17534b: mov    %rcx,0x38(%rsp)
    0.00 :   175350: mov    %r12,0x40(%rsp)
    0.00 :   175355: mov    0x18(%r12),%r15
    0.00 :   17535a: mov    0x68(%r15),%eax
    0.00 :   17535e: add    $0x60,%r15
    0.00 :   175362: test   %eax,%eax
    0.00 :   175364: jne    1754d0 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x310>
    0.00 :   17536a: mov    (%r15),%rcx
    0.00 :   17536d: mov    0x38(%rcx),%rax
    0.00 :   175371: data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   175380: mov    %eax,%edx
    0.00 :   175382: and    $0xf,%edx
    0.00 :   175385: cmp    $0xd,%edx
    0.00 :   175388: jae    1758d1 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x711>
    0.00 :   17538e: test   $0xd0,%al
    0.00 :   175390: je     175430 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x270>
    0.00 :   175396: mov    %eax,%edx
    0.00 :   175398: and    $0x2f,%edx
    0.00 :   17539b: jne    175430 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x270>
    0.00 :   1753a1: mov    %rax,%rdx
    0.00 :   1753a4: and    $0xffffffffffffff00,%rdx
    0.00 :   1753ab: lock cmpxchg %rdx,0x38(%rcx)
    0.00 :   1753b1: jne    175380 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x1c0>
    0.00 :   1753b3: jmp    175438 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x278>
    0.00 :   1753b8: nopl   0x0(%rax,%rax,1)
    0.00 :   1753c0: mov    0x20(%rsp),%rax
    0.00 :   1753c5: mov    0x18(%rax),%rax
    0.00 :   1753c9: mov    0x68(%rax),%ecx
    0.00 :   1753cc: test   %ecx,%ecx
    0.00 :   1753ce: jne    1758ef <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x72f>
    0.00 :   1753d4: mov    0x60(%rax),%rcx
    0.00 :   1753d8: lea    0x48(%rsp),%rdi
    0.00 :   1753dd: mov    %r13,%rsi
    0.00 :   1753e0: mov    %r14,%rdx
    0.00 :   1753e3: call   176c90 <vthread::channel::wait::Ticket<T>::enqueue>
    0.00 :   1753e8: cmp    %rbp,0x48(%rsp)
    0.00 :   1753ed: jne    175673 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x4b3>
    0.00 :   1753f3: movb   $0x0,0x78(%r14)
    0.00 :   1753f8: cmpl   $0x11,0x10(%rsp)
    0.00 :   1753fd: je     17590d <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x74d>
    0.00 :   175403: lea    0x48(%rsp),%rdi
    0.00 :   175408: lea    0x10(%rsp),%rsi
    0.00 :   17540d: call   *0x1e0bd(%rip)        # 1934d0 <_DYNAMIC+0x14b8>
    0.00 :   175413: cmp    %rbp,0x48(%rsp)
    0.00 :   175418: je     175272 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0xb2>
    0.00 :   17541e: jmp    1756a5 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x4e5>
    0.00 :   175423: data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   175430: test   $0x2f,%al
    0.00 :   175432: jne    1756cf <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x50f>
    0.00 :   175438: mov    (%r15),%rax
    0.00 :   17543b: mov    0x30(%rax),%rax
    0.00 :   17543f: cmpq   $0x0,0xa8(%rsp)
    0.00 :   175448: movq   $0x1,0xa8(%rsp)
    0.00 :   175454: mov    %rax,0xb0(%rsp)
    0.00 :   17545c: jne    175928 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x768>
    0.00 :   175462: mov    0x10(%rsp),%rax
    0.00 :   175467: cmp    $0x11,%rax
    0.00 :   17546b: je     175250 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x90>
    0.00 :   175471: mov    0x18(%rsp),%rcx
    0.00 :   175476: mov    0x20(%rsp),%rdx
    0.00 :   17547b: mov    0x10(%rdx),%rsi
    0.00 :   17547f: mov    0x38(%rsi),%rsi
    0.00 :   175483: mov    %rax,0x20(%rsi)
    0.00 :   175487: mov    %rcx,0x28(%rsi)
    0.00 :   17548b: decq   (%rdx)
    0.00 :   17548e: jne    175250 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x90>
    0.00 :   175494: lea    0x20(%rsp),%rdi
    0.00 :   175499: call   *0x1dcd9(%rip)        # 193178 <_DYNAMIC+0x1160>
    0.00 :   17549f: jmp    175250 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x90>
    0.00 :   1754a4: call   *0x1d2ce(%rip)        # 192778 <sched_yield@GLIBC_2.2.5>
    0.00 :   1754aa: xor    %ecx,%ecx
    0.00 :   1754ac: movzbl 0x78(%r14),%eax
   25.22 :   1754b1: test   %al,%al
    0.14 :   1754b3: jne    1754c3 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x303>
    0.00 :   1754b5: xor    %eax,%eax
    1.30 :   1754b7: lock cmpxchg %r15b,0x78(%r14)
   20.02 :   1754bd: je     1752a0 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0xe0>
    0.00 :   1754c3: pause
   26.04 :   1754c5: inc    %rcx
    3.99 :   1754c8: cmp    $0x40,%rcx
    0.00 :   1754cc: jne    1754ac <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2ec>
    0.00 :   1754ce: jmp    1754a4 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x2e4>
    0.00 :   1754d0: mov    %r15,%rdi
    0.00 :   1754d3: call   d1e7a <_ZN3std4sync9once_lock17OnceLock$LT$T$GT$10initialize17hd31d093978ca14d7E.llvm.10657235172099788962>
    0.00 :   1754d8: jmp    17536a <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x1aa>
    0.00 :   1754dd: movups 0x48(%rsp),%xmm0
    0.00 :   1754e2: movups 0x58(%rsp),%xmm1
    0.00 :   1754e7: movups 0x68(%rsp),%xmm2
    0.00 :   1754ec: movups 0x78(%rsp),%xmm3
    0.00 :   1754f1: movups %xmm3,0x30(%rbx)
    0.00 :   1754f5: movups %xmm2,0x20(%rbx)
    0.00 :   1754f9: movups %xmm1,0x10(%rbx)
    0.00 :   1754fd: movups %xmm0,(%rbx)
    0.00 :   175500: jmp    175794 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5d4>
    0.00 :   175505: add    $0xffffffffffffffe3,%rbp
    0.00 :   175509: mov    0x8(%rsp),%rax
    0.00 :   17550e: mov    %rbp,(%rax)
    0.00 :   175511: movb   $0x0,0x78(%r14)
    0.00 :   175516: jmp    175745 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x585>
    0.00 :   17551b: mov    0x8(%rsp),%rax
    0.00 :   175520: mov    0xd8(%rsp),%rcx
    0.00 :   175528: mov    %rcx,0x8(%rax)
    0.00 :   17552c: mov    0xe0(%rsp),%rcx
    0.00 :   175534: mov    %rcx,0x10(%rax)
    0.00 :   175538: mov    0xd0(%rsp),%rcx
    0.00 :   175540: mov    %rcx,0x18(%rax)
    0.00 :   175544: mov    0xc8(%rsp),%rcx
    0.00 :   17554c: mov    %rcx,(%rax)
    0.00 :   17554f: jmp    175745 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x585>
    0.00 :   175554: mov    0x18(%r14),%rax
    0.00 :   175558: test   %rax,%rax
    0.00 :   17555b: je     17598e <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x7ce>
    0.00 :   175561: mov    0x10(%r14),%rdx
    0.00 :   175565: lea    0x1(%rdx),%rsi
    0.00 :   175569: mov    (%r14),%rdi
    0.00 :   17556c: mov    0x8(%r14),%r8
    0.00 :   175570: xor    %ecx,%ecx
    0.00 :   175572: cmp    %rdi,%rsi
    0.00 :   175575: cmovb  %rcx,%rdi
    0.00 :   175579: neg    %rdi
    0.00 :   17557c: lea    (%rdx,%rdi,1),%rsi
    0.00 :   175580: inc    %rsi
    0.00 :   175583: mov    %rsi,0x10(%r14)
    0.00 :   175587: dec    %rax
    0.00 :   17558a: mov    %rax,0x18(%r14)
    0.00 :   17558e: mov    (%r8,%rdx,8),%rbx
    0.26 :   175592: cmpq   $0x0,0x38(%r14)
    0.00 :   175597: je     1757a8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5e8>
    0.00 :   17559d: mov    0x30(%r14),%rdi
    0.00 :   1755a1: mov    0x20(%r14),%rax
    0.00 :   1755a5: mov    0x28(%r14),%rdx
    0.00 :   1755a9: xor    %ecx,%ecx
    0.00 :   1755ab: cmp    %rax,%rdi
    0.00 :   1755ae: cmovb  %rcx,%rax
    0.00 :   1755b2: sub    %rax,%rdi
    0.00 :   1755b5: shl    $0x4,%rdi
    0.00 :   1755b9: mov    0x8(%rdx,%rdi,1),%rsi
    0.51 :   1755be: test   %rsi,%rsi
    0.00 :   1755c1: je     1757a8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5e8>
    0.00 :   1755c7: mov    0x38(%rsi),%rax
    0.51 :   1755cb: mov    %eax,%r8d
    0.00 :   1755ce: and    $0xf,%r8d
    0.00 :   1755d2: cmp    $0xc,%r8
    0.00 :   1755d6: ja     175943 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x783>
    0.00 :   1755dc: add    %rdi,%rdx
    0.00 :   1755df: xor    %ecx,%ecx
    0.00 :   1755e1: mov    $0x155,%edi
    0.00 :   1755e6: jmp    175607 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x447>
    0.00 :   1755e8: nopl   0x0(%rax,%rax,1)
    0.00 :   1755f0: pause
    0.00 :   1755f2: mov    0x38(%rsi),%rax
    0.00 :   1755f6: mov    %eax,%r8d
    0.00 :   1755f9: and    $0xf,%r8d
    0.00 :   1755fd: cmp    $0xd,%r8
    0.00 :   175601: jae    175943 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x783>
    0.00 :   175607: cmp    $0x1,%r8
    0.00 :   17560b: je     1755f0 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x430>
    0.00 :   17560d: test   $0x20,%al
    0.00 :   17560f: jne    1757a8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5e8>
    0.00 :   175615: lea    -0x3(%r8),%r9d
    0.00 :   175619: cmp    $0x9,%r9b
    0.00 :   17561d: jae    17562d <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x46d>
    0.00 :   17561f: movzbl %r9b,%r9d
    0.00 :   175623: bt     %r9d,%edi
    0.00 :   175627: jb     1757a8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5e8>
    0.00 :   17562d: mov    %rax,%r9
    0.00 :   175630: and    $0xffffffffffffffd0,%r9
    0.00 :   175634: or     $0x3,%r9
    0.00 :   175638: mov    %rax,%r10
    0.00 :   17563b: or     $0x10,%r10
    0.00 :   17563f: cmp    $0x2,%r8
    0.00 :   175643: cmove  %r9,%r10
    0.00 :   175647: lock cmpxchg %r10,0x38(%rsi)
    3.11 :   17564d: jne    1755f6 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x436>
    0.00 :   17564f: cmp    $0x2,%r8
    0.00 :   175653: jne    1757a6 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5e6>
    0.00 :   175659: mov    0x8(%rdx),%rcx
    0.00 :   17565d: movq   $0x0,0x8(%rdx)
    0.00 :   175665: test   %rcx,%rcx
    0.00 :   175668: jne    1757a8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5e8>
    0.00 :   17566e: jmp    17587e <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6be>
    0.00 :   175673: movups 0x48(%rsp),%xmm0
    0.00 :   175678: movups 0x58(%rsp),%xmm1
    0.00 :   17567d: movups 0x68(%rsp),%xmm2
    0.00 :   175682: movups 0x78(%rsp),%xmm3
    0.00 :   175687: mov    0x8(%rsp),%rax
    0.00 :   17568c: movups %xmm3,0x30(%rax)
    0.00 :   175690: movups %xmm2,0x20(%rax)
    0.00 :   175694: movups %xmm1,0x10(%rax)
    0.00 :   175698: movups %xmm0,(%rax)
    0.00 :   17569b: movb   $0x0,0x78(%r14)
    0.00 :   1756a0: jmp    175745 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x585>
    0.00 :   1756a5: movups 0x48(%rsp),%xmm0
    0.00 :   1756aa: movups 0x58(%rsp),%xmm1
    0.00 :   1756af: movups 0x68(%rsp),%xmm2
    0.00 :   1756b4: movups 0x78(%rsp),%xmm3
    0.00 :   1756b9: mov    0x8(%rsp),%rax
    0.00 :   1756be: movups %xmm3,0x30(%rax)
    0.00 :   1756c2: movups %xmm2,0x20(%rax)
    0.00 :   1756c6: movups %xmm1,0x10(%rax)
    0.00 :   1756ca: movups %xmm0,(%rax)
    0.00 :   1756cd: jmp    175745 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x585>
    0.00 :   1756cf: mov    0x1f95a(%rip),%rax        # 195030 <_ZN7vthread5error13error_context12RuntimeFault3new4NEXT17haba27211dcb56122E.llvm.10657235172099788962>
    0.00 :   1756d6: cs nopw 0x0(%rax,%rax,1)
    0.00 :   1756e0: cmp    $0xffffffffffffffff,%rax
    0.00 :   1756e4: je     17595e <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x79e>
    0.00 :   1756ea: lea    0x1(%rax),%rcx
    0.00 :   1756ee: lock cmpxchg %rcx,0x1f939(%rip)        # 195030 <_ZN7vthread5error13error_context12RuntimeFault3new4NEXT17haba27211dcb56122E.llvm.10657235172099788962>
    0.00 :   1756f7: jne    1756e0 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x520>
    0.00 :   1756f9: mov    0x8(%rsp),%rcx
    0.00 :   1756fe: movq   $0x2b,0x10(%rcx)
    0.00 :   175706: mov    %rax,0x18(%rcx)
    0.00 :   17570a: movb   $0x0,0x20(%rcx)
    0.00 :   17570e: dec    %rbp
    0.00 :   175711: mov    %rbp,(%rcx)
    0.00 :   175714: lea    -0x156b07(%rip),%rax        # 1ec14 <anon.de2471ab41e489a293ba001b839d8fc3.880.llvm.10657235172099788962>
    0.00 :   17571b: mov    %rax,0x8(%rcx)
    0.00 :   17571f: mov    0x40(%rsp),%rax
    0.00 :   175724: mov    0x10(%rax),%rcx
    0.00 :   175728: mov    0x38(%rcx),%rcx
    0.00 :   17572c: movaps 0x30(%rsp),%xmm0
    0.00 :   175731: movups %xmm0,0x20(%rcx)
    0.00 :   175735: decq   (%rax)
    0.00 :   175738: jne    175745 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x585>
    0.00 :   17573a: lea    0x40(%rsp),%rdi
    0.00 :   17573f: call   *0x1da33(%rip)        # 193178 <_DYNAMIC+0x1160>
    0.00 :   175745: lea    0x88(%rsp),%rdi
    0.00 :   17574d: call   166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>
    0.00 :   175752: lea    0xa8(%rsp),%rdi
    0.00 :   17575a: call   16b400 <core::ptr::drop_in_place<vthread::channel::wait::Ticket<i32>>>
    0.00 :   17575f: mov    0x10(%rsp),%rax
    0.00 :   175764: cmp    $0x11,%rax
    0.00 :   175768: je     175794 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5d4>
    0.00 :   17576a: mov    0x18(%rsp),%rcx
    0.00 :   17576f: mov    0x20(%rsp),%rdx
    0.00 :   175774: mov    0x10(%rdx),%rsi
    0.00 :   175778: mov    0x38(%rsi),%rsi
    0.00 :   17577c: mov    %rax,0x20(%rsi)
    0.00 :   175780: mov    %rcx,0x28(%rsi)
    0.00 :   175784: decq   (%rdx)
    0.00 :   175787: jne    175794 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x5d4>
    0.00 :   175789: lea    0x20(%rsp),%rdi
    0.00 :   17578e: call   *0x1d9e4(%rip)        # 193178 <_DYNAMIC+0x1160>
    0.00 :   175794: add    $0xe8,%rsp
    0.00 :   17579b: pop    %rbx
    0.00 :   17579c: pop    %r12
    0.00 :   17579e: pop    %r13
    0.00 :   1757a0: pop    %r14
    0.00 :   1757a2: pop    %r15
    0.00 :   1757a4: pop    %rbp
    0.00 :   1757a5: ret
    0.00 :   1757a6: xor    %ecx,%ecx
    0.00 :   1757a8: mov    %rcx,0x88(%rsp)
    0.00 :   1757b0: mov    %r9,0x90(%rsp)
    0.00 :   1757b8: cmpq   $0x0,0x58(%r14)
    0.00 :   1757bd: je     17589c <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6dc>
    0.00 :   1757c3: mov    0x50(%r14),%rdi
    0.00 :   1757c7: mov    0x40(%r14),%rax
    0.00 :   1757cb: mov    0x48(%r14),%rdx
    0.00 :   1757cf: xor    %ecx,%ecx
    0.00 :   1757d1: cmp    %rax,%rdi
    0.00 :   1757d4: cmovb  %rcx,%rax
    0.00 :   1757d8: sub    %rax,%rdi
    0.00 :   1757db: shl    $0x4,%rdi
    0.00 :   1757df: mov    0x8(%rdx,%rdi,1),%rsi
    0.27 :   1757e4: test   %rsi,%rsi
    0.00 :   1757e7: je     17589e <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6de>
    0.00 :   1757ed: mov    0x38(%rsi),%rax
    0.25 :   1757f1: mov    %eax,%r8d
    0.00 :   1757f4: and    $0xf,%r8d
    0.00 :   1757f8: cmp    $0xc,%r8
    0.00 :   1757fc: ja     175943 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x783>
    0.00 :   175802: add    %rdi,%rdx
    0.00 :   175805: xor    %ecx,%ecx
    0.00 :   175807: mov    $0x155,%edi
    0.00 :   17580c: jmp    175827 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x667>
    0.00 :   17580e: xchg   %ax,%ax
    0.00 :   175810: pause
    0.00 :   175812: mov    0x38(%rsi),%rax
    0.00 :   175816: mov    %eax,%r8d
    0.00 :   175819: and    $0xf,%r8d
    0.00 :   17581d: cmp    $0xd,%r8
    0.00 :   175821: jae    175943 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x783>
    0.00 :   175827: cmp    $0x1,%r8
    0.00 :   17582b: je     175810 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x650>
    0.00 :   17582d: test   $0x20,%al
    0.27 :   17582f: jne    17589e <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6de>
    0.00 :   175831: lea    -0x3(%r8),%r9d
    0.00 :   175835: cmp    $0x9,%r9b
    0.00 :   175839: jae    175845 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x685>
    0.00 :   17583b: movzbl %r9b,%r9d
    0.00 :   17583f: bt     %r9d,%edi
    0.00 :   175843: jb     17589e <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6de>
    0.00 :   175845: mov    %rax,%r9
    0.00 :   175848: and    $0xffffffffffffffd0,%r9
    0.00 :   17584c: or     $0x3,%r9
    0.00 :   175850: mov    %rax,%r10
    0.00 :   175853: or     $0x10,%r10
    0.00 :   175857: cmp    $0x2,%r8
    0.00 :   17585b: cmove  %r9,%r10
    0.00 :   17585f: lock cmpxchg %r10,0x38(%rsi)
    4.34 :   175865: jne    175816 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x656>
    0.00 :   175867: cmp    $0x2,%r8
    0.00 :   17586b: jne    17589c <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6dc>
    0.00 :   17586d: mov    0x8(%rdx),%rcx
    0.00 :   175871: movq   $0x0,0x8(%rdx)
    0.00 :   175879: test   %rcx,%rcx
    0.00 :   17587c: jne    17589e <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x6de>
    0.00 :   17587e: lea    -0x15737c(%rip),%rdi        # 1e509 <anon.de2471ab41e489a293ba001b839d8fc3.708.llvm.10657235172099788962>
    0.00 :   175885: lea    0x191c4(%rip),%rdx        # 18ea50 <anon.de2471ab41e489a293ba001b839d8fc3.710.llvm.10657235172099788962>
    0.00 :   17588c: mov    $0x1a,%esi
    0.00 :   175891: call   *0x1cba9(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   175897: jmp    1759a7 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x7e7>
    0.00 :   17589c: xor    %ecx,%ecx
    0.00 :   17589e: mov    %rcx,0x98(%rsp)
    0.00 :   1758a6: mov    %r9,0xa0(%rsp)
    0.00 :   1758ae: movb   $0x0,0x78(%r14)
    0.00 :   1758b3: lea    0x88(%rsp),%rdi
    0.00 :   1758bb: call   166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>
    0.00 :   1758c0: mov    0x8(%rsp),%rax
    0.00 :   1758c5: mov    %rbx,0x8(%rax)
    0.00 :   1758c9: mov    %rbp,(%rax)
    0.00 :   1758cc: jmp    175752 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x592>
    0.00 :   1758d1: lea    -0x1574fc(%rip),%rdi        # 1e3dc <anon.de2471ab41e489a293ba001b839d8fc3.694.llvm.10657235172099788962>
    0.00 :   1758d8: lea    0x190f9(%rip),%rdx        # 18e9d8 <anon.de2471ab41e489a293ba001b839d8fc3.695.llvm.10657235172099788962>
    0.00 :   1758df: mov    $0x79,%esi
    0.00 :   1758e4: call   *0x1c9b6(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   1758ea: jmp    1759a7 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x7e7>
    0.00 :   1758ef: lea    -0x156cb7(%rip),%rdi        # 1ec3f <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962>
    0.00 :   1758f6: lea    0x197eb(%rip),%rdx        # 18f0e8 <anon.de2471ab41e489a293ba001b839d8fc3.882.llvm.10657235172099788962>
    0.00 :   1758fd: mov    $0x1d,%esi
    0.00 :   175902: call   *0x1cb38(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   175908: jmp    1759a7 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x7e7>
    0.00 :   17590d: lea    -0x1600e4(%rip),%rdi        # 15830 <anon.3a58b439f571e0ec141896abec7fa7cc.106.llvm.7674982464417394995+0x80>
    0.00 :   175914: lea    0x1b465(%rip),%rdx        # 190d80 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1c50>
    0.00 :   17591b: mov    $0x10,%esi
    0.00 :   175920: call   *0x1cb1a(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   175926: jmp    1759a7 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x7e7>
    0.00 :   175928: lea    -0x153dec(%rip),%rdi        # 21b43 <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962+0x2f04>
    0.00 :   17592f: lea    0x1b492(%rip),%rdx        # 190dc8 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1c98>
    0.00 :   175936: mov    $0x37,%esi
    0.00 :   17593b: call   *0x1c95f(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   175941: jmp    1759a7 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x7e7>
    0.00 :   175943: lea    -0x15756e(%rip),%rdi        # 1e3dc <anon.de2471ab41e489a293ba001b839d8fc3.694.llvm.10657235172099788962>
    0.00 :   17594a: lea    0x19087(%rip),%rdx        # 18e9d8 <anon.de2471ab41e489a293ba001b839d8fc3.695.llvm.10657235172099788962>
    0.00 :   175951: mov    $0x79,%esi
    0.00 :   175956: call   *0x1c944(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   17595c: jmp    1759a7 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x7e7>
    0.00 :   17595e: movq   $0xffffffffffffffff,0x48(%rsp)
    0.00 :   175967: lea    -0x15744b(%rip),%rdi        # 1e523 <anon.de2471ab41e489a293ba001b839d8fc3.714.llvm.10657235172099788962>
    0.00 :   17596e: lea    0x17ebb(%rip),%rcx        # 18d830 <anon.de2471ab41e489a293ba001b839d8fc3.179.llvm.10657235172099788962>
    0.00 :   175975: lea    0x19104(%rip),%r8        # 18ea80 <anon.de2471ab41e489a293ba001b839d8fc3.716.llvm.10657235172099788962>
    0.00 :   17597c: lea    0x48(%rsp),%rdx
    0.00 :   175981: mov    $0x1e,%esi
    0.00 :   175986: call   *0x1c8f4(%rip)        # 192280 <_DYNAMIC+0x268>
    0.00 :   17598c: jmp    1759a7 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x7e7>
    0.00 :   17598e: lea    -0x15fd35(%rip),%rdi        # 15c60 <anon.de2471ab41e489a293ba001b839d8fc3.887.llvm.10657235172099788962+0x3e0>
    0.00 :   175995: lea    0x1b3fc(%rip),%rdx        # 190d98 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1c68>
    0.00 :   17599c: mov    $0x10,%esi
    0.00 :   1759a1: call   *0x1ca99(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   1759a7: ud2
    0.00 :   1759a9: jmp    1759f8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x838>
    0.00 :   1759ab: mov    %rax,%rbx
    0.00 :   1759ae: jmp    175a05 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x845>
    0.00 :   1759b0: jmp    1759d9 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x819>
    0.00 :   1759b2: jmp    1759ee <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x82e>
    0.00 :   1759b4: mov    %rax,%rbx
    0.00 :   1759b7: mov    0x40(%rsp),%rax
    0.00 :   1759bc: mov    %rax,0x20(%rsp)
    0.00 :   1759c1: movaps 0x30(%rsp),%xmm0
    0.00 :   1759c6: movaps %xmm0,0x10(%rsp)
    0.00 :   1759cb: jmp    175a05 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x845>
    0.00 :   1759cd: jmp    1759d9 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x819>
    0.00 :   1759cf: mov    %rax,%rbx
    0.00 :   1759d2: jmp    175a1f <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x85f>
    0.00 :   1759d4: mov    %rax,%rbx
    0.00 :   1759d7: jmp    175a05 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x845>
    0.00 :   1759d9: mov    %rax,%rbx
    0.00 :   1759dc: jmp    175a12 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x852>
    0.00 :   1759de: mov    %rax,%rbx
    0.00 :   1759e1: jmp    175a05 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x845>
    0.00 :   1759e3: jmp    1759ee <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x82e>
    0.00 :   1759e5: jmp    1759ee <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x82e>
    0.00 :   1759e7: jmp    1759f8 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x838>
    0.00 :   1759e9: mov    %rax,%rbx
    0.00 :   1759ec: jmp    175a05 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x845>
    0.00 :   1759ee: mov    %rax,%rbx
    0.00 :   1759f1: movb   $0x0,0x78(%r14)
    0.00 :   1759f6: jmp    175a05 <vthread::channel::core::<impl vthread::channel::Core<T>>::recv+0x845>
    0.00 :   1759f8: mov    %rax,%rbx
    0.00 :   1759fb: lea    0x30(%rsp),%rdi
    0.00 :   175a00: call   1699d0 <core::ptr::drop_in_place<vthread::sync::wait::Wait>>
    0.00 :   175a05: lea    0x88(%rsp),%rdi
    0.00 :   175a0d: call   166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>
    0.00 :   175a12: lea    0xa8(%rsp),%rdi
    0.00 :   175a1a: call   16b400 <core::ptr::drop_in_place<vthread::channel::wait::Ticket<i32>>>
    0.00 :   175a1f: lea    0x10(%rsp),%rdi
    0.00 :   175a24: call   16c410 <core::ptr::drop_in_place<core::option::Option<vthread::sync::wait::Wait>>>
    0.00 :   175a29: mov    %rbx,%rdi
    0.00 :   175a2c: call   187ca0 <_Unwind_Resume@plt>
    0.00 :   175a31: call   *0x1ca21(%rip)        # 192458 <_DYNAMIC+0x440>
