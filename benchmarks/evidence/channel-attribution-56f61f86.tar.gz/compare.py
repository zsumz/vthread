"""Complete missing A/E attribution with existing default, symbol-bearing binaries."""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
OLD = ROOT / 'target/finish-line/channel-publication'
spec = importlib.util.spec_from_file_location('control', ROOT / 'target/finish-line/native-control.R84U9h/control.py')
control = importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
control.OUT = OUT
evidence = control.evidence
BINARIES = {'A': OLD / 'baseline-benchmark', 'E': OLD / 'candidate-inlined'}
HASHES = {
    'A': '1680cc617dd9b42d1ecf3e55b4ac5ee4cab5046ccab5767930e66e1dc6226c1a',
    'E': '4006e9fa85878ad5af188c4b79be3a6dc049a7453de3fada64121dd9213c9d6b',
}
CASES = {
    'local-short': ('7', 10000, 1, 8),
    'local-long': ('7', 100000, 1, 8),
    'local-profile': ('7', 1000000, 1, 8),
    'remote8-short': ('0-3', 10000, 4, 8),
    'remote8-long': ('0-3', 100000, 4, 8),
    'remote64-short': ('0-3', 2000, 4, 64),
    'remote64-long': ('0-3', 20000, 4, 64),
}


def capture(command, path):
    with path.open('x') as stream:
        return subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)


def main(mode, cohort, cases):
    assert mode in ('stat', 'stat-core', 'record', 'record-frequency', 'record-low', 'bare')
    assert {arm: evidence.digest(path) for arm, path in BINARIES.items()} == HASHES
    manifest = evidence.metadata('historical 3161514 default baseline versus rejected inlined channel E; mechanism attribution, not current-head or May acceptance')
    manifest.update(binaries=HASHES, features='default', handoff_timing=False,
                    orders=['AE', 'EA', 'EA', 'AE'] if mode in ('stat', 'stat-core', 'bare') else ['AE', 'EA'],
                    rounds=7, mode=mode, cases=cases)
    manifest['perf_limits'] = {name: Path(f'/proc/sys/kernel/{name}').read_text().strip()
                               for name in ('perf_event_max_sample_rate', 'perf_cpu_time_max_percent')}
    with (OUT / f'{cohort}-manifest.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
    for case in cases:
        mask, iterations, carriers, tasks = CASES[case]
        for pair, order in enumerate(manifest['orders'], 1):
            for arm in order:
                prefix = f'{cohort}-{pair}-{case}-{arm}'
                control.observe(prefix, 'before')
                args = ['taskset', '-c', mask, str(BINARIES[arm]), 'vthread',
                        'channel-mpmc', str(iterations), '1', str(carriers), str(tasks),
                        '7', '--pin-carriers']
                if mode in ('stat', 'stat-core'):
                    events = 'task-clock,cycles,instructions,context-switches,cpu-migrations'
                    if mode == 'stat':
                        events += ',branches,branch-misses'
                    command = ['timeout', '120s', 'perf', 'stat', '-x,', '-e',
                               events,
                               '-o', str(OUT / f'{prefix}.csv'), *args]
                elif mode == 'bare':
                    command = ['timeout', '120s', *args]
                else:
                    sampling = {'record-frequency': ['-F', '199'],
                                'record-low': ['-c', '20000003']}.get(mode, ['-c', '250003'])
                    command = ['timeout', '120s', 'perf', 'record', '-e', 'cycles:u',
                               *sampling, '-P', '--no-buildid-cache',
                               '-o', str(OUT / f'{prefix}.data'), '--', *args]
                with (OUT / f'{prefix}.command.json').open('x') as stream:
                    json.dump(command, stream)
                result = capture(command, OUT / f'{prefix}.log')
                control.observe(prefix, 'after')
                with (OUT / f'{prefix}.result.json').open('x') as stream:
                    json.dump({'returncode': result.returncode}, stream)
                assert result.returncode == 0, (prefix, result.returncode)
                if mode.startswith('record'):
                    report = ['perf', 'report', '--stdio', '--no-children',
                              '--show-total-period', '--show-nr-samples', '--percent-limit', '0',
                              '--sort', 'symbol', '-i', str(OUT / f'{prefix}.data')]
                    with (OUT / f'{prefix}.report-command.json').open('x') as stream:
                        json.dump(report, stream)
                    assert capture(report, OUT / f'{prefix}.report').returncode == 0
                print(f'completed {prefix}', flush=True)
    assert {arm: evidence.digest(path) for arm, path in BINARIES.items()} == HASHES
    assert manifest['source_sha256'] == evidence.source_digest()


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3:])
