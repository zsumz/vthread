"""Strict complete-pair analysis of default process counters and work-count slopes."""

import csv
import json
from pathlib import Path
import re
from statistics import median
import sys

OUT = Path(__file__).resolve().parent
METRICS = ('cycles', 'instructions', 'branches', 'branch-misses',
           'task-clock', 'context-switches', 'cpu-migrations')


def sample(prefix):
    for stage in ('before', 'after'):
        assert (OUT / f'{prefix}.{stage}.guard').read_text() == '', prefix
    assert json.loads((OUT / f'{prefix}.result.json').read_text())['returncode'] == 0
    reports = re.findall(r'\bns_per_operation=([\d.]+)', (OUT / f'{prefix}.log').read_text())
    assert len(reports) == 1, prefix
    values = {'ns/value': float(reports[0])}
    for row in csv.reader((OUT / f'{prefix}.csv').read_text().splitlines()):
        if len(row) > 2 and row[2] in METRICS:
            assert float(row[4]) >= 99, (prefix, 'multiplexing', row)
            values[row[2]] = float(row[0])
    expected = set(METRICS) - {'branches', 'branch-misses'}
    assert expected | {'ns/value'} <= set(values), prefix
    return values


def analyze(cohort, cases):
    manifest = json.loads((OUT / f'{cohort}-manifest.json').read_text())
    summary = {'cases': {}, 'slopes': {}}
    selected = cases or manifest['cases']
    summary['not_analyzed'] = [case for case in manifest['cases'] if case not in selected]
    for case in selected:
        arms = {arm: [sample(f'{cohort}-{pair}-{case}-{arm}') for pair in range(1, 5)]
                for arm in 'AE'}
        metrics = {}
        metrics_present = [metric for metric in (*METRICS, 'ns/value') if metric in arms['A'][0]]
        for metric in metrics_present:
            before, after = [median(sample[metric] for sample in arms[arm]) for arm in 'AE']
            metrics[metric] = {'A': before, 'E': after, 'percent': 100 * (after / before - 1) if before else None,
                               'paired_percent': [100 * (e[metric] / a[metric] - 1) if a[metric] else None
                                                  for a, e in zip(arms['A'], arms['E'])]}
        summary['cases'][case] = {'metrics': metrics, 'raw': arms}
    for mechanism, short_values in [('local', 320000), ('remote8', 320000), ('remote64', 512000)]:
        if not all(f'{mechanism}-{length}' in summary['cases'] for length in ('short', 'long')):
            continue
        slopes = {}
        for metric in METRICS:
            if metric not in summary['cases'][f'{mechanism}-long']['metrics']:
                continue
            slope = {arm: (summary['cases'][f'{mechanism}-long']['metrics'][metric][arm]
                           - summary['cases'][f'{mechanism}-short']['metrics'][metric][arm])
                          / (9 * short_values) for arm in 'AE'}
            slopes[metric] = {**slope, 'extra_per_value': slope['E'] - slope['A']}
        summary['slopes'][mechanism] = slopes
    with (OUT / f'{cohort}-analysis.json').open('x') as stream:
        json.dump(summary, stream, indent=2)
    for case, result in summary['cases'].items():
        metrics = result['metrics']
        print(case, 'ns/value', metrics['ns/value']['A'], metrics['ns/value']['E'],
              'cycles%', round(metrics['cycles']['percent'], 2),
              'instructions%', round(metrics['instructions']['percent'], 2))
    for case, result in summary['slopes'].items():
        print(case, 'two-count process slope, not isolated handoff:', result['cycles'])


if __name__ == '__main__':
    analyze(sys.argv[1], sys.argv[2:])
