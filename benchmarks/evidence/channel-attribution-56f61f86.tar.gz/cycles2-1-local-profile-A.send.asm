 Percent |	Source code & Disassembly of baseline-benchmark for cycles:u (419 samples, percent: global period)
------------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3      Disassembly of section .text:
         :
         : 5      0000000000175370 <vthread::channel::core::<impl vthread::channel::Core<T>>::send>:
         : 6      vthread::channel::core::<impl vthread::channel::Core<T>>::send:
    0.00 :   175370: push   %rbp
    0.00 :   175371: push   %r15
    0.00 :   175373: push   %r14
    0.00 :   175375: push   %r13
    0.00 :   175377: push   %r12
    0.00 :   175379: push   %rbx
    0.00 :   17537a: sub    $0xf8,%rsp
    0.00 :   175381: mov    %rdx,%r13
    0.00 :   175384: mov    %rsi,%r12
    0.00 :   175387: mov    %rdi,%r15
    0.00 :   17538a: movabs $0x8000000000000022,%rbx
    0.00 :   175394: lea    0x48(%rsp),%rdi
    0.24 :   175399: call   175e70 <vthread::context::check_current>
    0.47 :   17539e: mov    0x48(%rsp),%r14
    0.00 :   1753a3: cmp    %rbx,%r14
    0.00 :   1753a6: jne    175657 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x2e7>
    0.00 :   1753ac: mov    %r15,0x8(%rsp)
    0.00 :   1753b1: movq   $0x11,0x10(%rsp)
    0.00 :   1753ba: mov    %r12,0xe8(%rsp)
    0.00 :   1753c2: movw   $0x0,0xf0(%rsp)
    0.00 :   1753cc: movq   $0x0,0xd8(%rsp)
    0.00 :   1753d8: lea    0xd8(%rsp),%r15
    0.00 :   1753e0: lea    -0x7(%rbx),%r14
    0.00 :   1753e4: mov    $0x1,%bl
    0.00 :   1753e6: lea    0x48(%rsp),%rbp
    0.00 :   1753eb: nopl   0x0(%rax,%rax,1)
    0.00 :   1753f0: xor    %eax,%eax
    0.00 :   1753f2: lock cmpxchg %bl,0x78(%r12)
   52.48 :   1753f9: jne    175593 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x223>
    0.00 :   1753ff: cmpb   $0x0,0x70(%r12)
    0.00 :   175405: jne    17568c <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x31c>
    0.00 :   17540b: cmpq   $0x0,0x68(%r12)
    0.00 :   175411: je     17568c <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x31c>
    0.00 :   175417: mov    0x18(%r12),%rax
    0.00 :   17541c: cmp    0x80(%r12),%rax
    0.00 :   175424: jae    175439 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0xc9>
    0.00 :   175426: mov    %r15,%rdi
    0.00 :   175429: mov    %r12,%rsi
    0.00 :   17542c: call   175d40 <vthread::channel::wait::Ticket<T>::take_turn>
    0.00 :   175431: test   %al,%al
    0.00 :   175433: jne    175817 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x4a7>
    0.00 :   175439: cmpl   $0x11,0x10(%rsp)
    0.00 :   17543e: je     1754ba <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x14a>
    0.00 :   175440: mov    0x20(%rsp),%rax
    0.00 :   175445: mov    0x18(%rax),%rax
    0.00 :   175449: mov    0x68(%rax),%ecx
    0.00 :   17544c: test   %ecx,%ecx
    0.00 :   17544e: jne    1759fb <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x68b>
    0.00 :   175454: mov    0x60(%rax),%rcx
    0.00 :   175458: mov    %rbp,%rdi
    0.00 :   17545b: mov    %r15,%rsi
    0.00 :   17545e: mov    %r12,%rdx
    0.00 :   175461: call   175bf0 <vthread::channel::wait::Ticket<T>::enqueue>
    0.00 :   175466: mov    0x48(%rsp),%rax
    0.00 :   17546b: movabs $0x8000000000000022,%rcx
    0.00 :   175475: cmp    %rcx,%rax
    0.00 :   175478: jne    17569e <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x32e>
    0.00 :   17547e: movb   $0x0,0x78(%r12)
    0.00 :   175484: cmpl   $0x11,0x10(%rsp)
    0.00 :   175489: je     175a19 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x6a9>
    0.00 :   17548f: mov    %rbp,%rdi
    0.00 :   175492: lea    0x10(%rsp),%rsi
    0.00 :   175497: call   *0x1cddb(%rip)        # 192278 <_DYNAMIC+0x14b8>
    0.00 :   17549d: mov    0x48(%rsp),%rax
    0.00 :   1754a2: movabs $0x8000000000000022,%rcx
    0.00 :   1754ac: cmp    %rcx,%rax
    0.00 :   1754af: je     1753f0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x80>
    0.00 :   1754b5: jmp    1756ed <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x37d>
    0.00 :   1754ba: mov    %r13,0x88(%rsp)
    0.00 :   1754c2: movb   $0x0,0x78(%r12)
    0.00 :   1754c8: call   *0x1ccda(%rip)        # 1921a8 <_DYNAMIC+0x13e8>
    0.00 :   1754ce: mov    %rax,%rbx
    0.00 :   1754d1: mov    %r14,0x48(%rsp)
    0.25 :   1754d6: cmp    $0x2,%rax
    0.00 :   1754da: je     175909 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x599>
    0.00 :   1754e0: mov    %rdx,%r13
    0.00 :   1754e3: mov    %rbp,%rdi
    0.00 :   1754e6: call   d75c0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10013882635303053058>
    0.00 :   1754eb: test   $0x1,%bl
    0.00 :   1754ee: jne    175909 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x599>
    0.00 :   1754f4: mov    0x10(%r13),%rax
    0.00 :   1754f8: mov    0x38(%rax),%rax
    0.00 :   1754fc: mov    0x20(%rax),%rcx
    0.00 :   175500: mov    0x28(%rax),%rdx
    0.00 :   175504: movq   $0x8,0x20(%rax)
    0.00 :   17550c: mov    %rcx,0x38(%rsp)
    0.00 :   175511: mov    %rcx,0x90(%rsp)
    0.00 :   175519: mov    %rdx,0x30(%rsp)
    0.00 :   17551e: mov    %rdx,0x98(%rsp)
    0.00 :   175526: mov    %r13,0xa0(%rsp)
    0.00 :   17552e: mov    %r13,0x40(%rsp)
    0.00 :   175533: mov    0x18(%r13),%r13
    0.00 :   175537: mov    0x68(%r13),%eax
    0.00 :   17553b: add    $0x60,%r13
    0.00 :   17553f: test   %eax,%eax
    0.00 :   175541: jne    17564a <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x2da>
    0.00 :   175547: mov    0x0(%r13),%rcx
    0.00 :   17554b: mov    0x38(%rcx),%rax
    0.00 :   17554f: mov    $0x1,%bl
    0.00 :   175551: data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   175560: mov    %eax,%edx
    0.00 :   175562: and    $0xf,%edx
    0.00 :   175565: cmp    $0xd,%edx
    0.00 :   175568: jae    175afb <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x78b>
    0.00 :   17556e: test   $0xd0,%al
    0.00 :   175570: je     1755bb <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x24b>
    0.00 :   175572: mov    %eax,%edx
    0.00 :   175574: and    $0x2f,%edx
    0.00 :   175577: jne    1755bb <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x24b>
    0.00 :   175579: mov    %rax,%rdx
    0.00 :   17557c: and    $0xffffffffffffff00,%rdx
    0.00 :   175583: lock cmpxchg %rdx,0x38(%rcx)
   13.50 :   175589: jne    175560 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x1f0>
    0.00 :   17558b: jmp    1755c3 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x253>
    0.00 :   17558d: call   *0x1bf8d(%rip)        # 191520 <sched_yield@GLIBC_2.2.5>
    0.00 :   175593: xor    %ecx,%ecx
    0.00 :   175595: movzbl 0x78(%r12),%eax
    0.00 :   17559b: test   %al,%al
    0.00 :   17559d: jne    1755ae <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x23e>
    0.00 :   17559f: xor    %eax,%eax
    0.00 :   1755a1: lock cmpxchg %bl,0x78(%r12)
    0.00 :   1755a8: je     1753ff <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8f>
    0.00 :   1755ae: pause
    0.00 :   1755b0: inc    %rcx
    0.00 :   1755b3: cmp    $0x40,%rcx
    0.00 :   1755b7: jne    175595 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x225>
    0.00 :   1755b9: jmp    17558d <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x21d>
    0.00 :   1755bb: test   $0x2f,%al
    0.00 :   1755bd: jne    175a37 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x6c7>
    0.00 :   1755c3: mov    0x0(%r13),%rax
    0.00 :   1755c7: mov    0x30(%rax),%rax
    0.00 :   1755cb: cmpq   $0x0,0xd8(%rsp)
    0.00 :   1755d4: movq   $0x1,0xd8(%rsp)
    0.00 :   1755e0: mov    %rax,0xe0(%rsp)
    0.00 :   1755e8: jne    175b16 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7a6>
    0.00 :   1755ee: mov    0x10(%rsp),%rax
    0.00 :   1755f3: cmp    $0x11,%rax
    0.00 :   1755f7: mov    0x88(%rsp),%r13
    0.00 :   1755ff: je     17562b <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x2bb>
    0.00 :   175601: mov    0x18(%rsp),%rcx
    0.00 :   175606: mov    0x20(%rsp),%rdx
    0.00 :   17560b: mov    0x10(%rdx),%rsi
    0.00 :   17560f: mov    0x38(%rsi),%rsi
    0.00 :   175613: mov    %rax,0x20(%rsi)
    0.00 :   175617: mov    %rcx,0x28(%rsi)
    0.00 :   17561b: decq   (%rdx)
    0.00 :   17561e: jne    17562b <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x2bb>
    0.00 :   175620: lea    0x20(%rsp),%rdi
    0.00 :   175625: call   *0x1c8f5(%rip)        # 191f20 <_DYNAMIC+0x1160>
    0.00 :   17562b: mov    0xa0(%rsp),%rax
    0.00 :   175633: mov    %rax,0x20(%rsp)
    0.00 :   175638: movaps 0x90(%rsp),%xmm0
    0.00 :   175640: movaps %xmm0,0x10(%rsp)
    0.00 :   175645: jmp    1753f0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x80>
    0.00 :   17564a: mov    %r13,%rdi
    0.00 :   17564d: call   d196a <_ZN3std4sync9once_lock17OnceLock$LT$T$GT$10initialize17hd31d093978ca14d7E.llvm.10013882635303053058>
    0.00 :   175652: jmp    175547 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x1d7>
    0.00 :   175657: mov    0x50(%rsp),%rdx
    0.00 :   17565c: mov    0x58(%rsp),%rsi
    0.00 :   175661: mov    0x60(%rsp),%rcx
    0.00 :   175666: movzbl 0x68(%rsp),%ebp
    0.00 :   17566b: movups 0x69(%rsp),%xmm0
    0.00 :   175670: movaps %xmm0,0xb0(%rsp)
    0.00 :   175678: movups 0x78(%rsp),%xmm0
    0.00 :   17567d: movups %xmm0,0xbf(%rsp)
    0.00 :   175685: mov    $0x1,%bl
    0.00 :   175687: jmp    175799 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x429>
    0.00 :   17568c: movabs $0x8000000000000022,%rax
    0.00 :   175696: add    $0xffffffffffffffe3,%rax
    0.00 :   17569a: mov    $0x1,%bl
    0.00 :   17569c: jmp    1756dd <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x36d>
    0.00 :   17569e: mov    0x50(%rsp),%rcx
    0.00 :   1756a3: mov    %rcx,0x38(%rsp)
    0.00 :   1756a8: mov    0x58(%rsp),%rcx
    0.00 :   1756ad: mov    %rcx,0x30(%rsp)
    0.00 :   1756b2: mov    0x60(%rsp),%rcx
    0.00 :   1756b7: mov    %rcx,0x40(%rsp)
    0.00 :   1756bc: movzbl 0x68(%rsp),%ebp
    0.00 :   1756c1: movups 0x69(%rsp),%xmm0
    0.00 :   1756c6: movaps %xmm0,0xb0(%rsp)
    0.00 :   1756ce: movups 0x78(%rsp),%xmm0
    0.00 :   1756d3: movups %xmm0,0xbf(%rsp)
    0.00 :   1756db: mov    $0x1,%bl
    0.00 :   1756dd: mov    0x8(%rsp),%r15
    0.00 :   1756e2: movb   $0x0,0x78(%r12)
    0.00 :   1756e8: mov    %rax,%r14
    0.00 :   1756eb: jmp    175734 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x3c4>
    0.00 :   1756ed: mov    0x50(%rsp),%rcx
    0.00 :   1756f2: mov    %rcx,0x38(%rsp)
    0.00 :   1756f7: mov    0x58(%rsp),%rcx
    0.00 :   1756fc: mov    %rcx,0x30(%rsp)
    0.00 :   175701: mov    0x60(%rsp),%rcx
    0.00 :   175706: mov    %rcx,0x40(%rsp)
    0.00 :   17570b: movzbl 0x68(%rsp),%ebp
    0.00 :   175710: movups 0x69(%rsp),%xmm0
    0.00 :   175715: movaps %xmm0,0xb0(%rsp)
    0.00 :   17571d: movups 0x78(%rsp),%xmm0
    0.00 :   175722: movups %xmm0,0xbf(%rsp)
    0.00 :   17572a: mov    $0x1,%bl
    0.00 :   17572c: mov    %rax,%r14
    0.00 :   17572f: mov    0x8(%rsp),%r15
    0.00 :   175734: lea    0xd8(%rsp),%rdi
    0.00 :   17573c: call   16af80 <core::ptr::drop_in_place<vthread::channel::wait::Ticket<i32>>>
    0.00 :   175741: mov    0x10(%rsp),%rax
    0.00 :   175746: cmp    $0x11,%rax
    0.00 :   17574a: je     175776 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x406>
    0.00 :   17574c: mov    0x18(%rsp),%rcx
    0.00 :   175751: mov    0x20(%rsp),%rdx
    0.00 :   175756: mov    0x10(%rdx),%rsi
    0.00 :   17575a: mov    0x38(%rsi),%rsi
    0.00 :   17575e: mov    %rax,0x20(%rsi)
    0.00 :   175762: mov    %rcx,0x28(%rsi)
    0.00 :   175766: decq   (%rdx)
    0.00 :   175769: jne    175776 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x406>
    0.00 :   17576b: lea    0x20(%rsp),%rdi
    0.00 :   175770: call   *0x1c7aa(%rip)        # 191f20 <_DYNAMIC+0x1160>
    0.00 :   175776: movabs $0x8000000000000022,%rax
    0.00 :   175780: cmp    %rax,%r14
    0.00 :   175783: mov    0x40(%rsp),%rcx
    0.00 :   175788: mov    0x38(%rsp),%rdx
    0.00 :   17578d: mov    0x30(%rsp),%rsi
    0.00 :   175792: jne    175799 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x429>
    0.00 :   175794: mov    %rax,(%r15)
    0.00 :   175797: jmp    175805 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x495>
    0.00 :   175799: mov    %r14,0x48(%rsp)
    0.00 :   17579e: mov    %rdx,0x50(%rsp)
    0.00 :   1757a3: mov    %rsi,0x58(%rsp)
    0.00 :   1757a8: mov    %rcx,0x60(%rsp)
    0.00 :   1757ad: mov    %bpl,0x68(%rsp)
    0.00 :   1757b2: movaps 0xb0(%rsp),%xmm0
    0.00 :   1757ba: movups %xmm0,0x69(%rsp)
    0.00 :   1757bf: movups 0xbf(%rsp),%xmm0
    0.00 :   1757c7: movups %xmm0,0x78(%rsp)
    0.00 :   1757cc: test   %bl,%bl
    0.00 :   1757ce: je     175ae0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x770>
    0.00 :   1757d4: mov    %rsi,0x10(%r15)
    0.00 :   1757d8: mov    %rcx,0x18(%r15)
    0.00 :   1757dc: mov    %bpl,0x20(%r15)
    0.00 :   1757e0: movaps 0xb0(%rsp),%xmm0
    0.00 :   1757e8: movups %xmm0,0x21(%r15)
    0.00 :   1757ed: movups 0xbf(%rsp),%xmm0
    0.00 :   1757f5: movups %xmm0,0x30(%r15)
    0.00 :   1757fa: mov    %r14,(%r15)
    0.00 :   1757fd: mov    %rdx,0x8(%r15)
    0.00 :   175801: mov    %r13,0x40(%r15)
    0.00 :   175805: add    $0xf8,%rsp
    0.00 :   17580c: pop    %rbx
    0.00 :   17580d: pop    %r12
    0.00 :   17580f: pop    %r13
    0.00 :   175811: pop    %r14
    0.00 :   175813: pop    %r15
    0.00 :   175815: pop    %rbp
    0.00 :   175816: ret
    0.00 :   175817: mov    (%r12),%rcx
    0.00 :   17581b: mov    0x18(%r12),%rax
    0.00 :   175820: cmp    %rcx,%rax
    0.00 :   175823: mov    0x8(%rsp),%r15
    0.00 :   175828: jne    17583b <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x4cb>
    0.00 :   17582a: mov    %r12,%rdi
    0.00 :   17582d: call   170a90 <alloc::collections::vec_deque::VecDeque<T,A>::grow>
    0.00 :   175832: mov    (%r12),%rcx
    0.00 :   175836: mov    0x18(%r12),%rax
    0.00 :   17583b: lea    0x1(%rax),%rdx
    0.00 :   17583f: mov    %rdx,0x18(%r12)
    0.00 :   175844: add    0x10(%r12),%rax
    0.00 :   175849: xor    %edx,%edx
    0.00 :   17584b: cmp    %rcx,%rax
    0.00 :   17584e: cmovae %rcx,%rdx
    0.00 :   175852: sub    %rdx,%rax
    0.00 :   175855: mov    0x8(%r12),%rcx
    0.00 :   17585a: mov    %r13,(%rcx,%rax,8)
    0.00 :   17585e: cmpq   $0x0,0x38(%r12)
    0.00 :   175864: je     175929 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x5b9>
    0.00 :   17586a: mov    0x30(%r12),%rax
    0.00 :   17586f: mov    0x20(%r12),%rcx
    0.00 :   175874: mov    0x28(%r12),%rdx
    0.00 :   175879: xor    %esi,%esi
    0.00 :   17587b: cmp    %rcx,%rax
    0.00 :   17587e: cmovae %rcx,%rsi
    0.00 :   175882: sub    %rsi,%rax
    0.00 :   175885: mov    (%rdx,%rax,8),%rcx
    0.00 :   175889: mov    0x38(%rcx),%rax
    0.00 :   17588d: mov    %eax,%esi
    0.00 :   17588f: and    $0xf,%esi
    0.00 :   175892: cmp    $0xc,%rsi
    0.00 :   175896: ja     175ac5 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x755>
    0.00 :   17589c: lea    0x10(%rcx),%rdi
    0.00 :   1758a0: mov    $0xaa8,%edx
    0.00 :   1758a5: jmp    1758c5 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x555>
    0.00 :   1758a7: nopw   0x0(%rax,%rax,1)
    0.00 :   1758b0: pause
    0.00 :   1758b2: mov    0x38(%rcx),%rax
    0.00 :   1758b6: mov    %eax,%esi
    0.00 :   1758b8: and    $0xf,%esi
    0.00 :   1758bb: cmp    $0xd,%rsi
    0.00 :   1758bf: jae    175ac5 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x755>
    0.00 :   1758c5: cmp    $0x1,%rsi
    0.00 :   1758c9: je     1758b0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x540>
    0.00 :   1758cb: test   $0x20,%al
    0.00 :   1758cd: jne    175929 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x5b9>
    0.00 :   1758cf: cmp    $0xb,%sil
    0.00 :   1758d3: ja     1758f8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x588>
    0.00 :   1758d5: movzbl %sil,%esi
    0.00 :   1758d9: bt     %esi,%edx
    0.00 :   1758dc: jb     1758b0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x540>
    0.00 :   1758de: cmp    $0x2,%esi
    0.00 :   1758e1: jne    1758f8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x588>
    0.00 :   1758e3: mov    %rax,%rsi
    0.00 :   1758e6: and    $0xffffffffffffffd0,%rsi
    0.00 :   1758ea: or     $0x3,%rsi
    0.00 :   1758ee: lock cmpxchg %rsi,0x38(%rcx)
    8.79 :   1758f4: jne    1758b6 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x546>
    0.00 :   1758f6: jmp    17591a <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x5aa>
    0.00 :   1758f8: mov    %rax,%rsi
    0.00 :   1758fb: or     $0x10,%rsi
    0.00 :   1758ff: lock cmpxchg %rsi,0x38(%rcx)
    0.00 :   175905: jne    1758b6 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x546>
    0.00 :   175907: jmp    175929 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x5b9>
    0.00 :   175909: mov    $0x1,%bl
    0.00 :   17590b: xor    %ebp,%ebp
    0.00 :   17590d: mov    0x88(%rsp),%r13
    0.00 :   175915: jmp    17572f <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x3bf>
    0.00 :   17591a: xor    %edx,%edx
    0.00 :   17591c: xor    %ecx,%ecx
    0.00 :   17591e: mov    $0x1,%r8d
    0.00 :   175924: call   109e00 <_ZN7vthread4wait11wait_select16enqueue_selected17h5a35090e1549dd93E.llvm.10013882635303053058>
    0.00 :   175929: cmpq   $0x0,0x58(%r12)
    0.00 :   17592f: je     1759d7 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x667>
    0.00 :   175935: mov    0x50(%r12),%rax
    0.00 :   17593a: mov    0x40(%r12),%rcx
    0.00 :   17593f: mov    0x48(%r12),%rdx
    0.00 :   175944: xor    %esi,%esi
    0.00 :   175946: cmp    %rcx,%rax
    0.00 :   175949: cmovae %rcx,%rsi
    0.00 :   17594d: sub    %rsi,%rax
    0.00 :   175950: mov    (%rdx,%rax,8),%rcx
    0.00 :   175954: mov    0x38(%rcx),%rax
    0.00 :   175958: mov    %eax,%esi
    0.00 :   17595a: and    $0xf,%esi
    0.00 :   17595d: cmp    $0xc,%rsi
    0.00 :   175961: ja     175ac5 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x755>
    0.00 :   175967: lea    0x10(%rcx),%rdi
    0.00 :   17596b: mov    $0xaa8,%edx
    0.00 :   175970: jmp    175995 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x625>
    0.00 :   175972: data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   175980: pause
    0.00 :   175982: mov    0x38(%rcx),%rax
    0.00 :   175986: mov    %eax,%esi
    0.00 :   175988: and    $0xf,%esi
    0.00 :   17598b: cmp    $0xd,%rsi
    0.00 :   17598f: jae    175ac5 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x755>
    0.00 :   175995: cmp    $0x1,%rsi
    0.00 :   175999: je     175980 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x610>
    0.00 :   17599b: test   $0x20,%al
    0.00 :   17599d: jne    1759d7 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x667>
    0.00 :   17599f: cmp    $0xb,%sil
    0.00 :   1759a3: ja     1759c8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x658>
    0.00 :   1759a5: movzbl %sil,%esi
    0.00 :   1759a9: bt     %esi,%edx
    0.00 :   1759ac: jb     175980 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x610>
    0.00 :   1759ae: cmp    $0x2,%esi
    0.00 :   1759b1: jne    1759c8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x658>
    0.00 :   1759b3: mov    %rax,%rsi
    0.00 :   1759b6: and    $0xffffffffffffffd0,%rsi
    0.00 :   1759ba: or     $0x3,%rsi
    0.00 :   1759be: lock cmpxchg %rsi,0x38(%rcx)
   24.27 :   1759c4: jne    175986 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x616>
    0.00 :   1759c6: jmp    1759e8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x678>
    0.00 :   1759c8: mov    %rax,%rsi
    0.00 :   1759cb: or     $0x10,%rsi
    0.00 :   1759cf: lock cmpxchg %rsi,0x38(%rcx)
    0.00 :   1759d5: jne    175986 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x616>
    0.00 :   1759d7: xor    %ebx,%ebx
    0.00 :   1759d9: movabs $0x8000000000000022,%rax
    0.00 :   1759e3: jmp    1756e2 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x372>
    0.00 :   1759e8: xor    %ebx,%ebx
    0.00 :   1759ea: xor    %edx,%edx
    0.00 :   1759ec: xor    %ecx,%ecx
    0.00 :   1759ee: mov    $0x1,%r8d
    0.00 :   1759f4: call   109e00 <_ZN7vthread4wait11wait_select16enqueue_selected17h5a35090e1549dd93E.llvm.10013882635303053058>
    0.00 :   1759f9: jmp    1759d9 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x669>
    0.00 :   1759fb: lea    -0x156e8d(%rip),%rdi        # 1eb75 <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058>
    0.00 :   175a02: lea    0x1849f(%rip),%rdx        # 18dea8 <anon.cccb389264607a2d4c2b49e143c9c1b6.877.llvm.10013882635303053058>
    0.00 :   175a09: mov    $0x1d,%esi
    0.00 :   175a0e: call   *0x1b7d4(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   175a14: jmp    175b5f <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7ef>
    0.00 :   175a19: lea    -0x153fd3(%rip),%rdi        # 21a4d <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058+0x2ed8>
    0.00 :   175a20: lea    0x1a101(%rip),%rdx        # 18fb28 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x1c38>
    0.00 :   175a27: mov    $0xd,%esi
    0.00 :   175a2c: call   *0x1b7b6(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   175a32: jmp    175b5f <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7ef>
    0.00 :   175a37: mov    0x1e39a(%rip),%rax        # 193dd8 <_ZN7vthread5error13error_context12RuntimeFault3new4NEXT17haba27211dcb56122E.llvm.10013882635303053058>
    0.00 :   175a3e: mov    0x88(%rsp),%r13
    0.00 :   175a46: mov    0x8(%rsp),%r15
    0.00 :   175a4b: movabs $0x8000000000000022,%rdx
    0.00 :   175a55: cmp    $0xffffffffffffffff,%rax
    0.00 :   175a59: je     175b31 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7c1>
    0.00 :   175a5f: lea    0x1(%rax),%rcx
    0.00 :   175a63: lock cmpxchg %rcx,0x1e36c(%rip)        # 193dd8 <_ZN7vthread5error13error_context12RuntimeFault3new4NEXT17haba27211dcb56122E.llvm.10013882635303053058>
    0.00 :   175a6c: jne    175a55 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x6e5>
    0.00 :   175a6e: mov    %rax,0x40(%rsp)
    0.00 :   175a73: mov    0xa0(%rsp),%rax
    0.00 :   175a7b: mov    0x10(%rax),%rcx
    0.00 :   175a7f: mov    0x38(%rcx),%rcx
    0.00 :   175a83: movaps 0x90(%rsp),%xmm0
    0.00 :   175a8b: movups %xmm0,0x20(%rcx)
    0.00 :   175a8f: decq   (%rax)
    0.00 :   175a92: lea    -0x1(%rdx),%r14
    0.00 :   175a96: mov    $0x1,%bl
    0.00 :   175a98: lea    -0x156f55(%rip),%rax        # 1eb4a <anon.cccb389264607a2d4c2b49e143c9c1b6.875.llvm.10013882635303053058>
    0.00 :   175a9f: mov    $0x2b,%ecx
    0.00 :   175aa4: mov    %rcx,0x30(%rsp)
    0.00 :   175aa9: mov    %rax,0x38(%rsp)
    0.00 :   175aae: jne    175abe <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x74e>
    0.00 :   175ab0: lea    0xa0(%rsp),%rdi
    0.00 :   175ab8: call   *0x1c462(%rip)        # 191f20 <_DYNAMIC+0x1160>
    0.00 :   175abe: xor    %ebp,%ebp
    0.00 :   175ac0: jmp    175734 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x3c4>
    0.00 :   175ac5: lea    -0x1577a0(%rip),%rdi        # 1e32c <anon.cccb389264607a2d4c2b49e143c9c1b6.694.llvm.10013882635303053058>
    0.00 :   175acc: lea    0x17cf5(%rip),%rdx        # 18d7c8 <anon.cccb389264607a2d4c2b49e143c9c1b6.695.llvm.10013882635303053058>
    0.00 :   175ad3: mov    $0x79,%esi
    0.00 :   175ad8: call   *0x1b56a(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   175ade: jmp    175b5f <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7ef>
    0.00 :   175ae0: lea    -0x15408d(%rip),%rdi        # 21a5a <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058+0x2ee5>
    0.00 :   175ae7: lea    0x1a082(%rip),%rdx        # 18fb70 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x1c80>
    0.00 :   175aee: mov    $0x19,%esi
    0.00 :   175af3: call   *0x1b6ef(%rip)        # 1911e8 <_DYNAMIC+0x428>
    0.00 :   175af9: jmp    175b5f <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7ef>
    0.00 :   175afb: lea    -0x1577d6(%rip),%rdi        # 1e32c <anon.cccb389264607a2d4c2b49e143c9c1b6.694.llvm.10013882635303053058>
    0.00 :   175b02: lea    0x17cbf(%rip),%rdx        # 18d7c8 <anon.cccb389264607a2d4c2b49e143c9c1b6.695.llvm.10013882635303053058>
    0.00 :   175b09: mov    $0x79,%esi
    0.00 :   175b0e: call   *0x1b534(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   175b14: jmp    175b5f <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7ef>
    0.00 :   175b16: lea    -0x1540aa(%rip),%rdi        # 21a73 <anon.cccb389264607a2d4c2b49e143c9c1b6.876.llvm.10013882635303053058+0x2efe>
    0.00 :   175b1d: lea    0x1a064(%rip),%rdx        # 18fb88 <anon.cccb389264607a2d4c2b49e143c9c1b6.883.llvm.10013882635303053058+0x1c98>
    0.00 :   175b24: mov    $0x37,%esi
    0.00 :   175b29: call   *0x1b519(%rip)        # 191048 <_DYNAMIC+0x288>
    0.00 :   175b2f: jmp    175b5f <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7ef>
    0.00 :   175b31: movq   $0xffffffffffffffff,0x48(%rsp)
    0.00 :   175b3a: lea    -0x1576e8(%rip),%rdi        # 1e459 <anon.cccb389264607a2d4c2b49e143c9c1b6.711.llvm.10013882635303053058>
    0.00 :   175b41: lea    0x16ad8(%rip),%rcx        # 18c620 <anon.cccb389264607a2d4c2b49e143c9c1b6.179.llvm.10013882635303053058>
    0.00 :   175b48: lea    0x17d09(%rip),%r8        # 18d858 <anon.cccb389264607a2d4c2b49e143c9c1b6.713.llvm.10013882635303053058>
    0.00 :   175b4f: lea    0x48(%rsp),%rdx
    0.00 :   175b54: mov    $0x1e,%esi
    0.00 :   175b59: call   *0x1b4c9(%rip)        # 191028 <_DYNAMIC+0x268>
    0.00 :   175b5f: ud2
    0.00 :   175b61: jmp    175b91 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x821>
    0.00 :   175b63: jmp    175bba <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x84a>
    0.00 :   175b65: mov    %rax,%rbx
    0.00 :   175b68: mov    0xa0(%rsp),%rax
    0.00 :   175b70: mov    %rax,0x20(%rsp)
    0.00 :   175b75: movaps 0x90(%rsp),%xmm0
    0.00 :   175b7d: movaps %xmm0,0x10(%rsp)
    0.00 :   175b82: jmp    175bc8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x858>
    0.00 :   175b84: jmp    175bba <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x84a>
    0.00 :   175b86: mov    %rax,%rbx
    0.00 :   175b89: jmp    175bd5 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x865>
    0.00 :   175b8b: jmp    175bba <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x84a>
    0.00 :   175b8d: jmp    175bbf <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x84f>
    0.00 :   175b8f: jmp    175b91 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x821>
    0.00 :   175b91: mov    %rax,%rbx
    0.00 :   175b94: lea    0x90(%rsp),%rdi
    0.00 :   175b9c: call   1691d0 <core::ptr::drop_in_place<vthread::sync::wait::Wait>>
    0.00 :   175ba1: jmp    175bc8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x858>
    0.00 :   175ba3: mov    %rax,%rbx
    0.00 :   175ba6: lea    0x48(%rsp),%rdi
    0.00 :   175bab: call   168cf0 <core::ptr::drop_in_place<vthread::error::Error>>
    0.00 :   175bb0: jmp    175bdf <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x86f>
    0.00 :   175bb2: call   *0x1b648(%rip)        # 191200 <_DYNAMIC+0x440>
    0.00 :   175bb8: jmp    175bbf <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x84f>
    0.00 :   175bba: mov    %rax,%rbx
    0.00 :   175bbd: jmp    175bc8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x858>
    0.00 :   175bbf: mov    %rax,%rbx
    0.00 :   175bc2: movb   $0x0,0x78(%r12)
    0.00 :   175bc8: lea    0xd8(%rsp),%rdi
    0.00 :   175bd0: call   16af80 <core::ptr::drop_in_place<vthread::channel::wait::Ticket<i32>>>
    0.00 :   175bd5: lea    0x10(%rsp),%rdi
    0.00 :   175bda: call   16b9c0 <core::ptr::drop_in_place<core::option::Option<vthread::sync::wait::Wait>>>
    0.00 :   175bdf: mov    %rbx,%rdi
    0.00 :   175be2: call   186a90 <_Unwind_Resume@plt>
    0.00 :   175be7: call   *0x1b613(%rip)        # 191200 <_DYNAMIC+0x440>
