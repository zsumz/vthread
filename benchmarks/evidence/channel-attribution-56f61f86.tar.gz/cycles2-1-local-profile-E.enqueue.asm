 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (129 samples, percent: global period)
-----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3      Disassembly of section .text:
         :
         : 5      0000000000176c90 <vthread::channel::wait::Ticket<T>::enqueue>:
         : 6      vthread::channel::wait::Ticket<T>::enqueue:
    0.00 :   176c90: push   %rbp
    0.00 :   176c91: push   %r15
    0.00 :   176c93: push   %r14
    0.00 :   176c95: push   %r13
    0.00 :   176c97: push   %r12
    0.00 :   176c99: push   %rbx
    0.00 :   176c9a: sub    $0x28,%rsp
    0.00 :   176c9e: mov    %rcx,%r14
    0.00 :   176ca1: mov    %rsi,%r15
    0.00 :   176ca4: mov    %rdi,%rbx
    0.00 :   176ca7: cmpb   $0x0,0x19(%rsi)
    0.00 :   176cab: je     176d22 <vthread::channel::wait::Ticket<T>::enqueue+0x92>
    0.00 :   176cad: movzbl 0x18(%r15),%esi
    0.00 :   176cb2: shl    $0x5,%esi
    0.00 :   176cb5: mov    0x38(%rdx,%rsi,1),%r8
    0.00 :   176cba: add    $0x20,%rsi
    0.00 :   176cbe: test   %r8,%r8
    0.00 :   176cc1: je     176df0 <vthread::channel::wait::Ticket<T>::enqueue+0x160>
    0.00 :   176cc7: mov    0x10(%rdx,%rsi,1),%rcx
    0.00 :   176ccc: mov    (%rdx,%rsi,1),%r9
    0.00 :   176cd0: xor    %edi,%edi
    0.00 :   176cd2: cmp    %r9,%rcx
    0.00 :   176cd5: mov    %r9,%rax
    0.00 :   176cd8: cmovb  %rdi,%rax
    0.00 :   176cdc: sub    %rax,%rcx
    0.00 :   176cdf: mov    %r9,%r10
    0.00 :   176ce2: sub    %rcx,%r10
    0.00 :   176ce5: mov    %r8,%rax
    0.00 :   176ce8: sub    %r10,%rax
    0.00 :   176ceb: shl    $0x4,%rax
    0.00 :   176cef: cmp    %r10,%r8
    0.00 :   176cf2: cmovbe %rdi,%rax
    0.00 :   176cf6: lea    (%rcx,%r8,1),%rdi
    0.00 :   176cfa: cmp    %r10,%r8
    0.00 :   176cfd: cmova  %r9,%rdi
    0.00 :   176d01: mov    (%r15),%r8
    0.00 :   176d04: test   $0x1,%r8b
    0.00 :   176d08: je     176ed4 <vthread::channel::wait::Ticket<T>::enqueue+0x244>
    0.00 :   176d0e: mov    0x8(%rdx,%rsi,1),%rdx
    0.00 :   176d13: shl    $0x4,%rdi
    0.00 :   176d17: add    %rdx,%rdi
    0.00 :   176d1a: add    %rdx,%rax
    0.00 :   176d1d: jmp    176e08 <vthread::channel::wait::Ticket<T>::enqueue+0x178>
    0.00 :   176d22: mov    0x30(%r14),%rbp
    0.00 :   176d26: mov    %rbp,0x18(%rsp)
    0.00 :   176d2b: cmpb   $0x0,(%r15)
    0.00 :   176d2f: je     176ef7 <vthread::channel::wait::Ticket<T>::enqueue+0x267>
    0.00 :   176d35: mov    0x8(%r15),%rax
    0.00 :   176d39: mov    %rax,0x20(%rsp)
    0.00 :   176d3e: cmp    %rax,%rbp
    0.00 :   176d41: jne    176e98 <vthread::channel::wait::Ticket<T>::enqueue+0x208>
    0.00 :   176d47: movzbl 0x18(%r15),%ecx
    0.00 :   176d4c: shl    $0x5,%ecx
    0.00 :   176d4f: mov    0x38(%rcx,%rdx,1),%rax
    0.00 :   176d54: mov    0x10(%r15),%rsi
    0.00 :   176d58: cmp    0x88(%rsi),%rax
    0.00 :   176d5f: jne    176d7f <vthread::channel::wait::Ticket<T>::enqueue+0xef>
    0.00 :   176d61: movabs $0x8000000000000022,%rcx
    0.00 :   176d6b: add    $0xffffffffffffffeb,%rcx
    0.00 :   176d6f: mov    %rcx,(%rbx)
    0.00 :   176d72: mov    %rax,0x8(%rbx)
    0.00 :   176d76: movb   $0x5,0x10(%rbx)
    0.00 :   176d7a: jmp    176e89 <vthread::channel::wait::Ticket<T>::enqueue+0x1f9>
    0.00 :   176d7f: lock incq (%r14)
   54.92 :   176d83: jle    176f10 <vthread::channel::wait::Ticket<T>::enqueue+0x280>
    0.00 :   176d89: lea    (%rcx,%rdx,1),%r12
    0.00 :   176d8d: add    $0x20,%r12
    0.00 :   176d91: mov    %rbp,0x8(%rsp)
    0.00 :   176d96: mov    %r14,0x10(%rsp)
    0.00 :   176d9b: mov    (%r12),%rcx
    0.00 :   176d9f: cmp    %rcx,%rax
    0.00 :   176da2: jne    176dba <vthread::channel::wait::Ticket<T>::enqueue+0x12a>
    0.00 :   176da4: lea    0x10(%rsp),%r13
    0.00 :   176da9: mov    %r12,%rdi
    0.00 :   176dac: call   171670 <alloc::collections::vec_deque::VecDeque<T,A>::grow>
    0.00 :   176db1: mov    (%r12),%rcx
    0.00 :   176db5: mov    0x18(%r12),%rax
    0.00 :   176dba: lea    0x1(%rax),%rdx
    0.00 :   176dbe: mov    %rdx,0x18(%r12)
    0.00 :   176dc3: add    0x10(%r12),%rax
    0.00 :   176dc8: xor    %edx,%edx
    0.00 :   176dca: cmp    %rcx,%rax
    0.00 :   176dcd: cmovae %rcx,%rdx
    0.00 :   176dd1: sub    %rdx,%rax
    0.00 :   176dd4: mov    0x8(%r12),%rcx
    0.00 :   176dd9: shl    $0x4,%rax
    0.00 :   176ddd: mov    %rbp,(%rcx,%rax,1)
    0.00 :   176de1: mov    %r14,0x8(%rcx,%rax,1)
    0.00 :   176de6: movb   $0x1,0x19(%r15)
    0.00 :   176deb: jmp    176e7c <vthread::channel::wait::Ticket<T>::enqueue+0x1ec>
    0.00 :   176df0: mov    (%r15),%rax
    0.00 :   176df3: test   $0x1,%al
    0.00 :   176df5: je     176ede <vthread::channel::wait::Ticket<T>::enqueue+0x24e>
    0.00 :   176dfb: mov    0x8(%rdx,%rsi,1),%rax
    0.00 :   176e00: xor    %ecx,%ecx
    0.00 :   176e02: mov    %rax,%rdi
    0.00 :   176e05: mov    %rax,%rdx
    0.00 :   176e08: mov    0x8(%r15),%r8
    0.00 :   176e0c: shl    $0x4,%rcx
    0.00 :   176e10: add    %rdx,%rcx
    0.00 :   176e13: data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   176e20: cmp    %rdi,%rcx
    0.00 :   176e23: je     176e40 <vthread::channel::wait::Ticket<T>::enqueue+0x1b0>
    0.00 :   176e25: lea    0x10(%rcx),%rsi
    0.00 :   176e29: cmp    %r8,(%rcx)
    0.00 :   176e2c: mov    %rsi,%rcx
    0.00 :   176e2f: jne    176e20 <vthread::channel::wait::Ticket<T>::enqueue+0x190>
    0.00 :   176e31: jmp    176e55 <vthread::channel::wait::Ticket<T>::enqueue+0x1c5>
    0.00 :   176e33: data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   176e40: cmp    %rax,%rdx
    0.00 :   176e43: je     176ede <vthread::channel::wait::Ticket<T>::enqueue+0x24e>
    0.00 :   176e49: lea    0x10(%rdx),%rsi
    0.00 :   176e4d: cmp    %r8,(%rdx)
    0.00 :   176e50: mov    %rsi,%rdx
    0.00 :   176e53: jne    176e40 <vthread::channel::wait::Ticket<T>::enqueue+0x1b0>
    0.00 :   176e55: add    $0xfffffffffffffff0,%rsi
    0.00 :   176e59: mov    0x30(%r14),%rax
    0.00 :   176e5d: mov    %rax,0x8(%rsp)
    0.00 :   176e62: cmp    %rax,%r8
    0.00 :   176e65: jne    176ebe <vthread::channel::wait::Ticket<T>::enqueue+0x22e>
    0.00 :   176e67: cmpq   $0x0,0x8(%rsi)
    0.00 :   176e6c: jne    176e7c <vthread::channel::wait::Ticket<T>::enqueue+0x1ec>
    0.00 :   176e6e: lock incq (%r14)
   45.08 :   176e72: jle    176f10 <vthread::channel::wait::Ticket<T>::enqueue+0x280>
    0.00 :   176e78: mov    %r14,0x8(%rsi)
    0.00 :   176e7c: movabs $0x8000000000000022,%rax
    0.00 :   176e86: mov    %rax,(%rbx)
    0.00 :   176e89: add    $0x28,%rsp
    0.00 :   176e8d: pop    %rbx
    0.00 :   176e8e: pop    %r12
    0.00 :   176e90: pop    %r13
    0.00 :   176e92: pop    %r14
    0.00 :   176e94: pop    %r15
    0.00 :   176e96: pop    %rbp
    0.00 :   176e97: ret
    0.00 :   176e98: lea    -0x155317(%rip),%rcx        # 21b88 <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962+0x2f49>
    0.00 :   176e9f: lea    0x19f6a(%rip),%r9        # 190e10 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1ce0>
    0.00 :   176ea6: lea    0x18(%rsp),%rsi
    0.00 :   176eab: lea    0x20(%rsp),%rdx
    0.00 :   176eb0: mov    $0x29,%r8d
    0.00 :   176eb6: xor    %edi,%edi
    0.00 :   176eb8: call   *0x1b45a(%rip)        # 192318 <_DYNAMIC+0x300>
    0.00 :   176ebe: lea    0x180bb(%rip),%r9        # 18ef80 <anon.de2471ab41e489a293ba001b839d8fc3.857.llvm.10657235172099788962>
    0.00 :   176ec5: lea    0x8(%rsp),%rdx
    0.00 :   176eca: xor    %edi,%edi
    0.00 :   176ecc: xor    %ecx,%ecx
    0.00 :   176ece: call   *0x1b444(%rip)        # 192318 <_DYNAMIC+0x300>
    0.00 :   176ed4: cmp    %rdi,%rcx
    0.00 :   176ed7: jne    176ef7 <vthread::channel::wait::Ticket<T>::enqueue+0x267>
    0.00 :   176ed9: test   %rax,%rax
    0.00 :   176edc: jne    176ef7 <vthread::channel::wait::Ticket<T>::enqueue+0x267>
    0.00 :   176ede: lea    -0x155349(%rip),%rdi        # 21b9c <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962+0x2f5d>
    0.00 :   176ee5: lea    0x19f3c(%rip),%rdx        # 190e28 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1cf8>
    0.00 :   176eec: mov    $0x21,%esi
    0.00 :   176ef1: call   *0x1b549(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   176ef7: lea    -0x15538b(%rip),%rdi        # 21b73 <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962+0x2f34>
    0.00 :   176efe: lea    0x19ef3(%rip),%rdx        # 190df8 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1cc8>
    0.00 :   176f05: mov    $0x15,%esi
    0.00 :   176f0a: call   *0x1b530(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   176f10: ud2
    0.00 :   176f12: mov    %rax,%rbx
    0.00 :   176f15: lock decq (%r14)
    0.00 :   176f19: jne    176f24 <vthread::channel::wait::Ticket<T>::enqueue+0x294>
    0.00 :   176f1b: mov    %r13,%rdi
    0.00 :   176f1e: call   *0x1c234(%rip)        # 193158 <_DYNAMIC+0x1140>
    0.00 :   176f24: mov    %rbx,%rdi
    0.00 :   176f27: call   187ca0 <_Unwind_Resume@plt>
    0.00 :   176f2c: call   *0x1b526(%rip)        # 192458 <_DYNAMIC+0x440>
