 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (319 samples, percent: global period)
-----------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3      Disassembly of section .text:
         :
         : 5      0000000000176360 <vthread::channel::core::<impl vthread::channel::Core<T>>::send>:
         : 6      vthread::channel::core::<impl vthread::channel::Core<T>>::send:
    0.00 :   176360: push   %rbp
    0.00 :   176361: push   %r15
    0.00 :   176363: push   %r14
    0.00 :   176365: push   %r13
    0.00 :   176367: push   %r12
    0.00 :   176369: push   %rbx
    0.00 :   17636a: sub    $0xf8,%rsp
    0.00 :   176371: mov    %rdx,0x80(%rsp)
    0.00 :   176379: mov    %rsi,%r12
    0.00 :   17637c: mov    %rdi,0x88(%rsp)
    0.00 :   176384: movabs $0x8000000000000022,%r13
    0.00 :   17638e: lea    0x20(%rsp),%rdi
    0.00 :   176393: call   177080 <vthread::context::check_current>
    0.00 :   176398: mov    0x20(%rsp),%rbp
    0.00 :   17639d: cmp    %r13,%rbp
    0.00 :   1763a0: jne    17666e <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x30e>
    0.00 :   1763a6: movq   $0x11,(%rsp)
    0.33 :   1763ae: mov    %r12,0xe0(%rsp)
    0.00 :   1763b6: movw   $0x0,0xe8(%rsp)
    0.00 :   1763c0: movq   $0x0,0xd0(%rsp)
    0.00 :   1763cc: mov    $0x1,%r14b
    0.00 :   1763cf: lea    0xd0(%rsp),%r15
    0.00 :   1763d7: lea    -0x7(%r13),%rbp
    0.00 :   1763db: jmp    176410 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0xb0>
    0.00 :   1763dd: nopl   (%rax)
    0.00 :   1763e0: mov    0x70(%rsp),%rax
    0.00 :   1763e5: mov    %rax,0x10(%rsp)
    0.00 :   1763ea: movaps 0x60(%rsp),%xmm0
    0.00 :   1763ef: movaps %xmm0,(%rsp)
    0.00 :   1763f3: mov    %r13,%rbx
    0.00 :   1763f6: movabs $0x8000000000000022,%r13
    0.00 :   176400: mov    $0x1,%r14b
    0.00 :   176403: lea    0xb0(%rsp),%rdi
    0.00 :   17640b: call   166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>
    0.00 :   176410: movq   $0x0,0xb0(%rsp)
    0.00 :   17641c: movq   $0x0,0xc0(%rsp)
    0.00 :   176428: xor    %eax,%eax
    0.00 :   17642a: lock cmpxchg %r14b,0x78(%r12)
   72.84 :   176431: jne    176639 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x2d9>
    0.00 :   176437: cmpb   $0x0,0x70(%r12)
    0.00 :   17643d: jne    1766a5 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x345>
    0.00 :   176443: cmpq   $0x0,0x68(%r12)
    0.00 :   176449: je     1766a5 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x345>
    0.00 :   17644f: mov    0x18(%r12),%rax
    0.00 :   176454: cmp    0x80(%r12),%rax
    0.00 :   17645c: jae    176471 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x111>
    0.00 :   17645e: mov    %r15,%rdi
    0.00 :   176461: mov    %r12,%rsi
    0.00 :   176464: call   176f40 <vthread::channel::wait::Ticket<T>::take_turn>
    0.00 :   176469: test   %al,%al
    0.00 :   17646b: jne    1766ce <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x36e>
    0.00 :   176471: cmpl   $0x11,(%rsp)
    0.00 :   176475: jne    176550 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x1f0>
    0.00 :   17647b: mov    %r15,%r14
    0.00 :   17647e: movb   $0x0,0x78(%r12)
    0.00 :   176484: call   *0x1cf76(%rip)        # 193400 <_DYNAMIC+0x13e8>
    0.00 :   17648a: mov    %rax,%r15
    0.00 :   17648d: mov    %rbp,0x20(%rsp)
    0.00 :   176492: cmp    $0x2,%rax
    0.00 :   176496: je     1766b4 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x354>
    0.00 :   17649c: mov    %rdx,%r13
    0.00 :   17649f: lea    0x20(%rsp),%rdi
    0.00 :   1764a4: call   d7ad0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10657235172099788962>
    0.00 :   1764a9: test   $0x1,%r15b
    0.00 :   1764ad: jne    1766b4 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x354>
    0.00 :   1764b3: mov    0x10(%r13),%rax
    0.00 :   1764b7: mov    0x38(%rax),%rax
    0.00 :   1764bb: mov    0x20(%rax),%rcx
    0.00 :   1764bf: mov    0x28(%rax),%rdx
    0.00 :   1764c3: movq   $0x8,0x20(%rax)
    0.00 :   1764cb: mov    %rcx,0xf0(%rsp)
    0.00 :   1764d3: mov    %rcx,0x60(%rsp)
    0.00 :   1764d8: mov    %rdx,0x18(%rsp)
    0.00 :   1764dd: mov    %rdx,0x68(%rsp)
    0.00 :   1764e2: mov    %r13,0x70(%rsp)
    0.00 :   1764e7: mov    0x18(%r13),%rbx
    0.00 :   1764eb: mov    0x68(%rbx),%eax
    0.00 :   1764ee: add    $0x60,%rbx
    0.00 :   1764f2: test   %eax,%eax
    0.00 :   1764f4: jne    176661 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x301>
    0.00 :   1764fa: mov    (%rbx),%rcx
    0.00 :   1764fd: mov    0x38(%rcx),%rax
    0.00 :   176501: mov    %r14,%r15
    0.00 :   176504: data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   176510: mov    %eax,%edx
    0.00 :   176512: and    $0xf,%edx
    0.00 :   176515: cmp    $0xd,%edx
    0.00 :   176518: jae    176b1c <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7bc>
    0.00 :   17651e: test   $0xd0,%al
    0.00 :   176520: je     1765c0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x260>
    0.00 :   176526: mov    %eax,%edx
    0.00 :   176528: and    $0x2f,%edx
    0.00 :   17652b: jne    1765c0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x260>
    0.00 :   176531: mov    %rax,%rdx
    0.00 :   176534: and    $0xffffffffffffff00,%rdx
    0.00 :   17653b: lock cmpxchg %rdx,0x38(%rcx)
    0.00 :   176541: jne    176510 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x1b0>
    0.00 :   176543: jmp    1765c8 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x268>
    0.00 :   176548: nopl   0x0(%rax,%rax,1)
    0.00 :   176550: mov    0x10(%rsp),%rax
    0.00 :   176555: mov    0x18(%rax),%rax
    0.00 :   176559: mov    0x68(%rax),%ecx
    0.00 :   17655c: test   %ecx,%ecx
    0.00 :   17655e: jne    176b3a <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7da>
    0.00 :   176564: mov    0x60(%rax),%rcx
    0.00 :   176568: lea    0x20(%rsp),%rdi
    0.00 :   17656d: mov    %r15,%rsi
    0.00 :   176570: mov    %r12,%rdx
    0.00 :   176573: call   176c90 <vthread::channel::wait::Ticket<T>::enqueue>
    0.00 :   176578: mov    0x20(%rsp),%rax
    0.00 :   17657d: cmp    %r13,%rax
    0.00 :   176580: jne    176803 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x4a3>
    0.00 :   176586: movb   $0x0,0x78(%r12)
    0.00 :   17658c: cmpl   $0x11,(%rsp)
    0.00 :   176590: je     176b58 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x7f8>
    0.00 :   176596: lea    0x20(%rsp),%rdi
    0.00 :   17659b: mov    %rsp,%rsi
    0.00 :   17659e: call   *0x1cf2c(%rip)        # 1934d0 <_DYNAMIC+0x14b8>
    0.00 :   1765a4: mov    0x20(%rsp),%rax
    0.00 :   1765a9: cmp    %r13,%rax
    0.00 :   1765ac: je     176403 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0xa3>
    0.00 :   1765b2: jmp    176845 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x4e5>
    0.00 :   1765b7: nopw   0x0(%rax,%rax,1)
    0.00 :   1765c0: test   $0x2f,%al
    0.00 :   1765c2: jne    17687e <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x51e>
    0.00 :   1765c8: mov    (%rbx),%rax
    0.00 :   1765cb: mov    0x30(%rax),%rax
    0.00 :   1765cf: cmpq   $0x0,0xd0(%rsp)
    0.00 :   1765d8: movq   $0x1,0xd0(%rsp)
    0.00 :   1765e4: mov    %rax,0xd8(%rsp)
    0.00 :   1765ec: jne    176b73 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x813>
    0.00 :   1765f2: mov    (%rsp),%rax
    0.00 :   1765f6: cmp    $0x11,%rax
    0.00 :   1765fa: je     1763e0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x80>
    0.00 :   176600: mov    0x8(%rsp),%rcx
    0.00 :   176605: mov    0x10(%rsp),%rdx
    0.00 :   17660a: mov    0x10(%rdx),%rsi
    0.00 :   17660e: mov    0x38(%rsi),%rsi
    0.00 :   176612: mov    %rax,0x20(%rsi)
    0.00 :   176616: mov    %rcx,0x28(%rsi)
    0.00 :   17661a: decq   (%rdx)
    0.00 :   17661d: jne    1763e0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x80>
    0.00 :   176623: lea    0x10(%rsp),%rdi
    0.00 :   176628: call   *0x1cb4a(%rip)        # 193178 <_DYNAMIC+0x1160>
    0.00 :   17662e: jmp    1763e0 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x80>
    0.00 :   176633: call   *0x1c13f(%rip)        # 192778 <sched_yield@GLIBC_2.2.5>
    0.00 :   176639: xor    %ecx,%ecx
    0.00 :   17663b: movzbl 0x78(%r12),%eax
    0.00 :   176641: test   %al,%al
    0.00 :   176643: jne    176654 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x2f4>
    0.00 :   176645: xor    %eax,%eax
    0.00 :   176647: lock cmpxchg %r14b,0x78(%r12)
    0.00 :   17664e: je     176437 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0xd7>
    0.00 :   176654: pause
    0.00 :   176656: inc    %rcx
    0.00 :   176659: cmp    $0x40,%rcx
    0.00 :   17665d: jne    17663b <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x2db>
    0.00 :   17665f: jmp    176633 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x2d3>
    0.00 :   176661: mov    %rbx,%rdi
    0.00 :   176664: call   d1e7a <_ZN3std4sync9once_lock17OnceLock$LT$T$GT$10initialize17hd31d093978ca14d7E.llvm.10657235172099788962>
    0.00 :   176669: jmp    1764fa <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x19a>
    0.00 :   17666e: mov    0x28(%rsp),%r14
    0.00 :   176673: mov    0x30(%rsp),%rax
    0.00 :   176678: mov    0x38(%rsp),%rbx
    0.00 :   17667d: movzbl 0x40(%rsp),%r15d
    0.00 :   176683: movups 0x41(%rsp),%xmm0
    0.00 :   176688: movaps %xmm0,0x90(%rsp)
    0.00 :   176690: movups 0x50(%rsp),%xmm0
    0.00 :   176695: movups %xmm0,0x9f(%rsp)
    0.00 :   17669d: mov    $0x1,%r12b
    0.00 :   1766a0: jmp    176962 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x602>
    0.00 :   1766a5: lea    -0x1d(%r13),%rbp
    0.00 :   1766a9: movb   $0x0,0x78(%r12)
    0.00 :   1766af: jmp    1768ed <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x58d>
    0.00 :   1766b4: xor    %r15d,%r15d
    0.00 :   1766b7: movabs $0x8000000000000022,%r13
    0.00 :   1766c1: mov    0xf0(%rsp),%r14
    0.00 :   1766c9: jmp    1768ed <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x58d>
    0.00 :   1766ce: mov    (%r12),%rax
    0.00 :   1766d2: mov    0x18(%r12),%rdx
    0.00 :   1766d7: cmp    %rax,%rdx
    0.00 :   1766da: jne    1766ed <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x38d>
    0.00 :   1766dc: mov    %r12,%rdi
    0.00 :   1766df: call   171550 <alloc::collections::vec_deque::VecDeque<T,A>::grow>
    0.00 :   1766e4: mov    (%r12),%rax
    0.00 :   1766e8: mov    0x18(%r12),%rdx
    0.00 :   1766ed: lea    0x1(%rdx),%rcx
    0.00 :   1766f1: mov    %rcx,0x18(%r12)
    0.00 :   1766f6: add    0x10(%r12),%rdx
    0.00 :   1766fb: xor    %ecx,%ecx
    0.00 :   1766fd: cmp    %rax,%rdx
    0.00 :   176700: cmovb  %rcx,%rax
    0.00 :   176704: sub    %rax,%rdx
    0.00 :   176707: mov    0x8(%r12),%rax
    0.00 :   17670c: mov    0x80(%rsp),%rsi
    0.00 :   176714: mov    %rsi,(%rax,%rdx,8)
    0.00 :   176718: cmpq   $0x0,0x38(%r12)
    0.00 :   17671e: je     1769f1 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x691>
    0.00 :   176724: mov    0x30(%r12),%rdi
    0.00 :   176729: mov    0x20(%r12),%rax
    0.00 :   17672e: mov    0x28(%r12),%rdx
    0.00 :   176733: xor    %ecx,%ecx
    0.00 :   176735: cmp    %rax,%rdi
    0.00 :   176738: cmovb  %rcx,%rax
    0.00 :   17673c: sub    %rax,%rdi
    0.00 :   17673f: shl    $0x4,%rdi
    0.00 :   176743: mov    0x8(%rdx,%rdi,1),%rsi
    0.00 :   176748: test   %rsi,%rsi
    0.00 :   17674b: je     1769f1 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x691>
    0.00 :   176751: mov    0x38(%rsi),%rax
    0.00 :   176755: mov    %eax,%r8d
    0.00 :   176758: and    $0xf,%r8d
    0.00 :   17675c: cmp    $0xc,%r8
    0.00 :   176760: ja     176ba9 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x849>
    0.00 :   176766: add    %rdi,%rdx
    0.00 :   176769: xor    %ecx,%ecx
    0.00 :   17676b: mov    $0x155,%edi
    0.00 :   176770: jmp    176797 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x437>
    0.00 :   176772: data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   176780: pause
    0.00 :   176782: mov    0x38(%rsi),%rax
    0.00 :   176786: mov    %eax,%r8d
    0.00 :   176789: and    $0xf,%r8d
    0.00 :   17678d: cmp    $0xd,%r8
    0.00 :   176791: jae    176ba9 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x849>
    0.00 :   176797: cmp    $0x1,%r8
    0.00 :   17679b: je     176780 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x420>
    0.00 :   17679d: test   $0x20,%al
    0.00 :   17679f: jne    1769f1 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x691>
    0.00 :   1767a5: lea    -0x3(%r8),%r9d
    0.00 :   1767a9: cmp    $0x9,%r9b
    0.00 :   1767ad: jae    1767bd <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x45d>
    0.00 :   1767af: movzbl %r9b,%r9d
    0.00 :   1767b3: bt     %r9d,%edi
    0.00 :   1767b7: jb     1769f1 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x691>
    0.00 :   1767bd: mov    %rax,%r9
    0.00 :   1767c0: and    $0xffffffffffffffd0,%r9
    0.00 :   1767c4: or     $0x3,%r9
    0.00 :   1767c8: mov    %rax,%r10
    0.00 :   1767cb: or     $0x10,%r10
    0.00 :   1767cf: cmp    $0x2,%r8
    0.00 :   1767d3: cmove  %r9,%r10
    0.00 :   1767d7: lock cmpxchg %r10,0x38(%rsi)
   16.10 :   1767dd: jne    176786 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x426>
    0.00 :   1767df: cmp    $0x2,%r8
    0.00 :   1767e3: jne    1769ef <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x68f>
    0.00 :   1767e9: mov    0x8(%rdx),%rcx
    0.00 :   1767ed: movq   $0x0,0x8(%rdx)
    0.00 :   1767f5: test   %rcx,%rcx
    0.00 :   1767f8: jne    1769f1 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x691>
    0.00 :   1767fe: jmp    176ace <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x76e>
    0.00 :   176803: mov    0x28(%rsp),%r14
    0.00 :   176808: mov    0x30(%rsp),%rcx
    0.00 :   17680d: mov    %rcx,0x18(%rsp)
    0.00 :   176812: mov    0x38(%rsp),%rbx
    0.00 :   176817: movzbl 0x40(%rsp),%r15d
    0.00 :   17681d: movups 0x41(%rsp),%xmm0
    0.00 :   176822: movaps %xmm0,0x90(%rsp)
    0.00 :   17682a: movups 0x50(%rsp),%xmm0
    0.00 :   17682f: movups %xmm0,0x9f(%rsp)
    0.00 :   176837: movb   $0x0,0x78(%r12)
    0.00 :   17683d: mov    %rax,%rbp
    0.00 :   176840: jmp    1768ed <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x58d>
    0.00 :   176845: mov    0x28(%rsp),%r14
    0.00 :   17684a: mov    0x30(%rsp),%rcx
    0.00 :   17684f: mov    %rcx,0x18(%rsp)
    0.00 :   176854: mov    0x38(%rsp),%rbx
    0.00 :   176859: movzbl 0x40(%rsp),%r15d
    0.00 :   17685f: movups 0x41(%rsp),%xmm0
    0.00 :   176864: movaps %xmm0,0x90(%rsp)
    0.00 :   17686c: movups 0x50(%rsp),%xmm0
    0.00 :   176871: movups %xmm0,0x9f(%rsp)
    0.00 :   176879: mov    %rax,%rbp
    0.00 :   17687c: jmp    1768ed <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x58d>
    0.00 :   17687e: mov    0x1e7ab(%rip),%rbx        # 195030 <_ZN7vthread5error13error_context12RuntimeFault3new4NEXT17haba27211dcb56122E.llvm.10657235172099788962>
    0.00 :   176885: movabs $0x8000000000000022,%r13
    0.00 :   17688f: nop
    0.00 :   176890: cmp    $0xffffffffffffffff,%rbx
    0.00 :   176894: je     176bc4 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x864>
    0.00 :   17689a: lea    0x1(%rbx),%rcx
    0.00 :   17689e: mov    %rbx,%rax
    0.00 :   1768a1: lock cmpxchg %rcx,0x1e786(%rip)        # 195030 <_ZN7vthread5error13error_context12RuntimeFault3new4NEXT17haba27211dcb56122E.llvm.10657235172099788962>
    0.00 :   1768aa: mov    %rax,%rbx
    0.00 :   1768ad: jne    176890 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x530>
    0.00 :   1768af: mov    0x70(%rsp),%rax
    0.00 :   1768b4: mov    0x10(%rax),%rcx
    0.00 :   1768b8: mov    0x38(%rcx),%rcx
    0.00 :   1768bc: movaps 0x60(%rsp),%xmm0
    0.00 :   1768c1: movups %xmm0,0x20(%rcx)
    0.00 :   1768c5: decq   (%rax)
    0.00 :   1768c8: lea    -0x1(%r13),%rbp
    0.00 :   1768cc: lea    -0x157cbf(%rip),%r14        # 1ec14 <anon.de2471ab41e489a293ba001b839d8fc3.880.llvm.10657235172099788962>
    0.00 :   1768d3: mov    $0x2b,%eax
    0.00 :   1768d8: mov    %rax,0x18(%rsp)
    0.00 :   1768dd: jne    1768ea <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x58a>
    0.00 :   1768df: lea    0x70(%rsp),%rdi
    0.00 :   1768e4: call   *0x1c88e(%rip)        # 193178 <_DYNAMIC+0x1160>
    0.00 :   1768ea: xor    %r15d,%r15d
    0.00 :   1768ed: mov    $0x1,%r12b
    0.00 :   1768f0: lea    0xb0(%rsp),%rdi
    0.00 :   1768f8: call   166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>
    0.00 :   1768fd: lea    0xd0(%rsp),%rdi
    0.00 :   176905: call   16b400 <core::ptr::drop_in_place<vthread::channel::wait::Ticket<i32>>>
    0.00 :   17690a: mov    (%rsp),%rax
    0.00 :   17690e: cmp    $0x11,%rax
    0.00 :   176912: je     176933 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x5d3>
    0.00 :   176914: mov    0x8(%rsp),%rcx
    0.00 :   176919: mov    0x10(%rsp),%rdx
    0.00 :   17691e: mov    0x10(%rdx),%rsi
    0.00 :   176922: mov    0x38(%rsi),%rsi
    0.00 :   176926: mov    %rax,0x20(%rsi)
    0.00 :   17692a: mov    %rcx,0x28(%rsi)
    0.00 :   17692e: decq   (%rdx)
    0.00 :   176931: je     17694d <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x5ed>
    0.00 :   176933: cmp    %r13,%rbp
    0.00 :   176936: mov    0x18(%rsp),%rax
    0.00 :   17693b: jne    176962 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x602>
    0.00 :   17693d: mov    0x88(%rsp),%rax
    0.00 :   176945: mov    %r13,(%rax)
    0.00 :   176948: jmp    1769dd <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x67d>
    0.00 :   17694d: lea    0x10(%rsp),%rdi
    0.00 :   176952: call   *0x1c820(%rip)        # 193178 <_DYNAMIC+0x1160>
    0.00 :   176958: cmp    %r13,%rbp
    0.00 :   17695b: mov    0x18(%rsp),%rax
    0.00 :   176960: je     17693d <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x5dd>
    0.00 :   176962: mov    %rbp,0x20(%rsp)
    0.00 :   176967: mov    %r14,0x28(%rsp)
    0.00 :   17696c: mov    %rax,0x30(%rsp)
    0.00 :   176971: mov    %rbx,0x38(%rsp)
    0.00 :   176976: mov    %r15b,0x40(%rsp)
    0.00 :   17697b: movaps 0x90(%rsp),%xmm0
    0.00 :   176983: movups %xmm0,0x41(%rsp)
    0.00 :   176988: movups 0x9f(%rsp),%xmm0
    0.00 :   176990: movups %xmm0,0x50(%rsp)
    0.00 :   176995: test   %r12b,%r12b
    0.00 :   176998: je     176b8e <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x82e>
    0.00 :   17699e: mov    0x88(%rsp),%rcx
    0.00 :   1769a6: mov    %rax,0x10(%rcx)
    0.00 :   1769aa: mov    %rbx,0x18(%rcx)
    0.00 :   1769ae: mov    %r15b,0x20(%rcx)
    0.00 :   1769b2: movaps 0x90(%rsp),%xmm0
    0.00 :   1769ba: movups %xmm0,0x21(%rcx)
    0.00 :   1769be: movups 0x9f(%rsp),%xmm0
    0.00 :   1769c6: movups %xmm0,0x30(%rcx)
    0.00 :   1769ca: mov    %rbp,(%rcx)
    0.00 :   1769cd: mov    %r14,0x8(%rcx)
    0.00 :   1769d1: mov    0x80(%rsp),%rax
    0.00 :   1769d9: mov    %rax,0x40(%rcx)
    0.00 :   1769dd: add    $0xf8,%rsp
    0.00 :   1769e4: pop    %rbx
    0.00 :   1769e5: pop    %r12
    0.00 :   1769e7: pop    %r13
    0.00 :   1769e9: pop    %r14
    0.00 :   1769eb: pop    %r15
    0.00 :   1769ed: pop    %rbp
    0.00 :   1769ee: ret
    0.00 :   1769ef: xor    %ecx,%ecx
    0.00 :   1769f1: mov    %rcx,0xb0(%rsp)
    0.00 :   1769f9: mov    %r9,0xb8(%rsp)
    0.00 :   176a01: cmpq   $0x0,0x58(%r12)
    0.00 :   176a07: je     176aec <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x78c>
    0.00 :   176a0d: mov    0x50(%r12),%rdi
    0.00 :   176a12: mov    0x40(%r12),%rax
    0.00 :   176a17: mov    0x48(%r12),%rdx
    0.00 :   176a1c: xor    %ecx,%ecx
    0.00 :   176a1e: cmp    %rax,%rdi
    0.00 :   176a21: cmovb  %rcx,%rax
    0.00 :   176a25: sub    %rax,%rdi
    0.00 :   176a28: shl    $0x4,%rdi
    0.00 :   176a2c: mov    0x8(%rdx,%rdi,1),%rsi
    0.00 :   176a31: test   %rsi,%rsi
    0.00 :   176a34: je     176aee <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x78e>
    0.00 :   176a3a: mov    0x38(%rsi),%rax
    0.00 :   176a3e: mov    %eax,%r8d
    0.00 :   176a41: and    $0xf,%r8d
    0.00 :   176a45: cmp    $0xc,%r8
    0.00 :   176a49: ja     176ba9 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x849>
    0.00 :   176a4f: add    %rdi,%rdx
    0.00 :   176a52: xor    %ecx,%ecx
    0.00 :   176a54: mov    $0x155,%edi
    0.00 :   176a59: jmp    176a77 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x717>
    0.00 :   176a5b: nopl   0x0(%rax,%rax,1)
    0.00 :   176a60: pause
    0.00 :   176a62: mov    0x38(%rsi),%rax
    0.00 :   176a66: mov    %eax,%r8d
    0.00 :   176a69: and    $0xf,%r8d
    0.00 :   176a6d: cmp    $0xd,%r8
    0.00 :   176a71: jae    176ba9 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x849>
    0.00 :   176a77: cmp    $0x1,%r8
    0.00 :   176a7b: je     176a60 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x700>
    0.00 :   176a7d: test   $0x20,%al
    0.00 :   176a7f: jne    176aee <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x78e>
    0.00 :   176a81: lea    -0x3(%r8),%r9d
    0.00 :   176a85: cmp    $0x9,%r9b
    0.00 :   176a89: jae    176a95 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x735>
    0.00 :   176a8b: movzbl %r9b,%r9d
    0.00 :   176a8f: bt     %r9d,%edi
    0.00 :   176a93: jb     176aee <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x78e>
    0.00 :   176a95: mov    %rax,%r9
    0.00 :   176a98: and    $0xffffffffffffffd0,%r9
    0.00 :   176a9c: or     $0x3,%r9
    0.00 :   176aa0: mov    %rax,%r10
    0.00 :   176aa3: or     $0x10,%r10
    0.00 :   176aa7: cmp    $0x2,%r8
    0.00 :   176aab: cmove  %r9,%r10
    0.00 :   176aaf: lock cmpxchg %r10,0x38(%rsi)
   10.73 :   176ab5: jne    176a66 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x706>
    0.00 :   176ab7: cmp    $0x2,%r8
    0.00 :   176abb: jne    176aec <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x78c>
    0.00 :   176abd: mov    0x8(%rdx),%rcx
    0.00 :   176ac1: movq   $0x0,0x8(%rdx)
    0.00 :   176ac9: test   %rcx,%rcx
    0.00 :   176acc: jne    176aee <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x78e>
    0.00 :   176ace: lea    -0x1585cc(%rip),%rdi        # 1e509 <anon.de2471ab41e489a293ba001b839d8fc3.708.llvm.10657235172099788962>
    0.00 :   176ad5: lea    0x17f74(%rip),%rdx        # 18ea50 <anon.de2471ab41e489a293ba001b839d8fc3.710.llvm.10657235172099788962>
    0.00 :   176adc: mov    $0x1a,%esi
    0.00 :   176ae1: call   *0x1b959(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   176ae7: jmp    176bf2 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x892>
    0.00 :   176aec: xor    %ecx,%ecx
    0.00 :   176aee: mov    %rcx,0xc0(%rsp)
    0.00 :   176af6: mov    %r9,0xc8(%rsp)
    0.00 :   176afe: movb   $0x0,0x78(%r12)
    0.00 :   176b04: lea    0xb0(%rsp),%rdi
    0.00 :   176b0c: call   166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>
    0.00 :   176b11: xor    %r12d,%r12d
    0.00 :   176b14: mov    %r13,%rbp
    0.00 :   176b17: jmp    1768fd <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x59d>
    0.00 :   176b1c: lea    -0x158747(%rip),%rdi        # 1e3dc <anon.de2471ab41e489a293ba001b839d8fc3.694.llvm.10657235172099788962>
    0.00 :   176b23: lea    0x17eae(%rip),%rdx        # 18e9d8 <anon.de2471ab41e489a293ba001b839d8fc3.695.llvm.10657235172099788962>
    0.00 :   176b2a: mov    $0x79,%esi
    0.00 :   176b2f: call   *0x1b76b(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   176b35: jmp    176bf2 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x892>
    0.00 :   176b3a: lea    -0x157f02(%rip),%rdi        # 1ec3f <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962>
    0.00 :   176b41: lea    0x185a0(%rip),%rdx        # 18f0e8 <anon.de2471ab41e489a293ba001b839d8fc3.882.llvm.10657235172099788962>
    0.00 :   176b48: mov    $0x1d,%esi
    0.00 :   176b4d: call   *0x1b8ed(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   176b53: jmp    176bf2 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x892>
    0.00 :   176b58: lea    -0x155042(%rip),%rdi        # 21b1d <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962+0x2ede>
    0.00 :   176b5f: lea    0x1a202(%rip),%rdx        # 190d68 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1c38>
    0.00 :   176b66: mov    $0xd,%esi
    0.00 :   176b6b: call   *0x1b8cf(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   176b71: jmp    176bf2 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x892>
    0.00 :   176b73: lea    -0x155037(%rip),%rdi        # 21b43 <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962+0x2f04>
    0.00 :   176b7a: lea    0x1a247(%rip),%rdx        # 190dc8 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1c98>
    0.00 :   176b81: mov    $0x37,%esi
    0.00 :   176b86: call   *0x1b714(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   176b8c: jmp    176bf2 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x892>
    0.00 :   176b8e: lea    -0x15506b(%rip),%rdi        # 21b2a <anon.de2471ab41e489a293ba001b839d8fc3.881.llvm.10657235172099788962+0x2eeb>
    0.00 :   176b95: lea    0x1a214(%rip),%rdx        # 190db0 <anon.de2471ab41e489a293ba001b839d8fc3.888.llvm.10657235172099788962+0x1c80>
    0.00 :   176b9c: mov    $0x19,%esi
    0.00 :   176ba1: call   *0x1b899(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   176ba7: jmp    176bf2 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x892>
    0.00 :   176ba9: lea    -0x1587d4(%rip),%rdi        # 1e3dc <anon.de2471ab41e489a293ba001b839d8fc3.694.llvm.10657235172099788962>
    0.00 :   176bb0: lea    0x17e21(%rip),%rdx        # 18e9d8 <anon.de2471ab41e489a293ba001b839d8fc3.695.llvm.10657235172099788962>
    0.00 :   176bb7: mov    $0x79,%esi
    0.00 :   176bbc: call   *0x1b6de(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   176bc2: jmp    176bf2 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x892>
    0.00 :   176bc4: movq   $0xffffffffffffffff,0x20(%rsp)
    0.00 :   176bcd: lea    -0x1586b1(%rip),%rdi        # 1e523 <anon.de2471ab41e489a293ba001b839d8fc3.714.llvm.10657235172099788962>
    0.00 :   176bd4: lea    0x16c55(%rip),%rcx        # 18d830 <anon.de2471ab41e489a293ba001b839d8fc3.179.llvm.10657235172099788962>
    0.00 :   176bdb: lea    0x17e9e(%rip),%r8        # 18ea80 <anon.de2471ab41e489a293ba001b839d8fc3.716.llvm.10657235172099788962>
    0.00 :   176be2: lea    0x20(%rsp),%rdx
    0.00 :   176be7: mov    $0x1e,%esi
    0.00 :   176bec: call   *0x1b68e(%rip)        # 192280 <_DYNAMIC+0x268>
    0.00 :   176bf2: ud2
    0.00 :   176bf4: jmp    176c4d <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8ed>
    0.00 :   176bf6: jmp    176c3d <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8dd>
    0.00 :   176bf8: jmp    176c1b <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8bb>
    0.00 :   176bfa: mov    %rax,%rbx
    0.00 :   176bfd: mov    0x70(%rsp),%rax
    0.00 :   176c02: mov    %rax,0x10(%rsp)
    0.00 :   176c07: movaps 0x60(%rsp),%xmm0
    0.00 :   176c0c: movaps %xmm0,(%rsp)
    0.00 :   176c10: jmp    176c5a <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8fa>
    0.00 :   176c12: jmp    176c1b <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8bb>
    0.00 :   176c14: mov    %rax,%rbx
    0.00 :   176c17: jmp    176c74 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x914>
    0.00 :   176c19: jmp    176c3d <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8dd>
    0.00 :   176c1b: mov    %rax,%rbx
    0.00 :   176c1e: jmp    176c67 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x907>
    0.00 :   176c20: jmp    176c3d <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8dd>
    0.00 :   176c22: jmp    176c42 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8e2>
    0.00 :   176c24: jmp    176c42 <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8e2>
    0.00 :   176c26: mov    %rax,%rbx
    0.00 :   176c29: lea    0x20(%rsp),%rdi
    0.00 :   176c2e: call   1694f0 <core::ptr::drop_in_place<vthread::error::Error>>
    0.00 :   176c33: jmp    176c7c <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x91c>
    0.00 :   176c35: call   *0x1b81d(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   176c3b: jmp    176c4d <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8ed>
    0.00 :   176c3d: mov    %rax,%rbx
    0.00 :   176c40: jmp    176c5a <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8fa>
    0.00 :   176c42: mov    %rax,%rbx
    0.00 :   176c45: movb   $0x0,0x78(%r12)
    0.00 :   176c4b: jmp    176c5a <vthread::channel::core::<impl vthread::channel::Core<T>>::send+0x8fa>
    0.00 :   176c4d: mov    %rax,%rbx
    0.00 :   176c50: lea    0x60(%rsp),%rdi
    0.00 :   176c55: call   1699d0 <core::ptr::drop_in_place<vthread::sync::wait::Wait>>
    0.00 :   176c5a: lea    0xb0(%rsp),%rdi
    0.00 :   176c62: call   166da0 <core::ptr::drop_in_place<[core::option::Option<vthread::wait::wait_notification::NotificationPublication>; 2]>>
    0.00 :   176c67: lea    0xd0(%rsp),%rdi
    0.00 :   176c6f: call   16b400 <core::ptr::drop_in_place<vthread::channel::wait::Ticket<i32>>>
    0.00 :   176c74: mov    %rsp,%rdi
    0.00 :   176c77: call   16c410 <core::ptr::drop_in_place<core::option::Option<vthread::sync::wait::Wait>>>
    0.00 :   176c7c: mov    %rbx,%rdi
    0.00 :   176c7f: call   187ca0 <_Unwind_Resume@plt>
    0.00 :   176c84: call   *0x1b7ce(%rip)        # 192458 <_DYNAMIC+0x440>
