 Percent |	Source code & Disassembly of candidate-inlined for cycles:u (3 samples, percent: global period)
---------------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     00000000000cada0 <std::sys::backtrace::__rust_begin_short_backtrace>:
         : 6     std::sys::backtrace::__rust_begin_short_backtrace:
    0.00 :   cada0:  push   %rbp
    0.00 :   cada1:  push   %r15
    0.00 :   cada3:  push   %r14
    0.00 :   cada5:  push   %r13
    0.00 :   cada7:  push   %r12
    0.00 :   cada9:  push   %rbx
    0.00 :   cadaa:  sub    $0x558,%rsp
    0.00 :   cadb1:  mov    %rdi,%r12
    0.00 :   cadb4:  mov    %rdi,0xc0(%rsp)
    0.00 :   cadbc:  mov    %rsi,0x28(%rsp)
    0.00 :   cadc1:  mov    %rsi,0xc8(%rsp)
    0.00 :   cadc9:  jmp    cadd2 <std::sys::backtrace::__rust_begin_short_backtrace+0x32>
    0.00 :   cadcb:  nopl   0x0(%rax,%rax,1)
    0.00 :   cadd0:  pause
    0.00 :   cadd2:  mov    0x8(%r12),%rax
    0.00 :   cadd7:  nopw   0x0(%rax,%rax,1)
    0.00 :   cade0:  cmp    $0xffffffffffffffff,%rax
    0.00 :   cade4:  je     cadd0 <std::sys::backtrace::__rust_begin_short_backtrace+0x30>
    0.00 :   cade6:  test   %rax,%rax
    0.00 :   cade9:  js     cb362 <std::sys::backtrace::__rust_begin_short_backtrace+0x5c2>
    0.00 :   cadef:  lea    0x1(%rax),%rcx
    0.00 :   cadf3:  lock cmpxchg %rcx,0x8(%r12)
    0.00 :   cadfa:  jne    cade0 <std::sys::backtrace::__rust_begin_short_backtrace+0x40>
    0.00 :   cadfc:  mov    %r12,%rdi
    0.00 :   cadff:  xor    %esi,%esi
    0.00 :   cae01:  call   102ff0 <vthread::worker_context::attach>
    0.00 :   cae06:  lock incq (%r12)
    0.00 :   cae0b:  jle    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae11:  mov    %r12,0x98(%rsp)
    0.00 :   cae19:  lock incq (%r12)
    0.00 :   cae1e:  jle    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae24:  mov    %r12,0xd0(%rsp)
    0.00 :   cae2c:  mov    0xa0(%r12),%rsi
    0.00 :   cae34:  mov    0x28(%rsp),%rdi
    0.00 :   cae39:  cmp    %rsi,%rdi
    0.00 :   cae3c:  jae    cc3b1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1611>
    0.00 :   cae42:  movups 0x50(%r12),%xmm0
    0.00 :   cae48:  mov    0x70(%r12),%rax
    0.00 :   cae4d:  mov    0x98(%r12),%rcx
    0.00 :   cae55:  mov    (%rcx,%rdi,8),%rbx
    0.00 :   cae59:  lock incq (%rbx)
    0.00 :   cae5d:  jle    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cae63:  mov    %rbx,0xd8(%rsp)
    0.00 :   cae6b:  mov    %r12,0x40(%rsp)
    0.00 :   cae70:  movq   $0x0,0x3a8(%rsp)
    0.00 :   cae7c:  movq   $0x8,0x3b0(%rsp)
    0.00 :   cae88:  xorps  %xmm1,%xmm1
    0.00 :   cae8b:  movups %xmm1,0x3b8(%rsp)
    0.00 :   cae93:  movq   $0x8,0x3c8(%rsp)
    0.00 :   cae9f:  movups %xmm1,0x3d0(%rsp)
    0.00 :   caea7:  movq   $0x8,0x3e0(%rsp)
    0.00 :   caeb3:  movups %xmm1,0x3e8(%rsp)
    0.00 :   caebb:  movq   $0x8,0x3f8(%rsp)
    0.00 :   caec7:  movq   $0x0,0x400(%rsp)
    0.00 :   caed3:  movq   $0x0,0x480(%rsp)
    0.00 :   caedf:  movq   $0x8,0x488(%rsp)
    0.00 :   caeeb:  movups %xmm1,0x490(%rsp)
    0.00 :   caef3:  movq   $0x0,0x4a0(%rsp)
    0.00 :   caeff:  movq   $0x8,0x4a8(%rsp)
    0.00 :   caf0b:  movups %xmm1,0x4b0(%rsp)
    0.00 :   caf13:  movb   $0x0,0x4c0(%rsp)
    0.00 :   caf1b:  movq   $0x0,0x58(%rsp)
    0.00 :   caf24:  movq   $0x8,0x60(%rsp)
    0.00 :   caf2d:  movups %xmm1,0x68(%rsp)
    0.00 :   caf32:  movq   $0x8,0x78(%rsp)
    0.00 :   caf3b:  movups %xmm1,0x80(%rsp)
    0.00 :   caf43:  movq   $0x2,0x100(%rsp)
    0.00 :   caf4f:  movq   $0x0,0xe0(%rsp)
    0.00 :   caf5b:  movups %xmm1,0xf0(%rsp)
    0.00 :   caf63:  movq   $0x8,0xe8(%rsp)
    0.00 :   caf6f:  movq   $0x0,0xa0(%rsp)
    0.00 :   caf7b:  movq   $0x8,0xa8(%rsp)
    0.00 :   caf87:  movq   $0x0,0xb0(%rsp)
    0.00 :   caf93:  movq   $0x1,0x120(%rsp)
    0.00 :   caf9f:  movq   $0x1,0x128(%rsp)
    0.00 :   cafab:  movups %xmm1,0x130(%rsp)
    0.00 :   cafb3:  movq   $0x8,0x140(%rsp)
    0.00 :   cafbf:  movq   $0x0,0x148(%rsp)
    0.00 :   cafcb:  movups %xmm0,0x150(%rsp)
    0.00 :   cafd3:  movq   $0x1,0x160(%rsp)
    0.00 :   cafdf:  movups %xmm1,0x168(%rsp)
    0.00 :   cafe7:  movups %xmm1,0x178(%rsp)
    0.00 :   cafef:  movups %xmm1,0x188(%rsp)
    0.00 :   caff7:  movq   $0x0,0x198(%rsp)
    0.00 :   cb003:  movq   $0x8,0x1a0(%rsp)
    0.00 :   cb00f:  movups %xmm1,0x1a8(%rsp)
    0.00 :   cb017:  movups %xmm1,0x1b8(%rsp)
    0.00 :   cb01f:  movq   $0x0,0x1c8(%rsp)
    0.00 :   cb02b:  movq   $0x8,0x1d0(%rsp)
    0.00 :   cb037:  movups %xmm1,0x1d8(%rsp)
    0.00 :   cb03f:  movups %xmm1,0x1e8(%rsp)
    0.00 :   cb047:  mov    %rax,0x1f8(%rsp)
    0.00 :   cb04f:  mov    $0xe0,%edi
    0.00 :   cb054:  call   *0xc7206(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cb05a:  test   %rax,%rax
    0.00 :   cb05d:  je     cb3a1 <std::sys::backtrace::__rust_begin_short_backtrace+0x601>
    0.00 :   cb063:  mov    %rax,%r14
    0.00 :   cb066:  lea    0x120(%rsp),%rsi
    0.00 :   cb06e:  mov    $0xe0,%edx
    0.00 :   cb073:  mov    %rax,%rdi
    0.00 :   cb076:  call   *0xc71b4(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   cb07c:  mov    %r12,0x2b8(%rsp)
    0.00 :   cb084:  mov    %rbx,0x2c0(%rsp)
    0.00 :   cb08c:  mov    0x28(%rsp),%rax
    0.00 :   cb091:  mov    %rax,0x2d0(%rsp)
    0.00 :   cb099:  movups 0x3a8(%rsp),%xmm0
    0.00 :   cb0a1:  movups 0x3b8(%rsp),%xmm1
    0.00 :   cb0a9:  movups 0x3c8(%rsp),%xmm2
    0.00 :   cb0b1:  movups 0x3d8(%rsp),%xmm3
    0.00 :   cb0b9:  movaps %xmm0,0x1a0(%rsp)
    0.00 :   cb0c1:  movaps %xmm1,0x1b0(%rsp)
    0.00 :   cb0c9:  movaps %xmm2,0x1c0(%rsp)
    0.00 :   cb0d1:  movaps %xmm3,0x1d0(%rsp)
    0.00 :   cb0d9:  movups 0x3e8(%rsp),%xmm0
    0.00 :   cb0e1:  movaps %xmm0,0x1e0(%rsp)
    0.00 :   cb0e9:  movups 0x3f8(%rsp),%xmm0
    0.00 :   cb0f1:  movaps %xmm0,0x1f0(%rsp)
    0.00 :   cb0f9:  movups 0x480(%rsp),%xmm0
    0.00 :   cb101:  movups 0x490(%rsp),%xmm1
    0.00 :   cb109:  movups 0x4a0(%rsp),%xmm2
    0.00 :   cb111:  movups 0x4b0(%rsp),%xmm3
    0.00 :   cb119:  movaps %xmm0,0x200(%rsp)
    0.00 :   cb121:  movaps %xmm1,0x210(%rsp)
    0.00 :   cb129:  movaps %xmm2,0x220(%rsp)
    0.00 :   cb131:  movaps %xmm3,0x230(%rsp)
    0.00 :   cb139:  mov    0x4c0(%rsp),%rax
    0.00 :   cb141:  mov    %rax,0x240(%rsp)
    0.00 :   cb149:  mov    0x88(%rsp),%rax
    0.00 :   cb151:  mov    %rax,0x278(%rsp)
    0.00 :   cb159:  movups 0x58(%rsp),%xmm0
    0.00 :   cb15e:  movups 0x68(%rsp),%xmm1
    0.00 :   cb163:  movups 0x78(%rsp),%xmm2
    0.00 :   cb168:  movups %xmm2,0x268(%rsp)
    0.00 :   cb170:  movups %xmm1,0x258(%rsp)
    0.00 :   cb178:  movups %xmm0,0x248(%rsp)
    0.00 :   cb180:  movq   $0x0,0x2d8(%rsp)
    0.00 :   cb18c:  movups 0x100(%rsp),%xmm0
    0.00 :   cb194:  movups 0x110(%rsp),%xmm1
    0.00 :   cb19c:  movaps %xmm0,0x120(%rsp)
    0.00 :   cb1a4:  movaps %xmm1,0x130(%rsp)
    0.00 :   cb1ac:  movups 0xe0(%rsp),%xmm0
    0.00 :   cb1b4:  movups 0xf0(%rsp),%xmm1
    0.00 :   cb1bc:  movaps %xmm0,0x280(%rsp)
    0.00 :   cb1c4:  movaps %xmm1,0x290(%rsp)
    0.00 :   cb1cc:  movb   $0x0,0x39c(%rsp)
    0.00 :   cb1d4:  movq   $0x18,0x140(%rsp)
    0.00 :   cb1e0:  movq   $0x0,0x168(%rsp)
    0.00 :   cb1ec:  movq   $0x8,0x170(%rsp)
    0.00 :   cb1f8:  xorps  %xmm1,%xmm1
    0.00 :   cb1fb:  movups %xmm1,0x2e8(%rsp)
    0.00 :   cb203:  movups %xmm1,0x178(%rsp)
    0.00 :   cb20b:  movups %xmm1,0x188(%rsp)
    0.00 :   cb213:  movq   $0x0,0x198(%rsp)
    0.00 :   cb21f:  mov    0xb0(%rsp),%rax
    0.00 :   cb227:  mov    %rax,0x2b0(%rsp)
    0.00 :   cb22f:  movups 0xa0(%rsp),%xmm0
    0.00 :   cb237:  movaps %xmm0,0x2a0(%rsp)
    0.00 :   cb23f:  mov    %r14,0x2c8(%rsp)
    0.00 :   cb247:  movw   $0x0,0x39d(%rsp)
    0.00 :   cb251:  movaps %xmm1,0x300(%rsp)
    0.00 :   cb259:  movups %xmm1,0x388(%rsp)
    0.00 :   cb261:  movups %xmm1,0x378(%rsp)
    0.00 :   cb269:  movups %xmm1,0x368(%rsp)
    0.00 :   cb271:  movups %xmm1,0x358(%rsp)
    0.00 :   cb279:  movups %xmm1,0x348(%rsp)
    0.00 :   cb281:  movups %xmm1,0x338(%rsp)
    0.00 :   cb289:  movups %xmm1,0x328(%rsp)
    0.00 :   cb291:  movups %xmm1,0x318(%rsp)
    0.00 :   cb299:  movl   $0x0,0x398(%rsp)
    0.00 :   cb2a4:  mov    $0x280,%edi
    0.00 :   cb2a9:  call   *0xc6fb1(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cb2af:  test   %rax,%rax
    0.00 :   cb2b2:  je     cb3b6 <std::sys::backtrace::__rust_begin_short_backtrace+0x616>
    0.00 :   cb2b8:  mov    %rax,%rbx
    0.00 :   cb2bb:  lea    0x120(%rsp),%rsi
    0.00 :   cb2c3:  mov    $0x280,%edx
    0.00 :   cb2c8:  mov    %rax,%rdi
    0.00 :   cb2cb:  call   *0xc6f5f(%rip)        # 192230 <memcpy@GLIBC_2.14>
    0.00 :   cb2d1:  mov    0x1a0(%rbx),%rax
    0.00 :   cb2d8:  mov    %rbx,0x8(%rsp)
    0.00 :   cb2dd:  mov    0x1a8(%rbx),%rbx
    0.00 :   cb2e4:  mov    0xe0(%rax),%r14
    0.00 :   cb2eb:  lock incq (%r14)
    0.00 :   cb2ef:  jle    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb2f5:  incq   (%rbx)
    0.00 :   cb2f8:  je     cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb2fe:  mov    %r14,0x3a8(%rsp)
    0.00 :   cb306:  mov    %rbx,0x3b0(%rsp)
    0.00 :   cb30e:  movzbl %fs:0xffffffffffffffd8,%eax
    0.00 :   cb317:  cmp    $0x1,%eax
    0.00 :   cb31a:  je     cb3f1 <std::sys::backtrace::__rust_begin_short_backtrace+0x651>
    0.00 :   cb320:  cmp    $0x2,%eax
    0.00 :   cb323:  jne    cb3cb <std::sys::backtrace::__rust_begin_short_backtrace+0x62b>
    0.00 :   cb329:  lock decq (%r14)
    0.00 :   cb32d:  jne    cb33d <std::sys::backtrace::__rust_begin_short_backtrace+0x59d>
    0.00 :   cb32f:  lea    0x3a8(%rsp),%rdi
    0.00 :   cb337:  call   *0xc7e43(%rip)        # 193180 <_DYNAMIC+0x1168>
    0.00 :   cb33d:  decq   (%rbx)
    0.00 :   cb340:  jne    cb350 <std::sys::backtrace::__rust_begin_short_backtrace+0x5b0>
    0.00 :   cb342:  lea    0x3b0(%rsp),%rdi
    0.00 :   cb34a:  call   *0xc7e38(%rip)        # 193188 <_DYNAMIC+0x1170>
    0.00 :   cb350:  lea    0xc23a9(%rip),%rdi        # 18d700 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962>
    0.00 :   cb357:  call   *0xc74d3(%rip)        # 192830 <_DYNAMIC+0x818>
    0.00 :   cb35d:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb362:  lea    0xc1de7(%rip),%rax        # 18d150 <anon.e19cb05173cfa9d2277c28e7a8ac702e.942.llvm.13342753452097612697+0x210>
    0.00 :   cb369:  mov    %rax,0x120(%rsp)
    0.00 :   cb371:  lea    0x8778(%rip),%rax        # d3af0 <_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hb2a2ab9295a6d20aE.llvm.10657235172099788962>
    0.00 :   cb378:  mov    %rax,0x128(%rsp)
    0.00 :   cb380:  lea    -0xb8b8c(%rip),%rdi        # 127fb <anon.48996dcd35f4b7aad43cb5fc1472ecbf.144.llvm.7041895458470441471>
    0.00 :   cb387:  lea    0xc2b92(%rip),%rdx        # 18df20 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x6b0>
    0.00 :   cb38e:  lea    0x120(%rsp),%rsi
    0.00 :   cb396:  call   *0xc6f04(%rip)        # 1922a0 <_DYNAMIC+0x288>
    0.00 :   cb39c:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb3a1:  mov    $0x8,%edi
    0.00 :   cb3a6:  mov    $0xe0,%esi
    0.00 :   cb3ab:  call   *0xc6ed7(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   cb3b1:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb3b6:  mov    $0x8,%edi
    0.00 :   cb3bb:  mov    $0x280,%esi
    0.00 :   cb3c0:  call   *0xc6ec2(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   cb3c6:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cb3cb:  mov    %fs:0x0,%rax
    0.00 :   cb3d4:  lea    -0x40(%rax),%rdi
    0.00 :   cb3db:  lea    -0x4db2(%rip),%rsi        # c6630 <std::sys::thread_local::native::eager::destroy>
    0.00 :   cb3e2:  call   *0xc7598(%rip)        # 192980 <_DYNAMIC+0x968>
    0.00 :   cb3e8:  movb   $0x1,%fs:0xffffffffffffffd8
    0.00 :   cb3f1:  mov    %r14,0x120(%rsp)
    0.00 :   cb3f9:  mov    %rbx,0x128(%rsp)
    0.00 :   cb401:  cmpq   $0x0,%fs:0xffffffffffffffc0
    0.00 :   cb40b:  jne    cc290 <std::sys::backtrace::__rust_begin_short_backtrace+0x14f0>
    0.00 :   cb411:  movups %fs:0xffffffffffffffc8,%xmm0
    0.00 :   cb41a:  mov    %r14,%fs:0xffffffffffffffc8
    0.00 :   cb423:  mov    %rbx,%fs:0xffffffffffffffd0
    0.00 :   cb42c:  movaps %xmm0,0x40(%rsp)
    0.00 :   cb431:  mov    %r12,0x18(%rsp)
    0.00 :   cb436:  lea    0x10(%r12),%rax
    0.00 :   cb43b:  mov    %rax,0x20(%rsp)
    0.00 :   cb440:  mov    0x8(%rsp),%rdi
    0.00 :   cb445:  lea    0x20(%rdi),%rax
    0.00 :   cb449:  mov    %rax,0x90(%rsp)
    0.00 :   cb451:  mov    %rdi,%rax
    0.00 :   cb454:  add    $0x58,%rax
    0.00 :   cb458:  mov    %rax,0xb8(%rsp)
    0.00 :   cb460:  mov    $0x1,%al
    0.00 :   cb462:  jmp    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb464:  data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb470:  mov    0x1a0(%rdi),%rax
    0.00 :   cb477:  mov    0xd0(%rax),%rax
    0.00 :   cb47e:  test   %rax,%rax
    0.00 :   cb481:  je     cb960 <std::sys::backtrace::__rust_begin_short_backtrace+0xbc0>
    0.00 :   cb487:  movb   $0x1,0x27c(%rdi)
    0.00 :   cb48e:  xor    %eax,%eax
    0.00 :   cb490:  mov    0x1a0(%rdi),%rcx
    0.00 :   cb497:  mov    0xd8(%rcx),%rcx
    0.00 :   cb49e:  mov    0x10(%rcx),%rcx
    0.00 :   cb4a2:  mov    %rcx,0x38(%rsp)
    0.00 :   cb4a7:  cmp    %rcx,%r15
    0.00 :   cb4aa:  setne  %bl
    0.00 :   cb4ad:  or     %al,%bl
    0.00 :   cb4af:  test   $0x1,%bl
   32.98 :   cb4b2:  je     cb710 <std::sys::backtrace::__rust_begin_short_backtrace+0x970>
    0.00 :   cb4b8:  mov    0x1a0(%rdi),%rax
    0.00 :   cb4bf:  movzbl 0xeb(%rax),%eax
    0.00 :   cb4c6:  test   %al,%al
    0.00 :   cb4c8:  jne    cbfff <std::sys::backtrace::__rust_begin_short_backtrace+0x125f>
    0.00 :   cb4ce:  mov    %bl,0x14(%rsp)
    0.00 :   cb4d2:  mov    0x1a0(%rdi),%r12
    0.00 :   cb4d9:  movzbl 0xec(%r12),%eax
    0.00 :   cb4e2:  test   %al,%al
    0.00 :   cb4e4:  je     cb720 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb4ea:  lea    0xec(%r12),%rbx
    0.00 :   cb4f2:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb500:  lea    0x88(%r12),%r13
    0.00 :   cb508:  xor    %eax,%eax
    0.00 :   cb50a:  mov    $0x1,%ecx
    0.00 :   cb50f:  lock cmpxchg %ecx,0x88(%r12)
    0.00 :   cb519:  jne    cb6a5 <std::sys::backtrace::__rust_begin_short_backtrace+0x905>
    0.00 :   cb51f:  mov    0xc7082(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cb526:  mov    (%rax),%rax
    0.00 :   cb529:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb533:  test   %rcx,%rax
    0.00 :   cb536:  jne    cb6b3 <std::sys::backtrace::__rust_begin_short_backtrace+0x913>
    0.00 :   cb53c:  xor    %ebp,%ebp
    0.00 :   cb53e:  movzbl 0x8c(%r12),%eax
    0.00 :   cb547:  mov    0xb0(%r12),%rax
    0.00 :   cb54f:  mov    $0x6,%r14b
    0.00 :   cb552:  test   %rax,%rax
    0.00 :   cb555:  je     cb610 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb55b:  mov    0xb8(%r12),%rcx
    0.00 :   cb563:  test   %rcx,%rcx
    0.00 :   cb566:  je     cb5c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb568:  mov    %rcx,%rdx
    0.00 :   cb56b:  and    $0x7,%rdx
    0.00 :   cb56f:  je     cb693 <std::sys::backtrace::__rust_begin_short_backtrace+0x8f3>
    0.00 :   cb575:  xor    %esi,%esi
    0.00 :   cb577:  nopw   0x0(%rax,%rax,1)
    0.00 :   cb580:  mov    0x70(%rax),%rax
    0.00 :   cb584:  inc    %rsi
    0.00 :   cb587:  cmp    %rsi,%rdx
    0.00 :   cb58a:  jne    cb580 <std::sys::backtrace::__rust_begin_short_backtrace+0x7e0>
    0.00 :   cb58c:  mov    %rcx,%rdx
    0.00 :   cb58f:  sub    %rsi,%rdx
    0.00 :   cb592:  cmp    $0x8,%rcx
    0.00 :   cb596:  jb     cb5c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb598:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb5a0:  mov    0x70(%rax),%rax
    0.00 :   cb5a4:  mov    0x70(%rax),%rax
    0.00 :   cb5a8:  mov    0x70(%rax),%rax
    0.00 :   cb5ac:  mov    0x70(%rax),%rax
    0.00 :   cb5b0:  mov    0x70(%rax),%rax
    0.00 :   cb5b4:  mov    0x70(%rax),%rax
    0.00 :   cb5b8:  mov    0x70(%rax),%rax
    0.00 :   cb5bc:  mov    0x70(%rax),%rax
    0.00 :   cb5c0:  add    $0xfffffffffffffff8,%rdx
    0.00 :   cb5c4:  jne    cb5a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x800>
    0.00 :   cb5c6:  cmpw   $0x0,0x62(%rax)
    0.00 :   cb5cb:  je     cb610 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb5cd:  lea    0xb0(%r12),%rcx
    0.00 :   cb5d5:  lea    0x128(%rsp),%rdx
    0.00 :   cb5dd:  xorps  %xmm0,%xmm0
    0.00 :   cb5e0:  movups %xmm0,(%rdx)
    0.00 :   cb5e3:  mov    %rax,0x120(%rsp)
    0.00 :   cb5eb:  mov    %rcx,0x138(%rsp)
    0.00 :   cb5f3:  lea    0x120(%rsp),%rdi
    0.00 :   cb5fb:  call   e4a00 <alloc::collections::btree::map::entry::OccupiedEntry<K,V,A>::remove_kv>
    0.00 :   cb600:  mov    %rax,%r15
    0.00 :   cb603:  mov    %edx,%r14d
    0.00 :   cb606:  jmp    cb610 <std::sys::backtrace::__rust_begin_short_backtrace+0x870>
    0.00 :   cb608:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb610:  cmpq   $0x0,0xc0(%r12)
    0.00 :   cb619:  setne  %al
    0.00 :   cb61c:  mov    %al,(%rbx)
    0.00 :   cb61e:  test   %bpl,%bpl
    0.00 :   cb621:  jne    cb640 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb623:  mov    0xc6f7e(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cb62a:  mov    (%rax),%rax
    0.00 :   cb62d:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb637:  test   %rcx,%rax
    0.00 :   cb63a:  jne    cb6ea <std::sys::backtrace::__rust_begin_short_backtrace+0x94a>
    0.00 :   cb640:  xor    %eax,%eax
    0.00 :   cb642:  xchg   %eax,0x0(%r13)
    0.00 :   cb646:  cmp    $0x2,%eax
    0.00 :   cb649:  je     cb6c4 <std::sys::backtrace::__rust_begin_short_backtrace+0x924>
    0.00 :   cb64b:  cmp    $0x6,%r14b
    0.00 :   cb64f:  je     cb720 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb655:  movzbl %r14b,%ecx
    0.00 :   cb659:  mov    $0x1,%esi
    0.00 :   cb65e:  mov    0x8(%rsp),%rbx
    0.00 :   cb663:  mov    %rbx,%rdi
    0.00 :   cb666:  mov    %r15,%rdx
    0.00 :   cb669:  call   113700 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cb66e:  mov    0x1a0(%rbx),%r12
    0.00 :   cb675:  lea    0xec(%r12),%rbx
    0.00 :   cb67d:  movzbl 0xec(%r12),%eax
    0.00 :   cb686:  test   %al,%al
    0.00 :   cb688:  jne    cb500 <std::sys::backtrace::__rust_begin_short_backtrace+0x760>
    0.00 :   cb68e:  jmp    cb720 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb693:  mov    %rcx,%rdx
    0.00 :   cb696:  cmp    $0x8,%rcx
    0.00 :   cb69a:  jae    cb5a0 <std::sys::backtrace::__rust_begin_short_backtrace+0x800>
    0.00 :   cb6a0:  jmp    cb5c6 <std::sys::backtrace::__rust_begin_short_backtrace+0x826>
    0.00 :   cb6a5:  mov    %r13,%rdi
    0.00 :   cb6a8:  call   *0xc6f72(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cb6ae:  jmp    cb51f <std::sys::backtrace::__rust_begin_short_backtrace+0x77f>
    0.00 :   cb6b3:  call   *0xc6f0f(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cb6b9:  mov    %eax,%ebp
    0.00 :   cb6bb:  xor    $0x1,%bpl
    0.00 :   cb6bf:  jmp    cb53e <std::sys::backtrace::__rust_begin_short_backtrace+0x79e>
    0.00 :   cb6c4:  mov    $0xca,%edi
    0.00 :   cb6c9:  mov    %r13,%rsi
    0.00 :   cb6cc:  mov    $0x81,%edx
    0.00 :   cb6d1:  mov    $0x1,%ecx
    0.00 :   cb6d6:  xor    %eax,%eax
    0.00 :   cb6d8:  call   *0xc6efa(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cb6de:  cmp    $0x6,%r14b
    0.00 :   cb6e2:  jne    cb655 <std::sys::backtrace::__rust_begin_short_backtrace+0x8b5>
    0.00 :   cb6e8:  jmp    cb720 <std::sys::backtrace::__rust_begin_short_backtrace+0x980>
    0.00 :   cb6ea:  call   *0xc6ed8(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cb6f0:  test   %al,%al
    0.00 :   cb6f2:  jne    cb640 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb6f8:  movb   $0x1,0x8c(%r12)
    0.00 :   cb701:  jmp    cb640 <std::sys::backtrace::__rust_begin_short_backtrace+0x8a0>
    0.00 :   cb706:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb710:  cmpb   $0x0,0x27c(%rdi)
    0.00 :   cb717:  je     cb740 <std::sys::backtrace::__rust_begin_short_backtrace+0x9a0>
    0.00 :   cb719:  call   1159d0 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive>
    0.00 :   cb71e:  jmp    cb790 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb720:  mov    0x8(%rsp),%rdi
    0.00 :   cb725:  call   1159d0 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive>
    0.00 :   cb72a:  mov    0x38(%rsp),%r15
    0.00 :   cb72f:  movzbl 0x14(%rsp),%ebx
    0.00 :   cb734:  jmp    cb790 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb736:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb740:  call   115410 <vthread::kernel::kernel_receive::<impl vthread::kernel::Kernel>::receive_local_tasks>
    0.00 :   cb745:  test   %al,%al
    0.00 :   cb747:  je     cb790 <std::sys::backtrace::__rust_begin_short_backtrace+0x9f0>
    0.00 :   cb749:  mov    0x8(%rsp),%rsi
    0.00 :   cb74e:  movb   $0x0,0x27e(%rsi)
    0.00 :   cb755:  mov    0x198(%rsi),%r14
    0.00 :   cb75c:  lea    0x120(%rsp),%rdi
    0.00 :   cb764:  mov    $0x1,%edx
    0.00 :   cb769:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cb76e:  add    $0x10,%r14
    0.00 :   cb772:  mov    %r14,%rdi
    0.00 :   cb775:  lea    0x120(%rsp),%rsi
    0.00 :   cb77d:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cb782:  data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cb790:  movzbl %bl,%edx
   35.15 :   cb793:  and    $0x1,%edx
    0.00 :   cb796:  lea    0x120(%rsp),%rdi
    0.00 :   cb79e:  mov    0x8(%rsp),%rsi
    0.00 :   cb7a3:  call   10df50 <vthread::kernel::kernel_drive::<impl vthread::kernel::Kernel>::tick>
    0.00 :   cb7a8:  mov    0x120(%rsp),%rax
   31.87 :   cb7b0:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cb7ba:  add    $0x23,%rcx
    0.00 :   cb7be:  cmp    %rcx,%rax
    0.00 :   cb7c1:  jne    cbe00 <std::sys::backtrace::__rust_begin_short_backtrace+0x1060>
    0.00 :   cb7c7:  xor    %eax,%eax
    0.00 :   cb7c9:  cmpb   $0x0,0x128(%rsp)
    0.00 :   cb7d1:  mov    0x8(%rsp),%rdi
    0.00 :   cb7d6:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb7dc:  cmpq   $0x0,0x60(%rdi)
    0.00 :   cb7e1:  je     cb83d <std::sys::backtrace::__rust_begin_short_backtrace+0xa9d>
    0.00 :   cb7e3:  mov    0x1c8(%rdi),%rdx
    0.00 :   cb7ea:  test   %rdx,%rdx
    0.00 :   cb7ed:  je     cc26d <std::sys::backtrace::__rust_begin_short_backtrace+0x14cd>
    0.00 :   cb7f3:  mov    0x198(%rdi),%rdi
    0.00 :   cb7fa:  add    $0x10,%rdi
    0.00 :   cb7fe:  add    $0x40,%rdx
    0.00 :   cb802:  mov    0x90(%rsp),%rsi
    0.00 :   cb80a:  call   120f60 <vthread::control::control_completion::<impl vthread::control::Shared>::publish_completions>
    0.00 :   cb80f:  mov    0x90(%rsp),%rax
    0.00 :   cb817:  movq   $0x18,(%rax)
    0.00 :   cb81e:  mov    0xb8(%rsp),%rax
    0.00 :   cb826:  xorps  %xmm0,%xmm0
    0.00 :   cb829:  movups %xmm0,0x10(%rax)
    0.00 :   cb82d:  movups %xmm0,(%rax)
    0.00 :   cb830:  movq   $0x0,0x20(%rax)
    0.00 :   cb838:  mov    0x8(%rsp),%rdi
    0.00 :   cb83d:  mov    0x1d0(%rdi),%rax
    0.00 :   cb844:  test   %rax,%rax
    0.00 :   cb847:  je     cb470 <std::sys::backtrace::__rust_begin_short_backtrace+0x6d0>
    0.00 :   cb84d:  mov    0x1d8(%rdi),%rcx
    0.00 :   cb854:  test   %rcx,%rcx
    0.00 :   cb857:  je     cb8ce <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb859:  mov    %rcx,%rdx
    0.00 :   cb85c:  and    $0x7,%rdx
    0.00 :   cb860:  je     cba6e <std::sys::backtrace::__rust_begin_short_backtrace+0xcce>
    0.00 :   cb866:  xor    %esi,%esi
    0.00 :   cb868:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb870:  mov    0x170(%rax),%rax
    0.00 :   cb877:  inc    %rsi
    0.00 :   cb87a:  cmp    %rsi,%rdx
    0.00 :   cb87d:  jne    cb870 <std::sys::backtrace::__rust_begin_short_backtrace+0xad0>
    0.00 :   cb87f:  mov    %rcx,%rdx
    0.00 :   cb882:  sub    %rsi,%rdx
    0.00 :   cb885:  cmp    $0x8,%rcx
    0.00 :   cb889:  jb     cb8ce <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cb88b:  nopl   0x0(%rax,%rax,1)
    0.00 :   cb890:  mov    0x170(%rax),%rax
    0.00 :   cb897:  mov    0x170(%rax),%rax
    0.00 :   cb89e:  mov    0x170(%rax),%rax
    0.00 :   cb8a5:  mov    0x170(%rax),%rax
    0.00 :   cb8ac:  mov    0x170(%rax),%rax
    0.00 :   cb8b3:  mov    0x170(%rax),%rax
    0.00 :   cb8ba:  mov    0x170(%rax),%rax
    0.00 :   cb8c1:  mov    0x170(%rax),%rax
    0.00 :   cb8c8:  add    $0xfffffffffffffff8,%rdx
    0.00 :   cb8cc:  jne    cb890 <std::sys::backtrace::__rust_begin_short_backtrace+0xaf0>
    0.00 :   cb8ce:  cmpw   $0x0,0x16a(%rax)
    0.00 :   cb8d6:  mov    0x8(%rsp),%rdi
    0.00 :   cb8db:  je     cb470 <std::sys::backtrace::__rust_begin_short_backtrace+0x6d0>
    0.00 :   cb8e1:  mov    (%rax),%r13
    0.00 :   cb8e4:  mov    0x8(%rax),%ebp
    0.00 :   cb8e7:  incq   0x250(%rdi)
    0.00 :   cb8ee:  mov    0x1a0(%rdi),%rax
    0.00 :   cb8f5:  mov    0xd0(%rax),%rax
    0.00 :   cb8fc:  test   %rax,%rax
    0.00 :   cb8ff:  jne    cb487 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e7>
    0.00 :   cb905:  mov    0x1a8(%rdi),%rcx
    0.00 :   cb90c:  xor    %eax,%eax
    0.00 :   cb90e:  cmpq   $0x0,0xc8(%rcx)
    0.00 :   cb916:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb91c:  mov    0x1a0(%rdi),%rax
    0.00 :   cb923:  mov    0xe0(%rax),%rcx
    0.00 :   cb92a:  mov    0x80(%rcx),%rdx
    0.00 :   cb931:  xor    %eax,%eax
    0.00 :   cb933:  test   %rdx,%rdx
    0.00 :   cb936:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb93c:  mov    0x40(%rcx),%rcx
    0.00 :   cb940:  xor    %eax,%eax
    0.00 :   cb942:  mov    $0x0,%r12d
    0.00 :   cb948:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb952:  test   %rdx,%rcx
    0.00 :   cb955:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb95b:  jmp    cba85 <std::sys::backtrace::__rust_begin_short_backtrace+0xce5>
    0.00 :   cb960:  mov    0x1a8(%rdi),%rcx
    0.00 :   cb967:  xor    %eax,%eax
    0.00 :   cb969:  cmpq   $0x0,0xc8(%rcx)
    0.00 :   cb971:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb977:  mov    0x1a0(%rdi),%rax
    0.00 :   cb97e:  mov    0xe0(%rax),%rcx
    0.00 :   cb985:  mov    0x80(%rcx),%rdx
    0.00 :   cb98c:  xor    %eax,%eax
    0.00 :   cb98e:  test   %rdx,%rdx
    0.00 :   cb991:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb997:  mov    0x40(%rcx),%rcx
    0.00 :   cb99b:  xor    %eax,%eax
    0.00 :   cb99d:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cb9a7:  test   %rdx,%rcx
    0.00 :   cb9aa:  jne    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cb9b0:  mov    0x198(%rdi),%rax
    0.00 :   cb9b7:  mov    $0x3b9aca00,%ebp
    0.00 :   cb9bc:  mov    $0x1,%r12b
    0.00 :   cb9bf:  cmpq   $0x2,0x60(%rax)
    0.00 :   cb9c4:  jb     cba80 <std::sys::backtrace::__rust_begin_short_backtrace+0xce0>
    0.00 :   cb9ca:  mov    $0x281,%ecx
    0.00 :   cb9cf:  dec    %rcx
    0.00 :   cb9d2:  je     cba80 <std::sys::backtrace::__rust_begin_short_backtrace+0xce0>
    0.00 :   cb9d8:  pause
    0.00 :   cb9da:  mov    0x8(%rsp),%rdi
    0.00 :   cb9df:  mov    0x1a0(%rdi),%rax
    0.00 :   cb9e6:  mov    0xd0(%rax),%rax
    0.00 :   cb9ed:  test   %rax,%rax
    0.00 :   cb9f0:  jne    cb487 <std::sys::backtrace::__rust_begin_short_backtrace+0x6e7>
    0.00 :   cb9f6:  mov    0x1a8(%rdi),%rax
    0.00 :   cb9fd:  cmpq   $0x0,0xc8(%rax)
    0.00 :   cba05:  jne    cbda4 <std::sys::backtrace::__rust_begin_short_backtrace+0x1004>
    0.00 :   cba0b:  mov    0x1a0(%rdi),%rax
    0.00 :   cba12:  mov    0xe0(%rax),%rax
    0.00 :   cba19:  mov    0x80(%rax),%rdx
    0.00 :   cba20:  test   %rdx,%rdx
    0.00 :   cba23:  jne    cbd98 <std::sys::backtrace::__rust_begin_short_backtrace+0xff8>
    0.00 :   cba29:  mov    0x40(%rax),%rax
    0.00 :   cba2d:  movabs $0x7fffffffffffffff,%rdx
    0.00 :   cba37:  test   %rdx,%rax
    0.00 :   cba3a:  jne    cbd98 <std::sys::backtrace::__rust_begin_short_backtrace+0xff8>
    0.00 :   cba40:  mov    0x8(%rsp),%rax
    0.00 :   cba45:  mov    0x1a0(%rax),%rax
    0.00 :   cba4c:  mov    0xd8(%rax),%rax
    0.00 :   cba53:  mov    0x10(%rax),%rdx
    0.00 :   cba57:  xor    %eax,%eax
    0.00 :   cba59:  cmp    0x38(%rsp),%rdx
    0.00 :   cba5e:  je     cb9cf <std::sys::backtrace::__rust_begin_short_backtrace+0xc2f>
    0.00 :   cba64:  mov    0x8(%rsp),%rdi
    0.00 :   cba69:  jmp    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cba6e:  mov    %rcx,%rdx
    0.00 :   cba71:  cmp    $0x8,%rcx
    0.00 :   cba75:  jae    cb890 <std::sys::backtrace::__rust_begin_short_backtrace+0xaf0>
    0.00 :   cba7b:  jmp    cb8ce <std::sys::backtrace::__rust_begin_short_backtrace+0xb2e>
    0.00 :   cba80:  mov    0x8(%rsp),%rdi
    0.00 :   cba85:  movb   $0x0,0x27e(%rdi)
    0.00 :   cba8c:  mov    0x198(%rdi),%r14
    0.00 :   cba93:  mov    %rdi,%rsi
    0.00 :   cba96:  lea    0x120(%rsp),%rdi
    0.00 :   cba9e:  xor    %edx,%edx
    0.00 :   cbaa0:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbaa5:  add    $0x10,%r14
    0.00 :   cbaa9:  mov    %r14,%rdi
    0.00 :   cbaac:  lea    0x120(%rsp),%rsi
    0.00 :   cbab4:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cbab9:  mov    0x8(%rsp),%rax
    0.00 :   cbabe:  mov    0x1a0(%rax),%rax
    0.00 :   cbac5:  mov    0xe0(%rax),%rbx
    0.00 :   cbacc:  mov    0x110(%rbx),%r14
    0.00 :   cbad3:  lea    0x20(%r14),%rax
    0.00 :   cbad7:  mov    %rax,0x50(%rsp)
    0.00 :   cbadc:  xor    %eax,%eax
    0.00 :   cbade:  mov    $0x1,%ecx
    0.00 :   cbae3:  lock cmpxchg %ecx,0x20(%r14)
    0.00 :   cbae9:  jne    cbdab <std::sys::backtrace::__rust_begin_short_backtrace+0x100b>
    0.00 :   cbaef:  mov    0xc6ab2(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cbaf6:  mov    (%rax),%rax
    0.00 :   cbaf9:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbb03:  test   %rcx,%rax
    0.00 :   cbb06:  jne    cbdba <std::sys::backtrace::__rust_begin_short_backtrace+0x101a>
    0.00 :   cbb0c:  movl   $0x0,0x14(%rsp)
    0.00 :   cbb14:  movzbl 0x24(%r14),%eax
    0.00 :   cbb19:  lock incq 0x18(%r14)
    0.00 :   cbb1e:  mov    0x10(%r14),%rax
    0.00 :   cbb22:  cmp    0x38(%rsp),%rax
    0.00 :   cbb27:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbb2d:  test   %r12b,%r12b
    0.00 :   cbb30:  je     cbc6d <std::sys::backtrace::__rust_begin_short_backtrace+0xecd>
    0.00 :   cbb36:  mov    0x80(%rbx),%rax
    0.00 :   cbb3d:  test   %rax,%rax
    0.00 :   cbb40:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbb46:  mov    0x40(%rbx),%rax
    0.00 :   cbb4a:  nopw   0x0(%rax,%rax,1)
    0.00 :   cbb50:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbb5a:  test   %rcx,%rax
    0.00 :   cbb5d:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbb63:  test   %rax,%rax
    0.00 :   cbb66:  jne    cbb7c <std::sys::backtrace::__rust_begin_short_backtrace+0xddc>
    0.00 :   cbb68:  xor    %eax,%eax
    0.00 :   cbb6a:  movabs $0x8000000000000000,%rcx
    0.00 :   cbb74:  lock cmpxchg %rcx,0x40(%rbx)
    0.00 :   cbb7a:  jne    cbb50 <std::sys::backtrace::__rust_begin_short_backtrace+0xdb0>
    0.00 :   cbb7c:  lea    0x28(%r14),%rax
    0.00 :   cbb80:  mov    (%rax),%ebp
    0.00 :   cbb82:  xor    %eax,%eax
    0.00 :   cbb84:  lea    0x20(%r14),%r13
    0.00 :   cbb88:  xchg   %eax,0x0(%r13)
    0.00 :   cbb8c:  cmp    $0x2,%eax
    0.00 :   cbb8f:  je     cbc2b <std::sys::backtrace::__rust_begin_short_backtrace+0xe8b>
    0.00 :   cbb95:  movq   $0x0,0x120(%rsp)
    0.00 :   cbba1:  mov    0xc6ad0(%rip),%r12        # 192678 <__errno_location@GLIBC_2.2.5>
    0.00 :   cbba8:  nopl   0x0(%rax,%rax,1)
    0.00 :   cbbb0:  lea    0x28(%r14),%rax
    0.00 :   cbbb4:  mov    (%rax),%eax
    0.00 :   cbbb6:  cmp    %ebp,%eax
    0.00 :   cbbb8:  jne    cbc03 <std::sys::backtrace::__rust_begin_short_backtrace+0xe63>
    0.00 :   cbbba:  cmpb   $0x0,0x120(%rsp)
    0.00 :   cbbc2:  mov    $0x0,%r8d
    0.00 :   cbbc8:  lea    0x128(%rsp),%rax
    0.00 :   cbbd0:  cmovne %rax,%r8
    0.00 :   cbbd4:  movl   $0xffffffff,(%rsp)
    0.00 :   cbbdb:  mov    $0xca,%edi
    0.00 :   cbbe0:  lea    0x28(%r14),%rsi
    0.00 :   cbbe4:  mov    $0x89,%edx
    0.00 :   cbbe9:  mov    %ebp,%ecx
    0.00 :   cbbeb:  xor    %r9d,%r9d
    0.00 :   cbbee:  xor    %eax,%eax
    0.00 :   cbbf0:  call   *0xc69e2(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cbbf6:  test   %rax,%rax
    0.00 :   cbbf9:  jns    cbc03 <std::sys::backtrace::__rust_begin_short_backtrace+0xe63>
    0.00 :   cbbfb:  call   *%r12
    0.00 :   cbbfe:  cmpl   $0x4,(%rax)
    0.00 :   cbc01:  je     cbbb0 <std::sys::backtrace::__rust_begin_short_backtrace+0xe10>
    0.00 :   cbc03:  xor    %eax,%eax
    0.00 :   cbc05:  mov    $0x1,%ecx
    0.00 :   cbc0a:  lock cmpxchg %ecx,0x0(%r13)
    0.00 :   cbc10:  jne    cbc4a <std::sys::backtrace::__rust_begin_short_backtrace+0xeaa>
    0.00 :   cbc12:  movzbl 0x24(%r14),%eax
    0.00 :   cbc17:  mov    0x10(%r14),%rax
    0.00 :   cbc1b:  cmp    0x38(%rsp),%rax
    0.00 :   cbc20:  je     cbb36 <std::sys::backtrace::__rust_begin_short_backtrace+0xd96>
    0.00 :   cbc26:  jmp    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbc2b:  mov    $0xca,%edi
    0.00 :   cbc30:  mov    %r13,%rsi
    0.00 :   cbc33:  mov    $0x81,%edx
    0.00 :   cbc38:  mov    $0x1,%ecx
    0.00 :   cbc3d:  xor    %eax,%eax
    0.00 :   cbc3f:  call   *0xc6993(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cbc45:  jmp    cbb95 <std::sys::backtrace::__rust_begin_short_backtrace+0xdf5>
    0.00 :   cbc4a:  lea    0x20(%r14),%rdi
    0.00 :   cbc4e:  call   *0xc69cc(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cbc54:  movzbl 0x24(%r14),%eax
    0.00 :   cbc59:  mov    0x10(%r14),%rax
    0.00 :   cbc5d:  cmp    0x38(%rsp),%rax
    0.00 :   cbc62:  je     cbb36 <std::sys::backtrace::__rust_begin_short_backtrace+0xd96>
    0.00 :   cbc68:  jmp    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbc6d:  mov    0x80(%rbx),%rax
    0.00 :   cbc74:  test   %rax,%rax
    0.00 :   cbc77:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbc7d:  mov    0x40(%rbx),%rax
    0.00 :   cbc81:  data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    0.00 :   cbc90:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbc9a:  test   %rcx,%rax
    0.00 :   cbc9d:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbca3:  test   %rax,%rax
    0.00 :   cbca6:  jne    cbcbc <std::sys::backtrace::__rust_begin_short_backtrace+0xf1c>
    0.00 :   cbca8:  xor    %eax,%eax
    0.00 :   cbcaa:  movabs $0x8000000000000000,%rcx
    0.00 :   cbcb4:  lock cmpxchg %rcx,0x40(%rbx)
    0.00 :   cbcba:  jne    cbc90 <std::sys::backtrace::__rust_begin_short_backtrace+0xef0>
    0.00 :   cbcbc:  mov    %r13,0xa0(%rsp)
    0.00 :   cbcc4:  mov    %ebp,0xa8(%rsp)
    0.00 :   cbccb:  mov    $0x1,%edi
    0.00 :   cbcd0:  call   a17e0 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.13342753452097612697>
    0.00 :   cbcd5:  mov    %rax,0x100(%rsp)
    0.00 :   cbcdd:  mov    %edx,0x108(%rsp)
    0.00 :   cbce4:  lea    0x120(%rsp),%rdi
    0.00 :   cbcec:  lea    0xa0(%rsp),%rsi
    0.00 :   cbcf4:  lea    0x100(%rsp),%rdx
    0.00 :   cbcfc:  call   a1710 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec.llvm.13342753452097612697>
    0.00 :   cbd01:  cmpb   $0x0,0x120(%rsp)
    0.00 :   cbd09:  mov    0x130(%rsp),%ecx
    0.00 :   cbd10:  mov    $0x0,%eax
    0.00 :   cbd15:  cmovne %eax,%ecx
    0.00 :   cbd18:  mov    0x128(%rsp),%rdx
    0.00 :   cbd20:  cmovne %rax,%rdx
    0.00 :   cbd24:  test   %rdx,%rdx
    0.00 :   cbd27:  sete   %al
    0.00 :   cbd2a:  test   %ecx,%ecx
    0.00 :   cbd2c:  sete   %sil
    0.00 :   cbd30:  test   %sil,%al
    0.00 :   cbd33:  jne    cbd56 <std::sys::backtrace::__rust_begin_short_backtrace+0xfb6>
    0.00 :   cbd35:  lea    0x28(%r14),%rdi
    0.00 :   cbd39:  lea    0x20(%r14),%rsi
    0.00 :   cbd3d:  call   a1d80 <_RNvMNtNtNtNtCs3JBboNF8E1m_3std3sys4sync7condvar5futexNtB2_7Condvar21wait_optional_timeout.llvm.13342753452097612697>
    0.00 :   cbd42:  movzbl 0x24(%r14),%eax
    0.00 :   cbd47:  mov    0x10(%r14),%rax
    0.00 :   cbd4b:  cmp    0x38(%rsp),%rax
    0.00 :   cbd50:  je     cbc6d <std::sys::backtrace::__rust_begin_short_backtrace+0xecd>
    0.00 :   cbd56:  lock decq 0x18(%r14)
    0.00 :   cbd5b:  cmpb   $0x0,0x14(%rsp)
    0.00 :   cbd60:  jne    cbd7b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cbd62:  mov    0xc683f(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cbd69:  mov    (%rax),%rax
    0.00 :   cbd6c:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbd76:  test   %rcx,%rax
    0.00 :   cbd79:  jne    cbdec <std::sys::backtrace::__rust_begin_short_backtrace+0x104c>
    0.00 :   cbd7b:  xor    %eax,%eax
    0.00 :   cbd7d:  mov    0x50(%rsp),%rsi
    0.00 :   cbd82:  xchg   %eax,(%rsi)
    0.00 :   cbd84:  cmp    $0x2,%eax
    0.00 :   cbd87:  je     cbdd3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1033>
    0.00 :   cbd89:  movabs $0x7fffffffffffffff,%rax
    0.00 :   cbd93:  lock and %rax,0x40(%rbx)
    0.00 :   cbd98:  xor    %eax,%eax
    0.00 :   cbd9a:  mov    0x8(%rsp),%rdi
    0.00 :   cbd9f:  jmp    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cbda4:  xor    %eax,%eax
    0.00 :   cbda6:  jmp    cb490 <std::sys::backtrace::__rust_begin_short_backtrace+0x6f0>
    0.00 :   cbdab:  lea    0x20(%r14),%rdi
    0.00 :   cbdaf:  call   *0xc686b(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cbdb5:  jmp    cbaef <std::sys::backtrace::__rust_begin_short_backtrace+0xd4f>
    0.00 :   cbdba:  call   *0xc6808(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cbdc0:  mov    %eax,0x14(%rsp)
    0.00 :   cbdc4:  mov    0x14(%rsp),%eax
    0.00 :   cbdc8:  xor    $0x1,%al
    0.00 :   cbdca:  mov    %eax,0x14(%rsp)
    0.00 :   cbdce:  jmp    cbb14 <std::sys::backtrace::__rust_begin_short_backtrace+0xd74>
    0.00 :   cbdd3:  mov    $0xca,%edi
    0.00 :   cbdd8:  mov    $0x81,%edx
    0.00 :   cbddd:  mov    $0x1,%ecx
    0.00 :   cbde2:  xor    %eax,%eax
    0.00 :   cbde4:  call   *0xc67ee(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cbdea:  jmp    cbd89 <std::sys::backtrace::__rust_begin_short_backtrace+0xfe9>
    0.00 :   cbdec:  call   *0xc67d6(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cbdf2:  test   %al,%al
    0.00 :   cbdf4:  jne    cbd7b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cbdf6:  movb   $0x1,0x24(%r14)
    0.00 :   cbdfb:  jmp    cbd7b <std::sys::backtrace::__rust_begin_short_backtrace+0xfdb>
    0.00 :   cbe00:  movups 0x128(%rsp),%xmm0
    0.00 :   cbe08:  movups 0x138(%rsp),%xmm1
    0.00 :   cbe10:  movups 0x148(%rsp),%xmm2
    0.00 :   cbe18:  mov    0x158(%rsp),%rcx
    0.00 :   cbe20:  mov    %rcx,0x3e0(%rsp)
    0.00 :   cbe28:  movups %xmm2,0x3d0(%rsp)
    0.00 :   cbe30:  movups %xmm1,0x3c0(%rsp)
    0.00 :   cbe38:  mov    %rax,0x3a8(%rsp)
    0.00 :   cbe40:  movups %xmm0,0x3b0(%rsp)
    0.00 :   cbe48:  movq   $0x0,0x58(%rsp)
    0.00 :   cbe51:  movq   $0x1,0x60(%rsp)
    0.00 :   cbe5a:  movq   $0x0,0x68(%rsp)
    0.00 :   cbe63:  movq   $0x60000020,0x130(%rsp)
    0.00 :   cbe6f:  lea    0x58(%rsp),%rax
    0.00 :   cbe74:  mov    %rax,0x120(%rsp)
    0.00 :   cbe7c:  lea    0xc1965(%rip),%rax        # 18d7e8 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0xe8>
    0.00 :   cbe83:  mov    %rax,0x128(%rsp)
    0.00 :   cbe8b:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbe93:  lea    0x120(%rsp),%rsi
    0.00 :   cbe9b:  call   *0xc738f(%rip)        # 193230 <_DYNAMIC+0x1218>
    0.00 :   cbea1:  test   %al,%al
    0.00 :   cbea3:  jne    cc323 <std::sys::backtrace::__rust_begin_short_backtrace+0x1583>
    0.00 :   cbea9:  mov    0x58(%rsp),%rbx
    0.00 :   cbeae:  mov    0x60(%rsp),%r15
    0.00 :   cbeb3:  mov    0x68(%rsp),%r14
    0.00 :   cbeb8:  mov    $0x18,%edi
    0.00 :   cbebd:  call   *0xc639d(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cbec3:  test   %rax,%rax
    0.00 :   cbec6:  je     cc34d <std::sys::backtrace::__rust_begin_short_backtrace+0x15ad>
    0.00 :   cbecc:  mov    %rbx,(%rax)
    0.00 :   cbecf:  mov    %r15,0x8(%rax)
    0.00 :   cbed3:  mov    %r14,0x10(%rax)
    0.00 :   cbed7:  lea    0xc3082(%rip),%rdx        # 18ef60 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x4c8>
    0.00 :   cbede:  lea    0x58(%rsp),%rdi
    0.00 :   cbee3:  mov    %rax,%rsi
    0.00 :   cbee6:  mov    0x18(%rsp),%r12
    0.00 :   cbeeb:  mov    0x20(%rsp),%r13
    0.00 :   cbef0:  call   *0xc727a(%rip)        # 193170 <_DYNAMIC+0x1158>
    0.00 :   cbef6:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbefe:  call   d7ad0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10657235172099788962>
    0.00 :   cbf03:  lea    0x58(%rsp),%rsi
    0.00 :   cbf08:  mov    %r13,%rdi
    0.00 :   cbf0b:  call   118580 <vthread::carrier::record_failure>
    0.00 :   cbf10:  mov    0x8(%rsp),%rax
    0.00 :   cbf15:  mov    0x1a0(%rax),%rbx
    0.00 :   cbf1c:  lea    0x88(%rbx),%r14
    0.00 :   cbf23:  mov    $0x1,%ecx
    0.00 :   cbf28:  xor    %eax,%eax
    0.00 :   cbf2a:  lock cmpxchg %ecx,0x88(%rbx)
    0.00 :   cbf32:  jne    cc2b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1517>
    0.00 :   cbf38:  mov    0xc6669(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cbf3f:  mov    (%rax),%rax
    0.00 :   cbf42:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbf4c:  test   %rcx,%rax
    0.00 :   cbf4f:  jne    cc2c5 <std::sys::backtrace::__rust_begin_short_backtrace+0x1525>
    0.00 :   cbf55:  lea    0x8c(%rbx),%r15
    0.00 :   cbf5c:  movzbl 0x8c(%rbx),%eax
    0.00 :   cbf63:  movb   $0x1,0xc8(%rbx)
    0.00 :   cbf6a:  mov    0xc6637(%rip),%rax        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cbf71:  mov    (%rax),%rax
    0.00 :   cbf74:  movabs $0x7fffffffffffffff,%rcx
    0.00 :   cbf7e:  test   %rcx,%rax
    0.00 :   cbf81:  jne    cc30c <std::sys::backtrace::__rust_begin_short_backtrace+0x156c>
    0.00 :   cbf87:  xor    %eax,%eax
    0.00 :   cbf89:  xchg   %eax,(%r14)
    0.00 :   cbf8c:  cmp    $0x2,%eax
    0.00 :   cbf8f:  je     cc2ed <std::sys::backtrace::__rust_begin_short_backtrace+0x154d>
    0.00 :   cbf95:  movb   $0x1,0xeb(%rbx)
    0.00 :   cbf9c:  mov    0xd8(%rbx),%rdi
    0.00 :   cbfa3:  add    $0x10,%rdi
    0.00 :   cbfa7:  call   118460 <_ZN7vthread6signal6Signal6notify17ha0494737ef19d1a9E.llvm.10657235172099788962>
    0.00 :   cbfac:  mov    0x8(%rsp),%rdi
    0.00 :   cbfb1:  xor    %esi,%esi
    0.00 :   cbfb3:  mov    $0x4,%ecx
    0.00 :   cbfb8:  call   113700 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cbfbd:  lea    0x3a8(%rsp),%rdi
    0.00 :   cbfc5:  mov    0x8(%rsp),%rsi
    0.00 :   cbfca:  mov    $0x3,%edx
    0.00 :   cbfcf:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cbfd4:  movq   $0x0,0x450(%rsp)
    0.00 :   cbfe0:  mov    0x8(%rsp),%rax
    0.00 :   cbfe5:  mov    0x198(%rax),%rdi
    0.00 :   cbfec:  add    $0x10,%rdi
    0.00 :   cbff0:  lea    0x3a8(%rsp),%rsi
    0.00 :   cbff8:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cbffd:  jmp    cc056 <std::sys::backtrace::__rust_begin_short_backtrace+0x12b6>
    0.00 :   cbfff:  mov    %rdi,%rbx
    0.00 :   cc002:  xor    %esi,%esi
    0.00 :   cc004:  mov    $0x3,%ecx
    0.00 :   cc009:  mov    0x20(%rsp),%r13
    0.00 :   cc00e:  call   113700 <vthread::kernel::kernel_cleanup::<impl vthread::kernel::Kernel>::abort>
    0.00 :   cc013:  lea    0x120(%rsp),%rdi
    0.00 :   cc01b:  mov    %rbx,%rsi
    0.00 :   cc01e:  mov    $0x2,%edx
    0.00 :   cc023:  mov    0x18(%rsp),%r12
    0.00 :   cc028:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cc02d:  movq   $0x0,0x1c8(%rsp)
    0.00 :   cc039:  mov    0x8(%rsp),%rax
    0.00 :   cc03e:  mov    0x198(%rax),%rdi
    0.00 :   cc045:  add    $0x10,%rdi
    0.00 :   cc049:  lea    0x120(%rsp),%rsi
    0.00 :   cc051:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cc056:  mov    0xa0(%r12),%rsi
    0.00 :   cc05e:  mov    0x28(%rsp),%rcx
    0.00 :   cc063:  cmp    %rsi,%rcx
    0.00 :   cc066:  jae    cc3c0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1620>
    0.00 :   cc06c:  mov    0x98(%r12),%rax
    0.00 :   cc074:  mov    (%rax,%rcx,8),%rax
    0.00 :   cc078:  movb   $0x1,0xe9(%rax)
    0.00 :   cc07f:  mov    0x8(%rsp),%rcx
    0.00 :   cc084:  cmpl   $0x2,(%rcx)
    0.00 :   cc087:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc08d:  cmpq   $0x0,0x178(%rcx)
    0.00 :   cc095:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc09b:  cmpq   $0x0,0x1b8(%rcx)
    0.00 :   cc0a3:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0a9:  cmpq   $0x0,0xf8(%rcx)
    0.00 :   cc0b1:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0b7:  cmpq   $0x0,0x118(%rcx)
    0.00 :   cc0bf:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0c5:  cmpq   $0x0,0x158(%rcx)
    0.00 :   cc0cd:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0d3:  mov    0x90(%rcx),%rax
    0.00 :   cc0da:  cmp    0xa8(%rcx),%rax
    0.00 :   cc0e1:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0e7:  mov    0xc0(%rcx),%rax
    0.00 :   cc0ee:  cmp    0xd8(%rcx),%rax
    0.00 :   cc0f5:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0f7:  cmpq   $0x0,0x60(%rcx)
    0.00 :   cc0fc:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc0fe:  mov    0x198(%rcx),%rax
    0.00 :   cc105:  mov    0x1b0(%rcx),%rdi
    0.00 :   cc10c:  mov    0x88(%rax),%rsi
    0.00 :   cc113:  cmp    %rsi,%rdi
    0.00 :   cc116:  jae    cc3d7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1637>
    0.00 :   cc11c:  mov    0x80(%rax),%rax
    0.00 :   cc123:  shl    $0x6,%rdi
    0.00 :   cc127:  mov    (%rax,%rdi,1),%rax
    0.00 :   cc12b:  test   %rax,%rax
    0.00 :   cc12e:  mov    0x8(%rsp),%rdi
    0.00 :   cc133:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc135:  mov    0x1a8(%rdi),%rax
    0.00 :   cc13c:  cmpq   $0x0,0x98(%rax)
    0.00 :   cc144:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc146:  cmpq   $0x0,0xc8(%rax)
    0.00 :   cc14e:  jne    cc167 <std::sys::backtrace::__rust_begin_short_backtrace+0x13c7>
    0.00 :   cc150:  mov    0x1a0(%rdi),%rax
    0.00 :   cc157:  mov    0xd0(%rax),%rax
    0.00 :   cc15e:  test   %rax,%rax
    0.00 :   cc161:  je     cc36c <std::sys::backtrace::__rust_begin_short_backtrace+0x15cc>
    0.00 :   cc167:  mov    $0x10,%edi
    0.00 :   cc16c:  call   *0xc60ee(%rip)        # 192260 <malloc@GLIBC_2.2.5>
    0.00 :   cc172:  test   %rax,%rax
    0.00 :   cc175:  je     cc2a2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1502>
    0.00 :   cc17b:  lea    -0xad66d(%rip),%rcx        # 1eb15 <anon.de2471ab41e489a293ba001b839d8fc3.749.llvm.10657235172099788962+0x321>
    0.00 :   cc182:  mov    %rcx,(%rax)
    0.00 :   cc185:  movq   $0x1a,0x8(%rax)
    0.00 :   cc18d:  lea    0xc2734(%rip),%rdx        # 18e8c8 <anon.de2471ab41e489a293ba001b839d8fc3.433.llvm.10657235172099788962+0x858>
    0.00 :   cc194:  lea    0xe0(%rsp),%rdi
    0.00 :   cc19c:  mov    %rax,%rsi
    0.00 :   cc19f:  call   *0xc6fcb(%rip)        # 193170 <_DYNAMIC+0x1158>
    0.00 :   cc1a5:  lea    0xe0(%rsp),%rsi
    0.00 :   cc1ad:  mov    %r13,%rdi
    0.00 :   cc1b0:  call   118580 <vthread::carrier::record_failure>
    0.00 :   cc1b5:  mov    0x8(%rsp),%rsi
    0.00 :   cc1ba:  movb   $0x0,0x27e(%rsi)
    0.00 :   cc1c1:  mov    0x198(%rsi),%r14
    0.00 :   cc1c8:  lea    0x480(%rsp),%rdi
    0.00 :   cc1d0:  mov    $0x3,%edx
    0.00 :   cc1d5:  call   117ea0 <vthread::kernel::Kernel::snapshot>
    0.00 :   cc1da:  add    $0x10,%r14
    0.00 :   cc1de:  lea    0x480(%rsp),%rsi
    0.00 :   cc1e6:  mov    %r14,%rdi
    0.00 :   cc1e9:  call   121ed0 <vthread::control::Shared::publish>
    0.00 :   cc1ee:  mov    %r13,%rdi
    0.00 :   cc1f1:  call   1214f0 <_ZN7vthread7control6Shared12request_stop17hb40bf47e89bed244E.llvm.10657235172099788962>
    0.00 :   cc1f6:  lea    0x40(%rsp),%rdi
    0.00 :   cc1fb:  call   *0xc7037(%rip)        # 193238 <_DYNAMIC+0x1220>
    0.00 :   cc201:  mov    0x40(%rsp),%rax
    0.00 :   cc206:  test   %rax,%rax
    0.00 :   cc209:  je     cc231 <std::sys::backtrace::__rust_begin_short_backtrace+0x1491>
    0.00 :   cc20b:  lock decq (%rax)
    0.00 :   cc20f:  jne    cc21c <std::sys::backtrace::__rust_begin_short_backtrace+0x147c>
    0.00 :   cc211:  lea    0x40(%rsp),%rdi
    0.00 :   cc216:  call   *0xc6f64(%rip)        # 193180 <_DYNAMIC+0x1168>
    0.00 :   cc21c:  mov    0x48(%rsp),%rax
    0.00 :   cc221:  decq   (%rax)
    0.00 :   cc224:  jne    cc231 <std::sys::backtrace::__rust_begin_short_backtrace+0x1491>
    0.00 :   cc226:  lea    0x48(%rsp),%rdi
    0.00 :   cc22b:  call   *0xc6f57(%rip)        # 193188 <_DYNAMIC+0x1170>
    0.00 :   cc231:  lock decq (%r12)
    0.00 :   cc236:  jne    cc246 <std::sys::backtrace::__rust_begin_short_backtrace+0x14a6>
    0.00 :   cc238:  lea    0x98(%rsp),%rdi
    0.00 :   cc240:  call   *0xc6fca(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc246:  lock decq (%r12)
    0.00 :   cc24b:  jne    cc25b <std::sys::backtrace::__rust_begin_short_backtrace+0x14bb>
    0.00 :   cc24d:  lea    0xc0(%rsp),%rdi
    0.00 :   cc255:  call   *0xc6fb5(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc25b:  add    $0x558,%rsp
    0.00 :   cc262:  pop    %rbx
    0.00 :   cc263:  pop    %r12
    0.00 :   cc265:  pop    %r13
    0.00 :   cc267:  pop    %r14
    0.00 :   cc269:  pop    %r15
    0.00 :   cc26b:  pop    %rbp
    0.00 :   cc26c:  ret
    0.00 :   cc26d:  lea    -0xad78c(%rip),%rdi        # 1eae8 <anon.de2471ab41e489a293ba001b839d8fc3.749.llvm.10657235172099788962+0x2f4>
    0.00 :   cc274:  lea    0xc2c0d(%rip),%rdx        # 18ee88 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x3f0>
    0.00 :   cc27b:  mov    $0x19,%esi
    0.00 :   cc280:  mov    0x20(%rsp),%r13
    0.00 :   cc285:  call   *0xc61b5(%rip)        # 192440 <_DYNAMIC+0x428>
    0.00 :   cc28b:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc290:  lea    0xc2d19(%rip),%rdi        # 18efb0 <anon.de2471ab41e489a293ba001b839d8fc3.857.llvm.10657235172099788962+0x30>
    0.00 :   cc297:  call   *0xc6183(%rip)        # 192420 <_DYNAMIC+0x408>
    0.00 :   cc29d:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc2a2:  mov    $0x8,%edi
    0.00 :   cc2a7:  mov    $0x10,%esi
    0.00 :   cc2ac:  call   *0xc5fd6(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   cc2b2:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc2b7:  mov    %r14,%rdi
    0.00 :   cc2ba:  call   *0xc6360(%rip)        # 192620 <_DYNAMIC+0x608>
    0.00 :   cc2c0:  jmp    cbf38 <std::sys::backtrace::__rust_begin_short_backtrace+0x1198>
    0.00 :   cc2c5:  call   *0xc62fd(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cc2cb:  movzbl 0x8c(%rbx),%ecx
    0.00 :   cc2d2:  movb   $0x1,0xc8(%rbx)
    0.00 :   cc2d9:  test   %al,%al
    0.00 :   cc2db:  je     cbf87 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cc2e1:  lea    0x8c(%rbx),%r15
    0.00 :   cc2e8:  jmp    cbf6a <std::sys::backtrace::__rust_begin_short_backtrace+0x11ca>
    0.00 :   cc2ed:  mov    $0xca,%edi
    0.00 :   cc2f2:  mov    %r14,%rsi
    0.00 :   cc2f5:  mov    $0x81,%edx
    0.00 :   cc2fa:  mov    $0x1,%ecx
    0.00 :   cc2ff:  xor    %eax,%eax
    0.00 :   cc301:  call   *0xc62d1(%rip)        # 1925d8 <syscall@GLIBC_2.2.5>
    0.00 :   cc307:  jmp    cbf95 <std::sys::backtrace::__rust_begin_short_backtrace+0x11f5>
    0.00 :   cc30c:  call   *0xc62b6(%rip)        # 1925c8 <_DYNAMIC+0x5b0>
    0.00 :   cc312:  test   %al,%al
    0.00 :   cc314:  jne    cbf87 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cc31a:  movb   $0x1,(%r15)
    0.00 :   cc31e:  jmp    cbf87 <std::sys::backtrace::__rust_begin_short_backtrace+0x11e7>
    0.00 :   cc323:  lea    -0xaee9f(%rip),%rdi        # 1d48b <anon.de2471ab41e489a293ba001b839d8fc3.150.llvm.10657235172099788962+0x73>
    0.00 :   cc32a:  lea    0xc155f(%rip),%rcx        # 18d890 <anon.de2471ab41e489a293ba001b839d8fc3.181.llvm.10657235172099788962+0x20>
    0.00 :   cc331:  lea    0xc14e0(%rip),%r8        # 18d818 <anon.de2471ab41e489a293ba001b839d8fc3.154.llvm.10657235172099788962+0x118>
    0.00 :   cc338:  lea    0x37(%rsp),%rdx
    0.00 :   cc33d:  mov    $0x37,%esi
    0.00 :   cc342:  call   *0xc5f38(%rip)        # 192280 <_DYNAMIC+0x268>
    0.00 :   cc348:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc34d:  mov    $0x8,%edi
    0.00 :   cc352:  mov    $0x18,%esi
    0.00 :   cc357:  mov    0x18(%rsp),%r12
    0.00 :   cc35c:  mov    0x20(%rsp),%r13
    0.00 :   cc361:  call   *0xc5f21(%rip)        # 192288 <_DYNAMIC+0x270>
    0.00 :   cc367:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc36c:  call   d7e70 <core::ptr::drop_in_place<vthread::kernel::Kernel>>
    0.00 :   cc371:  mov    0x8(%rsp),%rdi
    0.00 :   cc376:  call   *0xc5ecc(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cc37c:  mov    0x18(%rsp),%rax
    0.00 :   cc381:  mov    0xa0(%rax),%rsi
    0.00 :   cc388:  cmp    %rsi,0x28(%rsp)
    0.00 :   cc38d:  jae    cc3e9 <std::sys::backtrace::__rust_begin_short_backtrace+0x1649>
    0.00 :   cc38f:  mov    0x18(%rsp),%r12
    0.00 :   cc394:  mov    0x98(%r12),%rax
    0.00 :   cc39c:  mov    0x28(%rsp),%rcx
    0.00 :   cc3a1:  mov    (%rax,%rcx,8),%rax
    0.00 :   cc3a5:  movb   $0x1,0xea(%rax)
    0.00 :   cc3ac:  jmp    cc1f6 <std::sys::backtrace::__rust_begin_short_backtrace+0x1456>
    0.00 :   cc3b1:  lea    0xc2ae8(%rip),%rdx        # 18eea0 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x408>
    0.00 :   cc3b8:  call   *0xc5e62(%rip)        # 192220 <_DYNAMIC+0x208>
    0.00 :   cc3be:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc3c0:  xor    %r15d,%r15d
    0.00 :   cc3c3:  lea    0xc2b66(%rip),%rdx        # 18ef30 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x498>
    0.00 :   cc3ca:  mov    0x28(%rsp),%rdi
    0.00 :   cc3cf:  call   *0xc5e4b(%rip)        # 192220 <_DYNAMIC+0x208>
    0.00 :   cc3d5:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc3d7:  xor    %r15d,%r15d
    0.00 :   cc3da:  lea    0xc2b37(%rip),%rdx        # 18ef18 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x480>
    0.00 :   cc3e1:  call   *0xc5e39(%rip)        # 192220 <_DYNAMIC+0x208>
    0.00 :   cc3e7:  jmp    cc3fe <std::sys::backtrace::__rust_begin_short_backtrace+0x165e>
    0.00 :   cc3e9:  xor    %r15d,%r15d
    0.00 :   cc3ec:  lea    0xc2b55(%rip),%rdx        # 18ef48 <anon.de2471ab41e489a293ba001b839d8fc3.751.llvm.10657235172099788962+0x4b0>
    0.00 :   cc3f3:  mov    0x28(%rsp),%rdi
    0.00 :   cc3f8:  call   *0xc5e22(%rip)        # 192220 <_DYNAMIC+0x208>
    0.00 :   cc3fe:  ud2
    0.00 :   cc400:  mov    %rax,%r14
    0.00 :   cc403:  mov    0x8(%rsp),%rdi
    0.00 :   cc408:  call   *0xc5e3a(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cc40e:  xor    %r15d,%r15d
    0.00 :   cc411:  jmp    cc48d <std::sys::backtrace::__rust_begin_short_backtrace+0x16ed>
    0.00 :   cc413:  mov    %rax,%r14
    0.00 :   cc416:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc41e:  call   dc9f0 <core::ptr::drop_in_place<vthread::context::wake::mount_carrier::{{closure}}>>
    0.00 :   cc423:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc428:  call   *0xc602a(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc42e:  mov    %rax,%r14
    0.00 :   cc431:  movzbl 0x14(%rsp),%esi
    0.00 :   cc436:  mov    0x50(%rsp),%rdi
    0.00 :   cc43b:  call   dbb70 <_ZN4core3ptr73drop_in_place$LT$std..sync..poison..mutex..MutexGuard$LT$$LP$$RP$$GT$$GT$17h714f23ec911ea948E.llvm.10657235172099788962>
    0.00 :   cc440:  jmp    cc4d2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1732>
    0.00 :   cc445:  call   *0xc600d(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc44b:  mov    %rax,%r14
    0.00 :   cc44e:  movzbl 0x14(%rsp),%esi
    0.00 :   cc453:  mov    0x50(%rsp),%rdi
    0.00 :   cc458:  call   dbb70 <_ZN4core3ptr73drop_in_place$LT$std..sync..poison..mutex..MutexGuard$LT$$LP$$RP$$GT$$GT$17h714f23ec911ea948E.llvm.10657235172099788962>
    0.00 :   cc45d:  jmp    cc4d2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1732>
    0.00 :   cc45f:  call   *0xc5ff3(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc465:  mov    %rax,%r14
    0.00 :   cc468:  jmp    cc524 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cc46d:  mov    %rax,%r14
    0.00 :   cc470:  lea    0x40(%rsp),%rdi
    0.00 :   cc475:  call   dc930 <core::ptr::drop_in_place<core::option::Option<vthread::context::wake::CarrierRoute>>>
    0.00 :   cc47a:  mov    0x18(%rsp),%r12
    0.00 :   cc47f:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc484:  call   *0xc5fce(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc48a:  mov    %rax,%r14
    0.00 :   cc48d:  mov    %r15,%rdi
    0.00 :   cc490:  mov    %r12,%rsi
    0.00 :   cc493:  call   d6130 <core::ptr::drop_in_place<core::result::Result<(),alloc::boxed::Box<dyn core::any::Any+core::marker::Send>>>>
    0.00 :   cc498:  mov    0x18(%rsp),%r12
    0.00 :   cc49d:  jmp    cc5b0 <std::sys::backtrace::__rust_begin_short_backtrace+0x1810>
    0.00 :   cc4a2:  mov    %rax,%r14
    0.00 :   cc4a5:  lock decq (%r12)
    0.00 :   cc4aa:  jne    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc4b0:  lea    0xd0(%rsp),%rdi
    0.00 :   cc4b8:  call   *0xc6d52(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc4be:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc4c3:  mov    %rax,%r14
    0.00 :   cc4c6:  movzbl %bpl,%esi
    0.00 :   cc4ca:  mov    %r13,%rdi
    0.00 :   cc4cd:  call   d5340 <core::ptr::drop_in_place<std::sync::poison::mutex::MutexGuard<vthread::thread_failure::ThreadFailures>>>
    0.00 :   cc4d2:  mov    %r14,%rdi
    0.00 :   cc4d5:  jmp    cc4e2 <std::sys::backtrace::__rust_begin_short_backtrace+0x1742>
    0.00 :   cc4d7:  call   *0xc5f7b(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc4dd:  jmp    cc4df <std::sys::backtrace::__rust_begin_short_backtrace+0x173f>
    0.00 :   cc4df:  mov    %rax,%rdi
    0.00 :   cc4e2:  mov    0x18(%rsp),%r12
    0.00 :   cc4e7:  mov    0x20(%rsp),%r13
    0.00 :   cc4ec:  jmp    cc671 <std::sys::backtrace::__rust_begin_short_backtrace+0x18d1>
    0.00 :   cc4f1:  mov    %rax,%r14
    0.00 :   cc4f4:  test   %rbx,%rbx
    0.00 :   cc4f7:  je     cc524 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cc4f9:  mov    %r15,%rdi
    0.00 :   cc4fc:  call   *0xc5d46(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cc502:  jmp    cc524 <std::sys::backtrace::__rust_begin_short_backtrace+0x1784>
    0.00 :   cc504:  mov    %rax,%r14
    0.00 :   cc507:  cmpq   $0x0,0x58(%rsp)
    0.00 :   cc50d:  je     cc51a <std::sys::backtrace::__rust_begin_short_backtrace+0x177a>
    0.00 :   cc50f:  mov    0x60(%rsp),%rdi
    0.00 :   cc514:  call   *0xc5d2e(%rip)        # 192248 <free@GLIBC_2.2.5>
    0.00 :   cc51a:  mov    0x18(%rsp),%r12
    0.00 :   cc51f:  mov    0x20(%rsp),%r13
    0.00 :   cc524:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc52c:  call   d7ad0 <_ZN4core3ptr42drop_in_place$LT$vthread..error..Error$GT$17h59bb756dcdd73a7cE.llvm.10657235172099788962>
    0.00 :   cc531:  mov    %r14,%rdi
    0.00 :   cc534:  call   *0xc64f6(%rip)        # 192a30 <_DYNAMIC+0xa18>
    0.00 :   cc53a:  mov    0xc6067(%rip),%rcx        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cc541:  lock decq (%rcx)
    0.00 :   cc545:  decq   %fs:0xffffffffffffff70
    0.00 :   cc54e:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cc557:  mov    0xa0(%r12),%rsi
    0.00 :   cc55f:  mov    0x28(%rsp),%rdi
    0.00 :   cc564:  cmp    %rsi,%rdi
    0.00 :   cc567:  jae    cc581 <std::sys::backtrace::__rust_begin_short_backtrace+0x17e1>
    0.00 :   cc569:  mov    0x98(%r12),%rcx
    0.00 :   cc571:  mov    (%rcx,%rdi,8),%rcx
    0.00 :   cc575:  movb   $0x1,0xe9(%rcx)
    0.00 :   cc57c:  jmp    cc194 <std::sys::backtrace::__rust_begin_short_backtrace+0x13f4>
    0.00 :   cc581:  mov    %rdx,%r12
    0.00 :   cc584:  mov    %rax,%r15
    0.00 :   cc587:  jmp    cc3c3 <std::sys::backtrace::__rust_begin_short_backtrace+0x1623>
    0.00 :   cc58c:  call   *0xc5ec6(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc592:  mov    %rax,%r14
    0.00 :   cc595:  lea    0x120(%rsp),%rdi
    0.00 :   cc59d:  call   dc930 <core::ptr::drop_in_place<core::option::Option<vthread::context::wake::CarrierRoute>>>
    0.00 :   cc5a2:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc5a7:  call   *0xc5eab(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc5ad:  mov    %rax,%r14
    0.00 :   cc5b0:  lea    0x40(%rsp),%rdi
    0.00 :   cc5b5:  call   db170 <core::ptr::drop_in_place<vthread::context::wake::CarrierRouteGuard>>
    0.00 :   cc5ba:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc5bf:  mov    %rax,%r14
    0.00 :   cc5c2:  lea    0x120(%rsp),%rdi
    0.00 :   cc5ca:  call   d7e70 <core::ptr::drop_in_place<vthread::kernel::Kernel>>
    0.00 :   cc5cf:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc5d4:  call   *0xc5e7e(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc5da:  mov    %rax,%r14
    0.00 :   cc5dd:  lea    0x120(%rsp),%rdi
    0.00 :   cc5e5:  call   dc5c0 <core::ptr::drop_in_place<alloc::rc::RcInner<vthread::local_carrier::LocalCarrier>>>
    0.00 :   cc5ea:  lea    0xa0(%rsp),%rdi
    0.00 :   cc5f2:  call   dd0a0 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::rc::Rc<vthread::context::Execution>>>>
    0.00 :   cc5f7:  lea    0xe0(%rsp),%rdi
    0.00 :   cc5ff:  call   dd330 <core::ptr::drop_in_place<alloc::collections::vec_deque::VecDeque<vthread::inbox::SpawnPacket>>>
    0.00 :   cc604:  lea    0x100(%rsp),%rdi
    0.00 :   cc60c:  call   dc060 <core::ptr::drop_in_place<core::option::Option<vthread::inbox::SpawnPacket>>>
    0.00 :   cc611:  lea    0x58(%rsp),%rdi
    0.00 :   cc616:  call   db2f0 <core::ptr::drop_in_place<vthread::kernel::parked_tasks::ParkedTasks>>
    0.00 :   cc61b:  lea    0x480(%rsp),%rdi
    0.00 :   cc623:  call   d9c90 <core::ptr::drop_in_place<vthread::ready_queue::ReadyQueue>>
    0.00 :   cc628:  lea    0x3a8(%rsp),%rdi
    0.00 :   cc630:  call   d9e60 <core::ptr::drop_in_place<vthread::kernel_tasks::KernelTasks>>
    0.00 :   cc635:  lock decq (%r12)
    0.00 :   cc63a:  jne    cc647 <std::sys::backtrace::__rust_begin_short_backtrace+0x18a7>
    0.00 :   cc63c:  lea    0x40(%rsp),%rdi
    0.00 :   cc641:  call   *0xc6bc9(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc647:  lock decq (%rbx)
    0.00 :   cc64b:  jne    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc64d:  lea    0xd8(%rsp),%rdi
    0.00 :   cc655:  call   *0xc6be5(%rip)        # 193240 <_DYNAMIC+0x1228>
    0.00 :   cc65b:  jmp    cc6b7 <std::sys::backtrace::__rust_begin_short_backtrace+0x1917>
    0.00 :   cc65d:  call   *0xc5df5(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc663:  call   *0xc5def(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc669:  mov    %rax,%rdi
    0.00 :   cc66c:  mov    0x18(%rsp),%r12
    0.00 :   cc671:  call   *0xc63b9(%rip)        # 192a30 <_DYNAMIC+0xa18>
    0.00 :   cc677:  mov    0xc5f2a(%rip),%rcx        # 1925a8 <_DYNAMIC+0x590>
    0.00 :   cc67e:  lock decq (%rcx)
    0.00 :   cc682:  decq   %fs:0xffffffffffffff70
    0.00 :   cc68b:  movb   $0x0,%fs:0xffffffffffffff78
    0.00 :   cc694:  lea    0x58(%rsp),%rdi
    0.00 :   cc699:  mov    %rax,%rsi
    0.00 :   cc69c:  call   *0xc6ace(%rip)        # 193170 <_DYNAMIC+0x1158>
    0.00 :   cc6a2:  jmp    cbf03 <std::sys::backtrace::__rust_begin_short_backtrace+0x1163>
    0.00 :   cc6a7:  mov    %rax,%r14
    0.00 :   cc6aa:  jmp    cc531 <std::sys::backtrace::__rust_begin_short_backtrace+0x1791>
    0.00 :   cc6af:  mov    %rax,%r14
    0.00 :   cc6b2:  jmp    cc6cc <std::sys::backtrace::__rust_begin_short_backtrace+0x192c>
    0.00 :   cc6b4:  mov    %rax,%r14
    0.00 :   cc6b7:  lock decq (%r12)
    0.00 :   cc6bc:  jne    cc6cc <std::sys::backtrace::__rust_begin_short_backtrace+0x192c>
    0.00 :   cc6be:  lea    0x98(%rsp),%rdi
    0.00 :   cc6c6:  call   *0xc6b44(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc6cc:  lock decq (%r12)
    0.00 :   cc6d1:  jne    cc6e1 <std::sys::backtrace::__rust_begin_short_backtrace+0x1941>
    0.00 :   cc6d3:  lea    0xc0(%rsp),%rdi
    0.00 :   cc6db:  call   *0xc6b2f(%rip)        # 193210 <_DYNAMIC+0x11f8>
    0.00 :   cc6e1:  mov    %r14,%rdi
    0.00 :   cc6e4:  call   187ca0 <_Unwind_Resume@plt>
    0.00 :   cc6e9:  call   *0xc5d69(%rip)        # 192458 <_DYNAMIC+0x440>
    0.00 :   cc6ef:  call   *0xc5d63(%rip)        # 192458 <_DYNAMIC+0x440>
