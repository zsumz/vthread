"""Summarize counted events; instrumented timing is intentionally not compared."""

import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
NAMES = ('attach', 'enqueue', 'rearm', 'rearm_clone', 'take_turn', 'remove', 'retire')
results = {}
for path in sorted(OUT.glob('diagnostic-*.log')):
    prefix = path.stem
    for stage in ('before', 'after'):
        assert (OUT / f'{prefix}.{stage}.guard').read_text() == ''
    assert json.loads((OUT / f'{prefix}.result.json').read_text())['returncode'] == 0
    totals = {direction: {} for direction in ('Send', 'Receive')}
    for line in path.read_text().splitlines():
        fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
        if fields.get('phase') not in ('handoff-channel', 'handoff-ticket'):
            continue
        direction = fields['direction']
        if fields['phase'] == 'handoff-ticket':
            counts = json.loads(re.search(r'counts=(\[[^]]*\])', line)[1])
            assert len(counts) == len(NAMES)
            fields = dict(zip(NAMES, counts))
        else:
            fields = {key: int(value) for key, value in fields.items() if value.isdigit() and key != 'carrier'}
        for key, value in fields.items():
            totals[direction][key] = totals[direction].get(key, 0) + int(value)
    values = totals['Send']['transfers']
    assert values == totals['Receive']['transfers']
    for counts in totals.values():
        assert counts['enqueue'] == counts['take_turn'] + counts['remove']
        assert counts['rearm'] == counts['retries']
        assert counts['rearm_clone'] <= counts['rearm']
        assert counts['retire'] == counts['parks']
        assert counts['attach'] <= counts['calls']
        counts['notification_attempts'] = sum(counts.get(key, 0) for key in (
            'selected_notifications', 'stored_notifications', 'closed_notifications', 'pending_notifications'))
    ratios = {key: sum(counts.get(key, 0) for counts in totals.values()) / values
              for key in ('attach', 'enqueue', 'rearm', 'rearm_clone', 'retire',
                          'notification_attempts', 'selected_notifications', 'stored_notifications',
                          'pending_notifications', 'parks', 'retries')}
    results[prefix] = {'values': values, 'directions': totals, 'per_value': ratios}
    print(prefix, 'values', values, 'parks/value', round(ratios['parks'], 4),
          'retries/value', round(ratios['retries'], 4),
          'rearm clones/value', round(ratios['rearm_clone'], 4))
assert len(results) == 12, 'incomplete diagnostic panel'
with (OUT / 'diagnostic-analysis.json').open('x') as stream:
    json.dump(results, stream, indent=2)
