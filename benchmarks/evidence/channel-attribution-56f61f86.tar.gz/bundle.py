"""Create an immutable focused archive; exclude worktrees and executed binaries."""

import hashlib
from pathlib import Path
import subprocess
import tarfile
import tempfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/root/vthread')
ARCHIVE = ROOT / 'benchmarks/evidence/channel-attribution-56f61f86.tar.gz'
EXCLUDE = {'probeA', 'probeE', '__pycache__', 'probe-A-benchmark', 'probe-E-benchmark'}

assert not ARCHIVE.exists()
if not (OUT / 'analyzer-tests.log').exists():
    with (OUT / 'analyzer-tests.log').open('x') as stream:
        subprocess.run(['python3', str(OUT / 'analyze_test.py')], stdout=stream,
                       stderr=subprocess.STDOUT, check=True)
paths = sorted(path for path in OUT.rglob('*') if path.is_file()
               and not EXCLUDE.intersection(path.relative_to(OUT).parts)
               and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(OUT)}\n')
with tarfile.open(ARCHIVE, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
verify = Path(tempfile.mkdtemp(prefix='channel-attribution-verify.', dir=ROOT / 'target/finish-line'))
with tarfile.open(ARCHIVE) as archive:
    members = archive.getmembers()
    assert all(member.isfile() and not Path(member.name).is_absolute()
               and '..' not in Path(member.name).parts for member in members)
    archive.extractall(verify, members=members)
with (verify / 'verification.log').open('x') as stream:
    subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=verify,
                   stdout=stream, stderr=subprocess.STDOUT, check=True)
print('archive', ARCHIVE)
print('sha256', hashlib.sha256(ARCHIVE.read_bytes()).hexdigest())
print('verified', len(paths), 'internal hashes', verify)
