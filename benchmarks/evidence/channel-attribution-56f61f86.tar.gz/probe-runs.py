"""Existing clocked diagnostics quantify events only, never optimization acceptance."""

import importlib.util
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('compare', OUT / 'compare.py')
compare = importlib.util.module_from_spec(spec)
spec.loader.exec_module(compare)

for case, mask, iterations, carriers, tasks in (
    ('local', '7', 2000, 1, 8),
    ('remote8', '0-3', 2000, 4, 8),
    ('remote64', '0-3', 500, 4, 64),
):
    for pair, order in enumerate(('AE', 'EA'), 1):
        for arm in order:
            prefix = f'diagnostic-{pair}-{case}-{arm}'
            binary = OUT / f'probe-{arm}-benchmark'
            source = json.loads((OUT / f'probe-{arm}-source.json').read_text())
            assert compare.evidence.digest(binary) == source['binary_sha256']
            compare.control.observe(prefix, 'before')
            command = ['timeout', '120s', 'perf', 'stat', '-x,', '-e',
                       'task-clock,cycles,instructions,context-switches,cpu-migrations',
                       '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', mask,
                       str(binary), 'vthread', 'channel-mpmc', str(iterations), '1',
                       str(carriers), str(tasks), '3', '--pin-carriers']
            with (OUT / f'{prefix}.command.json').open('x') as stream:
                json.dump(command, stream)
            result = compare.capture(command, OUT / f'{prefix}.log')
            compare.control.observe(prefix, 'after')
            with (OUT / f'{prefix}.result.json').open('x') as stream:
                json.dump({'returncode': result.returncode}, stream)
            assert result.returncode == 0, (prefix, result.returncode)
            print(f'completed {prefix}', flush=True)
