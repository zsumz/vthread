# Channel attribution: retained baseline versus rejected E

No new runtime optimization is retained. The production perf branch stays at the
publication-progress repair, source `90bc31261224939e4e1f15fbecd09ca29784d348ce2175dbe901a6f22541511d`.
The measurements below explain an older matching comparison; they are not a new
current-head/May panel or release qualification. Stacks, affinity, checkpoints,
fairness, ownership, admission, capacity observation and polling are unchanged.

## Exact default builds

Both executed binaries are the saved, symbol-bearing default release builds from
the earlier channel-publication experiment, with no handoff timing features:

- A: pristine `3161514f20da1d08d8a5e863c9f3a0b7d2bf2920`, source
  `f57b1db1457fc45f855e561e5eb89e489c72bcf166ef4c50400596057840c976`, binary
  `1680cc617dd9b42d1ecf3e55b4ac5ee4cab5046ccab5767930e66e1dc6226c1a`.
- E: the inlined retained-notification-handle prototype, source
  `56f61f8642ebd8f12599096f91fefa7c5dabad649f5d9ae7b11c2ab95aa84668`, binary
  `4006e9fa85878ad5af188c4b79be3a6dc049a7453de3fada64121dd9213c9d6b`.

`original-candidate-inlined.patch` reconstructs E from that base. Applying it in
the isolated diagnostic worktree first reproduced the exact source digest above.
The original manifests, binary digests and current retained-source manifest are
included. Rust 1.96.1 / LLVM 22.1.2, Linux x86-64, eight-vCPU KVM guest exposing
AMD EPYC 9555P. Exact commands and endpoint CPU/build observations accompany runs.
No own builds/tests overlap default measurements. Endpoint guards cannot prove
continuous physical-host isolation.

## Process counter panel

`core1` completes 48 independent processes: four AE/EA/EA/AE pairs for six cases.
It uses the established five events: task-clock, cycles, instructions, context
switches and CPU migrations. Reported events have 100% enabled coverage. One
carrier uses CPU 7; four use CPUs 0-3 with existing verified carrier pinning.
Normal admission/placement and exact delivery checking remain.

Eight-task short/long processes transfer 320,000/3,200,000 values including warmup.
64-task short/long processes transfer 512,000/5,120,000. Whole-process counters
include setup, recording, validation and teardown. Throughput-derived ns/value is
not individual operation latency. Two-count secants are not isolated handoff costs
or a fitted linear model; workload duration and cache footprint also differ.

E's median cycles change +2.07%/+3.10% locally, with +4.24%/+4.31% instructions.
All four long local cycle pairs are positive (+2.71% to +3.51%). Long remote-8
cycles change -7.64%; remote-64 -11.54%, both with mixed shorter-run effects.
The older report's remote losses are therefore not a workload-independent fact.
No protected burst/idle/tail acceptance panel follows this local loss.

`counts1` initially added branch/branch-miss events. It contains 25 completed
processes and a 120-second timeout in the first long remote-8 E process. Only
24 processes form complete pairs; the long A/E pair is not an analysis result.
Remote behavior is dramatically different from the established-counter group.
This group is retained separately, not stitched into `core1`. Event-set causality
has not been isolated with an interleaved modality control, and the timeout is
not established as a production deadlock. It affected a previously rejected binary.

## Default cycle profiles and coverage limits

`cycles1` completes 12 recordings at a fixed 250,003-cycle sampling period. The
host sampling ceiling is 500 Hz. Raw traces show 245-489 throttle records per
process; these recordings are not quantitative cycle attribution.

`cycles2` completes 12 recordings at requested 199 Hz: two AE/EA pairs per case,
32 million local values and the long remote counts above. It has no lost-record
markers, but does have 29-31 local and 117-152 remote throttle records. Their
per-process events and sample counts are explicitly retained. These profiles are
directional symbol/assembly evidence, not complete CPU coverage or a claim of
exact incremental cycles. Period-weighted means are reported, not rounded-hit sums.

`cycles3` tries a fixed 20,000,003-cycle period without changing host settings.
Its first A recording is excluded after the endpoint guard observes competing
cargo/rustc processes. No pair is completed. No hidden rerun or result is inferred.

Across `cycles2`'s local pair repetitions, ticket enqueue has about 3.07% of A's
sampled period and 4.35% of E's. E's assembly samples land immediately after
reference-count increments on both first enqueue and rearm. Its publication-array
destructor samples land immediately after reference-count decrements. Sampling
skid prevents treating those instruction positions as exact instruction costs.
Its entire publication symbol share is not added overhead: useful route work
moved there from A's channel body, and some ticket retirement/finish work disappears
from their old symbols. No whole difference is assigned to Arc, layout or inlining.

Remote channel send/receive take roughly 40-48% of sampled period. Annotated hot
regions include metadata spinlock acquisition/backoff. The inlined carrier loop
takes roughly 23-29%; its main annotated region is the existing polling loop.
Hub operations take roughly 7-9%. These observations do not authorize changing
backoff, expanding polling or equating shared routing with distinct carrier owners.

## Existing diagnostics, extended only for missing event distinctions

Two isolated checkouts add owner-local counters to the existing handoff profiler:
attachment, first enqueue, rearm attempt, rearm clone, consumed ticket, cleanup
removal and selected-generation finish retirement. Retirement excludes rollback.
Existing counters already distinguish completed notification outcomes, suspensions,
resumed retries and useful transfers. Summed notification outcomes are completed
attempts, not a count of failed internal CAS attempts. No new clock framework,
shared hot counter, runtime policy or default acceptance binary is introduced.

Full diagnostic patches apply independently to the historical base. A source is
`0b67e661a478a36f64d0a650a294c45c2613a72905f1042d70786c8b10421537`, binary
`9761d3562c7ebabcaa6e3e133318c69c770cae04c59ef69631da3b190235c6b5`.
E source is `478becedc400a975ddfd1e9bc06af77ab5d73a2f348e98636d4aec9386d0deed`,
binary `57cb2029215694752cf3a2560bb75eaf27aecb7180bceeb2120af2d52179c259`.
Each passes two native accounting tests and one benchmark report test. Deliberately
recording rearm as first enqueue makes the real-channel test fail (4 versus 3).
Restoring the exact source passes. Three analyzer tests reject failed, contaminated
and multiplexed counters and preserve unrounded sample periods.

Twelve diagnostic processes use AE/EA order over local, remote-8 and remote-64.
These binaries enable clocks and extra TLS accesses: timings are not acceptance
evidence. Final drained accounting checks exact useful sends/receives, ticket
balance, rearm/retry equality and selected retirement/suspension equality.

Both local repetitions match: 32,000 values, 63,996 initial ticket enqueues,
31,996 rearm attempts and 95,992 actual suspensions. A clones zero rearm handles;
E clones 31,996. E also releases the moved handle after each selected publication,
so it adds approximately one reference-count increment/decrement pair per value
relative to A's retained queue handle. It does not reduce the extra retry crossing.
E's pending coalescing replaces A's stored-permit rewrites; this also changes finish
work, so the extra pair is a demonstrated component, not the complete loss.

Remote diagnostic retry/clone ratios differ between arms and repetitions. They
must not be substituted for default-build event counts or topology measurements.
No diagnostic source is promoted to the production perf branch in this slice.

## Replay and next decision

Adapt absolute checkout/build/import/output paths in the saved scripts. Build
default A/E with the pinned release benchmark profile; build diagnostic probes
with `--features handoff-profiling` only after applying their complete patches.
`compare.py` records the exact event sets, masks, work counts, limits and ordering.
`analyze.py core1` requires complete clean pairs; the explicit subset for `counts1`
must exclude its incomplete long case. `profiles.py` retains throttling rather
than relying only on lost-sample totals. `diagnostics.py` validates the final event
partitions. Analyzer destinations are exclusive; use a fresh output directory.

The historical protocol proof is not rerun or enlarged by these diagnostic tests.
No full candidate canonical/native ARM64/sanitizer/release-soak qualification is
claimed. Default end-to-end and controlled diagnostic panels remain distinct.

Attribution identifies a concrete rearm/refcount tax plus redundant useful-work
crossings. It does not justify another layout permutation or a polling rescue.
No sixth channel implementation is attempted here; the two-implementation budget
remains unused. Out-of-lock channel publication remains open. Next independent
work is exact same-owner/remote-active/remote-sleeping mutex attribution, retaining
direct ownership, followed by the separately documented loaded-test findings.
