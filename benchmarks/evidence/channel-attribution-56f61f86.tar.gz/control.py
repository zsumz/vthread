"""Unchanged-source control; no instrumentation or candidate runtime."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

BINARY = OUT / 'baseline-benchmark'
BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
CASES = (
    ('yield4', '0-3', ['yield', '100000', '4', '64', '7', '--pin-carriers']),
    ('spawn1000', '0-3', ['spawn', '4', '1000', '63']),
    ('spawn10000', '0-3', ['spawn', '4', '10000', '63']),
    ('park4', '0-3', ['park', '10000', '4', '64', '7', '--pin-carriers']),
    ('mutex4', '0-3', ['mutex', '2000', '4', '64', '7', '--pin-carriers']),
    ('channel1c8', '7', ['channel-mpmc', '10000', '1', '1', '8', '7', '--pin-carriers']),
    ('channel4c8', '0-3', ['channel-mpmc', '10000', '1', '4', '8', '7', '--pin-carriers']),
    ('channel4c64', '0-3', ['channel-mpmc', '2000', '1', '4', '64', '7', '--pin-carriers']),
    ('channel-spare', '0-3', ['channel-mpmc', '2000', '1', '4', '64', '3', '--pin-carriers', '--max-vthreads', '65536']),
    ('wake4', '0-3', ['wake-tail', '2000', '4', '64', '7', '--pin-carriers']),
)


def observe(prefix, stage):
    (OUT / f'{prefix}.{stage}.host').write_text(evidence.output('ps', '-eo', 'pid,comm,pcpu,etime') + '\n')
    (OUT / f'{prefix}.{stage}.cpu').write_text(''.join(Path('/proc/stat').read_text().splitlines(keepends=True)[:9]))
    result = subprocess.run(['pgrep', '-x', 'cargo|rustc|clippy-driver|zrail'], capture_output=True, text=True)
    (OUT / f'{prefix}.{stage}.guard').write_text(result.stdout + result.stderr)
    if result.returncode != 1:
        raise RuntimeError('build guard rejected control; preserve output and investigate')


def main():
    assert not evidence.output('git', 'status', '--porcelain'), 'control requires pristine HEAD'
    assert not BINARY.exists(), 'do not overwrite control evidence'
    shutil.copy2(BUILD / 'release/vthread-benchmarks', BINARY)
    manifest = evidence.metadata('pristine 0b67337; default release; no profiling; baseline only')
    manifest['binary_sha256'] = evidence.digest(BINARY)
    manifest['features'] = 'default'
    manifest['build_command'] = 'CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml'
    (OUT / 'source.json').write_text(json.dumps(manifest, indent=2) + '\n')
    for round_number in range(1, 4):
        cases = CASES if round_number % 2 else tuple(reversed(CASES))
        for label, mask, arguments in cases:
            prefix = f'control-{round_number}-{label}'
            observe(prefix, 'before')
            command = ['timeout', '120s', 'perf', 'stat', '-x,', '-e',
                       'task-clock,cycles,instructions,context-switches,cpu-migrations',
                       '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', mask,
                       str(BINARY), 'vthread', *arguments]
            (OUT / f'{prefix}.command.json').write_text(json.dumps(command) + '\n')
            with (OUT / f'{prefix}.log').open('x') as log:
                result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            observe(prefix, 'after')
            if result.returncode:
                raise RuntimeError(f'{prefix} failed: {result.returncode}')
            print(f'completed {prefix}', flush=True)
    assert not evidence.output('git', 'status', '--porcelain'), 'source changed during control'
    assert manifest['source_sha256'] == evidence.source_digest()
    print('completed 30 pristine default-build controls; no May or candidate claim', flush=True)


if __name__ == '__main__':
    main()
