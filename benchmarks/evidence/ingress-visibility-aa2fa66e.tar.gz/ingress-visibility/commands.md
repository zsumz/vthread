# Final ingress repair qualification and experiments

Working directory: `/root/vthread`. `source.json` and `candidate.patch` identify
the final frozen source; `binaries.sha256` identifies the executed artifacts.

```sh
CARGO_INCREMENTAL=0 zcheck run check
CARGO_INCREMENTAL=0 cargo test --locked --workspace --all-targets
CARGO_INCREMENTAL=0 cargo test --locked --release -p vthread --lib carrier_ingress
CARGO_INCREMENTAL=0 cargo build --locked --release -p vthread-lab
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/root/vthread/target cargo test --locked --manifest-path benchmarks/Cargo.toml --all-features
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/root/vthread/target cargo clippy --locked --manifest-path benchmarks/Cargo.toml --all-targets --all-features -- -D warnings
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml --features scheduler-profiling
taskset -c 0 target/debug/deps/vthread-983657e34fb0f8af carrier_ingress --test-threads=1
timeout 120s taskset -c 0-3 target/release/vthread-lab soak 60 1 64
timeout 120s taskset -c 0-3 target/release/vthread-lab soak 60 4 64
```

The one-CPU native command was run 20 times serially (`replay-1.log` through
`replay-20.log`). `negative.log`/`negative.patch` and their source/binary identities
retain the failing old-code probe. Initial debug/optimized results used temporary
diagnostic printing; the final tests use assertion diagnostics and were requalified.

`run-controls.sh` and `control-commands.log` retain all actual performance commands.
Initial rounds 1-3 were interrupted by unrelated build/test activity. Only the
confirmed driver child PID 2406117 was paused with SIGSTOP, then resumed with
SIGCONT after a fresh empty Cargo/compiler/zrail activity check. Its current child
measurement was allowed to finish; no other job or Codex session was changed.

Fresh rounds 4-6 repeated yield, spawn1000, spawn10000, park-local and park under
new filenames. Rounds 7-9 added single-carrier yield and uncontended mutex. Start/end
host snapshots remain in the archive; later Python activity was detected during
the refreshed park runs. The analysis selects explicitly reported rounds, not
performance-accepted samples. Quiet-host multi-carrier acceptance remains open.

The archive does not include executables. All source changes for the distinct
observer-only capacity experiment are shelved and excluded from this runtime fix.
