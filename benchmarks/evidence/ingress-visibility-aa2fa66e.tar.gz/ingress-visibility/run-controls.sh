#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/ingress-visibility

run_pair() {
    local label=$1 mask=$2
    shift 2
    if [[ ${VTHREAD_CONTROL_CASES:-all} != all && " ${VTHREAD_CONTROL_CASES:-} " != *" $label "* ]]; then return; fi
    for round in ${VTHREAD_CONTROL_ROUNDS:-1 2 3}; do
        local engines='baseline candidate'
        if (( round % 3 == 2 )); then engines='candidate baseline'; fi
        for engine in $engines; do
            local binary=$evidence_dir/candidate-benchmark
            if [[ $engine == baseline ]]; then
                binary=target/finish-line/scheduler-profile/default-benchmark
            fi
            local prefix=$evidence_dir/control-$round-$engine-$label
            if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
                printf 'control deferred: other build activity before %s\n' "$prefix" >&2
                return 125
            fi
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            printf '%q ' timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@" >> "$evidence_dir/control-commands.log"
            printf '\n' >> "$evidence_dir/control-commands.log"
            timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@" > "$prefix.log" 2>&1
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'control round=%s engine=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

run_pair yield 0-3 yield 100000 4 64 9
run_pair yield-local 7 yield 100000 1 64 9
run_pair spawn1000 0-3 spawn 4 1000 501
run_pair spawn10000 0-3 spawn 4 10000 501
run_pair park-local 7 park 100000 1 64 3
run_pair park 0-3 park 100000 4 64 9 --pin-carriers
run_pair mutex 0-3 mutex 10000 4 64 9 --pin-carriers
run_pair mutex-uncontended 7 mutex-uncontended 10000000 1 1 9
run_pair channel 0-3 channel 10000 4 64 9 --pin-carriers
run_pair wake 0-3 wake-tail 10000 4 64 9 --pin-carriers
run_pair capacity 0-3 park 10000 4 64 5 --max-vthreads 65536 --pin-carriers
