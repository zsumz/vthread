"""Archive a failed optional candidate plus the restored checkpoint qualification."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

assert evidence.source_digest() == json.loads((OUT / 'A-source.json').read_text())['source_sha256']
jobs = json.loads((OUT / 'screen-plan.json').read_text())
assert len(jobs) == len(list(OUT.glob('screen-*.result.json'))) == 32
for job in jobs:
    assert json.loads((OUT / f'{job["prefix"]}.result.json').read_text())['returncode'] == 0
assert '6 passed; 1 failed' in (OUT / 'duplicate-publication-negative.log').read_text()
assert '75 passed; 0 failed; 1 ignored' in (OUT / 'admission-publication-positive.log').read_text()
assert json.loads((OUT / 'retained-canonical.result.json').read_text())['returncode'] == 1
assert (OUT / 'canonical-receipt.json').is_file()
assert 'a_terminal_sibling_does_not_hide_an_indefinitely_parked_child' in (
    OUT / 'failed-canonical/0008-test-native-release.log').read_text()
with (OUT / 'verification-tests.log').open('x') as stream:
    subprocess.run(['python3', '-m', 'unittest', 'discover', '-s', str(OUT), '-p', '*_test.py', '-v'],
                   cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=True)
dependencies = OUT / 'replay-dependencies'
dependencies.mkdir(exist_ok=False)
reference = ROOT / 'target/finish-line/may-refresh.yvxHtB'
for name in ['analyze.py', 'cases.py', 'bare-default-1-spawn1000-vthread.log']:
    shutil.copy2(reference / name, dependencies / name)
shutil.copy2(ROOT / 'benchmarks/counter-free-acceptance.md', OUT / 'predeclared-acceptance.md')
for arm in ['A', 'B']:
    manifest = json.loads((OUT / f'{arm}-source.json').read_text())
    assert manifest['binary_sha256'] == evidence.digest(OUT / f'benchmark-{arm}')
    with tarfile.open(OUT / f'{arm}-source.tar.gz') as archive:
        source = hashlib.sha256()
        for member in sorted(archive.getmembers(), key=lambda member: member.name):
            assert member.isfile()
            source.update(member.name.encode() + b'\0' + archive.extractfile(member).read() + b'\0')
        assert source.hexdigest() == manifest['source_sha256']
destination = ROOT / 'benchmarks/evidence/admission-publication-f406d0ca.tar.gz'
paths = sorted(path for path in OUT.rglob('*') if path.is_file() and '__pycache__' not in path.parts
               and not path.name.startswith('benchmark-') and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(destination, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
with tarfile.open(destination) as archive:
    assert len(archive.getmembers()) == len(paths) + 1
    for line in archive.extractfile('SHA256SUMS').read().decode().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
print(destination, evidence.digest(destination), len(paths), 'verified hashes; both source hashes reconstructed')
