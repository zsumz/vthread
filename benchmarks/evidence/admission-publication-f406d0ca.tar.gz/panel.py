"""Balanced A/B and bare/counter screen using the established benchmark protocol."""

import json
import os
from pathlib import Path
import subprocess
import sys
import time

from acceptance import parse, summarize

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def screen_plan():
    jobs = []
    for rep in range(1, 5):
        for pinned in ([False, True] if rep % 2 else [True, False]):
            case = dict(name='spawn1000-' + ('pinned' if pinned else 'default'), mask='0-3',
                        args=['spawn', '4', '1000', '501'] + (['--pin-carriers'] if pinned else []),
                        operation='task', workers=4, tasks=1000, capacity=1000,
                        per_task=1, rounds=501, pinned=pinned)
            collectors = ['bare', 'perf'] if (rep % 2) != pinned else ['perf', 'bare']
            for collector in collectors:
                arms = ['A', 'B'] if rep in [1, 4] else ['B', 'A']
                if collector == 'perf':
                    arms.reverse()
                for arm in arms:
                    jobs.append(dict(prefix=f'screen-{rep}-{case["name"]}-{collector}-{arm}',
                                     repetition=rep, collector=collector, arm=arm, case=case))
    return jobs


def observe(prefix, stage):
    with (OUT / f'{prefix}.{stage}.host').open('x') as stream:
        stream.write(evidence.output('ps', '-eo', 'pid,comm,pcpu,etime') + '\n')
    with (OUT / f'{prefix}.{stage}.cpu').open('x') as stream:
        stream.write(''.join(Path('/proc/stat').read_text().splitlines(keepends=True)[:9]))
    result = subprocess.run(['pgrep', '-x', 'cargo|rustc|clippy-driver|zrail'], capture_output=True, text=True)
    with (OUT / f'{prefix}.{stage}.guard').open('x') as stream:
        stream.write(result.stdout + result.stderr)
    assert result.returncode == 1, 'build overlap; preserve outcomes and unrun jobs, no replacements'


def run(name, jobs):
    source = evidence.source_digest()
    manifests = {arm: json.loads((OUT / f'{arm}-source.json').read_text()) for arm in ['A', 'B']}
    for arm, manifest in manifests.items():
        assert manifest['binary_sha256'] == evidence.digest(OUT / f'benchmark-{arm}')
    assert source == manifests['B']['source_sha256']
    assert len({job['prefix'] for job in jobs}) == len(jobs)
    with (OUT / f'{name}-plan.json').open('x') as stream:
        json.dump(jobs, stream, indent=2)
    for index, job in enumerate(jobs):
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '180s']
        if job['collector'] == 'perf':
            command.extend(['perf', 'stat', '-x,', '-e',
                            'task-clock,cycles,instructions,context-switches,cpu-migrations',
                            '-o', str(OUT / f'{prefix}.csv')])
        command.extend(['taskset', '-c', job['case']['mask'], str(OUT / f'benchmark-{job["arm"]}'),
                        'vthread', *job['case']['args']])
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, started_unix=time.time(), job=job,
                           source=manifests[job['arm']]), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            process = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            pid, status, usage = os.wait4(process.pid, 0)
            assert pid == process.pid
            process.returncode = os.waitstatus_to_exitcode(status)
        result = dict(returncode=process.returncode, finished_unix=time.time(), resources=dict(
            user_seconds=usage.ru_utime, system_seconds=usage.ru_stime, peak_rss_kib=usage.ru_maxrss,
            voluntary_switches=usage.ru_nvcsw, involuntary_switches=usage.ru_nivcsw))
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(result, stream, indent=2)
        observe(prefix, 'after')
        assert process.returncode == 0, (prefix, process.returncode)
        value = parse((OUT / f'{prefix}.log').read_text(), job)
        print(f'{index + 1}/{len(jobs)} {prefix}: {value["ns_per_operation"]:.2f} ns/op', flush=True)
    assert source == evidence.source_digest(), 'source changed during panel'
    return summarize(name, jobs)


if __name__ == '__main__':
    with (OUT / 'topology.json').open('x') as stream:
        stream.write(evidence.output('lscpu', '--json') + '\n')
    with (OUT / 'cpuinfo.txt').open('x') as stream:
        stream.write(Path('/proc/cpuinfo').read_text())
    groups = run('screen', screen_plan())
    stopped = [key for key, group in groups.items() if group['collector'] == 'bare'
               and group['timing_effect']['gross_bare_stop']]
    print('early stop cells:', stopped, flush=True)
