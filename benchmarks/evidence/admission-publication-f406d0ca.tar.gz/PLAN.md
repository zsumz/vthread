# One evidence-directed capacity follow-up

The scan-only screen demonstrated ~2.6x receive calls and ~15x idle entries,
without a default-placement native-wait increase. Source audit finds a redundant
publication boundary for a lone owned admission: receive publishes Running, then
the required lone first-mount path publishes again immediately before user code.

Candidate: scan-only B plus omission of only that admission publication when the
ready queue contains exactly one task, no borrowed task exists and stall detection
is disabled. Leave multi-entry admission, borrowed work, stall-enabled admission,
the first-mount publication, transition batching, completion flushing, all polling
and sleep/epoch ordering unchanged. No artificial pacing or new atomics.

The skipped observation is weakly consistent; before dispatch, a newly submitted
task still has its record-level Ready status and its owner may report its preceding
snapshot. The mandatory first-mount publication stays before potentially unbounded
user code. A wake that precedes that first dispatch retains the existing bounded
ready-cohort and transition-publication guarantees; there is no wall-time promise.

First add a test-only publication count and ordered negative control on historical
B: the single admission must not publish; the body must observe its own first
mount. Retain positive multi-entry, stall-enabled and borrowed-preservation
controls and the four scan/local/remote/deferred snapshot regressions.

Use the already declared acceptance margins. Early screen is the same 32 balanced
default/pinned bare/perf processes, 4 carriers / 1000 tasks / 501 rounds. Baseline
is the same byte-verified e344a60e default binary, not the rejected scan candidate.
Stop if either bare cell crosses the established gross-loss rule. A survivor still
needs the planned protected/scaling and canonical gates before promotion.

This is not a replacement for bounded pre-dispatch wake service. It is a narrowly
attributed attempt to close the earlier capacity slice without changing pacing.
