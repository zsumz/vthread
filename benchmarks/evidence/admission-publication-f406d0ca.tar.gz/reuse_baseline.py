"""Reuse the verified unchanged default executable; do not rebuild under candidate bytes."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
OLD = ROOT / 'target/finish-line/readiness-counterfree.Wpdxss'
manifest = json.loads((OLD / 'A-source.json').read_text())
assert manifest['source_sha256'] == 'e344a60e6098206922dc615bad1bbbbfbff7c32badedc164d5b67f862f31a1b4'
assert hashlib.sha256((OLD / 'benchmark-A').read_bytes()).hexdigest() == manifest['binary_sha256']
changed = subprocess.check_output(['git', 'diff', '--name-only', manifest['head'], 'HEAD'], cwd=ROOT, text=True).splitlines()
assert all(Path(name).suffix not in {'.rs', '.toml', '.lock', '.py', '.sh', '.yml'} for name in changed)
with tarfile.open(OLD / 'A-source.tar.gz') as archive:
    source = hashlib.sha256()
    for member in sorted(archive.getmembers(), key=lambda member: member.name):
        source.update(member.name.encode() + b'\0' + archive.extractfile(member).read() + b'\0')
    assert source.hexdigest() == manifest['source_sha256']
for path in sorted(OLD.glob('A-*')):
    assert not (OUT / path.name).exists()
    shutil.copy2(path, OUT / path.name)
shutil.copy2(OLD / 'benchmark-A', OUT / 'benchmark-A')
with (OUT / 'baseline-reuse.json').open('x') as stream:
    json.dump(dict(reused_from=str(OLD), base_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                   source_sha256=source.hexdigest(), binary_sha256=manifest['binary_sha256'],
                   differences_since_original_build=changed), stream, indent=2)
print('verified unchanged baseline source and binary', manifest['binary_sha256'])
