# Scan-free lone-admission publication: rejected

Baseline is the byte-verified retained e344a60e binary. Its source/configuration
identity is reused from the previous current-source build, with a verified
documentation-only bridge to base `4d7fe6a`. Candidate source f406d0ca.

Hypothesis and unchanged acceptance policy are in PLAN.md. Candidate restores
scan-only B and skips only duplicate lone-owned-admission publication when stall
detection is disabled and no borrowed task is present. First mount, completion,
batched/borrowed/stall-enabled publication, polling and fairness stay unchanged.

- Negative control on scan-only B: one intended duplicate-publication failure,
  six positive accounting/publication controls pass. After the guarded change,
  all 75 kernel-focused tests pass; one existing manual probe remains ignored.
- Default candidate benchmark build passes formatting, 47 benchmark tests, clippy
  and feature capture. Seven analysis tests pass.
- All 32 planned screen processes complete with clear endpoint build guards.
  Default bare crosses the three-loss early stop: median paired time +14.01%,
  process CPU +20.14%. Counter mode also loses. Pinned controls are multimodal;
  all observations remain included, not treated as replacement or fast samples.
- No broad candidate confirmation/scaling panel or full candidate canonical run
  follows the stop. No runtime change is promoted and no pooling/polling variant
  is added. Candidate preserved at stash 771294513b48af80db6d80f879451730a35f297a.
- Canonical zcheck is run on the restored retained runtime, not this candidate.
  Run-1788716551-875203881-3238339 failed the native release test
  a_terminal_sibling_does_not_hide_an_indefinitely_parked_child: its primary-error
  assertion failed without printing the actual error. Native debug and the
  all-feature suite passed. The failed receipt and all task logs are included,
  tied to source e344a60e. This is not a candidate regression, and a separate
  ordered correctness investigation must classify it. The restored checkpoint
  is not claimed green.
- One restore attempt used unsupported same-path delete/add patch operations;
  it changed no runtime file. Whole-file update patches then restored the archived
  candidate exactly before the new test-only instrumentation and narrow guard.

Timing/CPU use separate collection modes and independent paired processes.
Whole-process counters/resource accounting include wrappers and setup/teardown.
No instrumented timing, new May result or release-completion claim is made.
Archive replay dependencies contain the reused parser and known raw fixture.
