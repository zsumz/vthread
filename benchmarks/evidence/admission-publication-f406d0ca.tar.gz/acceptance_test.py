"""Reject unbalanced plans, mismatched configurations and misleading acceptance."""

import copy
from pathlib import Path
import unittest

from acceptance import paired, parse
from panel import screen_plan


class AcceptanceTests(unittest.TestCase):
    def test_plan_balances_candidate_and_collection_order(self):
        jobs = screen_plan()
        self.assertEqual(len(jobs), 32)
        self.assertEqual(len({job['prefix'] for job in jobs}), 32)
        for pinned in [False, True]:
            for collector in ['bare', 'perf']:
                first = [job['arm'] for index, job in enumerate(jobs)
                         if index % 2 == 0 and job['case']['pinned'] == pinned and job['collector'] == collector]
                self.assertEqual(first.count('A'), 2)
                self.assertEqual(first.count('B'), 2)
            first = [job['collector'] for index, job in enumerate(jobs)
                     if index % 4 == 0 and job['case']['pinned'] == pinned]
            self.assertEqual(first.count('bare'), 2)
            self.assertEqual(first.count('perf'), 2)

    def test_paired_ratios_are_not_ratio_of_unpaired_medians(self):
        result = paired([1, 2, 4, 8], [1.1, 2.2, 4.4, 8.8])
        self.assertAlmostEqual(result['upper_95'], 1.1)
        self.assertAlmostEqual(result['geometric_mean_ratio'], 1.1)

    def test_early_stop_requires_three_losses_and_median_loss(self):
        self.assertTrue(paired([1] * 4, [1.2] * 4)['gross_bare_stop'])
        self.assertFalse(paired([1] * 4, [0.9, 1, 1.5, 1.5])['gross_bare_stop'])

    def test_missing_pairs_cannot_qualify(self):
        with self.assertRaises(AssertionError):
            paired([1] * 4, [1] * 3)

    def fixture(self):
        job = copy.deepcopy(screen_plan()[0])
        job['case']['rounds'] = 101
        path = Path('/root/vthread/target/finish-line/may-refresh.yvxHtB/bare-default-1-spawn1000-vthread.log')
        return job, path.read_text()

    def test_known_raw_output_passes(self):
        job, text = self.fixture()
        self.assertAlmostEqual(parse(text, job)['ns_per_operation'], 411.54)

    def test_incomplete_rounds_fail(self):
        job, text = self.fixture()
        job['case']['rounds'] = 501
        with self.assertRaises(AssertionError):
            parse(text, job)

    def test_wrong_pinning_or_capacity_fails(self):
        job, text = self.fixture()
        for key, value in [('pinned', True), ('capacity', 65536)]:
            changed = copy.deepcopy(job)
            changed['case'][key] = value
            with self.assertRaises(AssertionError):
                parse(text, changed)


if __name__ == '__main__':
    unittest.main()
