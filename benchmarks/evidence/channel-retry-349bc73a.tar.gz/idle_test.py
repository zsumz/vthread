"""Keep quiet controls distinct from useful wake waves and reject lost accounting."""

import unittest
from idle import cases, parse, plan


def fixture(case):
    tasks = case['tasks']
    acknowledgements = case['waves'] * tasks
    owners = [tasks // case['workers']] * case['workers']
    return (f'phase=contract carriers={case["workers"]} tasks={tasks} capacity={case["capacity"]} '
            f'quiet_gap_us={case["gap_us"]} waves={case["waves"]} individual_pinning=false open_loop=false\n'
            f'phase=initial-parked parked={tasks} owner_counts={owners} timers=0\n'
            f'phase=interval elapsed_ns={case["gap_us"] * 1000} selected_wakes={acknowledgements} '
            f'stored_permits=0 acknowledgements={acknowledgements}\n'
            f'phase=drained completed={tasks} parks={acknowledgements + tasks} '
            f'wakes={acknowledgements + tasks} active=0\n')


class IdleTests(unittest.TestCase):
    def test_every_bounded_original_shape_has_balanced_pairs(self):
        jobs = plan()
        self.assertEqual(len(jobs), 48)
        self.assertEqual(len({job['prefix'] for job in jobs}), 48)
        for case in cases():
            group = [job for job in jobs if job['case'] == case]
            self.assertEqual([job['arm'] for job in group[::2]], ['A', 'B', 'A', 'B'])
            parsed = parse(fixture(case), case)
            self.assertEqual(parsed['interval']['acknowledgements'], case['tasks'] * case['waves'])

    def test_missing_park_drain_generation_or_capacity_evidence_fails(self):
        case = cases()[2]
        text = fixture(case)
        for old, new in [('capacity=8', 'capacity=64'), ('parked=8', 'parked=7'),
                         ('stored_permits=0', 'stored_permits=1'), ('timers=0', 'timers=1'),
                         ('active=0', 'active=1'), ('completed=8', 'completed=7'),
                         ('wakes=16008', 'wakes=16007'), ('open_loop=false', 'open_loop=true')]:
            with self.subTest(negative=old):
                with self.assertRaises(AssertionError):
                    parse(text.replace(old, new), case)


if __name__ == '__main__':
    unittest.main()
