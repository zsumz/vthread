"""Direction counts, independent pairs, and tail-report negative controls."""

import unittest
from tails import directions, plan, tail_cases


def fixture():
    case = dict(tail_cases()[0], rounds=1, per_task=1)
    text = (f'engine=vthread operation={case["operation"]} workers=1 tasks=8 '
            'median_ns=400 ns_per_operation=100.00 p95_ns=400 p99_ns=400 max_ns=400 samples=[400]\n'
            'engine=vthread phase=configuration pin_carriers=false max_vthreads=8\n'
            'engine=vthread phase=latency observations=8\n'
            'engine=vthread phase=fairness task_streams=8\n')
    for direction in ['send', 'receive']:
        text += (f'engine=vthread operation={case["operation"]} phase=channel-latency direction={direction} '
                 'median_ns=10 p90_ns=20 p95_ns=30 p99_ns=40 p99_9_ns=50 p99_99_ns=60 max_ns=70 observations=4\n'
                 f'engine=vthread operation={case["operation"]} phase=channel-fairness direction={direction} '
                 'task_median_min_ns=10 task_median_max_ns=20 task_p99_9_min_ns=30 task_p99_9_max_ns=60 '
                 'worst_stream=1 task_worst_ns=70 task_streams=4\n')
    return text, dict(case=case)


class TailTests(unittest.TestCase):
    def test_jobs_are_five_separate_cells_with_balanced_independent_pairs(self):
        jobs = plan()
        self.assertEqual(len(jobs), 40)
        self.assertEqual(len({job['prefix'] for job in jobs}), 40)
        for case in tail_cases():
            group = [job for job in jobs if job['case'] == case]
            self.assertEqual([job['arm'] for job in group[::2]], ['A', 'B', 'A', 'B'])
            self.assertTrue(all(job['collector'] == 'bare' for job in group))

    def test_direction_counts_exclude_warmup_and_cover_all_streams(self):
        text, job = fixture()
        self.assertEqual(set(directions(text, job)), {'send', 'receive'})
        for old, new in [('observations=4', 'observations=8'),
                         ('direction=send', 'direction=receive'),
                         ('task_streams=4', 'task_streams=3'),
                         ('p99_99_ns=60', 'p99_99_ns=40'),
                         ('task_worst_ns=70', 'task_worst_ns=71')]:
            with self.subTest(negative=old):
                with self.assertRaises(AssertionError):
                    directions(text.replace(old, new), job)


if __name__ == '__main__':
    unittest.main()
