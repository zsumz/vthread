"""Existing endpoint fixture, with exact directional accounting and paired effects."""

import json
from acceptance import fields, paired, parse
from panel import OUT, cases, run


def tail_cases():
    result = []
    for stage in ['local', 'remote', 'population']:
        for original in cases(stage):
            if original['per_task'] != 1000:
                continue
            case = dict(original)
            case['name'] += '-endpoints'
            case['operation'] += '-sampled'
            case['args'] = original['args'] + ['--sample-channel-latency']
            result.append(case)
    return result


def plan(name='tails', repetitions=4):
    jobs = []
    for rep in range(1, repetitions + 1):
        for case in (tail_cases() if rep % 2 else list(reversed(tail_cases()))):
            for arm in (['A', 'B'] if rep % 2 else ['B', 'A']):
                jobs.append(dict(prefix=f'{name}-{rep}-{case["name"]}-bare-{arm}',
                                 repetition=rep, collector='bare', arm=arm, case=case))
    return jobs


def directions(text, job):
    row = parse(text, job)
    case = job['case']
    expected = case['per_task'] * case['operation_tasks'] * case['rounds']
    assert row['phases']['latency']['observations'] == expected * 2
    assert row['phases']['fairness']['task_streams'] == case['tasks']
    result = {}
    for direction in ['send', 'receive']:
        phases = {}
        for phase in ['channel-latency', 'channel-fairness']:
            found = [fields(line) for line in text.splitlines()
                     if f'phase={phase} direction={direction} ' in line]
            assert len(found) == 1, 'direction coverage must be exact'
            values = found[0]
            assert values['engine'] == 'vthread' and values['operation'] == case['operation']
            phases[phase] = {key: int(value) for key, value in values.items() if value.isdigit()}
        latency, fairness = phases['channel-latency'], phases['channel-fairness']
        assert latency['observations'] == expected, 'warmup or missing endpoint calls'
        assert fairness['task_streams'] == case['operation_tasks']
        assert 0 <= fairness['worst_stream'] < fairness['task_streams']
        assert fairness['task_worst_ns'] == latency['max_ns']
        quantiles = [latency[key] for key in ['median_ns', 'p90_ns', 'p95_ns', 'p99_ns',
                                             'p99_9_ns', 'p99_99_ns', 'max_ns']]
        assert quantiles == sorted(quantiles) and quantiles[0] > 0
        for field in ['median', 'p99_9']:
            assert fairness[f'task_{field}_min_ns'] <= fairness[f'task_{field}_max_ns']
        result[direction] = phases
    return result


def analyze(name, jobs):
    groups = {}
    for job in jobs:
        value = directions((OUT / f'{job["prefix"]}.log').read_text(), job)
        group = groups.setdefault(job['case']['name'], dict(A=[], B=[]))
        group[job['arm']].append((job['repetition'], value))
    for group in groups.values():
        for arm in ['A', 'B']:
            group[arm].sort()
        assert [rep for rep, _ in group['A']] == [rep for rep, _ in group['B']]
        effects = {}
        for direction in ['send', 'receive']:
            for phase, keys in [('channel-latency', ['p99_9_ns', 'p99_99_ns', 'max_ns']),
                                ('channel-fairness', ['task_median_max_ns', 'task_p99_9_max_ns',
                                                      'task_worst_ns'])]:
                for key in keys:
                    effects[f'{direction}.{phase}.{key}'] = paired(
                        [value[direction][phase][key] for _, value in group['A']],
                        [value[direction][phase][key] for _, value in group['B']])
        group['effects'] = effects
    with (OUT / f'{name}-directions.json').open('x') as stream:
        json.dump(groups, stream, indent=2)
    return groups


if __name__ == '__main__':
    jobs = plan()
    timing = run('tails', jobs)
    endpoints = analyze('tails', jobs)
    print('gross time stops:', [name for name, group in timing.items()
                               if group['timing_effect']['gross_bare_stop']], flush=True)
    for name, group in endpoints.items():
        print(name, {key: round(effect['median_ratio'], 3)
                     for key, effect in group['effects'].items()}, flush=True)
