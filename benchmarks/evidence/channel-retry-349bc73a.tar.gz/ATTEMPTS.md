# Setup and non-performance attempts

The historical eligible patch's read-only application check fails only at the
wait.rs re-export context, which has gained owner-publication imports. Keep that
repair scoped to the import; it is not a new publication ordering change.

The rearm negative archive and manifest were successfully written, then the freeze
helper rejected an already-existing `rearm-oracle-negative.patch` created by the
test wrapper. No file was overwritten. Source and archive hashes were explicitly
verified before restoring the counter. The test fails as intended (four initial
enqueues versus three), not at compilation. Future freeze labels avoid wrapper
names. This artifact-name collision is not a runtime or model failure.

The patch-format adapter initially read one line of the next diff header while
extracting the two model files, and rejected that incomplete header. The runtime
subset was already applied; no model/test build ran against that partial state.
The exact two-file extraction and remaining rebased hunks were then applied.

The first model run passes 12 channel and 17 retained publication tests, with one
known cfg warning from importing the production diagnostic accessor into the
feature-free model crate. A scoped lint expectation on that imported module
documents the mismatch; no Cargo feature, production condition or atomic ordering
changes. Strict all-feature clippy and a clean model rerun qualify that adapter.
