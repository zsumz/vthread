"""Reproduce every accepted analysis from raw output without rerunning workloads."""

import hashlib
import json
from pathlib import Path
import unittest

import acceptance
from acceptance import counters, paired, parse
import diagnostics
import panel
import protected
import tails

OUT = Path(__file__).resolve().parent


def check_analysis(stage):
    jobs = json.loads((OUT / f'{stage}-plan.json').read_text())
    expected = (tails.plan() if stage == 'tails' else protected.plan(stage) if stage == 'capacity'
                else panel.screen_plan(stage))
    assert jobs == expected
    assert len(jobs) == len(list(OUT.glob(f'{stage}-*.result.json')))
    groups = json.loads((OUT / f'{stage}-analysis.json').read_text())
    covered = set()
    for group in groups.values():
        for arm in ['A', 'B']:
            for row in group[arm]:
                prefix = row['prefix']
                job = next(job for job in jobs if job['prefix'] == prefix)
                assert prefix not in covered
                covered.add(prefix)
                assert job['arm'] == arm and job['case'] == group['case']
                assert job['collector'] == group['collector']
                command = json.loads((OUT / f'{prefix}.command.json').read_text())
                assert command['job'] == job
                assert command['source'] == json.loads((OUT / f'{arm}-source.json').read_text())
                result = json.loads((OUT / f'{prefix}.result.json').read_text())
                assert result['returncode'] == 0 and row['resources'] == result['resources']
                for phase in ['before', 'after']:
                    assert not (OUT / f'{prefix}.{phase}.guard').read_text().strip()
                parsed = parse((OUT / f'{prefix}.log').read_text(), job)
                assert all(row[key] == value for key, value in parsed.items())
                cpu = sum(result['resources'][key] for key in ['user_seconds', 'system_seconds'])
                assert row['cpu_seconds_per_operation'] == cpu / parsed['process_operations']
                if job['collector'] == 'perf':
                    assert row['counters'] == counters(OUT / f'{prefix}.csv')
        for field, name in [('ns_per_operation', 'timing_effect'),
                            ('cpu_seconds_per_operation', 'cpu_effect')]:
            assert group[name] == paired([row[field] for row in group['A']],
                                         [row[field] for row in group['B']])
    assert covered == {job['prefix'] for job in jobs}
    return len(covered)


def check_diagnostics():
    count = 0
    for arm in ['A', 'B']:
        jobs = json.loads((OUT / f'diagnostic-{arm}-plan.json').read_text())
        recorded = json.loads((OUT / f'diagnostic-{arm}-analysis.json').read_text())
        assert len(jobs) == len(recorded) == 6
        for job in jobs:
            prefix = job['prefix']
            result = json.loads((OUT / f'{prefix}.result.json').read_text())
            assert result['returncode'] == 0
            for phase in ['before', 'after']:
                assert not (OUT / f'{prefix}.{phase}.guard').read_text().strip()
            value = diagnostics.parse((OUT / f'{prefix}.log').read_text(), job['workers'],
                                      job['tasks'] // 2 * 1000 * 8)
            assert value == recorded[prefix]
            count += 1
    return count


def check_tails():
    recorded = json.loads((OUT / 'tails-directions.json').read_text())
    jobs = json.loads((OUT / 'tails-plan.json').read_text())
    for name, group in recorded.items():
        for arm in ['A', 'B']:
            for rep, value in group[arm]:
                job = next(job for job in jobs if job['case']['name'] == name
                           and job['arm'] == arm and job['repetition'] == rep)
                assert value == tails.directions((OUT / f'{job["prefix"]}.log').read_text(), job)
        for key, effect in group['effects'].items():
            direction, phase, field = key.split('.')
            assert effect == paired([value[direction][phase][field] for _, value in group['A']],
                                     [value[direction][phase][field] for _, value in group['B']])


if __name__ == '__main__':
    assert acceptance.DEPENDENCIES == OUT / 'replay-dependencies'
    suite = unittest.defaultTestLoader.discover(str(OUT), pattern='*_test.py')
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.wasSuccessful()
    assert sum(check_analysis(stage) for stage in ['local', 'remote', 'population', 'tails', 'capacity']) == 264
    assert check_diagnostics() == 12
    check_tails()
    for name in ['unaffected-plan.json', 'idle-plan.json', 'confirmation-plan.json']:
        assert not (OUT / name).exists(), 'conditional unrun work must not be credited'
    if (OUT / 'SHA256SUMS').is_file():
        for line in (OUT / 'SHA256SUMS').read_text().splitlines():
            expected, name = line.split('  ', 1)
            assert hashlib.sha256((OUT / name).read_bytes()).hexdigest() == expected, name
    print('Verified 264 planned performance processes, twelve clocked diagnostics and exact directional tails.')
