"""Link the unchanged public-API burst fixture against each exact default source."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def run(prefix, command, source, environment, manifest):
    with (OUT / f'{prefix}.command.json').open('x') as stream:
        json.dump(dict(command=command, cwd=str(source), source=manifest), stream, indent=2)
    with (OUT / f'{prefix}.log').open('x') as stream:
        result = subprocess.run(command, cwd=source, env=environment, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=600)
    with (OUT / f'{prefix}.result.json').open('x') as stream:
        json.dump(dict(returncode=result.returncode), stream)
    assert result.returncode == 0, prefix
    print(prefix, 'passed', flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('arm', choices=['A', 'B'])
    parser.add_argument('source', type=Path)
    args = parser.parse_args()
    fixture = OUT / 'idle-fixture'
    fixture.mkdir(exist_ok=True)
    archive_path = ROOT / 'benchmarks/evidence/channel-tail-c6a2bd0a.tar.gz'
    assert evidence.digest(archive_path) == '7cd42245ad82c5333b09b0b0c251b03ae2ba4276dc2ea83b67367983f619d861'
    # Copy an existing fixture byte-for-byte, never generate a new workload.
    with tarfile.open(archive_path) as archive:
        for name in ['control.rs', 'control_test.rs']:
            old = ROOT / 'target/finish-line/idle-budget' / name
            expected = archive.extractfile(f'idle-budget/{name}').read()
            assert evidence.digest(old) == hashlib.sha256(expected).hexdigest()
            path = fixture / name
            if not path.exists():
                shutil.copy2(old, path)
            assert evidence.digest(path) == evidence.digest(old)
    evidence.ROOT = args.source.resolve()
    manifest = evidence.metadata(f'eligible channel {args.arm}; unchanged idle-budget fixture')
    expected = json.loads((OUT / f'{args.arm}-source.json').read_text())
    assert manifest['source_sha256'] == expected['source_sha256']
    environment = dict(os.environ, CARGO_TARGET_DIR=str(BUILD), CARGO_INCREMENTAL='0')
    manifest['build_environment'] = {key: environment[key] for key in ['CARGO_TARGET_DIR', 'CARGO_INCREMENTAL']}
    prefix = f'idle-{args.arm}'
    run(prefix + '-library-build', ['cargo', 'build', '--locked', '--release', '--manifest-path',
                                  'benchmarks/Cargo.toml', '--message-format=json'],
        args.source, environment, manifest)
    artifacts = []
    for line in (OUT / f'{prefix}-library-build.log').read_text().splitlines():
        if not line.startswith('{'):
            continue
        value = json.loads(line)
        if value.get('reason') == 'compiler-artifact' and value['target']['name'] == 'vthread':
            artifacts.append(value)
    assert len(artifacts) == 1
    artifact = artifacts[0]
    assert artifact['features'] == ['default'] and not artifact['profile']['test']
    libraries = [Path(name) for name in artifact['filenames'] if name.endswith('.rlib')]
    assert len(libraries) == 1
    library = libraries[0]
    manifest.update(library_sha256=evidence.digest(library), library_artifact=artifact,
                    fixture_sha256={name: evidence.digest(fixture / name)
                                    for name in ['control.rs', 'control_test.rs']})
    rustc = ['rustc', '--edition=2024', '-C', 'opt-level=3', '-D', 'warnings',
             '--crate-name', 'idle_budget', str(fixture / 'control.rs'), '--extern',
             f'vthread={library}', '-L', f'dependency={library.parent}']
    tests, binary = OUT / f'{prefix}-tests', OUT / f'{prefix}-control'
    assert not tests.exists() and not binary.exists()
    run(prefix + '-test-build', [*rustc, '--test', '-o', str(tests)], args.source, environment, manifest)
    run(prefix + '-test', [str(tests), '--test-threads=1'], args.source, environment, manifest)
    run(prefix + '-build', [*rustc, '-o', str(binary)], args.source, environment, manifest)
    assert evidence.source_digest() == expected['source_sha256']
    manifest.update(binary_sha256=evidence.digest(binary), tests_sha256=evidence.digest(tests))
    with (OUT / f'{prefix}-source.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
    print('frozen', prefix, manifest['source_sha256'], manifest['binary_sha256'], flush=True)


if __name__ == '__main__':
    main()
