"""Protect work denominators, independent pairs and collector balance."""

import unittest

from acceptance import paired
from panel import cases, screen_plan


class AcceptanceTests(unittest.TestCase):
    def test_every_cell_balances_arms_and_collectors(self):
        for stage in ['local', 'remote', 'population']:
            jobs = screen_plan(stage)
            self.assertEqual(len(jobs), len(cases(stage)) * 16)
            self.assertEqual(len({job['prefix'] for job in jobs}), len(jobs))
            for case in cases(stage):
                group = [job for job in jobs if job['case'] == case]
                for collector in ['bare', 'perf']:
                    first = [job['arm'] for i, job in enumerate(group)
                             if i % 2 == 0 and job['collector'] == collector]
                    self.assertCountEqual(first, ['A', 'A', 'B', 'B'])
                self.assertCountEqual([job['collector'] for job in group[::4]],
                                      ['bare', 'bare', 'perf', 'perf'])

    def test_work_denominator_counts_values_once(self):
        for stage in ['local', 'remote', 'population']:
            for case in cases(stage):
                self.assertEqual(case['args'][0], 'channel-mpmc')
                self.assertEqual(case['per_task'], int(case['args'][1]))
                self.assertEqual(case['args'][2], '1')
                self.assertEqual(case['workers'], int(case['args'][3]))
                self.assertEqual(case['tasks'], int(case['args'][4]))
                self.assertEqual(case['rounds'], int(case['args'][5]))
                self.assertEqual(case['operation_tasks'] * 2, case['tasks'])
                self.assertEqual(case['pinned'], '--pin-carriers' in case['args'])

    def test_gross_stop_requires_three_losses(self):
        self.assertTrue(paired([1] * 4, [1.2] * 4)['gross_bare_stop'])
        self.assertFalse(paired([1] * 4, [.9, 1, 1.5, 1.5])['gross_bare_stop'])
        with self.assertRaises(AssertionError):
            paired([1] * 4, [1] * 3)


if __name__ == '__main__':
    unittest.main()
