# Conditional protected panel, declared before its first process

Run this only if the local, small-remote and population screens survive their
existing stop rule. The unchanged A/B default binaries remain the subjects. No
new polling, queue representation, ownership or scheduler candidate is allowed.

First screen endpoint tails with four new balanced bare pairs at capacity one:
one carrier/eight tasks, four carriers/eight tasks, and four carriers/64 tasks.
Keep default placement and individual pinning separate in both remote shapes.
Use 1,000 values per producer and 101 measured rounds plus warmup. The existing
`--sample-channel-latency` flag measures complete endpoint calls with Instant
overhead included. Its elapsed time is not the untimed headline throughput.
Require exact observation counts for both directions and all logical streams;
report each direction's p99.9, p99.99 and worst-stream latency, not only the merged
distribution. These remain closed-loop observations, not offered-load evidence.

Next screen spare task capacity (1,024 and 65,536 at four carriers/64 live tasks),
buffer capacities 64 and 1,024, and unaffected lifecycle, yield, park, mutex and
timestamped-wake controls. Use the existing four-pair early timing stop and keep
every outcome. If that stop fires, subsequent conditional jobs remain unrun;
there is no reason to qualify a rejected optional candidate more broadly.

Reuse the public-API idle-budget fixture from channel-tail-c6a2bd0a, without
changing its operation protocol: four-carrier/eight-task two-second quiet parks
at tight and 65,536 capacity, 2,000 waves separated by 1 ms, 5,000 waves separated
by 100 us, plus the one-carrier burst control and eight-carrier/16-task burst.
Build both arms from their exact sources, save executable/library hashes, and
run fixture tests before timing. Preserve selected-wake/stored-permit counts,
wave/task identities and final drainage. Use post-exit wait4 CPU accounting;
do not add live sampling. The quiet/burst fixture is not an open-loop workload.

If all screens survive, each protected cell receives exactly twelve new bare
pairs in balanced order. Apply the already declared 5% time/CPU and 10% endpoint
tail/worst-stream margins using the fixed-seed 95% upper bootstrap bound. Report
inconclusive cells as held. No repeat-until-green runs or replacement samples.
Canonical qualification, inventory review, source-keyed evidence and release
limitations remain separate requirements. No timings in this file predate its
declaration; it schedules only conditional, not-yet-started work.
