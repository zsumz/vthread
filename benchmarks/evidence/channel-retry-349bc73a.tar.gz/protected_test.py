"""Protect exact work counts and independently balanced control cells."""

import unittest
from protected import cases, plan


class ProtectedTests(unittest.TestCase):
    def test_all_shapes_have_complete_independent_pairs(self):
        for stage in ['capacity', 'unaffected']:
            jobs = plan(stage)
            self.assertEqual(len(jobs), len(cases(stage)) * 8)
            self.assertEqual(len({job['prefix'] for job in jobs}), len(jobs))
            for case in cases(stage):
                group = [job for job in jobs if job['case'] == case]
                self.assertEqual([job['arm'] for job in group[::2]], ['A', 'B', 'A', 'B'])
                self.assertTrue(all(job['collector'] == 'bare' for job in group))

    def test_resource_capacity_does_not_change_useful_work(self):
        for stage in ['capacity', 'unaffected']:
            for case in cases(stage):
                args = case['args']
                self.assertEqual(case['capacity'], int(args[args.index('--max-vthreads') + 1]))
                self.assertEqual(case['pinned'], '--pin-carriers' in args)
                self.assertGreaterEqual(case['capacity'], max(case['tasks'], case['workers']))
                if args[0] == 'spawn':
                    self.assertEqual(args[1:4], ['4', str(case['tasks']), str(case['rounds'])])
                    self.assertEqual(case['per_task'], 1)
                else:
                    offset = 3 if args[0] == 'channel-mpmc' else 2
                    self.assertEqual(case['per_task'], int(args[1]))
                    self.assertEqual(args[offset:offset + 3], ['4', str(case['tasks']), str(case['rounds'])])
                divisor = 2 if args[0] == 'channel-mpmc' else 1
                self.assertEqual(case['operation_tasks'] * divisor, case['tasks'])


if __name__ == '__main__':
    unittest.main()
