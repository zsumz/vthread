"""Freeze separately identified default binaries, without altering benchmark flags."""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('arm', choices=['A', 'B'])
    args = parser.parse_args()
    manifest = evidence.metadata(f'eligible channel recovery arm {args.arm}; default native')
    if args.arm == 'A':
        assert not manifest['dirty']
        assert manifest['source_sha256'] == 'd38dcb8627f61e49f3f95e46c270b9349c6629365060ac98e2dab6bbb00bfa94'
    environment = dict(os.environ, CARGO_TARGET_DIR=str(BUILD), CARGO_INCREMENTAL='0')
    manifest['build_environment'] = {key: environment[key] for key in ('CARGO_TARGET_DIR', 'CARGO_INCREMENTAL')}
    commands = [
        ('format', ['cargo', 'fmt', '--manifest-path', 'benchmarks/Cargo.toml', '--', '--check']),
        ('test', ['cargo', 'test', '--locked', '--manifest-path', 'benchmarks/Cargo.toml']),
        ('clippy', ['cargo', 'clippy', '--locked', '--manifest-path', 'benchmarks/Cargo.toml', '--', '-D', 'warnings']),
        ('build', ['cargo', 'build', '--locked', '--release', '--manifest-path', 'benchmarks/Cargo.toml']),
        ('features', ['cargo', 'tree', '--locked', '--manifest-path', 'benchmarks/Cargo.toml', '-e', 'features']),
    ]
    for name, command in commands:
        prefix = f'{args.arm}-{name}'
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, source=manifest), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=600)
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(dict(returncode=result.returncode), stream)
        assert result.returncode == 0, prefix
        print(prefix, 'passed', flush=True)
    assert manifest['source_sha256'] == evidence.source_digest()
    binary = OUT / f'benchmark-{args.arm}'
    assert not binary.exists()
    shutil.copy2(BUILD / 'release/vthread-benchmarks', binary)
    manifest.update(binary_sha256=evidence.digest(binary), features='default; no profiling or allocation probe',
                    benchmark_lock_sha256=evidence.digest(ROOT / 'benchmarks/Cargo.lock'))
    paths = evidence.output('git', 'ls-files', '--cached', '--others', '--exclude-standard').splitlines()
    with tarfile.open(OUT / f'{args.arm}-source.tar.gz', 'x:gz') as archive:
        for name in sorted(set(paths)):
            if (ROOT / name).suffix in {'.rs', '.toml', '.lock', '.py', '.sh', '.yml'}:
                archive.add(ROOT / name, arcname=name, recursive=False)
    manifest['source_archive_sha256'] = evidence.digest(OUT / f'{args.arm}-source.tar.gz')
    with (OUT / f'{args.arm}-source.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
    with (OUT / f'{args.arm}-tracked.patch').open('x') as stream:
        stream.write(evidence.output('git', 'diff', 'HEAD'))
    print('frozen', args.arm, manifest['source_sha256'], manifest['binary_sha256'], flush=True)


if __name__ == '__main__':
    main()
