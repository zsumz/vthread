"""Fixed bare protection cells: capacity/buffering, then unaffected mechanisms."""

import argparse
from panel import run


def expand(name, args, operation, tasks, per_task, rounds, capacity, operation_tasks=None):
    return [dict(name=name + ('-pinned' if pinned else '-default'), mask='0-3',
                 args=args + ['--max-vthreads', str(capacity)] + (['--pin-carriers'] if pinned else []),
                 operation=operation, workers=4, tasks=tasks, per_task=per_task, rounds=rounds,
                 capacity=capacity, operation_tasks=operation_tasks or tasks, pinned=pinned)
            for pinned in [False, True]]


def cases(stage):
    result = []
    if stage == 'capacity':
        for buffer, capacity in [(1, 1024), (1, 65536), (64, 64), (1024, 64)]:
            result += expand(f'mpmc{buffer}-1000v-4c-64t-cap{capacity}',
                             ['channel-mpmc', '1000', str(buffer), '4', '64', '101'],
                             f'bounded-mpmc-channel-{buffer}-transfer', 64, 1000, 101, capacity, 32)
        return result
    assert stage == 'unaffected'
    for tasks, rounds, capacity in [(1000, 501, 1000), (1000, 501, 65536), (10000, 101, 10000)]:
        result += expand(f'spawn-{tasks}t-cap{capacity}', ['spawn', '4', str(tasks), str(rounds)],
                         'task', tasks, 1, rounds, capacity)
    for scenario, operation, count in [('yield', 'yield', 100000), ('park', 'park-handoff', 10000),
                                        ('mutex', 'mutex-handoff', 10000),
                                        ('channel', 'channel-handoff', 10000),
                                        ('wake-tail', 'wake-to-resume', 1000)]:
        result += expand(f'{scenario}-{count}v-4c-64t', [scenario, str(count), '4', '64', '101'],
                         operation, 64, count, 101, 64)
    return result


def plan(stage, repetitions=4, name=None):
    name = name or stage
    jobs = []
    for rep in range(1, repetitions + 1):
        for case in (cases(stage) if rep % 2 else list(reversed(cases(stage)))):
            for arm in (['A', 'B'] if rep % 2 else ['B', 'A']):
                jobs.append(dict(prefix=f'{name}-{rep}-{case["name"]}-bare-{arm}',
                                 repetition=rep, collector='bare', arm=arm, case=case))
    return jobs


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['capacity', 'unaffected'])
    args = parser.parse_args()
    groups = run(args.stage, plan(args.stage))
    print('early stop cells:', [key for key, group in groups.items()
                               if group['timing_effect']['gross_bare_stop']], flush=True)
