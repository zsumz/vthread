"""Freeze exact source bytes before each protocol experiment, including new tests."""

import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

name = sys.argv[1]
manifest = evidence.metadata(name)
paths = evidence.output('git', 'ls-files', '--cached', '--others', '--exclude-standard').splitlines()
with tarfile.open(OUT / f'{name}-source.tar.gz', 'x:gz') as archive:
    for path in sorted(set(paths)):
        if (ROOT / path).suffix in {'.rs', '.toml', '.lock', '.py', '.sh', '.yml'} and (ROOT / path).is_file():
            archive.add(ROOT / path, arcname=path, recursive=False)
manifest['archive_sha256'] = evidence.digest(OUT / f'{name}-source.tar.gz')
with (OUT / f'{name}-source.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
with (OUT / f'{name}.patch').open('x') as stream:
    subprocess.run(['git', 'diff', 'HEAD'], cwd=ROOT, stdout=stream, check=True)
assert manifest['source_sha256'] == evidence.source_digest()
print(manifest['source_sha256'])
