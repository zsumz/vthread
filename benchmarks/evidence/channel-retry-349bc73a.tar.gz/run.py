"""Record immutable, source-keyed qualification and expected negative controls."""

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

parser = argparse.ArgumentParser()
parser.add_argument('--expect', type=int, default=0)
parser.add_argument('name')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[0] == '--' else args.command
environment = dict(os.environ, CARGO_TARGET_DIR='/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI',
                   CARGO_INCREMENTAL='0')
manifest = evidence.metadata(args.name)
with (OUT / f'{args.name}.command.json').open('x') as stream:
    json.dump(dict(command=command, source=manifest, expected_exit=args.expect), stream, indent=2)
with (OUT / f'{args.name}.patch').open('x') as stream:
    stream.write(evidence.output('git', 'diff', 'HEAD'))
with (OUT / f'{args.name}.log').open('x') as stream:
    result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
with (OUT / f'{args.name}.result.json').open('x') as stream:
    json.dump(dict(returncode=result.returncode, finished_unix=time.time()), stream)
assert manifest['source_sha256'] == evidence.source_digest()
print((OUT / f'{args.name}.log').read_text()[-12000:])
assert result.returncode == args.expect, (args.name, result.returncode, args.expect)
