"""Reused event accounting with strict per-carrier coverage and no timing acceptance."""

import json
from pathlib import Path
import re
import sys

OUT = Path(__file__).resolve().parent
NAMES = ('attach', 'enqueue', 'rearm', 'rearm_clone', 'take_turn', 'remove', 'retire')


def parse(text, workers, values):
    channels, tickets = {}, {}
    native_waits = {}
    totals = {direction: {} for direction in ('Send', 'Receive')}
    for line in text.splitlines():
        fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
        phase = fields.get('phase')
        if phase == 'handoff-duration' and fields['stage'] == 'NativeWait':
            carrier = int(fields['carrier'])
            assert carrier not in native_waits
            native_waits[carrier] = int(fields['count'])
        if phase not in ('handoff-channel', 'handoff-ticket'):
            continue
        key = (int(fields['carrier']), fields['direction'])
        if phase == 'handoff-ticket':
            counts = json.loads(re.search(r'counts=(\[[^]]*\])', line)[1])
            assert len(counts) == len(NAMES) and key not in tickets
            tickets[key] = dict(zip(NAMES, counts))
        else:
            assert key not in channels
            channels[key] = {key: int(value) for key, value in fields.items()
                             if value.isdigit() and key != 'carrier'}
    expected = {(carrier, direction) for carrier in range(workers) for direction in totals}
    assert channels.keys() == tickets.keys() == expected
    assert native_waits.keys() == set(range(workers))
    for (_, direction), counts in channels.items():
        for key, value in counts.items():
            totals[direction][key] = totals[direction].get(key, 0) + value
    for (_, direction), counts in tickets.items():
        for key, value in counts.items():
            totals[direction][key] = totals[direction].get(key, 0) + value
    for counts in totals.values():
        assert counts['transfers'] == values
        assert counts['enqueue'] == counts['take_turn'] + counts['remove']
        assert counts['rearm'] == counts['retries']
        assert counts['rearm_clone'] <= counts['rearm']
        assert counts['retire'] == counts['parks']
        assert counts['parks'] <= counts['park_calls']
        assert counts['park_returns'] == counts['retries'] + counts['resumed_transfers'] + counts['resumed_exits']
        assert counts['attach'] <= counts['calls']
        counts['notification_attempts'] = sum(counts[key] for key in (
            'selected_notifications', 'stored_notifications', 'closed_notifications'))
    ratios = {key: sum(counts[key] for counts in totals.values()) / values
              for key in ('attach', 'enqueue', 'rearm', 'rearm_clone', 'retire',
                          'notification_attempts', 'selected_notifications', 'stored_notifications',
                          'park_calls', 'parks', 'retries')}
    return dict(values=values, directions=totals, per_value=ratios,
                native_wait_calls=sum(native_waits.values()),
                native_wait_calls_per_value=sum(native_waits.values()) / values)


def summarize(arm):
    jobs = json.loads((OUT / f'diagnostic-{arm}-plan.json').read_text())
    assert len(jobs) == 6
    results = {}
    for job in jobs:
        prefix = job['prefix']
        for phase in ('before', 'after'):
            assert not (OUT / f'{prefix}.{phase}.guard').read_text().strip()
        result = json.loads((OUT / f'{prefix}.result.json').read_text())
        assert result['returncode'] == 0
        parsed = parse((OUT / f'{prefix}.log').read_text(), job['workers'], job['tasks'] // 2 * 1000 * 8)
        results[prefix] = parsed
        print(prefix, 'values', parsed['values'], 'parks/value', round(parsed['per_value']['parks'], 4),
              'retries/value', round(parsed['per_value']['retries'], 4),
              'rearm clones/value', round(parsed['per_value']['rearm_clone'], 4),
              'native wait API calls/value', round(parsed['native_wait_calls_per_value'], 4))
    with (OUT / f'diagnostic-{arm}-analysis.json').open('x') as stream:
        json.dump(results, stream, indent=2)


if __name__ == '__main__':
    summarize(sys.argv[1])
