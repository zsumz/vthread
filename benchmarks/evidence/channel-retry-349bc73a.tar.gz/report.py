"""Derive the screen table from complete paired results, never select samples."""

import json
from pathlib import Path
import statistics

OUT = Path(__file__).resolve().parent


def main():
    print('case | bare time % | bare CPU % | bare time ratios | counter time % | counter CPU %')
    count = 0
    stopped = []
    for stage in ['local', 'remote', 'population']:
        jobs = json.loads((OUT / f'{stage}-plan.json').read_text())
        groups = json.loads((OUT / f'{stage}-analysis.json').read_text())
        count += len(jobs)
        for group in groups.values():
            if group['collector'] != 'bare':
                continue
            other = groups[group['case']['name'] + '-perf']
            values = [group['timing_effect']['median_ratio'], group['cpu_effect']['median_ratio'],
                      other['timing_effect']['median_ratio'], other['cpu_effect']['median_ratio']]
            print(group['case']['name'], '|', f'{100 * (values[0] - 1):+.2f}', '|',
                  f'{100 * (values[1] - 1):+.2f}', '|',
                  ', '.join(f'{ratio:.4f}' for ratio in group['timing_effect']['ratios']), '|',
                  f'{100 * (values[2] - 1):+.2f}', '|', f'{100 * (values[3] - 1):+.2f}')
            if group['timing_effect']['gross_bare_stop']:
                stopped.append(group['case']['name'])
    print('completed planned processes:', count, 'gross stops:', stopped)
    for stage in ['remote', 'population']:
        groups = json.loads((OUT / f'{stage}-analysis.json').read_text())
        for group in groups.values():
            if group['case']['per_task'] != 10000 or not group['case']['pinned']:
                continue
            for arm in ['A', 'B']:
                print('mode diagnostic', group['case']['name'], group['collector'], arm,
                      'median process voluntary switches', statistics.median(
                          row['resources']['voluntary_switches'] for row in group[arm]),
                      'median CPU seconds', statistics.median(
                          row['resources']['user_seconds'] + row['resources']['system_seconds']
                          for row in group[arm]))


if __name__ == '__main__':
    main()
