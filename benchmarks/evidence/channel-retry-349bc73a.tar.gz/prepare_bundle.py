"""Copy exact replay dependencies and the completed retained qualification."""

import json
from pathlib import Path
import shutil

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
dependencies = OUT / 'replay-dependencies'
dependencies.mkdir(exist_ok=False)
reference = ROOT / 'target/finish-line/may-refresh.yvxHtB'
for name in ['analyze.py', 'cases.py']:
    shutil.copy2(reference / name, dependencies / name)
shutil.copy2(ROOT / 'scripts/evidence.py', dependencies / 'evidence.py')
receipt = Path('/root/.cache/zcheck/run-1788731794-405597480-3338421')
record = json.loads((receipt / 'receipt.json').read_text())
assert record['status'] == 'passed' and record['repository']['preserved']
assert len(record['tasks']) == 14 and all(task['status'] == 'passed' for task in record['tasks'])
shutil.copytree(receipt, OUT / 'retained-canonical')
print('Copied exact replay dependencies and fourteen-gate preserved-checkout qualification.')
