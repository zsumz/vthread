"""Report every capacity and endpoint cell, including unfavorable pairs."""

import json
from pathlib import Path
import statistics

OUT = Path(__file__).resolve().parent

for stage in ['capacity', 'tails']:
    groups = json.loads((OUT / f'{stage}-analysis.json').read_text())
    for key, group in groups.items():
        print(key, 'time change %', round(100 * (group['timing_effect']['median_ratio'] - 1), 2),
              'CPU change %', round(100 * (group['cpu_effect']['median_ratio'] - 1), 2),
              'time pairs', group['timing_effect']['ratios'],
              'CPU pairs', group['cpu_effect']['ratios'])
        if stage == 'capacity' and group['case']['capacity'] == 1024:
            for arm in ['A', 'B']:
                print(arm, 'voluntary switches', [row['resources']['voluntary_switches'] for row in group[arm]],
                      'involuntary switches', [row['resources']['involuntary_switches'] for row in group[arm]],
                      'CPU seconds', [round(row['resources']['user_seconds'] + row['resources']['system_seconds'], 3)
                                      for row in group[arm]])

groups = json.loads((OUT / 'tails-directions.json').read_text())
for name, group in groups.items():
    for direction in ['send', 'receive']:
        print(name, direction,
              {key: {arm: statistics.median(value[direction]['channel-latency'][key]
                                            for _, value in group[arm]) for arm in ['A', 'B']}
               for key in ['p99_9_ns', 'p99_99_ns', 'max_ns']})
