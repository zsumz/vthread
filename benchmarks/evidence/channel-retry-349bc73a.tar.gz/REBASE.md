# Exact candidate recovery boundary

The default production bodies of channel.rs, channel/core.rs and
channel/endpoints.rs have Git blob hashes 0f28b2ab, 3471e22d and c4f1cea6,
matching the archived eligible candidate exactly. There is no sixth channel
layout or change to parked polling, admission, dispatch fairness or affinity.

Changes relative to that archived patch are its rebasing onto the retained
publication-progress runtime, the context-adjusted ResourcePublication re-export,
the previously developed seven-event diagnostics, and test/model qualification.
The diagnostic getter for an entry handle is available under the profiling
feature as well as tests. Ticket rearm counts that missing handle before the
original rearm operation, without cloning it for observation. No profiling
branch is present in default acceptance builds.

The native test-only protocol wrapper runs the same entry tests under the Loom
adapter; the model crate expects only the production diagnostic cfg mismatch on
that imported module. The recovered late-offer/retirement/reuse regression covers
direct cancellation, inherited cancellation and timeout. It adds no production
state transition. The existing model deliberately counts routed wakes rather
than implementing native signaling; the retained 17-test publication model is a
separate composition check, not a proof of the complete channel/runtime program.
