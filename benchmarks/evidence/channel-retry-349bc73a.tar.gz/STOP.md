# Stop the eligible-channel replay at the capacity screen

All 264 planned performance processes complete: 32 local, 64 small-remote, 64
population, 40 endpoint-tail and 64 capacity/buffer controls. There are 80 PMU
processes and 184 bare processes. All endpoint build guards are clear. Twelve
separate clocked diagnostic processes also complete; their timings are not
default-build acceptance. No failed or unfavorable process is replaced.

The default-placement 4-carrier/64-task/capacity-1,024 bare cell triggers the
predeclared stop. Its four B/A ratios are 1.437263, 1.210698, 0.655877 and 1.397505.
Three exceed 1.10; the median paired ratio is 1.304101. The large favorable local,
long-run, buffer and capacity-65,536 effects do not waive this protected loss.
This four-pair rule is a conservative stop decision, not a confidence claim that
all production workloads regress by 30.41%.

Do not run the conditional unaffected panel, idle/burst builds or processes,
twelve-pair confirmation, candidate canonical gate or a rescue implementation.
The prepared helper/fixture plans remain unrun, not silently counted as evidence.
Their parser tests can be qualified independently without performance collection.
The optional candidate is rejected, not a retained speedup or a release fix.

Preserve the exact final source 349bc73a, both default binaries, both profiling
binaries, all source snapshots, setup failures, native/production-word models,
ordered negative controls and every raw observation. Stash 844ec84dce1fd0696604de51eb7408fd2293a56f
contains the complete candidate and diagnostic/model changes. Production source
is restored to d38dcb8627f61e49f3f95e46c270b9349c6629365060ac98e2dab6bbb00bfa94.
No architecture inventory refresh, runtime grant or polling change was made.

The channel's useless-crossing mechanism is demonstrated: approximately three
actual parks per value become two in the local clocked fixture, with no retry or
rearm clone in B. Counter collection can reverse the long small-remote timing
effect. Neither observation alone identifies why the intermediate-capacity bare
case loses. Use the saved post-exit accounting and a precisely scoped future
attribution before another implementation; do not increase the polling budget.

Restore and qualify the retained runtime, archive the evidence durably, and then
advance to the independent production mutex ownership-round-trip attribution.
There is no new May comparison. Capacity-independent maintenance, readiness
acceptance, bounded pre-dispatch service and the separate release matrix remain
open.
