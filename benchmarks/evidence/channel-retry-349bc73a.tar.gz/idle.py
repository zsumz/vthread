"""Counter-free reuse of the existing quiet/burst fixture and post-exit accounting."""

import ast
import json
import os
from pathlib import Path
import re
import subprocess
import time

from acceptance import fields, paired
from panel import OUT, ROOT, evidence, observe


def cases():
    return [dict(name=name, mask=mask, workers=workers, tasks=tasks, capacity=capacity,
                 gap_us=gap, waves=waves, args=list(map(str, [workers, tasks, capacity, gap, waves])))
            for name, mask, workers, tasks, capacity, gap, waves in [
                ('quiet4', '0-3', 4, 8, 8, 2000000, 0),
                ('quiet4-spare', '0-3', 4, 8, 65536, 2000000, 0),
                ('burst4-1ms', '0-3', 4, 8, 8, 1000, 2000),
                ('burst4-100us', '0-3', 4, 8, 8, 100, 5000),
                ('burst1-1ms', '0', 1, 8, 8, 1000, 2000),
                ('burst8-1ms', '0-7', 8, 16, 16, 1000, 2000)]]


def plan(name='idle', repetitions=4):
    jobs = []
    for rep in range(1, repetitions + 1):
        for case in (cases() if rep % 2 else list(reversed(cases()))):
            for arm in (['A', 'B'] if rep % 2 else ['B', 'A']):
                jobs.append(dict(prefix=f'{name}-{rep}-{case["name"]}-bare-{arm}',
                                 repetition=rep, collector='bare', arm=arm, case=case))
    return jobs


def parse(text, case):
    records = {}
    for phase in ['contract', 'initial-parked', 'interval', 'drained']:
        found = [line for line in text.splitlines() if line.startswith(f'phase={phase} ')]
        assert len(found) == 1
        records[phase] = fields(found[0])
        if phase == 'initial-parked':
            owners = ast.literal_eval(re.search(r'owner_counts=(\[[^]]*\])', found[0])[1])
            assert len(owners) == case['workers'] and sum(owners) == case['tasks']
            assert all(isinstance(count, int) and count >= 0 for count in owners)
    contract = records['contract']
    for key, expected in [('carriers', 'workers'), ('tasks', 'tasks'), ('capacity', 'capacity'),
                          ('quiet_gap_us', 'gap_us'), ('waves', 'waves')]:
        assert int(contract[key]) == case[expected]
    assert contract['individual_pinning'] == contract['open_loop'] == 'false'
    initial = records['initial-parked']
    assert int(initial['parked']) == case['tasks'] and int(initial['timers']) == 0
    interval = {key: int(value) for key, value in records['interval'].items() if value.isdigit()}
    drained = {key: int(value) for key, value in records['drained'].items() if value.isdigit()}
    assert interval['selected_wakes'] + interval['stored_permits'] == interval['acknowledgements']
    assert interval['acknowledgements'] == case['waves'] * case['tasks']
    assert interval['elapsed_ns'] >= case['gap_us'] * 1000
    assert drained['active'] == 0 and drained['completed'] == case['tasks']
    assert case['tasks'] <= drained['parks'] <= (case['waves'] + 1) * case['tasks']
    assert drained['parks'] == drained['wakes']
    return dict(interval=interval, drained=drained, initial_owners=owners)


def analyze(name, jobs):
    groups = {}
    for job in jobs:
        prefix = job['prefix']
        result = json.loads((OUT / f'{prefix}.result.json').read_text())
        assert result['returncode'] == 0
        for phase in ['before', 'after']:
            assert not (OUT / f'{prefix}.{phase}.guard').read_text().strip()
        row = parse((OUT / f'{prefix}.log').read_text(), job['case'])
        row.update(prefix=prefix, repetition=job['repetition'], resources=result['resources'])
        row['cpu_seconds'] = result['resources']['user_seconds'] + result['resources']['system_seconds']
        groups.setdefault(job['case']['name'], dict(case=job['case'], A=[], B=[]))[job['arm']].append(row)
    for group in groups.values():
        for arm in ['A', 'B']:
            group[arm].sort(key=lambda row: row['repetition'])
        assert [row['repetition'] for row in group['A']] == [row['repetition'] for row in group['B']]
        group['time_effect'] = paired([row['interval']['elapsed_ns'] for row in group['A']],
                                       [row['interval']['elapsed_ns'] for row in group['B']])
        group['cpu_effect'] = paired([row['cpu_seconds'] for row in group['A']],
                                    [row['cpu_seconds'] for row in group['B']])
        print(group['case']['name'], 'time', group['time_effect'], 'CPU', group['cpu_effect'], flush=True)
    with (OUT / f'{name}-analysis.json').open('x') as stream:
        json.dump(groups, stream, indent=2)
    return groups


def run(name, jobs):
    source = evidence.source_digest()
    manifests = {arm: json.loads((OUT / f'idle-{arm}-source.json').read_text()) for arm in ['A', 'B']}
    assert source == manifests['B']['source_sha256']
    for arm, manifest in manifests.items():
        assert manifest['binary_sha256'] == evidence.digest(OUT / f'idle-{arm}-control')
    with (OUT / f'{name}-plan.json').open('x') as stream:
        json.dump(jobs, stream, indent=2)
    for index, job in enumerate(jobs):
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '60s', 'taskset', '-c', job['case']['mask'],
                   str(OUT / f'idle-{job["arm"]}-control'), *job['case']['args']]
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, started_unix=time.time(), job=job,
                           source=manifests[job['arm']]), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            process = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            pid, status, usage = os.wait4(process.pid, 0)
            assert pid == process.pid
            process.returncode = os.waitstatus_to_exitcode(status)
        result = dict(returncode=process.returncode, finished_unix=time.time(), resources=dict(
            user_seconds=usage.ru_utime, system_seconds=usage.ru_stime, peak_rss_kib=usage.ru_maxrss,
            voluntary_switches=usage.ru_nvcsw, involuntary_switches=usage.ru_nivcsw))
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(result, stream, indent=2)
        observe(prefix, 'after')
        assert process.returncode == 0, (prefix, process.returncode)
        parse((OUT / f'{prefix}.log').read_text(), job['case'])
        print(f'{index + 1}/{len(jobs)} {prefix} passed', flush=True)
    assert source == evidence.source_digest()
    return analyze(name, jobs)


if __name__ == '__main__':
    run('idle', plan())
