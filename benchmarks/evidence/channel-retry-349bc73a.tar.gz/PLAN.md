# Re-evaluate existing eligible channel turns, not another layout

Base: pushed checkpoint 028d40a, native source d38dcb86. Preserve the restored
execution/scheduler/wake protocol, including publication deferral, checkpoints,
affinity, capacity scans, 640 probes, ready fairness, admission fairness and
direct mutex ownership. There is no May refresh or HTTP work in this slice.

First build a pristine default A. Reuse the historical seven-event channel ticket
diagnostics on the retained source, with their ordered accounting regression and
a deliberate rearm misclassification negative control. Reproduce the existing
shared capacity-one channel with eight tasks, 1,000 values per producer, seven
measured rounds plus warmup: 32,000 useful values per process. Keep actual parks,
park API calls/returns, retries, initial tickets, rearms and clone/retirement
counts distinct. Native clocked diagnostics are never acceptance timings.

Then restore the same baseline and reproduce exactly historical eligible-grant
candidate A from channel-publication-56f61f86, labeling it B here. Preserve FIFO
identity/accounting under the lock, owned resource publication outside it, the
immediate success path, selected cancellation cleanup and all historical tests.
Adapt only drifted private test/runtime interfaces needed for the current source.
Do not add a new channel implementation, payload transfer or polling policy.

Before timing, require targeted native correctness and the reusable protocol
model where applicable. The complete current composition and canonical suite
remain promotion gates even if the early performance screen survives.

Use the existing counter-free acceptance rules: four balanced A/B independent
process pairs per case and collection mode; separate bare and the existing five
perf-stat events. No new event group. Bare time median paired ratio >1.10 with
three of four >1.10 losses stops the candidate. Keep every planned outcome and
never fill an invalid or failed run with a replacement. A held/incomplete proof
cannot become promotion because one performance case looks good.

Screen capacity-one shared MPMC at 1 carrier/8 tasks, then 4 carriers/8 tasks,
with default placement and individually pinned four-carrier controls separate.
Use two fixed work counts (1,000 and 10,000 per producer), 101 measured rounds
plus warmup, to expose fixed setup versus recurring work; operation denominator
is producer count, not total tasks. Local mask 0; remote mask 0-3. Do not silently
co-locate communicating tasks or treat a shared hub as measured remote placement.
Only after those screens survive advance to 4 carriers/64 tasks, burst/idle CPU,
endpoint tails, spare capacity and full confirmation. Do not exceed two new
implementations without new mechanism evidence; this replay is not a new design.

For both arms run two timed diagnostic processes per 1c/8t, 4c/8t and 4c/64t
shape (1,000 values/producer, seven measured rounds, capacity one, pinned).
Report scheduler native waiting and channel useful-work ratios, with the known
instrumentation distortion stated. Post-exit bare voluntary context switches and
CPU stay separate. More sleeping is a hypothesis until these observations support
it; it is never a justification for a larger spin budget.

Archive all source/binary identities, commands, exact candidate patch, negatives,
diagnostics, raw acceptance attempts and stop decisions. One runtime candidate
at a time. If it loses, shelve it and restore/qualify the retained runtime.
