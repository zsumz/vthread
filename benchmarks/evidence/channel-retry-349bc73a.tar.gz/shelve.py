"""Preserve only this verified candidate, then verify the retained runtime exactly."""

import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

EXPECTED = {
    'benchmarks/src/handoff_profile.rs',
    'crates/vthread-sync-core/tests/channel_publication_model.rs',
    'crates/vthread-sync-core/tests/support/channel_wait_model.rs',
    'crates/vthread/src/channel.rs',
    'crates/vthread/src/channel/core.rs',
    'crates/vthread/src/channel/endpoints.rs',
    'crates/vthread/src/channel/entry.rs',
    'crates/vthread/src/channel/entry_test.rs',
    'crates/vthread/src/channel/publication.rs',
    'crates/vthread/src/channel/publication_test.rs',
    'crates/vthread/src/channel/reservation_test.rs',
    'crates/vthread/src/channel/wait.rs',
    'crates/vthread/src/handoff_channel.rs',
    'crates/vthread/src/handoff_channel_test.rs',
    'crates/vthread/src/sync/wait.rs',
    'crates/vthread/src/wait.rs',
    'crates/vthread/src/wait_finish.rs',
    'crates/vthread/src/wait_resource.rs',
}


def main():
    before = evidence.metadata('shelve rejected eligible-channel candidate')
    assert before['source_sha256'] == json.loads((OUT / 'B-source.json').read_text())['source_sha256']
    assert set(evidence.output('git', 'diff', '--name-only', 'HEAD').splitlines()) == EXPECTED
    assert not evidence.output('git', 'ls-files', '--others', '--exclude-standard')
    assert evidence.output('git', 'diff', 'HEAD') == (OUT / 'B-tracked.patch').read_text().strip()
    command = ['git', 'add', '--', *sorted(EXPECTED)]
    subprocess.run(command, cwd=ROOT, check=True)
    stash_command = ['git', 'stash', 'push', '-m', 'perf: preserve eligible channel counter-free candidate']
    output = subprocess.check_output(stash_command, cwd=ROOT, text=True)
    saved = evidence.output('git', 'rev-parse', 'stash@{0}')
    assert not evidence.output('git', 'status', '--porcelain')
    after = evidence.metadata('retained runtime after eligible-channel rejection')
    assert after['source_sha256'] == json.loads((OUT / 'A-source.json').read_text())['source_sha256']
    with (OUT / 'shelved.json').open('x') as stream:
        json.dump(dict(before=before, after=after, commands=[command, stash_command],
                       output=output, stash=saved), stream, indent=2)
    print(output, saved, after['source_sha256'], flush=True)


if __name__ == '__main__':
    main()
