# Eligible-channel recovery evidence

Decision: rejected at the counter-free capacity-1,024/default-placement screen.
`PLAN.md`, `PROTECTED.md` and `STOP.md` distinguish predeclared, completed and
conditional unrun work. `REBASE.md` identifies the historical implementation;
`ATTEMPTS.md` preserves setup/model-warning and negative-control details.

The bundle contains all 264 performance processes (184 bare, 80 PMU), twelve
clocked diagnostics, both default and both diagnostic executables, exact source
snapshots, patches, build/test/model output and the retained canonical receipt.
`shelved.json` verifies stash 844ec84d and restored runtime source d38dcb86.
No quiet/burst binary, unaffected panel or twelve-pair confirmation was run.
Prepared helpers are not evidence that their native workload was executed.

Build identities:

- A native source: d38dcb8627f61e49f3f95e46c270b9349c6629365060ac98e2dab6bbb00bfa94.
- A executable: 6c332adadb87d387a8ee82881db2b2a06b57c9d835724f20468228f3d44cc5b7.
- B native source: 349bc73a80863105c4ba16f2daefce7f85b89f4311a4e979715d4964c36e499c.
- B executable: 0de6d365b49f4cde0121a50316bc1993697b96131c1c704baba57fc0f1aa104b.
- Probe manifests describe their distinct feature/source/binary identities.

`*-plan.json` records every independent process and order. Raw logs, commands,
post-exit resource accounting and before/after host/guard snapshots accompany
every process. Endpoint distributions are closed-loop full API-call measurements
with Instant overhead, not offered-load or message-delivery distributions. Bare
CPU is post-exit accounting, not a live collector. Diagnostic clocks and PMU mode
are kept separate from default-build acceptance.

Run `python3 replay.py` after extraction to check thirteen analysis tests, exact
plan coverage, every paired ratio, directional tail count, clocked diagnostic and
file checksum without rerunning benchmarks. `report.py` and `protected_report.py`
derive the review tables. `verified-source-archives.json` records independently
reconstructed source digests. The historical eligible source manifest belongs
to its original archive and is not counted as a newly reconstructed source.

Candidate tests include the real metadata-pause negative/positive, intentionally
broken rearm classification, channel cancellation/FIFO/reuse/unwind cases, twelve
channel/word-adapter tests and seventeen retained publication-composition tests.
Their adapter bounds and native-signal limitations remain explicit. The candidate
has no canonical or full performance/release acceptance.

`retained-canonical/receipt.json` passes all fourteen gates with repository state
preserved, including native debug/release, architecture policy and application
smoke. It qualifies the restored runtime, not the shelved candidate. Native ARM64,
sanitizer integration, large mixed/live populations, footprint, loaded-tail and
historical release findings remain open. This slice performs no May comparison,
HTTP work, architecture-grant change or polling adjustment.
