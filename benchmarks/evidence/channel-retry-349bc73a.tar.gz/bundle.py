"""Verify sources, replay analyses, and archive this closed optional experiment."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def verify_source(path):
    manifest = json.loads(path.read_text())
    archive_path = path.with_suffix('.tar.gz')
    expected = manifest.get('source_archive_sha256', manifest.get('archive_sha256'))
    assert expected == evidence.digest(archive_path), path
    with tarfile.open(archive_path) as archive:
        members = sorted(archive.getmembers(), key=lambda member: member.name)
        assert len(members) == len({member.name for member in members})
        source = hashlib.sha256()
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute()
            assert '..' not in Path(member.name).parts
            source.update(member.name.encode() + b'\0' + archive.extractfile(member).read() + b'\0')
        assert source.hexdigest() == manifest['source_sha256'], path
    return dict(manifest=path.name, source_sha256=manifest['source_sha256'])


def main():
    assert evidence.source_digest() == json.loads((OUT / 'A-source.json').read_text())['source_sha256']
    assert json.loads((OUT / 'retained-canonical.result.json').read_text())['returncode'] == 0
    receipt = json.loads((OUT / 'retained-canonical/receipt.json').read_text())
    assert receipt['status'] == 'passed' and receipt['repository']['preserved']
    assert len(receipt['tasks']) == 14 and all(task['status'] == 'passed' for task in receipt['tasks'])
    for arm in ['A', 'B']:
        manifest = json.loads((OUT / f'{arm}-source.json').read_text())
        assert evidence.digest(OUT / f'benchmark-{arm}') == manifest['binary_sha256']
        probe = json.loads((OUT / f'probe-{arm}.json').read_text())
        assert evidence.digest(OUT / f'probe-{arm}') == probe['binary_sha256']
        for task in ['build', 'test', 'format', 'clippy', 'features']:
            assert json.loads((OUT / f'{arm}-{task}.result.json').read_text())['returncode'] == 0
    for name in ['retained-publication-negative', 'rearm-oracle-negative']:
        assert json.loads((OUT / f'{name}.result.json').read_text())['returncode'] == 101
    assert 'channel metadata lock remained held' in (OUT / 'retained-publication-negative.log').read_text()
    assert '0 passed; 1 failed' in (OUT / 'rearm-oracle-negative.log').read_text()
    sources = []
    for path in sorted(OUT.glob('*-source.json')):
        if path.name == 'candidate-eligible-source.json':
            assert not path.with_suffix('.tar.gz').exists()
            continue
        sources.append(verify_source(path))
    assert len(sources) == 7
    with (OUT / 'verified-source-archives.json').open('x') as stream:
        json.dump(sources, stream, indent=2)
    with (OUT / 'verification-tests.log').open('x') as stream:
        subprocess.run([sys.executable, str(OUT / 'replay.py')], cwd=OUT,
                       stdout=stream, stderr=subprocess.STDOUT, check=True)
    paths = sorted(path for path in OUT.rglob('*') if path.is_file()
                   and '__pycache__' not in path.parts and path.name != 'SHA256SUMS')
    with (OUT / 'SHA256SUMS').open('x') as stream:
        for path in paths:
            stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
    destination = ROOT / 'benchmarks/evidence/channel-retry-349bc73a.tar.gz'
    with tarfile.open(destination, 'x:gz') as archive:
        for path in [*paths, OUT / 'SHA256SUMS']:
            archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
    with tarfile.open(destination) as archive:
        assert len(archive.getmembers()) == len(paths) + 1
        for line in archive.extractfile('SHA256SUMS').read().decode().splitlines():
            expected, name = line.split('  ', 1)
            assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected, name
    print(destination, evidence.digest(destination), len(paths), 'verified files;',
          len(sources), 'source snapshots; 264 performance plus twelve diagnostic processes; fourteen gates')


if __name__ == '__main__':
    main()
