"""Paired collection-mode analysis, adapted from the existing quiet-window parser."""

import ast
import json
import math
from pathlib import Path
import random
import re
import statistics
import sys

OUT = Path(__file__).resolve().parent
DEPENDENCIES = OUT / 'replay-dependencies'
if not DEPENDENCIES.is_dir():
    DEPENDENCIES = Path('/root/vthread/target/finish-line/may-refresh.yvxHtB')
sys.path.insert(1, str(DEPENDENCIES))
from analyze import counters, fields, spread


def parse(text, job):
    case = job['case']
    reports = [line for line in text.splitlines() if ' ns_per_operation=' in line]
    assert len(reports) == 1
    report = fields(reports[0])
    assert report['engine'] == 'vthread' and report['operation'] == case['operation']
    assert int(report['workers']) == case['workers'] and int(report['tasks']) == case['tasks']
    samples = ast.literal_eval(re.search(r'\bsamples=(\[.*\])', reports[0])[1])
    assert len(samples) == case['rounds'] and all(isinstance(n, int) and n > 0 for n in samples)
    assert samples == sorted(samples)
    for key, percentile in [('median_ns', 50), ('p95_ns', 95), ('p99_ns', 99)]:
        assert int(report[key]) == samples[(len(samples) * percentile + 99) // 100 - 1]
    assert int(report['max_ns']) == samples[-1]
    operations = case.get('operation_tasks', case['tasks']) * case['per_task']
    timing = int(report['median_ns']) / operations
    assert abs(float(report['ns_per_operation']) - timing) <= 0.005001
    configurations = [fields(line) for line in text.splitlines() if 'phase=configuration ' in line]
    assert len(configurations) == 1
    assert configurations[0]['pin_carriers'] == str(case['pinned']).lower()
    assert int(configurations[0]['max_vthreads']) == case['capacity']
    phases = {}
    for phase in ['latency', 'fairness', 'pair-fairness', 'placement', 'migration', 'spawn']:
        found = [line for line in text.splitlines() if f'phase={phase} ' in line]
        assert len(found) <= 1
        if found:
            values = fields(found[0])
            assert values['engine'] == 'vthread'
            phases[phase] = {key: int(value) for key, value in values.items() if value.isdigit()}
    return dict(ns_per_operation=timing, round_samples_ns=samples, phases=phases,
                process_operations=operations * (case['rounds'] + 1))


def paired(a, b):
    assert len(a) == len(b) and len(a) >= 4
    assert all(value > 0 for value in a + b)
    ratios = [right / left for left, right in zip(a, b)]
    logs = [math.log(value) for value in ratios]
    rng = random.Random(20260906)
    boot = sorted(math.exp(statistics.mean(rng.choices(logs, k=len(logs)))) for _ in range(10000))
    return dict(ratios=ratios, median_ratio=statistics.median(ratios),
                geometric_mean_ratio=math.exp(statistics.mean(logs)),
                upper_95=boot[9499], lower_95=boot[499],
                gross_bare_stop=statistics.median(ratios) > 1.10 and sum(r > 1.10 for r in ratios) >= 3)


def summarize(name, jobs):
    groups = {}
    for job in jobs:
        prefix = job['prefix']
        result = json.loads((OUT / f'{prefix}.result.json').read_text())
        assert result['returncode'] == 0, f'failed attempt cannot become a sample: {prefix}'
        for stage in ['before', 'after']:
            assert not (OUT / f'{prefix}.{stage}.guard').read_text().strip()
        row = parse((OUT / f'{prefix}.log').read_text(), job)
        row.update(prefix=prefix, repetition=job['repetition'], resources=result['resources'])
        row['cpu_seconds_per_operation'] = (result['resources']['user_seconds'] + result['resources']['system_seconds']) / row['process_operations']
        if job['collector'] == 'perf':
            row['counters'] = counters(OUT / f'{prefix}.csv')
        key = f'{job["case"]["name"]}-{job["collector"]}'
        groups.setdefault(key, dict(case=job['case'], collector=job['collector'], A=[], B=[]))[job['arm']].append(row)
    for group in groups.values():
        for arm in ['A', 'B']:
            group[arm].sort(key=lambda row: row['repetition'])
        assert [row['repetition'] for row in group['A']] == [row['repetition'] for row in group['B']]
        group['timing_effect'] = paired([row['ns_per_operation'] for row in group['A']],
                                        [row['ns_per_operation'] for row in group['B']])
        group['cpu_effect'] = paired([row['cpu_seconds_per_operation'] for row in group['A']],
                                     [row['cpu_seconds_per_operation'] for row in group['B']])
        group['timing'] = {arm: spread([row['ns_per_operation'] for row in group[arm]]) for arm in ['A', 'B']}
        print(group['case']['name'], group['collector'], group['timing_effect'], flush=True)
    with (OUT / f'{name}-analysis.json').open('x') as stream:
        json.dump(groups, stream, indent=2)
    return groups
