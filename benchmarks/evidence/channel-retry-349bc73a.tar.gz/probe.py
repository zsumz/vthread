"""Reuse clocked, final-only diagnostics; never compare their timing for acceptance."""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def capture(prefix, command, source, environment=None):
    with (OUT / f'{prefix}.command.json').open('x') as stream:
        json.dump(dict(command=command, source=source, started_unix=time.time()), stream, indent=2)
    with (OUT / f'{prefix}.log').open('x') as stream:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        pid, status, usage = os.wait4(process.pid, 0)
        assert pid == process.pid
        process.returncode = os.waitstatus_to_exitcode(status)
    with (OUT / f'{prefix}.result.json').open('x') as stream:
        json.dump(dict(returncode=process.returncode, finished_unix=time.time(), resources=dict(
            user_seconds=usage.ru_utime, system_seconds=usage.ru_stime, peak_rss_kib=usage.ru_maxrss,
            voluntary_switches=usage.ru_nvcsw, involuntary_switches=usage.ru_nivcsw)), stream, indent=2)
    assert process.returncode == 0, (prefix, process.returncode)
    print(prefix, 'passed', flush=True)


def build(arm):
    manifest = evidence.metadata(f'clocked channel diagnostic {arm}; events only, not acceptance')
    environment = dict(os.environ, CARGO_TARGET_DIR=str(BUILD), CARGO_INCREMENTAL='0')
    for name, command in [
        ('format', ['cargo', 'fmt', '--all', '--', '--check']),
        ('format-bench', ['cargo', 'fmt', '--manifest-path', 'benchmarks/Cargo.toml', '--', '--check']),
        ('report', ['cargo', 'test', '--locked', '--manifest-path', 'benchmarks/Cargo.toml',
                    '--features', 'handoff-profiling', 'handoff_profile', '--', '--nocapture']),
        ('build', ['cargo', 'build', '--locked', '--release', '--manifest-path',
                   'benchmarks/Cargo.toml', '--features', 'handoff-profiling']),
    ]:
        capture(f'probe-{arm}-{name}', ['timeout', '600s', *command], manifest, environment)
    assert evidence.source_digest() == manifest['source_sha256']
    binary = OUT / f'probe-{arm}'
    assert not binary.exists()
    shutil.copy2(BUILD / 'release/vthread-benchmarks', binary)
    manifest.update(binary_sha256=evidence.digest(binary), features=['handoff-profiling'],
                    build_environment=dict(CARGO_TARGET_DIR=str(BUILD), CARGO_INCREMENTAL='0'))
    with (OUT / f'probe-{arm}.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)


def observe(prefix, phase):
    result = subprocess.run(['pgrep', '-x', 'cargo|rustc|clippy-driver|zrail'], capture_output=True, text=True)
    with (OUT / f'{prefix}.{phase}.guard').open('x') as stream:
        stream.write(result.stdout + result.stderr)
    with (OUT / f'{prefix}.{phase}.host').open('x') as stream:
        stream.write(evidence.output('ps', '-eo', 'pid,comm,pcpu,etime') + '\n')
    assert result.returncode == 1, 'build overlap; retain unrun jobs, no replacement'


def run(arm):
    source = json.loads((OUT / f'probe-{arm}.json').read_text())
    binary = OUT / f'probe-{arm}'
    assert evidence.digest(binary) == source['binary_sha256']
    jobs = [dict(prefix=f'diagnostic-{arm}-{rep}-{case}', mask=mask, workers=workers, tasks=tasks)
            for case, mask, workers, tasks in [('local', '0', 1, 8), ('remote8', '0-3', 4, 8),
                                              ('remote64', '0-3', 4, 64)] for rep in [1, 2]]
    with (OUT / f'diagnostic-{arm}-plan.json').open('x') as stream:
        json.dump(jobs, stream, indent=2)
    for job in jobs:
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '120s', 'taskset', '-c', job['mask'], str(binary), 'vthread',
                   'channel-mpmc', '1000', '1', str(job['workers']), str(job['tasks']), '7', '--pin-carriers']
        capture(prefix, command, source)
        observe(prefix, 'after')
    assert evidence.source_digest() == source['source_sha256']


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['build', 'run'])
    parser.add_argument('arm', choices=['A', 'B'])
    args = parser.parse_args()
    (build if args.action == 'build' else run)(args.arm)
