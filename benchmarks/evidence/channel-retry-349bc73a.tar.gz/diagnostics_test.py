"""Diagnostic accounting cannot silently merge permit returns with suspensions."""

import unittest

from diagnostics import parse


def fixture():
    rows = []
    for direction in ['Send', 'Receive']:
        rows.extend([
            f'phase=handoff-ticket carrier=0 direction={direction} counts=[1, 1, 1, 0, 1, 0, 1]',
            f'phase=handoff-channel carrier=0 direction={direction} calls=2 transfers=2 '
            'enqueue=0 retries=1 parks=1 park_calls=2 park_returns=2 resumed_transfers=1 '
            'resumed_exits=0 selected_notifications=1 stored_notifications=2 closed_notifications=0',
        ])
    rows.append('phase=handoff-duration carrier=0 stage=NativeWait count=3')
    return '\n'.join(rows)


class DiagnosticsTests(unittest.TestCase):
    def test_api_returns_are_not_actual_suspensions(self):
        result = parse(fixture(), 1, 2)
        self.assertEqual(result['per_value']['park_calls'], 2)
        self.assertEqual(result['per_value']['parks'], 1)
        self.assertEqual(result['native_wait_calls'], 3)

    def test_rearm_misclassification_is_rejected(self):
        with self.assertRaises(AssertionError):
            parse(fixture().replace('[1, 1, 1, 0, 1, 0, 1]', '[1, 2, 0, 0, 1, 0, 1]'), 1, 2)

    def test_missing_or_duplicate_carriers_are_rejected(self):
        for text, workers in [(fixture(), 2), (fixture() + '\n' + fixture(), 1)]:
            with self.assertRaises(AssertionError):
                parse(text, workers, 2)

    def test_transfer_denominator_and_retirement_are_exact(self):
        for text, values in [(fixture(), 4), (fixture().replace('parks=1', 'parks=2'), 2)]:
            with self.assertRaises(AssertionError):
                parse(text, 1, values)


if __name__ == '__main__':
    unittest.main()
