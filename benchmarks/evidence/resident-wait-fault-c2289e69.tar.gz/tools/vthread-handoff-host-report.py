"""Correlate coarse guest CPU counters, never equating them to task execution."""
import json
from pathlib import Path
import subprocess

OUT = Path('/mnt/volume_atl1_1787847588295/vthread-remote-handoff.FpsfHW')
records = [json.loads(line) for line in (OUT/'host-cpu.jsonl').read_text().splitlines()]

def cpus(row):
    return {fields[0]: list(map(int, fields[1:]))
            for line in row['stat'] if (fields := line.split())}

first, last = cpus(records[0]), cpus(records[-1])
summary = {}
for cpu in (f'cpu{i}' for i in range(8)):
    delta = [b-a for a, b in zip(first[cpu], last[cpu])]
    summary[cpu] = dict(delta=delta, steal_fraction=delta[7]/sum(delta[:8]))
print(json.dumps(summary, indent=2))
with (OUT/'host-cpu-summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
command = ['perf', 'sched', 'timehist', '--state', '-i', str(OUT/'host-sched.data')]
result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
with (OUT/'host-sched.txt').open('x') as stream:
    stream.write(result.stdout)
with (OUT/'host-sched.decode.json').open('x') as stream:
    json.dump(dict(command=command, returncode=result.returncode, stderr=result.stderr), stream)
for before, after in zip(records, records[1:]):
    a, b = cpus(before), cpus(after)
    changes = [b[f'cpu{i}'][7]-a[f'cpu{i}'][7] for i in range(4)]
    if max(changes) >= 3:
        print(f"{before['before_ns']/1e9:.6f}..{after['after_ns']/1e9:.6f}", changes)
