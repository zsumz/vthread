"""Small protected screens, balanced process order and explicit early stopping."""
import ast
import hashlib
import json
from pathlib import Path
import re
import resource
import statistics
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path('/mnt/volume_atl1_1787847588295/vthread-remote-handoff.FpsfHW')
BINS = dict(A=ROOT/'target/finish-line/mutex-attribution.jSLecM/benchmark-B', B=OUT/'benchmark-candidate')
CASES = [
    ('mutex-8t-short-default', ['mutex','1000','4','8','101']),
    ('mutex-8t-long-default', ['mutex','10000','4','8','21']),
    ('mutex-64t-long-default', ['mutex','10000','4','64','21']),
    ('mutex-8t-short-pinned', ['mutex','1000','4','8','101','--pin-carriers']),
    ('mutex-8t-long-pinned', ['mutex','10000','4','8','21','--pin-carriers']),
    ('mutex-64t-long-pinned', ['mutex','10000','4','64','21','--pin-carriers']),
]
EXTRA = [
    ('channel-8t-default', ['channel-mpmc','1000','1','4','8','21']),
    ('channel-64t-spare', ['channel-mpmc','1000','1','4','64','21','--max-vthreads','1024']),
    ('park-64t-pinned', ['park','10000','4','64','21','--pin-carriers']),
    ('wake-64t-pinned', ['wake-tail','1000','4','64','21','--pin-carriers']),
    ('yield-64t-pinned', ['yield','10000','4','64','21','--pin-carriers']),
    ('spawn-1000t-pinned', ['spawn','4','1000','101','--pin-carriers']),
    ('spawn-1000t-spare', ['spawn','4','1000','101','--max-vthreads','65536','--pin-carriers']),
]
phase = sys.argv[1]
CONFIRM = [
    ('mutex-8t-long-pinned', ['mutex','10000','4','8','101','--pin-carriers']),
    ('channel-64t-spare', ['channel-mpmc','1000','1','4','64','101','--max-vthreads','1024']),
    ('wake-64t-pinned', ['wake-tail','1000','4','64','101','--pin-carriers']),
    ('spawn-1000t-spare', ['spawn','4','1000','501','--max-vthreads','65536','--pin-carriers']),
    ('spawn-10000t-pinned', ['spawn','4','10000','101','--pin-carriers']),
    ('tcp-8t-pinned', ['tcp','1000','4','8','11','--pin-carriers']),
]
cases = {'remote': CASES, 'protected': EXTRA, 'confirmation': CONFIRM}[phase]
plan = dict(cases=cases, pairs=4, order=['AB','BA','AB','BA'], phase=phase,
            gross_stop='median paired elapsed or CPU >1.10 with at least 3/4 ratios >1.10; failed process stops',
            acceptance='screen only: protect elapsed and CPU within 5%; remote win needs repeatable >noise benefit; tail uncertainty is not acceptance',
            binaries={arm: hashlib.sha256(path.read_bytes()).hexdigest() for arm,path in BINS.items()},
            source_receipt='lazy-fault-build.command.json')
with (OUT/f'{phase}-plan.json').open('x') as stream:
    json.dump(plan, stream, indent=2)
decisions = []
for name,args in cases:
    rows = []
    for pair in range(4):
        for arm in ('AB' if pair%2==0 else 'BA'):
            prefix = f'{phase}-{name}-{pair}-{arm}'
            command = ['timeout','120s','taskset','-c','0-3',str(BINS[arm]),'vthread',*args]
            before = Path('/proc/stat').read_text().splitlines()[:9]
            usage = resource.getrusage(resource.RUSAGE_CHILDREN)
            result = subprocess.run(command,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            after_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
            after = Path('/proc/stat').read_text().splitlines()[:9]
            with (OUT/f'{prefix}.log').open('x') as stream:
                stream.write(result.stdout)
            row = dict(case=name,pair=pair,arm=arm,command=command,returncode=result.returncode,
                       before_cpu=before,after_cpu=after,
                       cpu_seconds=after_usage.ru_utime+after_usage.ru_stime-usage.ru_utime-usage.ru_stime,
                       voluntary_switches=after_usage.ru_nvcsw-usage.ru_nvcsw,
                       involuntary_switches=after_usage.ru_nivcsw-usage.ru_nivcsw)
            if result.returncode==0:
                lines = [line for line in result.stdout.splitlines() if 'ns_per_operation=' in line]
                assert len(lines)==1 and 'engine=vthread ' in lines[0]
                row['ns_per_operation'] = float(re.search(r'\bns_per_operation=([\d.]+)',lines[0])[1])
                row['samples_ns'] = ast.literal_eval(re.search(r'samples=(\[.*\])',lines[0])[1])
                assert row['samples_ns']==sorted(row['samples_ns']) and min(row['samples_ns'])>0
            with (OUT/f'{prefix}.json').open('x') as stream:
                json.dump(row,stream,indent=2)
            rows.append(row)
            print(prefix,row.get('ns_per_operation'),result.returncode,flush=True)
            if result.returncode:
                sys.exit(result.returncode)
    by = {(row['pair'],row['arm']):row for row in rows}
    decision = dict(case=name)
    for metric in ('ns_per_operation','cpu_seconds'):
        ratios = [by[p,'B'][metric]/by[p,'A'][metric] for p in range(4)]
        decision[metric] = dict(ratios=ratios,median_ratio=statistics.median(ratios),
                               gross_stop=statistics.median(ratios)>1.10 and sum(r>1.10 for r in ratios)>=3)
    decisions.append(decision)
    print(json.dumps(decision),flush=True)
    with (OUT/f'{phase}-{name}-decision.json').open('x') as stream:
        json.dump(decision,stream,indent=2)
    if any(decision[key]['gross_stop'] for key in ('ns_per_operation','cpu_seconds')):
        print('STOP: protected regression; remaining declared cases unrun',flush=True)
        break
with (OUT/f'{phase}-decisions.json').open('x') as stream:
    json.dump(decisions,stream,indent=2)
