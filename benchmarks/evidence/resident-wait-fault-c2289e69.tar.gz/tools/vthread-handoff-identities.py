"""Verify source inputs and immutable binaries without extracting or executing them."""
import hashlib
from pathlib import Path
import sys
import tarfile


def source(archives):
    inputs = {}
    for archive in archives:
        with tarfile.open(archive) as stream:
            for entry in stream.getmembers():
                name = entry.name.removeprefix('./')
                if entry.isfile() and Path(name).suffix in {'.rs', '.toml', '.lock', '.py', '.sh', '.yml'}:
                    payload = stream.extractfile(entry).read()
                    assert name not in inputs or inputs[name] == payload, name
                    inputs[name] = payload
    digest = hashlib.sha256()
    for name, payload in sorted(inputs.items()):
        digest.update(name.encode() + b'\0' + payload + b'\0')
    return digest.hexdigest()


if __name__ == '__main__':
    root = Path(sys.argv[1])
    cases = [
        ('baseline-source.tar.gz', '325396ac5f820b4714ccc439d994cb947e2fbb977ceb4a2a4be19a8491018cbe'),
        ('lazy-fault-source.tar.gz', 'c2289e693ebad73f68c58fb72752a1113260bec36e645ad5a60fe33883c36728'),
    ]
    for archive, expected in cases:
        actual = source([root / archive, root / 'identity-supplement.tar.gz'])
        assert actual == expected, (archive, actual, expected)
        print(archive, actual)
    for name, expected in [
        ('benchmark-baseline', '6b1942226797bd4170c886fdfa5eeb698c3383a824d92f21e5a1610802b8a316'),
        ('benchmark-candidate', '18c01827e605a0fc88fd0fc1bdb8ffb56b403e314eed7461c7a10ac37f50efc0'),
    ]:
        actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
        assert actual == expected, (name, actual, expected)
        print(name, actual)
