"""Replay recorded default-binary results without running benchmarks."""
import ast
import json
import math
from pathlib import Path
import re
import statistics
import sys


def fields(line):
    return dict(re.findall(r'\b([a-z_0-9]+)=([^\s]+)', line))


def validate(text, args):
    scenario = args[0]
    if scenario == 'spawn':
        per_task, workers, tasks, rounds = 1, *map(int, args[1:4])
    elif scenario == 'channel-mpmc':
        per_task, workers, tasks, rounds = int(args[1]), *map(int, args[3:6])
    else:
        per_task, workers, tasks, rounds = map(int, args[1:5])
    reports = [line for line in text.splitlines() if ' ns_per_operation=' in line]
    assert len(reports) == 1
    report = fields(reports[0])
    assert report['engine'] == 'vthread'
    expected = {'spawn':'task', 'mutex':'mutex-handoff', 'park':'park-handoff',
                'yield':'yield', 'wake-tail':'wake-to-resume', 'tcp':'tcp-round-trip',
                'channel-mpmc':f'bounded-mpmc-channel-{args[2]}-transfer'}[scenario]
    assert report['operation'] == expected
    assert (int(report['workers']), int(report['tasks'])) == (workers, tasks)
    samples = ast.literal_eval(re.search(r'samples=(\[.*\])', reports[0])[1])
    assert len(samples) == rounds and samples == sorted(samples) and all(type(n)==int and n>0 for n in samples)
    median = samples[(len(samples)+1)//2-1]
    assert median == int(report['median_ns']) and samples[-1] == int(report['max_ns'])
    for percentile in (95,99):
        assert int(report[f'p{percentile}_ns']) == samples[(rounds*percentile+99)//100-1]
    operations = per_task*(tasks//2 if scenario == 'channel-mpmc' else tasks)
    assert abs(float(report['ns_per_operation'])-median/operations) <= .005001
    configurations = [fields(line) for line in text.splitlines() if 'phase=configuration ' in line]
    assert len(configurations) == 1
    config = configurations[0]
    capacity = int(args[args.index('--max-vthreads')+1]) if '--max-vthreads' in args else max(workers,tasks)
    assert int(config['max_vthreads']) == capacity
    assert config['pin_carriers'] == str('--pin-carriers' in args).lower()
    tails = [fields(line) for line in text.splitlines() if 'phase=latency ' in line]
    if scenario in ('wake-tail', 'tcp'):
        assert len(tails) == 1 and int(tails[0]['observations']) == operations*rounds
    return dict(ns_per_operation=median/operations, operations=operations, tails=tails)


def paired(a, b):
    ratios = [right/left for left,right in zip(a,b)]
    assert len(ratios) == 4 and all(math.isfinite(r) and r>0 for r in ratios)
    return dict(ratios=ratios, median=statistics.median(ratios),
                geometric_mean=statistics.geometric_mean(ratios), minimum=min(ratios), maximum=max(ratios))


def analyze(out):
    groups = {}
    for phase in ('remote', 'protected', 'confirmation'):
        plan = json.loads((out/f'{phase}-plan.json').read_text())
        for case,args in plan['cases']:
            arms = dict(A=[], B=[])
            for pair in range(4):
                for arm in 'AB':
                    prefix = f'{phase}-{case}-{pair}-{arm}'
                    row = json.loads((out/f'{prefix}.json').read_text())
                    assert row['returncode'] == 0 and (row['pair'],row['arm'],row['case']) == (pair,arm,case)
                    assert row['command'][row['command'].index('vthread')+1:] == args
                    parsed = validate((out/f'{prefix}.log').read_text(), args)
                    parsed['cpu_seconds'] = row['cpu_seconds']
                    assert abs(parsed['ns_per_operation']-row['ns_per_operation']) <= .005001
                    arms[arm].append(parsed)
            result = {metric: paired([r[metric] for r in arms['A']], [r[metric] for r in arms['B']])
                      for metric in ('ns_per_operation','cpu_seconds')}
            if arms['A'][0]['tails']:
                result['tails'] = {metric: paired([int(r['tails'][0][metric]) for r in arms['A']],
                                                   [int(r['tails'][0][metric]) for r in arms['B']])
                                   for metric in ('median_ns','p99_9_ns','p99_99_ns','max_ns')}
            groups[f'{phase}/{case}'] = result
    return groups


if __name__ == '__main__':
    out = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
    results = analyze(out)
    if len(sys.argv)>2:
        with Path(sys.argv[2]).open('x') as stream:
            json.dump(results,stream,indent=2)
    for name, result in results.items():
        print(name, 'elapsed', round(result['ns_per_operation']['median'],4),
              'CPU', round(result['cpu_seconds']['median'],4),
              'tails', {k:round(v['median'],4) for k,v in result.get('tails',{}).items()})
