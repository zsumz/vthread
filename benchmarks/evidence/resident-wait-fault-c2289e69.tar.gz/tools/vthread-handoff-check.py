"""Reuse source-keyed qualification receipts for this isolated experiment."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/root/vthread')
OUT = Path('/mnt/volume_atl1_1787847588295/vthread-remote-handoff.FpsfHW')
sys.path.insert(0, str(ROOT/'scripts'))
import evidence

name, *command = sys.argv[1:]
env = dict(os.environ, CARGO_TARGET_DIR='/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI', CARGO_INCREMENTAL='0')
source = evidence.metadata(name)
with (OUT/f'{name}.command.json').open('x') as stream:
    json.dump(dict(command=command, source=source, build_environment={key: env[key] for key in ('CARGO_TARGET_DIR', 'CARGO_INCREMENTAL')}), stream, indent=2)
with (OUT/f'{name}.patch').open('x') as stream:
    stream.write(evidence.output('git', 'diff', 'HEAD'))
start = time.monotonic()
with (OUT/f'{name}.log').open('x') as stream:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
with (OUT/f'{name}.result.json').open('x') as stream:
    json.dump(dict(returncode=result.returncode, elapsed=time.monotonic()-start,
                   source_preserved=source['source_sha256']==evidence.source_digest()), stream)
print((OUT/f'{name}.log').read_text()[-8000:])
sys.exit(result.returncode)
