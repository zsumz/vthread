"""Balanced same-binary CPU-placement control, not a runtime candidate."""
import ast
import json
from pathlib import Path
import re
import resource
import statistics
import subprocess
import time

ROOT = Path('/root/vthread')
OUT = Path('/mnt/volume_atl1_1787847588295/vthread-remote-handoff.FpsfHW')
BIN = ROOT/'target/finish-line/mutex-attribution.jSLecM/benchmark-B'
jobs = [dict(pair=p, mask=mask) for p in range(4)
        for mask in (['0-3', '4-7'] if p % 2 == 0 else ['4-7', '0-3'])]
with (OUT/'cpu-control-plan.json').open('x') as stream:
    json.dump(dict(jobs=jobs, binary_source_plan='plan.json',
                   hypothesis='same executable on alternate CPU sets; no runtime performance claim',
                   rounds=21, acquisitions_per_task=10000, carriers=4, tasks=64), stream, indent=2)
rows = []
for job in jobs:
    name = f"cpu-control-{job['pair']}-{job['mask']}"
    command = ['timeout', '90s', 'taskset', '-c', job['mask'], str(BIN), 'vthread',
               'mutex', '10000', '4', '64', '21', '--pin-carriers']
    before = Path('/proc/stat').read_text().splitlines()[:9]
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    started = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    elapsed = time.monotonic()-started
    after_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    after = Path('/proc/stat').read_text().splitlines()[:9]
    with (OUT/f'{name}.log').open('x') as stream:
        stream.write(result.stdout)
    row = dict(**job, command=command, returncode=result.returncode, elapsed=elapsed,
               cpu_seconds=after_usage.ru_utime+after_usage.ru_stime-usage.ru_utime-usage.ru_stime,
               before_cpu=before, after_cpu=after)
    if result.returncode == 0:
        line = next(line for line in result.stdout.splitlines() if 'ns_per_operation=' in line)
        samples = ast.literal_eval(re.search(r'samples=(\[.*\])', line)[1])
        assert len(samples) == 21 and samples == sorted(samples)
        row['ns_per_operation'] = statistics.median(samples)/640000
    with (OUT/f'{name}.json').open('x') as stream:
        json.dump(row, stream, indent=2)
    rows.append(row)
    print(name, row.get('ns_per_operation'), result.returncode, flush=True)
with (OUT/'cpu-control-results.json').open('x') as stream:
    json.dump(rows, stream, indent=2)
