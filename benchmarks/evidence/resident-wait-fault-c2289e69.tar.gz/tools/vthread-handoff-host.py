"""One targeted scheduling trace with passive per-vCPU steal-time evidence."""
import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path('/mnt/volume_atl1_1787847588295/vthread-remote-handoff.FpsfHW')
ROOT = Path('/root/vthread')
BIN = ROOT/'target/finish-line/mutex-attribution.jSLecM/benchmark-B'
command = ['timeout', '90s', 'perf', 'record', '-a', '-k', 'mono',
           '-e', 'sched:sched_switch', '-e', 'sched:sched_wakeup',
           '-e', 'sched:sched_waking', '-o', str(OUT/'host-sched.data'), '--',
           'taskset', '-c', '0-3', str(BIN), 'vthread', 'mutex', '10000', '4', '64',
           '9', '--pin-carriers']
with (OUT/'host-sched.command.json').open('x') as stream:
    json.dump(dict(command=command, source_plan='plan.json',
                   cpu_fields='user nice system idle iowait irq softirq steal guest guest_nice',
                   clock='CLOCK_MONOTONIC; proc stat reads bounded by before/after'), stream, indent=2)
with (OUT/'host-sched.log').open('x') as log, (OUT/'host-cpu.jsonl').open('x') as ticks:
    child = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    while True:
        before = time.monotonic_ns()
        stat = Path('/proc/stat').read_text().splitlines()[:9]
        after = time.monotonic_ns()
        ticks.write(json.dumps(dict(before_ns=before, after_ns=after, stat=stat))+'\n')
        if child.poll() is not None:
            break
        time.sleep(0.02)
with (OUT/'host-sched.result.json').open('x') as stream:
    json.dump(dict(returncode=child.returncode), stream)
print((OUT/'host-sched.log').read_text())
sys.exit(child.returncode)
