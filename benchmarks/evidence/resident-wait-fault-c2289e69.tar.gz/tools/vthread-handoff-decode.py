"""Decode retained perf data; retain full output and print only hot instructions."""
import json
from pathlib import Path
import re
import subprocess

OUT = Path('/mnt/volume_atl1_1787847588295/vthread-remote-handoff.FpsfHW')
for tasks in (64, 8):
    for name, command in (
        ('report', ['perf', 'report', '--stdio', '--no-children', '-g', 'none', '-i', str(OUT/f'{tasks}t-cycles.data')]),
        ('annotate', ['perf', 'annotate', '--stdio', '--stdio-color', 'never', '--no-source',
                      '-i', str(OUT/f'{tasks}t-cycles.data'), '-s', 'std::sys::backtrace::__rust_begin_short_backtrace']),
        ('sched', ['perf', 'sched', 'timehist', '--state', '-i', str(OUT/f'{tasks}t-sched.data')]),
    ):
        result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        with (OUT/f'{tasks}t-{name}.txt').open('x') as stream:
            stream.write(result.stdout)
        with (OUT/f'{tasks}t-{name}.decode.json').open('x') as stream:
            json.dump(dict(command=command, returncode=result.returncode, stderr=result.stderr), stream)
        if name == 'annotate':
            hot = []
            for line in result.stdout.splitlines():
                match = re.match(r'\s*(\d+\.\d+)\s+:', line)
                if match and float(match[1]) >= 1:
                    hot.append(line)
            print(tasks, 'hot instructions', '\n'.join(hot))
        elif name == 'report':
            print(tasks, result.stdout[:5000])
