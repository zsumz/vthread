"""Bounded existing-binary attribution; no collected run is an acceptance sample."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/root/vthread')
OUT = Path('/mnt/volume_atl1_1787847588295/vthread-remote-handoff.FpsfHW')
BIN = ROOT / 'target/finish-line/mutex-attribution.jSLecM/benchmark-B'
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

jobs = []
for tasks in (64, 8):
    for mode in ('bare', 'cycles', 'sched', 'bare-after'):
        name = f'{tasks}t-{mode}'
        bench = ['taskset', '-c', '0-3', str(BIN), 'vthread', 'mutex',
                 '10000', '4', str(tasks), '9', '--pin-carriers']
        command = bench
        if mode == 'cycles':
            command = ['perf', 'record', '-o', str(OUT / f'{name}.data'),
                       '-e', 'cycles:u', '-F', '499', '--call-graph', 'dwarf,2048', '--'] + bench
        elif mode == 'sched':
            command = ['perf', 'sched', 'record', '-o', str(OUT / f'{name}.data'), '--'] + bench
        jobs.append(dict(name=name, mode=mode, tasks=tasks, command=['timeout', '90s'] + command))

with (OUT / 'plan.json').open('x') as stream:
    json.dump(dict(source=evidence.metadata('default native handoff stage probe'),
                   binary_sha256=evidence.digest(BIN), jobs=jobs), stream, indent=2)
for job in jobs:
    start = time.monotonic()
    name = job['name']
    print('START', name, flush=True)
    with (OUT / f'{name}.log').open('x') as stream:
        result = subprocess.run(job['command'], cwd=ROOT, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=100)
    with (OUT / f'{name}.result.json').open('x') as stream:
        json.dump(dict(returncode=result.returncode, elapsed=time.monotonic()-start), stream)
    print(name, result.returncode, (OUT / f'{name}.log').read_text()[-1800:], flush=True)
