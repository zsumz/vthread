"""Early counter-free local screen; no broader panel unless this candidate earns it."""
import ast
import hashlib
import json
from pathlib import Path
import re
import resource
import statistics
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path('/mnt/volume_atl1_1787847588295/vthread-remote-handoff.FpsfHW')
BINS = dict(A=ROOT/'target/finish-line/mutex-attribution.jSLecM/benchmark-B',
            B=OUT/'benchmark-candidate')
jobs = [dict(pair=p, arm=arm) for p in range(4)
        for arm in ('AB' if p % 2 == 0 else 'BA')]
plan = dict(jobs=jobs, carriers=1, tasks=8, calls_per_task=10000, rounds=101,
            proceed_only='median B/A elapsed <=0.99, at least 3 of 4 elapsed ratios <1, median process CPU B/A <=1.05',
            limits='early mechanism screen only; no latency/fairness/remote acceptance; every planned result retained',
            binary_sha256={arm: hashlib.sha256(path.read_bytes()).hexdigest() for arm,path in BINS.items()})
with (OUT/'candidate-screen-plan.json').open('x') as stream:
    json.dump(plan, stream, indent=2)
rows = []
for job in jobs:
    name = f"candidate-screen-{job['pair']}-{job['arm']}"
    command = ['timeout', '90s', 'taskset', '-c', '0', str(BINS[job['arm']]),
               'vthread', 'mutex', '10000', '1', '8', '101', '--pin-carriers']
    before = Path('/proc/stat').read_text().splitlines()[:9]
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    after_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    after = Path('/proc/stat').read_text().splitlines()[:9]
    with (OUT/f'{name}.log').open('x') as stream:
        stream.write(result.stdout)
    row = dict(**job, command=command, returncode=result.returncode, before_cpu=before, after_cpu=after,
               cpu_seconds=after_usage.ru_utime+after_usage.ru_stime-usage.ru_utime-usage.ru_stime)
    if result.returncode == 0:
        lines = [line for line in result.stdout.splitlines() if 'ns_per_operation=' in line]
        assert len(lines)==1
        samples = ast.literal_eval(re.search(r'samples=(\[.*\])', lines[0])[1])
        assert len(samples)==101 and samples==sorted(samples) and min(samples)>0
        row['samples_ns'] = samples
        row['ns_per_operation'] = statistics.median(samples)/80000
    with (OUT/f'{name}.json').open('x') as stream:
        json.dump(row, stream, indent=2)
    rows.append(row)
    print(name, row.get('ns_per_operation'), result.returncode, flush=True)
if any(row['returncode'] for row in rows):
    decision = dict(proceed=False, reason='failed process')
else:
    by = {(row['pair'], row['arm']): row for row in rows}
    elapsed = [by[p,'B']['ns_per_operation']/by[p,'A']['ns_per_operation'] for p in range(4)]
    cpu = [by[p,'B']['cpu_seconds']/by[p,'A']['cpu_seconds'] for p in range(4)]
    decision = dict(elapsed_ratios=elapsed, cpu_ratios=cpu,
                    proceed=statistics.median(elapsed)<=0.99 and sum(r<1 for r in elapsed)>=3 and statistics.median(cpu)<=1.05)
with (OUT/'candidate-screen-decision.json').open('x') as stream:
    json.dump(decision, stream, indent=2)
print(json.dumps(decision, indent=2))
