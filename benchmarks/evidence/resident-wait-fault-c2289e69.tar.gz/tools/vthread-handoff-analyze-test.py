"""Negative controls for replayed performance receipts."""
import importlib.util
from pathlib import Path
import sys
import unittest

spec = importlib.util.spec_from_file_location('analysis', sys.argv.pop(1))
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)
ARGS = ['mutex','1','1','8','3','--pin-carriers']
VALID = ('engine=vthread phase=configuration max_vthreads=8 workers=1 tasks=8 pin_carriers=true\n'
         'engine=vthread operation=mutex-handoff workers=1 tasks=8 median_ns=80 ns_per_operation=10.00 '
         'p95_ns=88 p99_ns=88 max_ns=88 samples=[72, 80, 88]\n')

class Receipts(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(analysis.validate(VALID,ARGS)['operations'],8)

    def test_missing_round(self):
        with self.assertRaises(AssertionError):
            analysis.validate(VALID.replace('[72, 80, 88]','[80, 88]'),ARGS)

    def test_false_operation(self):
        with self.assertRaises(AssertionError):
            analysis.validate(VALID.replace('mutex-handoff','park-handoff'),ARGS)

    def test_false_capacity(self):
        with self.assertRaises(AssertionError):
            analysis.validate(VALID.replace('max_vthreads=8','max_vthreads=64'),ARGS)

    def test_false_work_count(self):
        with self.assertRaises(AssertionError):
            analysis.validate(VALID.replace('ns_per_operation=10.00','ns_per_operation=5.00'),ARGS)

    def test_false_tail(self):
        with self.assertRaises(AssertionError):
            analysis.validate(VALID.replace('p99_ns=88','p99_ns=80'),ARGS)

if __name__ == '__main__':
    unittest.main()
