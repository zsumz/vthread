#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/capacity-pacing

run_pair() {
    local label=$1
    shift
    for round in 1 2 3; do
        local engines='baseline observer'
        if [[ $round == 2 ]]; then engines='observer baseline'; fi
        for engine in $engines; do
            local binary=$evidence_dir/observer-profile-benchmark
            if [[ $engine == baseline ]]; then
                binary=target/finish-line/scheduler-profile/profile-benchmark
            fi
            local prefix=$evidence_dir/profile-$round-$engine-$label
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            printf '%q ' timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c 0-3 "$binary" vthread "$@" >> "$evidence_dir/profile-commands.log"
            printf '\n' >> "$evidence_dir/profile-commands.log"
            timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c 0-3 "$binary" vthread "$@" > "$prefix.log" 2>&1
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'profile round=%s engine=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

run_pair spawn10000 spawn 4 10000 501
run_pair spawn-cap65536 spawn 4 10000 101 --max-vthreads 65536
run_pair park-cap64 park 10000 4 64 5 --max-vthreads 64
run_pair park-cap1024 park 10000 4 64 5 --max-vthreads 1024
run_pair park-cap65536 park 10000 4 64 5 --max-vthreads 65536
