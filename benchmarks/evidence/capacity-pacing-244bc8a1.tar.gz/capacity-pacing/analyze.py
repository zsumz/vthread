"""Summarize independent control processes and final-only owner counters."""

import json
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parent


def fields(line):
    return dict(re.findall(r"(\w+)=(\[[^\]]*\]|\S+)", line))


def record(path):
    result = {"log": path.name}
    admissions, idle = [], []
    for line in path.read_text().splitlines():
        data = fields(line)
        if "ns_per_operation" in data:
            result["ns_per_operation"] = float(data["ns_per_operation"])
        if data.get("phase") == "latency":
            result["latency"] = {key: int(value) for key, value in data.items() if key.endswith("_ns")}
        if data.get("phase") == "scheduler-admission":
            admissions.append(data)
        if data.get("phase") == "scheduler-idle":
            idle.append(data)
    counters = path.with_suffix(".csv")
    if counters.exists():
        result["perf"] = {}
        for line in counters.read_text().splitlines():
            columns = line.split(",")
            if len(columns) >= 3 and columns[0].isdigit():
                result["perf"][columns[2]] = int(columns[0])
    if admissions:
        profile = {}
        for group in (admissions, idle):
            for data in group:
                for key, value in data.items():
                    if key in ("engine", "phase", "carrier", "batch_histogram", "maximum_idle_dispatches"):
                        continue
                    profile[key] = profile.get(key, 0) + int(value)
        profile["maximum_idle_dispatches"] = max(int(data["maximum_idle_dispatches"]) for data in idle)
        histograms = [json.loads(data["batch_histogram"]) for data in admissions]
        profile["batch_histogram"] = [sum(bucket) for bucket in zip(*histograms)]
        drains = sum(profile["batch_histogram"][1:])
        profile["mean_nonempty_batch"] = profile["remote_packets"] / drains
        profile["poll_probes_per_task"] = profile["poll_probes"] / profile["remote_packets"]
        profile["dispatches_per_idle_entry"] = profile["idle_dispatches"] / max(profile["idle_entries"], 1)
        result["profile"] = profile
    return result


records = [record(path) for path in sorted(ROOT.glob("control-*-*.log"))]
comparisons = []
for case in ("yield", "spawn1000", "spawn10000", "park", "mutex", "channel", "wake", "capacity"):
    groups = {}
    for engine in ("previous", "current"):
        groups[engine] = [item for item in records if f"-{engine}-{case}.log" in item["log"]]
    if not all(groups.values()):
        continue
    entry = {"case": case}
    for metric in ("ns_per_operation", "cycles", "instructions"):
        values = {}
        for engine, group in groups.items():
            values[engine] = [item[metric] if metric in item else item["perf"][metric] for item in group]
        entry[metric] = values
        entry[metric]["change_percent"] = 100 * (
            statistics.median(values["current"]) / statistics.median(values["previous"]) - 1
        )
    comparisons.append(entry)
profiles = [record(path) for path in sorted(ROOT.glob("profile-*.log")) if path.with_suffix(".csv").exists()]
print(json.dumps({"controls": comparisons, "raw": records, "profiles": profiles}, indent=2))
