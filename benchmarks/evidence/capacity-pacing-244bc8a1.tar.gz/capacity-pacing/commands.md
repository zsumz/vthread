# Observer-only capacity and pacing experiment

Baseline commit: 62378f4b065be66852a48d3a17799ceec20b6b29.
Apply observer.patch for the candidate source recorded in observer-source.json.
The inventory was not refreshed and no canonical acceptance is claimed for this
rejected experiment. The three targeted snapshot regressions passed; the separate
negative patch records their behavior before the production observation changes.

```sh
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib kernel_snapshot -- --test-threads=1
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml --features scheduler-profiling
bash target/finish-line/capacity-pacing/run-profiles.sh
python3 target/finish-line/capacity-pacing/analyze.py
```

run-profiles.sh and profile-commands.log retain the exact 30 balanced processes.
Counter collection uses perf stat for cycles, instructions, context switches and
CPU migrations. Both binaries include opt-in owner-local scheduler diagnostics;
no result here is an uninstrumented headline or accepted tail/fairness gate.
Source and binary manifests, endpoint host snapshots, negative-test output and
raw per-process reports are preserved. Archives exclude executables.
