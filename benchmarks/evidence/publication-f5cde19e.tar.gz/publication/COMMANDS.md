# Replay

Final base: 23822ed07f2c0a0ecb7448e255f917019e60bc64.
Apply candidate.patch to a fresh checkout of that base. It contains no retained
production ordering change: hooks, storage and modules are all cfg(test).
The initial-probes patch/manifest instead apply to 2abae58 and identify the earlier
attempt, before the separate completion-observer test repair.

```sh
CARGO_INCREMENTAL=0 zcheck run check
CARGO_INCREMENTAL=0 cargo test --locked --workspace --all-targets
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib publication -- --test-threads=1 --nocapture
CARGO_INCREMENTAL=0 cargo test --release --locked -p vthread --lib publication -- --test-threads=1 --nocapture
```

ordered-repeat-cpu0.log contains 20 serial native debug invocations of
`timeout 30s taskset -c 0 target/debug/deps/vthread-983657e34fb0f8af publication --test-threads=1 --nocapture`.
Executable paths depend on compiler/build context; use the reported cargo path
and capture its hash before replay. binaries.sha256 records both debug backends
and the optimized native test executable. Executable contents are not archived.

The microsecond observations include deliberate publisher pauses, diagnostic
atomics/channels/output and OS scheduling. They are not performance samples.
Tests characterize a known owner-wide dependency; they do not prove progress while
a publisher remains paused. Production wait-word, wake queue and ownership paths
are exercised, but full composition model checking and loaded OS-tail attribution
remain required before a protocol repair or stable-release claim.

The rejected inventory-overlap receipt and naturally failed completion assertion
are preserved in completion-observer-f8f1f6f5.tar.gz. canonical-final.log and the
canonical-receipt directory are the valid final qualification for this slice.
