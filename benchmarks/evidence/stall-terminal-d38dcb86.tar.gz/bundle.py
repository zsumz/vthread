"""Preserve the original failure, ordered negative and qualified correction."""

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

assert json.loads((OUT / 'failed-canonical-result.json').read_text())['returncode'] == 1
assert json.loads((OUT / 'repaired-canonical.result.json').read_text())['returncode'] == 0
negative = (OUT / 'terminal-credit-ordered-negative.log').read_text()
assert 'cleanup: Some(RuntimeStalled { active: 2 })' in negative
assert 'name: "parked"' in negative and '0 passed; 1 failed' in negative
assert 'InvalidConfiguration' in (OUT / 'terminal-credit-negative.log').read_text()
assert '546 passed; 0 failed; 2 ignored' in (OUT / 'terminal-credit-native-debug.log').read_text()

manifest = evidence.metadata('terminal-credit correction; final canonical source')
qualified = json.loads((OUT / 'repaired-canonical.command.json').read_text())['source']
assert manifest['source_sha256'] == qualified['source_sha256']
names = sorted(set(evidence.output('git', 'ls-files', '--cached', '--others', '--exclude-standard').splitlines()))
names = [name for name in names if Path(name).suffix in {'.rs', '.toml', '.lock', '.py', '.sh', '.yml'}
         and (ROOT / name).is_file()]
if not (OUT / 'final-source.tar.gz').exists():
    with tarfile.open(OUT / 'final-source.tar.gz', 'x:gz') as archive:
        for name in names:
            archive.add(ROOT / name, arcname=name, recursive=False)
with tarfile.open(OUT / 'final-source.tar.gz') as archive:
    source = hashlib.sha256()
    for member in sorted(archive.getmembers(), key=lambda member: member.name):
        assert member.isfile()
        source.update(member.name.encode() + b'\0' + archive.extractfile(member).read() + b'\0')
    assert source.hexdigest() == manifest['source_sha256']
manifest['source_archive_sha256'] = evidence.digest(OUT / 'final-source.tar.gz')

# Reconstruct every recorded test source from the retained source archive and
# its exact patch. A nonzero test exit alone is never treated as a valid negative.
for prefix in ['terminal-credit-negative', 'terminal-credit-ordered-negative',
               'terminal-credit-native-debug', 'repaired-canonical']:
    command = json.loads((OUT / f'{prefix}.command.json').read_text())
    with tempfile.TemporaryDirectory(prefix='vthread-stall-replay-') as temporary:
        tree = Path(temporary)
        with tarfile.open(OUT / 'base-source.tar.gz') as archive:
            members = archive.getmembers()
            assert len(members) == len({member.name for member in members})
            assert all(member.isfile() and not Path(member.name).is_absolute()
                       and '..' not in Path(member.name).parts for member in members)
            archive.extractall(tree, members=members)
        # evidence.output strips the terminating newline, which git apply needs.
        # Keep the captured patch intact and restore only that input terminator.
        subprocess.run(['git', 'apply', '-'], cwd=tree, check=True, text=True,
                       input=(OUT / f'{prefix}.patch').read_text() + '\n')
        source = hashlib.sha256()
        for path in sorted(tree.rglob('*'), key=lambda path: str(path.relative_to(tree))):
            if path.is_file():
                source.update(str(path.relative_to(tree)).encode() + b'\0' + path.read_bytes() + b'\0')
        assert source.hexdigest() == command['source']['source_sha256'], prefix

binaries = {}
for log in (OUT / 'repaired-task-logs').glob('*.log'):
    for name in re.findall(r'Running .* \((/[^)]+)\)', log.read_text()):
        path = Path(name)
        if path.is_file():
            binaries[name] = evidence.digest(path)
manifest['qualification_binary_sha256'] = binaries
assert binaries
with (OUT / 'final-source.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)

destination = ROOT / f'benchmarks/evidence/stall-terminal-{manifest["source_sha256"][:8]}.tar.gz'
paths = sorted(path for path in OUT.rglob('*') if path.is_file() and '__pycache__' not in path.parts
               and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(destination, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
with tarfile.open(destination) as archive:
    for line in archive.extractfile('SHA256SUMS').read().decode().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
print(destination, evidence.digest(destination), len(paths), 'verified hashes and all source reconstructions')
