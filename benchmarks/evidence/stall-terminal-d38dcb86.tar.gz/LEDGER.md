# Terminal-credit stall count: ordered defect and cold-path correction

The original restored-baseline canonical receipt is retained in failed-canonical,
with its source-keyed wrapper metadata. It failed the terminal-sibling primary-
error assertion without printing the actual primary error. We cannot retroactively
recover that value, and do not call a quiet rerun an explanation.

The new native regression holds the existing completion after_notify hook after
the result and terminal status commit, before admission-credit retirement. Another
child is demonstrably parked. The root observes two credits and joins the committed
terminal result. A native observer releases the held carrier only after detecting
the stall snapshot, not after a chosen elapsed delay. On failed observer assertions,
sender destruction releases the hook. Scope cleanup and reuse are checked.

The first negative attempt failed test setup: max_vthreads=4 required explicitly
lowering stack-cache capacity. That attempt is preserved, not counted as evidence.
After fixing only configuration and removing a time-based hook release, the ordered
negative reaches the intended assertion: RuntimeStalled.active is 2, while the
captured live-task snapshot contains exactly the one parked child. This establishes
a real reachable count defect consistent with the original failure; it does not
prove the unprinted historical error by inference alone.

The correction takes the error count from the already-captured StallSnapshot.
It changes only construction of the opt-in failure: no extra default-path scan,
atomic, allocation or timing probe. Admission credits still retire in the same
place; completion/join, recovery policy, scheduling and ownership are unchanged.
The original intermittent assertion now prints the error and runtime snapshot.

The corrected default-native library run passes 546 tests, with two existing
ignored manual probes. Canonical output and final status are in the repaired
receipt; qualification explicitly identifies vthread-stack for default debug,
default release and all-feature diagnostic configurations. Exact source/binary
identities, source archives, all patches and failure/success logs are bundled.

This is correctness evidence, not a performance improvement or full release
qualification. Current-source ARM64, sanitizer integration, large mixed/parallel
populations and other previously open release findings remain separate.

The first archive verification attempt encountered an older Python tarfile API
without extraction filters. The verifier now validates regular-file-only members,
unique relative paths and no parent traversal before extraction into a fresh
temporary directory. The already-written final source archive is hash-verified,
not overwritten. This packaging correction changes no qualified source or test.
Source reconstruction also restores the trailing newline stripped by the shared
evidence.output helper before feeding each patch to git apply. Captured patches
stay unchanged; reconstructed file bytes must match each recorded source digest.
The replay digest uses full relative-path string ordering, matching source_digest,
not pathlib's component-wise ordering; the initial mismatch exposed that verifier
mistake. No failed source digest check is bypassed.
