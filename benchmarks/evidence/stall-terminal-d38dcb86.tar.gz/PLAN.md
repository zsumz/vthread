# Ordered terminal-credit stall accounting investigation

The restored e344a60e runtime failed native release canonical task 0008 at the
terminal-sibling primary-error assertion. The failure did not print the error;
retain the exact failed receipt rather than infer its value from a quiet rerun.

Hypothesis: RuntimeStalled.active uses admission credits although its public
contract says live tasks. A terminal record is excluded from quiescence and the
stall snapshot but can retain its credit after completion notification. Hold this
real native carrier boundary using the existing test-only completion hook. Order
the stall decision before releasing credit retirement. Assert two credits at the
boundary, one live snapshot task, RuntimeStalled.active == 1, clean reclamation
and runtime reuse. Run the regression against unchanged runtime code first.

If proved, repair only construction of the opt-in stall failure, using the live
snapshot already captured. Do not change admission retirement, completion/join
ordering, scheduling, stall timeouts or default-path observation. Qualification:
ordered negative control, native debug/release targeted tests, existing stall and
join tests, full canonical gate. Preserve every failed attempt with exact source.

The historical failure is consistent with this defect only if the ordered
counterexample agrees; its unprinted error cannot be reconstructed retroactively.
