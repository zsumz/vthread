| Case | A ns/op | B ns/op | C ns/op | D ns/op | B cycles | C cycles | D cycles |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| spawn1000 | 420.73 | 479.10 | 687.05 | 968.22 | +20.19% | +7.25% | +7.37% |
