"""Reuse the same complete sample checks for the one fixed-budget follow-up."""

import importlib.util
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('factorial', OUT / 'analyze.py')
factorial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(factorial)


if __name__ == '__main__':
    factorial.analyze(sys.argv[1], sys.argv[2:], 'AE')
