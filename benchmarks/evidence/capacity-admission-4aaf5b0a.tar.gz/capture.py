"""Check complete guarded process pairs and report distributions, not cherry picks."""

import csv
import json
from pathlib import Path
import re
import statistics
import sys

OUT = Path(__file__).resolve().parent


def change(before, after):
    return 100 * (after / before - 1) if before else None


def sample(prefix):
    for stage in ('before', 'after'):
        assert (OUT / f'{prefix}.{stage}.guard').read_text() == '', prefix
    text = (OUT / f'{prefix}.log').read_text()
    result = {'ns/op': float(re.search(r'\bns_per_operation=([\d.]+)', text)[1])}
    with (OUT / f'{prefix}.csv').open() as stream:
        for row in csv.reader(stream):
            if len(row) > 2 and row[2] in ('cycles', 'instructions', 'task-clock', 'context-switches', 'cpu-migrations'):
                result[row[2]] = float(row[0])
    assert len(result) == 6, prefix
    for phase in ('latency', 'fairness', 'pair-fairness'):
        line = next((line for line in text.splitlines() if f'phase={phase} ' in line), '')
        for key in ('median_ns', 'p99_9_ns', 'p99_99_ns', 'max_ns', 'task_p99_9_max_ns', 'pair_p99_9_max_ns'):
            match = re.search(rf'\b{key}=([\d.]+)\b', line)
            if match:
                result[f'{phase}/{key}'] = float(match[1])
    return result


def analyze(cohort, labels):
    commands = sorted(OUT.glob(f'{cohort}-*.command.json'))
    if labels:
        commands = [path for path in commands if path.name.split('-', 2)[2].rsplit('-', 1)[0] in labels]
    cases = sorted({path.name.split('-', 2)[2].rsplit('-', 1)[0] for path in commands})
    assert not labels or set(labels) == set(cases)
    summary = {}
    for case in cases:
        values = {arm: [sample(f'{cohort}-{round_number}-{case}-{arm}') for round_number in range(1, 5)] for arm in 'AB'}
        summary[case] = {}
        for metric in values['A'][0]:
            arms = {arm: [value[metric] for value in values[arm]] for arm in 'AB'}
            medians = {arm: statistics.median(series) for arm, series in arms.items()}
            paired = [change(left, right) for left, right in zip(arms['A'], arms['B'])]
            summary[case][metric] = {
                'samples': arms, 'medians': medians,
                'median_change_percent': change(medians['A'], medians['B']),
                'paired_change_percent': paired,
            }
    assert len(commands) == len(cases) * 8, 'incomplete or extra processes'
    destination = OUT / f'{cohort}-analysis.json'
    with destination.open('x') as stream:
        json.dump(summary, stream, indent=2)
    print('| Case | Baseline ns/op | Repair ns/op | Cycles change | Instructions change |')
    print('| --- | ---: | ---: | ---: | ---: |')
    for case, result in summary.items():
        times = result['ns/op']['medians']
        print(f"| {case} | {times['A']:.2f} | {times['B']:.2f} | {result['cycles']['median_change_percent']:+.2f}% | {result['instructions']['median_change_percent']:+.2f}% |")
    print(f'Validated {len(commands)} guarded processes; raw process samples in {destination.name}')


if __name__ == '__main__':
    analyze(sys.argv[1], sys.argv[2:])
