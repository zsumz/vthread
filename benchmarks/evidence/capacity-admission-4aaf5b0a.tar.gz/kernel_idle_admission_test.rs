//! A changed epoch makes the native wait nonblocking in either policy arm.

use super::Kernel;
use crate::{CarrierId, Runtime, TaskFailure, control::Shared};
use std::sync::Arc;

fn episode(parked: bool) -> usize {
    let config = Runtime::builder()
        .carriers(2)
        .max_vthreads(4)
        .carrier_queue_capacity(4)
        .stack_cache_capacity(4)
        .build()
        .unwrap()
        .config();
    let shared = Arc::new(Shared::new(config));
    let scope = shared.begin_scope().unwrap();
    let mut kernel = Kernel::new(Arc::clone(&shared), CarrierId(0));
    if parked {
        let (parker, _wake) = crate::park_pair();
        shared
            .submit(scope, "parked handoff".into(), move || parker.park())
            .unwrap();
        kernel.receive();
        assert!(kernel.tick(false).unwrap());
        assert_eq!(kernel.parked.len(), 1);
    }
    let observed = kernel.inbox.signal.version();
    kernel.inbox.signal.notify();
    kernel.wait_for_work(observed);
    let visits = kernel.idle_probe_visits;
    kernel.abort(None, TaskFailure::RuntimeStopped);
    shared.finish_scope(scope);
    visits
}

#[test]
fn admission_only_idle_does_not_spend_a_handoff_probe() {
    assert_eq!(episode(false), 0);
}

#[test]
fn parked_handoffs_keep_the_existing_probe_and_signal_check() {
    assert_eq!(episode(true), 1);
}
