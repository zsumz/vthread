| Case | A ns/op | E ns/op | E cycles |
| --- | ---: | ---: | ---: |
| spawn1000 | 433.99 | 802.88 | +10.32% |
