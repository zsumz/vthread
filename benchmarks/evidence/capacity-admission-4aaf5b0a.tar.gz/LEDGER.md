# Rejected capacity/admission experiment

Base 7f6e9cc652f30d1bd4db3d664a498445e2bc5766. The branch was restored after all
candidates failed tight lifecycle screening. No rejected runtime policy is retained.

Arm A is the preserved qualified publication-repair default binary, not the older
pre-repair baseline. source-A/B/C/D/E.json identify actual source for every binary.
The counter manifests contain executable hashes and complete invocation commands.
Executables are excluded from the archive; all hashes are retained.

Source reconstruction:

- arm-B/C/D-tracked.patch applies to the base commit. Add the original
  kernel_snapshot_test.rs and kernel_idle_admission_test.rs sibling files from this
  bundle; they are not in the tracked-only diffs.
- arm-E-full.patch includes every new file and final fixed-budget fixture.
- fixed-budget-idle-test.rs also preserves that fixture separately. Its notification
  happens after wait arming, not after an assumed elapsed delay.
- The full E work is shelved at the stash identity in stash-id.txt.

Proof/attempt accounting:

- old-snapshot-negative.log: retained A fails three snapshot assertions and passes
  fresh remote observation. The prior observer patch was reused/adapted, not
  presented as a new successful optimization.
- idle-fixture-configuration-error.log is only a fixture error. The corrected
  old-idle-negative-fixed.log fails admission-only probe avoidance and passes the
  preserved parked-handoff signal check.
- kernel-D.log: 66 pass, one ignored manual probe. ingress-D.log: three pass.
- fixed-budget-negative-zero.log rejects zero instead of 32 actual probe visits;
  the exact parked 640 check passes. kernel-E.log: 66 pass, one ignored probe.
- No full canonical run is claimed for the rejected candidates. The restored
  production runtime is identical to the preceding fourteen-gate qualified source.

Performance:

- tight1 has 19 completed invocations: all 16 balanced 1k factorial processes and
  three 10k processes. The third 10k process catches an unrelated build after-run;
  that incomplete group is excluded. Remaining planned 10k runs did not execute.
- fixed1 has eight complete A/E processes. This was the only fixed budget tested
  after rejecting zero probes. Neither optional candidate passed tight lifecycle.
- tight1-analysis.json/md and fixed1-analysis.json/md select only complete guarded
  process groups. Raw outputs, counter CSVs, host/CPU endpoint observations and
  exact commands remain available, including the excluded group.
- No own builds/tests/soaks overlap measurement. Endpoint guards are not continuous
  exclusivity proof. PMU cycles, CPU time, throughput-derived ns/task and context
  switches are distinct observables, not automatically interchangeable costs.
- No spare-capacity, synchronization, burst CPU, tails or refreshed May claim.

The comparison and analysis helpers reuse the prior capture functions. Copies of
their imported helpers are included as control.py and capture.py; adjust absolute
paths in a fresh extraction to verified source/binary locations. Analysis refuses
to overwrite existing JSON. The source-keyed review records the stop decision.
