"""Factorial case groups with complete, guarded, balanced process samples."""

import importlib.util
import json
from pathlib import Path
import statistics
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture', ROOT / 'target/finish-line/native-deferral.jBIgJM/analyze.py')
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
capture.OUT = OUT


def analyze(cohort, cases):
    result = {}
    for case in cases:
        samples = {arm: [capture.sample(f'{cohort}-{round_number}-{case}-{arm}') for round_number in range(1, 5)] for arm in 'ABCD'}
        metrics = {}
        for metric in samples['A'][0]:
            values = {arm: [row[metric] for row in rows] for arm, rows in samples.items()}
            medians = {arm: statistics.median(rows) for arm, rows in values.items()}
            metrics[metric] = {
                'samples': values,
                'medians': medians,
                'versus_A_percent': {arm: capture.change(medians['A'], value) for arm, value in medians.items()},
            }
        result[case] = metrics
    with (OUT / f'{cohort}-analysis.json').open('x') as stream:
        json.dump(result, stream, indent=2)
    print('| Case | A ns/op | B ns/op | C ns/op | D ns/op | B cycles | C cycles | D cycles |')
    print('| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |')
    for case, metrics in result.items():
        times = metrics['ns/op']['medians']
        changes = metrics['cycles']['versus_A_percent']
        print(f"| {case} | {times['A']:.2f} | {times['B']:.2f} | {times['C']:.2f} | {times['D']:.2f} | {changes['B']:+.2f}% | {changes['C']:+.2f}% | {changes['D']:+.2f}% |")


if __name__ == '__main__':
    analyze(sys.argv[1], sys.argv[2:])
