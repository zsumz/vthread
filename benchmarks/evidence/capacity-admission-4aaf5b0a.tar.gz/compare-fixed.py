"""The single predeclared 32-probe follow-up; no parameter search."""

import importlib.util
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('factorial', OUT / 'compare.py')
factorial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(factorial)
factorial.ORDERS = ('AE', 'EA', 'EA', 'AE')


if __name__ == '__main__':
    factorial.main(sys.argv[1], sys.argv[2:])
