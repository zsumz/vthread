//! The notifier observes wait arming only after the exact probe budget was spent.

use super::Kernel;
use crate::{CarrierId, Runtime, TaskFailure, control::Shared};
use std::sync::Arc;

fn episode(parked: bool) -> usize {
    let config = Runtime::builder()
        .carriers(2)
        .max_vthreads(4)
        .carrier_queue_capacity(4)
        .stack_cache_capacity(4)
        .build()
        .unwrap()
        .config();
    let shared = Arc::new(Shared::new(config));
    let scope = shared.begin_scope().unwrap();
    let mut kernel = Kernel::new(Arc::clone(&shared), CarrierId(0));
    if parked {
        let (parker, _wake) = crate::park_pair();
        shared
            .submit(scope, "parked handoff".into(), move || parker.park())
            .unwrap();
        kernel.receive();
        assert!(kernel.tick(false).unwrap());
        assert_eq!(kernel.parked.len(), 1);
    }
    let observed = kernel.inbox.signal.version();
    std::thread::scope(|threads| {
        let signal = Arc::clone(&kernel.inbox.signal);
        let notifier = threads.spawn(move || {
            let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
            while signal.waiting() == 0 && std::time::Instant::now() < deadline {
                std::thread::yield_now();
            }
            let armed = signal.waiting() != 0;
            signal.notify();
            assert!(armed, "idle episode did not reach its native wait boundary");
        });
        kernel.wait_for_work(observed);
        notifier.join().unwrap();
    });
    let visits = kernel.idle_probe_visits;
    kernel.abort(None, TaskFailure::RuntimeStopped);
    shared.finish_scope(scope);
    visits
}

#[test]
fn admission_only_idle_uses_its_small_fixed_probe_budget() {
    assert_eq!(episode(false), 32);
}

#[test]
fn parked_handoffs_keep_the_existing_probe_and_signal_check() {
    assert_eq!(episode(true), 640);
}
