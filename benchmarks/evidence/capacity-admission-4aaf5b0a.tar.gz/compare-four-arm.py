"""Four-arm scan/probe experiment, using the existing guarded perf capture."""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('control', ROOT / 'target/finish-line/native-control.R84U9h/control.py')
control = importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
control.OUT = OUT
evidence = control.evidence
CASES = {
    'spawn1000': ['spawn', '4', '1000', '501'],
    'spawn10000': ['spawn', '4', '10000', '501'],
    'spawn-spare': ['spawn', '4', '10000', '101', '--max-vthreads', '65536'],
    'park-tight': ['park', '10000', '4', '64', '7', '--pin-carriers'],
    'park-spare': ['park', '10000', '4', '64', '7', '--pin-carriers', '--max-vthreads', '65536'],
    'channel-tight': ['channel-mpmc', '2000', '1', '4', '64', '7', '--pin-carriers'],
    'channel-spare': ['channel-mpmc', '2000', '1', '4', '64', '7', '--pin-carriers', '--max-vthreads', '65536'],
    'wake-tight': ['wake-tail', '2000', '4', '64', '7', '--pin-carriers'],
}
ORDERS = ('ABDC', 'BCAD', 'CDBA', 'DACB')


def main(cohort, cases):
    manifest = evidence.metadata('four-arm default-build screen; no handoff timing; one case group at a time')
    manifest['arms'] = {
        arm: {'binary_sha256': evidence.digest(OUT / f'arm-{arm}'),
              'source': json.loads((OUT / f'source-{arm}.json').read_text())}
        for arm in 'ABCD'
    }
    manifest['orders'] = ORDERS
    with (OUT / f'{cohort}-manifest.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
    for case in cases:
        arguments = CASES[case]
        for round_number, order in enumerate(ORDERS, 1):
            for arm in order:
                prefix = f'{cohort}-{round_number}-{case}-{arm}'
                assert not (OUT / f'{prefix}.command.json').exists()
                control.observe(prefix, 'before')
                command = ['timeout', '120s', 'perf', 'stat', '-x,', '-e',
                           'task-clock,cycles,instructions,context-switches,cpu-migrations',
                           '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', '0-3',
                           str(OUT / f'arm-{arm}'), 'vthread', *arguments]
                with (OUT / f'{prefix}.command.json').open('x') as stream:
                    json.dump(command, stream)
                with (OUT / f'{prefix}.log').open('x') as stream:
                    result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
                control.observe(prefix, 'after')
                assert result.returncode == 0, (prefix, result.returncode)
                print(f'completed {prefix}', flush=True)
    assert manifest['source_sha256'] == evidence.source_digest()


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2:])
