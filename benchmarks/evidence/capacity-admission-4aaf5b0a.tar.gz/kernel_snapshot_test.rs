//! Observation remains explicit, including owner-deferred publication records.

use std::sync::Arc;

use super::Kernel;
use crate::{CarrierId, CarrierStatus, RuntimeConfig, control::Shared, park_pair};

#[test]
fn carrier_publication_leaves_remote_depth_observation_to_the_reader() {
    let shared = Arc::new(Shared::new(RuntimeConfig::default()));
    let kernel = Kernel::new(Arc::clone(&shared), CarrierId(0));
    let hub = &kernel.inbox.hub;
    let before = hub.pending_observations();
    kernel.publish(CarrierStatus::Running);
    kernel.retire(CarrierStatus::Stopped);
    assert_eq!(hub.pending_observations(), before);
    assert_eq!(shared.snapshot().carriers[0].pending_wakes(), 0);
    assert_eq!(hub.pending_observations(), before + 1);
}

#[test]
fn snapshot_combines_published_local_wakes_with_fresh_remote_wakes() {
    let shared = Arc::new(Shared::new(RuntimeConfig::default()));
    let scope = shared.begin_scope().unwrap();
    let (local_parker, local_waker) = park_pair();
    let (remote_parker, remote_waker) = park_pair();
    shared
        .submit(scope, "local waiter".into(), move || local_parker.park())
        .unwrap();
    shared
        .submit(scope, "remote waiter".into(), move || remote_parker.park())
        .unwrap();
    shared
        .submit(scope, "local notifier".into(), move || {
            local_waker.unpark();
            crate::yield_now()
        })
        .unwrap();
    let mut kernel = Kernel::new(Arc::clone(&shared), CarrierId(0));
    kernel.receive();
    for _ in 0..3 {
        assert!(kernel.tick(true).unwrap());
    }
    remote_waker.unpark();
    assert_eq!(kernel.local.pending_wakes(), 1);
    assert_eq!(kernel.inbox.hub.pending(), 1);
    kernel.publish(CarrierStatus::Running);
    let pending = shared.snapshot().carriers[0].pending_wakes();
    while kernel.tick(true).unwrap() {}
    kernel.publish(CarrierStatus::Idle);
    let drained = shared.snapshot().carriers[0].pending_wakes();
    shared.finish_scope(scope);
    assert_eq!(pending, 2, "neither wake lane may hide the other");
    assert_eq!(drained, 0);
}

#[test]
fn remote_wake_depth_refreshes_without_another_carrier_publication() {
    let shared = Arc::new(Shared::new(RuntimeConfig::default()));
    let scope = shared.begin_scope().unwrap();
    let (parker, waker) = park_pair();
    shared
        .submit(scope, "remote".into(), move || parker.park())
        .unwrap();
    let mut kernel = Kernel::new(Arc::clone(&shared), CarrierId(0));
    kernel.receive();
    assert!(kernel.tick(true).unwrap());
    kernel.publish(CarrierStatus::Idle);
    assert_eq!(shared.snapshot().carriers[0].pending_wakes(), 0);
    waker.unpark();
    let pending = shared.snapshot().carriers[0].pending_wakes();
    while kernel.tick(true).unwrap() {}
    kernel.retire(CarrierStatus::Stopped);
    let drained = shared.snapshot().carriers[0].pending_wakes();
    shared.finish_scope(scope);
    assert_eq!(pending, 1, "remote observation must not wait for dispatch");
    assert_eq!(drained, 0);
}

#[test]
fn a_deferred_publication_remains_visible_after_its_queue_notice_is_consumed() {
    use crate::wait::wait_publication_probe_test::{PausedPublication, Stage};
    let shared = Arc::new(Shared::new(RuntimeConfig::default()));
    let scope = shared.begin_scope().unwrap();
    let (parker, waker) = park_pair();
    let cell = parker.wait.clone();
    shared
        .submit(scope, "deferred".into(), move || parker.park())
        .unwrap();
    let mut kernel = Kernel::new(Arc::clone(&shared), CarrierId(0));
    kernel.receive();
    assert!(kernel.tick(false).unwrap());
    std::thread::scope(|threads| {
        let mut pause = PausedPublication::install(&cell);
        let publisher = threads.spawn(|| waker.unpark());
        pause.observe(Stage::NoticePublished);
        assert!(!kernel.tick(false).unwrap());
        pause.observe(Stage::OwnerDeferred);
        assert_eq!(kernel.inbox.hub.pending(), 0);
        kernel.publish(CarrierStatus::Idle);
        assert_eq!(shared.snapshot().carriers[0].pending_wakes(), 1);
        assert!(cell.publication_is_held());
        pause.release();
        publisher.join().unwrap();
    });
    while kernel.tick(true).unwrap() {}
    shared.finish_scope(scope);
}
