# Measurement fixture development

Base `d79b802`, runtime unchanged from the qualified publication-progress repair.
The first direct compile failed on private root parking aliases; paths were
corrected to the existing public `vthread::parking` module. A direct default
debug rerun passed all eight fixture tests; strict feature-on lab Clippy passed.
Those early commands were observed interactively, not captured as durable logs.

The initial architecture check found inventory/feature-definition drift and two
uses of the unapproved `println` macro. The lab uses the existing approved
`writeln` boundary instead; no macro grant was added. The reviewed contract delta
selects the existing lab-to-runtime profiling feature forwarding only in the
explicit handoff-profiling world, and adds one lab executable/eight Rust files.
This does not add any dependency, unsafe code, or runtime policy. The pre-update
diff classified the exact feature-world addition and changed contract bytes as
unknown rather than permissions. The user granted future session grants; this
inventory update is explicitly approved for this measurement-only slice.

The sleep fixture records Linux S/futex observations before release, not an
atomic proof of OS sleep at publication. Its source-gating yields, native procfs
reads, command wake, active borrowed keeper and reporting are deliberately not
part of the acquisition interval, but remain in process counter totals. The
control is closed-loop, one FIFO successor; it is not loaded fairness or the
default-contract mutex benchmark. The library's production source is unchanged.

The first canonical attempt passed all fourteen gates. An invalid timestamp
negative control failed as required, but initially printed only secondary peer
stop. Lab reporting was repaired to retain both outcomes; the repeated mutation
explicitly reports the primary stale sample and the secondary stopped source.
That mutation was reverted. The subsequent final canonical attempt caught a
separate existing observer-order assumption in the real sleeping-owner tests.
The lab was stashed as `1371b71e7f790bd6e32622b60fd106d99d81a1e5`; an initial
intent-to-add stash attempt failed without changing the worktree, then staging
the same exact owned paths allowed the recoverable stash. No other work was
touched, and the stash is retained after application.

Commit `7d4af02` independently repairs that test-only observer assumption with a
deterministic old-code failure, all fourteen gates and 400 additional native tests
(34 owner-first observations). The lab is restored on that checkpoint; the
resumed qualification is separately recorded. The original six loaded findings
remain open. No mutex performance process ran before this correction.

The resumed fourteen-gate run passed. The first CLI smoke then completed one
100-handoff local process and failed before admission in remote-active setup:
the initial pinning code assumed carrier names were already visible when the
runtime builder returned. The third smoke did not run. Those attempts and binary
identities are retained, not combined with the panel. Startup-only discovery now
matches the existing benchmark's bounded two-second wait for exactly the expected
carrier names, rejecting extra workers; a unit test covers partial visibility.
No runtime polling or operation timing changes. The rebuilt arms are default2
and diagnostic2; the original binaries/manifests are not overwritten.

The controls use the unchanged workspace release profile, not the standalone
benchmark crate's thin-LTO/single-codegen-unit profile. No release-profile or
RUSTFLAGS environment override was present in the inspected environment. This is
a mechanism control, not a refreshed main benchmark or direct May scorecard.

All three rebuilt 100-handoff smokes passed. The formal default2 panel stopped
before its first process: the guard observed cargo PID 2910471 and its active
zrail test child. The stopped guard/host files remain under the original prefix;
any later resumed panel uses a new `panel2-` prefix and never overwrites them.
Final qualification may overlap that unrelated build, but performance processes
must not. The smoke medians are preliminary, not the independent-process panel.
