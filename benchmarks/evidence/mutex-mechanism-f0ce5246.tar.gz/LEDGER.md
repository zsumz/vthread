# Mutex mechanism fixture; full attribution panel pending

This is lab-only code on base `7d4af02`, with no change to runtime ownership,
stack switching, affinity, checkpoints, fairness or polling. The full final source
SHA is `f0ce5246d87b7846b36b0d1ddc8f3f7c1b95e5509922f20f2fe8b4bbdfe9b9c5`.
The final default2 and diagnostic2 manifests identify the actual binaries. Both
use the ordinary workspace release profile, not the benchmark crate's thin-LTO
profile. No executed binary is included in this archive.

Qualification development is recorded in `qualification-notes.md`, including
private parking alias compile errors, macro/feature-world review, the original
timestamp negative control's masked primary error and the corrected two-outcome
error reporting. The deliberately invalid timestamp then reports both the stale
recipient sample and secondary source stop. The old reject-partial-startup policy
also fails its deterministic test. Mutations are reverted and the restored source
hash equals both final binary manifests. Nine fixture tests and four evidence
parser tests pass after restoration.

The final canonical receipt is `run-1788687621-285904529-2911800`: all fourteen
tasks pass with repository state preserved, including default native debug and
release and all-feature suites. Earlier attempts/receipts remain visible. The
separate observer-order failure was repaired in `7d4af02` with a deterministic
negative control, fourteen-gate qualification and 400 additional native tests;
this lab does not claim another production progress repair.

Five smoke processes ran: the original local process passed, original remote
setup failed before admission, and all three startup-repaired controls passed.
The repaired smokes contain 100 queued handoffs each and complete raw sample
sequences, pinning evidence and process counters. They are preliminary, not the
planned multi-process comparison. Source/recipient TIDs and carrier IDs are
checked on the measured tasks, not inferred from a shared hub or warm-up.

Two formal-panel attempts stopped before their first process. Both before-guards
observe unrelated cargo PID 2910471 and its CPU-bound zrail test child; their
original and panel2-prefixed files are retained. Consequently **zero formal
default-panel processes and zero diagnostic-panel processes ran**. No mutex
optimization or performance improvement is accepted. The analyzer must reject
this incomplete panel instead of emitting a successful empty comparison.

The next attempt must use a new prefix, preserve these exclusions, and run the
balanced 18-process default panel plus nine diagnostic controls without own or
observed competing builds. Review throughput/cycles only with the caveat that
process costs include fixture setup, procfs, control wakes/yields, borrowed active
keeper and raw sample reporting. Per-handoff timestamps cover before unlock to
recipient lock return, including their clock/stamp overhead. Sleep is observed
before unlock, not guaranteed at the exact publication instruction. These are
closed-loop single-successor controls, not multi-waiter fairness or offered-load
tail qualification. The six loaded findings remain open; no May result is new.
