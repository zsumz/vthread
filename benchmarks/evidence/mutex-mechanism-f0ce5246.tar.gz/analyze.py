"""Summarize independent controls; process costs are not isolated mutex costs."""

import csv
import json
from pathlib import Path
import statistics

from panel import parse

OUT = Path(__file__).resolve().parent


def counters(path):
    result = {}
    for row in csv.reader(path.read_text().splitlines()):
        if len(row) < 5 or row[2] not in {'task-clock', 'cycles', 'instructions', 'context-switches', 'cpu-migrations'}:
            continue
        assert '<' not in row[0], row
        if row[4]:
            assert float(row[4]) >= 99.5, row
        result[row[2]] = float(row[0])
    assert len(result) == 5
    return result


def selected(prefix):
    assert json.loads((OUT / f'{prefix}.result.json').read_text())['returncode'] == 0
    for stage in ['before', 'after']:
        assert not (OUT / f'{prefix}.{stage}.guard').read_text().strip()
    report, diagnostics = parse((OUT / f'{prefix}.log').read_text())
    return {'prefix': prefix, 'report': report, 'diagnostics': diagnostics,
            'counters': counters(OUT / f'{prefix}.csv')}


def main():
    results = {}
    for arm in ['default2', 'diagnostic2']:
        groups = {}
        for path in sorted(OUT.glob(f'panel2-{arm}-[123]-*.result.json')):
            value = selected(path.name.removesuffix('.result.json'))
            key = f'{value["report"]["mode"]}-{value["report"]["iterations"]}'
            groups.setdefault(key, []).append(value)
        expected = 6 if arm == 'default2' else 3
        assert len(groups) == expected, (arm, len(groups), expected, 'full planned panel is incomplete')
        results[arm] = {}
        for key, values in groups.items():
            assert len(values) == 3, (key, len(values), 'partial group is not the planned panel')
            count = int(values[0]['report']['iterations'])
            summary = {}
            for name in ['p50_ns', 'p99_ns', 'p999_ns', 'max_ns', 'recipient_parks', 'source_yields', 'keeper_yields', 'elapsed_ns']:
                observations = [int(value['report'][name]) for value in values]
                summary[name] = {'median': statistics.median(observations), 'range': [min(observations), max(observations)]}
            for name in values[0]['counters']:
                observations = [value['counters'][name] / count for value in values]
                summary[f'process_{name}_per_handoff'] = {'median': statistics.median(observations), 'range': [min(observations), max(observations)]}
            results[arm][key] = {'summary': summary, 'processes': values}
    with (OUT / 'analysis.json').open('x') as stream:
        json.dump(results, stream, indent=2)
    print(json.dumps({arm: {key: group['summary'] for key, group in groups.items()} for arm, groups in results.items()}, indent=2))


if __name__ == '__main__':
    main()
