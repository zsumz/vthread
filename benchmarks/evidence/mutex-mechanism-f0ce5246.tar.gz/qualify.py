"""Capture the measurement-only slice's qualification; never overlap its timing."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence
ENV = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_TARGET_DIR=str(BUILD))


def run(label, command, expected=0):
    with (OUT / f'{label}.command.json').open('x') as stream:
        json.dump(command, stream)
    with (OUT / f'{label}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream,
                                stderr=subprocess.STDOUT)
    with (OUT / f'{label}.result.json').open('x') as stream:
        json.dump({'returncode': result.returncode, 'expected': expected}, stream)
    print(f'{label}: {result.returncode}', flush=True)
    assert result.returncode == expected


def build(arm, features):
    run(f'{arm}-build', ['cargo', 'build', '--locked', '--release', '-p', 'vthread-lab',
                       '--bin', 'vthread-mutex-handoff', *features])
    binary = OUT / f'{arm}-binary'
    assert not binary.exists()
    shutil.copy2(BUILD / 'release/vthread-mutex-handoff', binary)
    manifest = evidence.metadata('controlled forced mutex handoffs; runtime retained; process counters include control and reporting; not optimization acceptance')
    manifest.update(binary_sha256=evidence.digest(binary), features=features)
    with (OUT / f'{arm}-source.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)


if __name__ == '__main__':
    if sys.argv[1] == 'qualify':
        run('zrail-update', ['zrail', 'update', '--base', 'HEAD', '--accept-grants'])
        run('zrail-diff', ['zrail', 'diff', '--base', 'HEAD', '--deny-grants'])
        run('canonical', ['zcheck', 'run', 'check'])
    elif sys.argv[1] == 'build':
        build('default', [])
        build('diagnostic', ['--features', 'handoff-profiling'])
    elif sys.argv[1] == 'canonical':
        run('zrail-final-update', ['zrail', 'update', '--base', 'HEAD', '--accept-grants'])
        run('zrail-final-diff', ['zrail', 'diff', '--base', 'HEAD', '--deny-grants'], expected=1)
        # The five reviewed analysis-universe deltas remain UNKNOWN to zrail.
        # This is not a zero-exit architecture-diff claim. Canonical zrail check
        # must independently validate the exact new lock and source census.
        run('canonical', ['zcheck', 'run', 'check'])
    elif sys.argv[1] == 'final':
        run('zrail-report-update', ['zrail', 'update', '--base', 'HEAD', '--accept-grants'])
        run('canonical-final', ['zcheck', 'run', 'check', '--logs-dir', str(OUT / 'canonical-final'),
                                '--receipt', str(OUT / 'canonical-final-receipt.json')])
    elif sys.argv[1] == 'resumed':
        run('zrail-resumed-check', ['zrail', 'check', '--format', 'json'])
        run('canonical-resumed', ['zcheck', 'run', 'check', '--logs-dir', str(OUT / 'canonical-resumed'),
                                  '--receipt', str(OUT / 'canonical-resumed-receipt.json')])
    elif sys.argv[1] == 'pin-fixed':
        run('pin-fixed-tests', ['cargo', 'test', '--locked', '-p', 'vthread-lab', '--bin', 'vthread-mutex-handoff', '--', '--nocapture'])
        build('default2', [])
        build('diagnostic2', ['--features', 'handoff-profiling'])
    elif sys.argv[1] == 'pinned-final':
        run('canonical-pinned', ['zcheck', 'run', 'check', '--logs-dir', str(OUT / 'canonical-pinned'),
                                 '--receipt', str(OUT / 'canonical-pinned-receipt.json')])
