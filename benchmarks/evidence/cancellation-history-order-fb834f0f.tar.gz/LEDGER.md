# Separate cancellation history semantics from timing

Base: 00b3e61 on perf/scheduler-hot-path. No production runtime or architecture
lock change. Frozen cancellation delivery, pruning, checkpoints, ownership,
affinity, scheduler and polling code remain unchanged after deliberate controls.

The original captured failure is a child-cancellation elapsed-time ratio:
ending.1 <= beginning.1 * 128 + 10_000_000. It happened before the old diagnostic
print, so the actual start/end samples are unavailable. The failure alone does
not distinguish OS delay from implementation cost. Do not classify that unique
historical cause as host noise or claim that a quiet rerun proves non-regression.

The required semantic test still traverses 100,000 dynamic successor generations
for both direct-ancestor and owning-scope cancellation. It checks exact graph
bounds (nodes <= 8, relays <= 1, edges <= 12), retained task diagnostics <= 2,
selected cancellation, typed completion and clean shutdown. Timing samples are
still printed as diagnostics, but no longer serve as the correctness oracle.

The bounded handoff receive follows completion of the parent whose body performs
the send. try_recv therefore checks ordered publication directly: no 10-second
test gate is needed after successful parent completion. Dropping that send fails
immediately with the missing-handoff evidence, before cleanup can mask it.

The unchanged 128x + 10 ms timing guard is retained in an explicitly ignored
performance test and zcheck run perf-cancellation-history (optimized defaults,
exact selection, --ignored). It is intentionally separate from zcheck run check.
The canonical policy gate rejects removal of the task or removal of --release,
--ignored or --exact. Eight policy tests pass, including these negative controls.
The Rust threshold test accepts the exact boundaries and rejects either excessive
sample. A mutation bypassing both comparisons makes that test fail.

The production pruning mutation causes the semantic history test to fail at
generation zero with (104, 0, 103), rather than merely relying on timing to detect
retained history. The successor-send mutation fails on an empty bounded handoff.
Both production/test sources are restored exactly. All targeted restored tests
pass. The initial and restored samples are preserved but are not performance
acceptance on this loaded host.

The separate performance invocation uses the existing mutex-panel host guard,
copied unchanged as measurement_support.py. A build overlap stops the invocation
and remains evidence, rather than silently retrying or counting a smoke as a
complete independent performance comparison.

Final canonical receipt run-1788691295-877243152-2986611 passes all fourteen tasks
with repository state preserved: 541 default-native runtime tests in debug and
release, 570 all-feature runtime tests, two explicit manual/performance probes
ignored in those suites. The original required native commands are unchanged.

Three debug and three release invocations, each pinned with its carriers to one
allowed CPU, pass all three non-ignored history tests. The dynamic cases traverse
1.2 million successor generations across those six invocations, with both
cancellation choices and at most two live tasks. This is not a high-population
mixed-lifetime release soak and not a benchmark acceptance result.

The distinct timing task passes under receipt run-1788691832-161701542-3004520,
with clean before/after build guards. Raw beginning/ending samples are retained.
This is one operational check of the unchanged timing allowance, not independent
multi-process cycle evidence or a reconstruction of the old unrecorded sample.
The semantic/timing oracle ambiguity is resolved; the historical performance
excursion remains explicitly open in release-performance evidence.
