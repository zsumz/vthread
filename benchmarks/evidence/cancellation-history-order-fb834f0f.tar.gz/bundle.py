"""Archive semantic proof, retained performance gate and explicit open evidence."""

import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

manifest = evidence.metadata('cancellation-history semantic and performance test separation; runtime unchanged')
assert manifest['source_sha256'] == json.loads(
    (OUT / 'canonical.command.json').read_text())['source']['source_sha256']
with (OUT / 'source.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
with (OUT / 'candidate.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--',
                 'crates/vthread/src/cancellation_history_test.rs', 'scripts/guardrail-policy.py',
                 'scripts/guardrail_policy_test.py', 'zcheck.toml'], cwd=ROOT))
archive_path = ROOT / f'benchmarks/evidence/cancellation-history-order-{manifest["source_sha256"][:8]}.tar.gz'
paths = sorted(path for path in OUT.rglob('*') if path.is_file()
               and '__pycache__' not in path.parts and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(archive_path, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
verify = Path(tempfile.mkdtemp(prefix='cancellation-history-order-verify.', dir=ROOT / 'target/finish-line'))
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    assert all(member.isfile() and not Path(member.name).is_absolute()
               and '..' not in Path(member.name).parts for member in members)
    archive.extractall(verify, members=members)
with (verify / 'verification.log').open('x') as stream:
    subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=verify, stdout=stream,
                   stderr=subprocess.STDOUT, check=True)
print('archive', archive_path)
print('sha256', evidence.digest(archive_path))
print('verified', len(paths), 'internal hashes', verify)
