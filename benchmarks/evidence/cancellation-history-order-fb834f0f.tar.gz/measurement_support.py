"""Controlled mechanism evidence, not candidate acceptance or a May comparison."""

import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/root/vthread')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

MODES = ['local', 'remote-active', 'remote-sleep-observed']


def observe(prefix, stage):
    (OUT / f'{prefix}.{stage}.host').write_text(evidence.output('ps', '-eo', 'pid,comm,pcpu,etime') + '\n')
    (OUT / f'{prefix}.{stage}.cpu').write_text(''.join(Path('/proc/stat').read_text().splitlines(keepends=True)[:9]))
    guard = subprocess.run(['pgrep', '-x', 'cargo|rustc|clippy-driver|zrail'], capture_output=True, text=True)
    (OUT / f'{prefix}.{stage}.guard').write_text(guard.stdout + guard.stderr)
    if guard.returncode != 1:
        raise RuntimeError('guarded build overlap: stop, retain, do not silently retry')


def parse(text):
    rows = [dict(piece.split('=', 1) for piece in line.split()) for line in text.splitlines()]
    reports = [row for row in rows if row.get('workload') == 'mutex-mechanism']
    assert len(reports) == 1
    report = reports[0]
    count = int(report['iterations'])
    samples = [row for row in rows if 'sample' in row]
    assert [int(row['sample']) for row in samples] == list(range(count))
    values = [int(row['nanoseconds']) for row in samples]
    sorted_values = sorted(values)
    for key, numerator, denominator in [('p50_ns', 50, 100), ('p99_ns', 99, 100), ('p999_ns', 999, 1000)]:
        assert int(report[key]) == sorted_values[(count * numerator + denominator - 1) // denominator - 1]
    assert int(report['max_ns']) == max(values)
    assert int(report['queued_handoffs']) == count
    assert int(report['recipient_parks']) >= count
    assert int(report['sleep_observations']) == (count if report['mode'] == 'remote-sleep-observed' else 0)
    local = report['mode'] == 'local'
    assert (report['sender_tid'] == report['recipient_tid']) == local
    assert (report['sender_carrier'] == report['recipient_carrier']) == local
    affinities = [row for row in rows if row.get('phase') == 'affinity']
    assert len(affinities) == (1 if local else 2)
    assert {row['tid'] for row in affinities} == {report['sender_tid'], report['recipient_tid']}
    assert all(row['verified'] == 'true' for row in affinities)
    return report, [row for row in rows if row.get('phase') == 'diagnostic']


def run(arm, prefix, mode, count):
    binary = OUT / f'{arm}-binary'
    manifest = json.loads((OUT / f'{arm}-source.json').read_text())
    assert evidence.digest(binary) == manifest['binary_sha256']
    assert evidence.source_digest() == manifest['source_sha256']
    observe(prefix, 'before')
    command = ['timeout', '90s', 'perf', 'stat', '-x,', '-e',
               'task-clock,cycles,instructions,context-switches,cpu-migrations',
               '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', '6-7', str(binary), mode, str(count)]
    with (OUT / f'{prefix}.command.json').open('x') as stream:
        json.dump(command, stream)
    with (OUT / f'{prefix}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    with (OUT / f'{prefix}.result.json').open('x') as stream:
        json.dump({'returncode': result.returncode}, stream)
    observe(prefix, 'after')
    assert result.returncode == 0, (prefix, result.returncode)
    # perf's success text is in its -o file, so stdout is an exact lab schema.
    report, diagnostics = parse((OUT / f'{prefix}.log').read_text())
    with (OUT / f'{prefix}.parsed.json').open('x') as stream:
        json.dump({'report': report, 'diagnostics': diagnostics}, stream, indent=2)
    print(f'completed {prefix}: p50={report["p50_ns"]} p999={report["p999_ns"]}', flush=True)


if __name__ == '__main__':
    arm = sys.argv[1]
    tag = sys.argv[2] if len(sys.argv) > 2 else ''
    if arm in ['smoke', 'smoke2']:
        for mode in MODES:
            run('default2' if arm == 'smoke2' else 'default', f'{arm}-{mode}', mode, 100)
    else:
        for round_number in range(1, 4):
            modes = MODES if round_number % 2 else list(reversed(MODES))
            counts = [1000, 10000] if arm.startswith('default') else [1000]
            if round_number % 2 == 0:
                counts.reverse()
            for count in counts:
                for mode in modes:
                    run(arm, f'{tag}{arm}-{round_number}-{mode}-{count}', mode, count)
