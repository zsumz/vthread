"""Keep semantic history proof separate from the original timing guard."""

import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
ENV = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_TARGET_DIR='/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def run(label, command, expected=0):
    with (OUT / f'{label}.command.json').open('x') as stream:
        json.dump({'argv': command, 'environment': {key: ENV[key] for key in ('CARGO_INCREMENTAL', 'CARGO_TARGET_DIR')},
                   'source': evidence.metadata(label)}, stream, indent=2)
    with (OUT / f'{label}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    with (OUT / f'{label}.result.json').open('x') as stream:
        json.dump({'returncode': result.returncode, 'expected': expected}, stream)
    print(label, result.returncode, flush=True)
    assert result.returncode == expected


mode = sys.argv[1]
if mode in ('positive', 'restored', 'negative-pruning', 'negative-performance', 'negative-handoff'):
    target = {'positive': 'cancellation_history_test', 'restored': 'cancellation_history_test',
              'negative-pruning': 'sequential_dynamic_generations_keep_cancellation_live_and_bounded',
              'negative-handoff': 'sequential_dynamic_generations_keep_cancellation_live_and_bounded',
              'negative-performance': 'the_history_performance_guard_rejects_each_excessive_sample'}[mode]
    run(mode, ['cargo', 'test', '--locked', '-p', 'vthread', target, '--', '--nocapture'],
        101 if mode.startswith('negative') else 0)
elif mode in ('canonical', 'performance'):
    task = 'check' if mode == 'canonical' else 'perf-cancellation-history'
    if mode == 'performance':
        import measurement_support
        measurement_support.observe('performance', 'before')
    run(mode, ['zcheck', 'run', task, '--logs-dir', str(OUT / mode),
               '--receipt', str(OUT / f'{mode}-receipt.json')])
    if mode == 'performance':
        measurement_support.observe('performance', 'after')
elif mode == 'repeat':
    profile = sys.argv[2]
    log = OUT / f'canonical/{"0007-test-native.log" if profile == "debug" else "0008-test-native-release.log"}'
    binaries = re.findall(r'Running unittests src/lib.rs \(([^)\s]*/deps/vthread-[0-9a-f]+)\)', log.read_text())
    assert len(binaries) == 1, binaries
    binary = binaries[0]
    with (OUT / f'repeat-{profile}-binary.json').open('x') as stream:
        json.dump({'path': binary, 'sha256': evidence.digest(Path(binary))}, stream)
    for index in range(3):
        label = f'repeat-{profile}-{index:02}'
        run(label, ['taskset', '-c', '6', binary, 'cancellation_history_test', '--nocapture'])
        assert 'test result: ok. 3 passed;' in (OUT / f'{label}.log').read_text()
else:
    raise SystemExit(f'unknown mode {mode}')
