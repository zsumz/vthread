"""Preserve the complete measured fixture panel and verify every member."""

import hashlib
from pathlib import Path
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'benchmarks/evidence/mutex-mechanism-quiet-f0ce5246.tar.gz'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


paths = sorted(path for path in OUT.rglob('*') if path.is_file()
               and '__pycache__' not in path.parts and path.name != 'SHA256SUMS'
               and not path.name.endswith('-binary'))
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(DESTINATION, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
with tarfile.open(DESTINATION) as archive:
    members = archive.getmembers()
    assert len(members) == len(paths) + 1
    assert all(member.isfile() and not Path(member.name).is_absolute()
               and '..' not in Path(member.name).parts for member in members)
    sums = archive.extractfile('SHA256SUMS').read().decode().splitlines()
    assert len(sums) == len(paths)
    for line in sums:
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
print(DESTINATION, digest(DESTINATION), len(paths), 'verified internal hashes')
