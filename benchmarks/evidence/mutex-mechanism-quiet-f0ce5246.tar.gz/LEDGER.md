# Complete quiet-host mutex mechanism panel

Exact frozen fixture: clean detached 80b3ba1, source f0ce5246, with the previously
qualified default/diagnostic binaries verified by identify.py. The current perf
branch is bfdef5e; intervening changes are test, policy, harness or evidence,
not production mutex, scheduling, affinity or polling changes. No runtime
candidate is being promoted and this fixture is not a May comparison.

All 18 default and nine diagnostic invocations completed, with every before/after
build guard clear. Three independent processes per cell, fixed 1,000/10,000 work
counts for default and 1,000 for diagnostics. Cases and work counts reverse on
the middle repetition. No earlier partial/guarded/smoke process is imported.
Fresh processes pin and verify actual measured owner TIDs on guest CPUs 6-7.
All queued handoffs, generations, protected values, samples and shutdown checks
pass. The analyzer requires all nine cells and all three observations in each.

Long counter-collected default cells (medians of process-level quantiles): local p50 191 ns,
remote-active p50 320 ns, observed-sleep p50 10,566 ns. Their p99.9 medians are
281 / 501 / 46,280 ns. Maximum observations remain 4,707 / 7,221,885 /
50,990,719 ns respectively. Quiet guest guards are not proof of an isolated
physical host; large outliers are not discarded or causally attributed.

Diagnostic local controls route 2,000 wakes locally and report two native waits.
Remote-active controls report 1,999 source-side shared routes, one recipient-local
route and two native waits per carrier. Observed-sleep controls report 1,999
source-side shared routes and 1,001-1,003 recipient native wait invocations.
The actual source/recipient identities, not a shared-hub counter alone, establish
which owner is remote. Command parks contribute to counts. Native wait calls are
not themselves proof of actual sleep, and sleep is observed before release, not
atomically at wake publication. Exact handshake/sleep evidence is in each report.

No operation times are taken from the diagnostic binary. Whole-process cycles
include setup, command parks, source/keeper yields, procfs observation, shutdown,
sample formatting and reporting. Two work counts do not make those isolated
mutex cycles. The fixture forces one FIFO successor and selected owner states;
it does not establish their frequencies in the production mutex benchmark,
multi-waiter fairness, offered-load tails or an ownership-representation defect.

Four existing parser tests passed before execution. All chronological sample
streams, counters, endpoint host/CPU observations, commands, outcomes, identities,
analysis and the preceding qualification patch/receipt are retained. The
qualified native fixture source is unchanged, so no new canonical run is claimed
for this measurement-only panel. The exact preceding canonical receipt and
complete fixture patch are included for reconstruction. Binaries remain local.

## Counter-free validation

The independent current-source May panel exposed large counter-on/off differences
in native-wait-heavy controls. Before closing this fixture, nine additional
counter-free default invocations ran: three fresh processes per mode, 10,000
handoffs each, middle repetition reversing mode order. All nine passed the exact
owner, generation, payload, sample, park-count, pinning and shutdown checks; all
build guards were clear. They are new explicitly labeled controls, not substituted
observations in the preceding 27-process panel.

Without perf, the median of process p50 values is 191 ns local, 311 ns remote-active
and 3,666 ns after observed sleep (sleep process medians 4,147 / 3,666 / 3,666 ns).
The corresponding p99.9 medians are 260 / 490 / 11,808 ns; maximum individual
observations are 5,108 / 10,726 / 3,338,834 ns. Every recipient records 20,000 parks,
including command parks. Headline mechanism timing uses these counter-free
controls. The earlier 10,566 ns sleep result is explicitly counter-collected,
not a default cost claim. These blocks are not an interleaved collector crossover;
they do not identify the underlying OS/PMU mechanism.

All 36 invocations are retained. Ordinary/diagnostic process counters and no-perf
latencies remain distinct; no averaging across instrumentation configurations.
