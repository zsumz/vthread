"""Counter-free long controls; separate from the complete process-counter panel."""

import json
import statistics
import subprocess
import time

from panel import MODES, OUT, ROOT, evidence, observe, parse

manifest = json.loads((OUT / 'default2-source.json').read_text())
binary = OUT / 'default2-binary'
assert evidence.source_digest() == manifest['source_sha256']
assert evidence.digest(binary) == manifest['binary_sha256']
assert not evidence.output('git', 'status', '--porcelain')
jobs = [dict(prefix=f'bare-default2-{rep}-{mode}-10000', repetition=rep, mode=mode, count=10000)
        for rep in [1, 2, 3] for mode in (MODES if rep % 2 else list(reversed(MODES)))]
with (OUT / 'bare-plan.json').open('x') as stream:
    json.dump(jobs, stream, indent=2)
groups = {}
for job in jobs:
    prefix = job['prefix']
    observe(prefix, 'before')
    command = ['timeout', '90s', 'taskset', '-c', '6-7', str(binary), job['mode'], str(job['count'])]
    with (OUT / f'{prefix}.command.json').open('x') as stream:
        json.dump(dict(command=command, started_unix=time.time(), job=job), stream, indent=2)
    with (OUT / f'{prefix}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    with (OUT / f'{prefix}.result.json').open('x') as stream:
        json.dump(dict(returncode=result.returncode, finished_unix=time.time()), stream)
    observe(prefix, 'after')
    assert result.returncode == 0, (prefix, result.returncode)
    report, diagnostics = parse((OUT / f'{prefix}.log').read_text())
    assert not diagnostics and report['mode'] == job['mode'] and int(report['iterations']) == job['count']
    groups.setdefault(job['mode'], []).append(dict(prefix=prefix, report=report))
    print(f'completed {prefix}: p50={report["p50_ns"]} p999={report["p999_ns"]}', flush=True)
assert evidence.source_digest() == manifest['source_sha256']
assert not evidence.output('git', 'status', '--porcelain')
assert len(groups) == 3 and all(len(rows) == 3 for rows in groups.values())
summary = {}
for mode, rows in groups.items():
    values = {key: [int(row['report'][key]) for row in rows]
              for key in ['p50_ns', 'p99_ns', 'p999_ns', 'max_ns', 'recipient_parks']}
    summary[mode] = dict(processes=rows, summary={key: dict(values=items, median=statistics.median(items),
        minimum=min(items), maximum=max(items)) for key, items in values.items()})
with (OUT / 'bare-analysis.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
print('all nine guarded counter-free long controls completed', flush=True)
