# Channel reservation/publication experiments, 2026-09-06

Decision: reject every runtime candidate. The production source and zrail lock
are restored to base `3161514f20da1d08d8a5e863c9f3a0b7d2bf2920`;
source digest `f57b1db1457fc45f855e561e5eb89e489c72bcf166ef4c50400596057840c976`.
Capacity maintenance, readiness, task affinity, admission and the idle policy are
unchanged. There is no May run and no new performance-win claim.

## Source and binary map

Each patch applies independently to the base. Generated zrail locks are not
refreshed for rejected experiments; candidate qualification is targeted, not
canonical release evidence. Replaying full candidate gates requires reviewing
the architecture delta separately. The restored checkout runs its canonical gate.

| Arm | Source manifest and patch | Binary hash file | Raw prefix |
| --- | --- | --- | --- |
| Baseline | Base commit and `restored-source.json` | `baseline-binary.sha256` | `*-baseline-*` |
| A, eligible resource grants | `candidate-initial-source.json`, `candidate-initial.patch` | `candidate-initial.sha256` | `screen-*-candidate-*` |
| B, both-direction resource grants | `candidate-notification-source.json`, `candidate-notification.patch` | `candidate-notification.sha256` | `notify-*-candidate-*` |
| C, compact notification guards | `candidate-compact-source.json`, `candidate-compact.patch` | `candidate-compact.sha256` | `compact-*-candidate-*` |
| D, retained notification handles | `candidate-retained-source.json`, `candidate-retained.patch` | `candidate-retained.sha256` | `retained-*-candidate-*` |
| E, inlined D | `candidate-inlined-source.json`, `candidate-inlined.patch` | `candidate-inlined.sha256` | `inlined-*-candidate-*` |

The archive is keyed by E's source digest
`56f61f8642ebd8f12599096f91fefa7c5dabad649f5d9ae7b11c2ab95aa84668`.
Source manifests include compiler, kernel, CPU, feature-build context, base and
lock identity. Builds use `CARGO_INCREMENTAL=0`, the repository-pinned Rust
toolchain, `cargo build --locked --release --manifest-path benchmarks/Cargo.toml`
and no profiling features. The external target directory used on this host is
`/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI`.
The binaries themselves are not included; their immutable local copies were used
throughout each panel. Source patches and their hashes are the replay boundary.

## Evidence scope

- `screen.sh`: three A/B process pairs for 12 cases (72 completed processes).
- `notification-screen.sh`: B panel stopped on its second-round build guard.
  Thirty-five processes completed; only 34 form complete analysis pairs. The
  candidate eight-carrier process in round two remains unpaired and excluded.
- `compact-screen.sh`, `retained-screen.sh`, `inlined-screen.sh`: four A/B process
  pairs each, four cases each (32 processes each). No endpoint guard exclusion.
- Totals: 203 completed counter processes, 202 in complete analysis pairs.
  These are rejection screens, not acceptance of any runtime optimization.
- Original shell scripts contain exact original paths, masks, counts, rounds and
  timeout/perf commands. Adapt paths in a separate base checkout for replay.
- Counter totals include warm-up, initialization, validation and shutdown. Clocked
  channel endpoint distributions are a distinct sampled workload, not individual
  latency inferred from elapsed-time/operation throughput numbers.
- Guard files and before/after host/CPU snapshots expose observed contamination;
  endpoint checks cannot prove continuous VM or physical-host isolation.
- `analyze.py` rejects incomplete pairs, missing records and observed host builds.
  `comparison.json` includes medians and raw per-process values. Four analyzer
  tests cover counter parsing, pairing and contamination/incomplete-run rejection.

## Race tests and models

`negative-source.patch` was the original tracked-only capture and omitted the new
test file. `negative-publication_test.rs` reconstructs the exact final failing
test body from the preserved prototype, removing only its later Entry accessor.
`negative-complete.patch` combines that file with the original module addition.
Its application to the base is checked. `negative-metadata.log` captures the real
old-code lock-across-publication failure after ordered cleanup. Compile and
configuration errors during setup have distinct logs.

The resource-grant variant's `candidate-eligible` and
`candidate-notification-complete` patches preserve added race/reuse tests beyond
the corresponding timed source. `model-initial.log` records three failed overly
strong assertions about clearing an idle grant at retirement. `model-reuse.log`
tests production's actual ticket-removal/recycle boundary and passes all 12.

C includes the production notification-selection function in its Loom model;
D also includes the production queue Entry. `compact-model-qualification.log`
passes 12 tests; `retained-model.log` passes 13, including the deliberately broken
early-dequeue negative control. Models have at most three threads, one buffered
value, two generations and 1,000 branches, with no permutation/preemption cap.
The native routing queue, Binding, signaling and full runtime composition remain
outside the adapter's proof. Production atomic orderings are not weakened.

`channel-initial.log`, `channel-reservation-native.log`,
`notification-native-profile.log`, `notification-native-reuse.log`,
`compact-native-channel-qualification.log`, `compact-native-wait.log` and
`retained-native.log` record targeted native qualification. Some logs deliberately
contain caught unwind panics; their final test status determines success.
E only changes the inlining attribute and is screened with exact-delivery release
benchmarks; it does not acquire an independent canonical candidate qualification.

`retained-reserve-fronts.asm` and `inlined-symbols.txt` preserve the codegen audit.
`codegen-profile.guard` rejected a planned cycle profile before it started. There
are no results from that profile, and no inferred CPU attribution from it.

The opt-in prototype counter named `pending_notifications` includes a retained
ticket whose handle has moved to publication, even after the claim is published
but before that task consumes/rearms the ticket. D/E's initial Rust getter wording
is narrower than that actual meaning; those counters are not used for headline
timing or acceptance. This is a known prototype documentation correction for any
future continuation, not a shipped API claim.

## Recovery and verification

E is also shelved locally as
`6372fcbbd6c39a73c623a7d3683715fd9d9905ff`. Do not rely on a moving stash index.
All five timed patches are retained independently; no prior stash was applied or
removed. `restored-source.json` verifies exact restoration of production sources.
No new architecture permissions or debt are accepted.

From an extracted bundle:

```sh
sha256sum --check SHA256SUMS
python3 analyze_test.py
python3 analyze.py . screen notify compact retained inlined
```

In a separate checkout at the base, apply the selected patch and run its native
and model tests before timing. Use a separate default release binary per arm.
The restored production check passes all 11 gates in `restored-zcheck.log` under
receipt `run-1788659610-751414318-2581158`. Its detailed receipt/logs are included
under `restored-qualification/`. That gate does not qualify a rejected
prototype or close broader ARM64, loaded-tail, sanitizer or release-soak work.
