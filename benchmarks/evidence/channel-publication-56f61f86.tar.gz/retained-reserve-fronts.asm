
target/finish-line/channel-publication/candidate-retained:     file format elf64-x86-64


Disassembly of section .text:

00000000001747b0 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts>:
  1747b0:	55                   	push   %rbp
  1747b1:	41 57                	push   %r15
  1747b3:	41 56                	push   %r14
  1747b5:	41 55                	push   %r13
  1747b7:	41 54                	push   %r12
  1747b9:	53                   	push   %rbx
  1747ba:	50                   	push   %rax
  1747bb:	48 89 f3             	mov    %rsi,%rbx
  1747be:	49 89 fe             	mov    %rdi,%r14
  1747c1:	48 83 7f 38 00       	cmpq   $0x0,0x38(%rdi)
  1747c6:	0f 84 ce 00 00 00    	je     17489a <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0xea>
  1747cc:	49 8b 76 30          	mov    0x30(%r14),%rsi
  1747d0:	49 8b 46 20          	mov    0x20(%r14),%rax
  1747d4:	49 8b 4e 28          	mov    0x28(%r14),%rcx
  1747d8:	45 31 ff             	xor    %r15d,%r15d
  1747db:	48 39 c6             	cmp    %rax,%rsi
  1747de:	49 0f 42 c7          	cmovb  %r15,%rax
  1747e2:	48 29 c6             	sub    %rax,%rsi
  1747e5:	48 c1 e6 04          	shl    $0x4,%rsi
  1747e9:	48 8b 54 31 08       	mov    0x8(%rcx,%rsi,1),%rdx
  1747ee:	48 85 d2             	test   %rdx,%rdx
  1747f1:	0f 84 a6 00 00 00    	je     17489d <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0xed>
  1747f7:	48 8b 42 38          	mov    0x38(%rdx),%rax
  1747fb:	89 c7                	mov    %eax,%edi
  1747fd:	83 e7 0f             	and    $0xf,%edi
  174800:	48 83 ff 0c          	cmp    $0xc,%rdi
  174804:	0f 87 eb 01 00 00    	ja     1749f5 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x245>
  17480a:	48 01 f1             	add    %rsi,%rcx
  17480d:	45 31 ff             	xor    %r15d,%r15d
  174810:	be 55 01 00 00       	mov    $0x155,%esi
  174815:	eb 1e                	jmp    174835 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x85>
  174817:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  17481e:	00 00 
  174820:	f3 90                	pause  
  174822:	48 8b 42 38          	mov    0x38(%rdx),%rax
  174826:	89 c7                	mov    %eax,%edi
  174828:	83 e7 0f             	and    $0xf,%edi
  17482b:	48 83 ff 0d          	cmp    $0xd,%rdi
  17482f:	0f 83 c0 01 00 00    	jae    1749f5 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x245>
  174835:	48 83 ff 01          	cmp    $0x1,%rdi
  174839:	74 e5                	je     174820 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x70>
  17483b:	a8 20                	test   $0x20,%al
  17483d:	75 5e                	jne    17489d <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0xed>
  17483f:	44 8d 47 fd          	lea    -0x3(%rdi),%r8d
  174843:	41 80 f8 09          	cmp    $0x9,%r8b
  174847:	73 0a                	jae    174853 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0xa3>
  174849:	45 0f b6 c0          	movzbl %r8b,%r8d
  17484d:	44 0f a3 c6          	bt     %r8d,%esi
  174851:	72 4a                	jb     17489d <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0xed>
  174853:	49 89 c4             	mov    %rax,%r12
  174856:	49 83 e4 d0          	and    $0xffffffffffffffd0,%r12
  17485a:	49 83 cc 03          	or     $0x3,%r12
  17485e:	49 89 c0             	mov    %rax,%r8
  174861:	49 83 c8 10          	or     $0x10,%r8
  174865:	48 83 ff 02          	cmp    $0x2,%rdi
  174869:	4d 0f 44 c4          	cmove  %r12,%r8
  17486d:	f0 4c 0f b1 42 38    	lock cmpxchg %r8,0x38(%rdx)
  174873:	75 b1                	jne    174826 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x76>
  174875:	48 83 ff 02          	cmp    $0x2,%rdi
  174879:	75 1f                	jne    17489a <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0xea>
  17487b:	4c 8b 79 08          	mov    0x8(%rcx),%r15
  17487f:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
  174886:	00 
  174887:	4d 85 ff             	test   %r15,%r15
  17488a:	0f 84 7e 01 00 00    	je     174a0e <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x25e>
  174890:	4c 8b 2b             	mov    (%rbx),%r13
  174893:	4d 85 ed             	test   %r13,%r13
  174896:	75 0d                	jne    1748a5 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0xf5>
  174898:	eb 32                	jmp    1748cc <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x11c>
  17489a:	45 31 ff             	xor    %r15d,%r15d
  17489d:	4c 8b 2b             	mov    (%rbx),%r13
  1748a0:	4d 85 ed             	test   %r13,%r13
  1748a3:	74 27                	je     1748cc <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x11c>
  1748a5:	49 8d 7d 10          	lea    0x10(%r13),%rdi
  1748a9:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  1748ad:	31 d2                	xor    %edx,%edx
  1748af:	31 c9                	xor    %ecx,%ecx
  1748b1:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  1748b7:	e8 b4 5a f9 ff       	call   10a370 <_ZN7vthread4wait11wait_select16enqueue_selected17h5a35090e1549dd93E.llvm.12585570228806776198>
  1748bc:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  1748c1:	75 09                	jne    1748cc <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x11c>
  1748c3:	48 89 df             	mov    %rbx,%rdi
  1748c6:	ff 15 1c e2 01 00    	call   *0x1e21c(%rip)        # 192ae8 <_DYNAMIC+0x1140>
  1748cc:	4c 89 3b             	mov    %r15,(%rbx)
  1748cf:	4c 89 63 08          	mov    %r12,0x8(%rbx)
  1748d3:	49 83 7e 58 00       	cmpq   $0x0,0x58(%r14)
  1748d8:	0f 84 c9 00 00 00    	je     1749a7 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x1f7>
  1748de:	49 8b 76 50          	mov    0x50(%r14),%rsi
  1748e2:	49 8b 46 40          	mov    0x40(%r14),%rax
  1748e6:	49 8b 4e 48          	mov    0x48(%r14),%rcx
  1748ea:	45 31 ed             	xor    %r13d,%r13d
  1748ed:	48 39 c6             	cmp    %rax,%rsi
  1748f0:	49 0f 42 c5          	cmovb  %r13,%rax
  1748f4:	48 29 c6             	sub    %rax,%rsi
  1748f7:	48 c1 e6 04          	shl    $0x4,%rsi
  1748fb:	48 8b 54 31 08       	mov    0x8(%rcx,%rsi,1),%rdx
  174900:	48 85 d2             	test   %rdx,%rdx
  174903:	0f 84 a1 00 00 00    	je     1749aa <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x1fa>
  174909:	48 8b 42 38          	mov    0x38(%rdx),%rax
  17490d:	89 c7                	mov    %eax,%edi
  17490f:	83 e7 0f             	and    $0xf,%edi
  174912:	48 83 ff 0c          	cmp    $0xc,%rdi
  174916:	0f 87 d9 00 00 00    	ja     1749f5 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x245>
  17491c:	48 01 f1             	add    %rsi,%rcx
  17491f:	45 31 ed             	xor    %r13d,%r13d
  174922:	be 55 01 00 00       	mov    $0x155,%esi
  174927:	eb 1c                	jmp    174945 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x195>
  174929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  174930:	f3 90                	pause  
  174932:	48 8b 42 38          	mov    0x38(%rdx),%rax
  174936:	89 c7                	mov    %eax,%edi
  174938:	83 e7 0f             	and    $0xf,%edi
  17493b:	48 83 ff 0d          	cmp    $0xd,%rdi
  17493f:	0f 83 b0 00 00 00    	jae    1749f5 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x245>
  174945:	48 83 ff 01          	cmp    $0x1,%rdi
  174949:	74 e5                	je     174930 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x180>
  17494b:	a8 20                	test   $0x20,%al
  17494d:	75 5b                	jne    1749aa <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x1fa>
  17494f:	44 8d 47 fd          	lea    -0x3(%rdi),%r8d
  174953:	41 80 f8 09          	cmp    $0x9,%r8b
  174957:	73 0a                	jae    174963 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x1b3>
  174959:	45 0f b6 c0          	movzbl %r8b,%r8d
  17495d:	44 0f a3 c6          	bt     %r8d,%esi
  174961:	72 47                	jb     1749aa <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x1fa>
  174963:	49 89 c4             	mov    %rax,%r12
  174966:	49 83 e4 d0          	and    $0xffffffffffffffd0,%r12
  17496a:	49 83 cc 03          	or     $0x3,%r12
  17496e:	49 89 c0             	mov    %rax,%r8
  174971:	49 83 c8 10          	or     $0x10,%r8
  174975:	48 83 ff 02          	cmp    $0x2,%rdi
  174979:	4d 0f 44 c4          	cmove  %r12,%r8
  17497d:	f0 4c 0f b1 42 38    	lock cmpxchg %r8,0x38(%rdx)
  174983:	75 b1                	jne    174936 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x186>
  174985:	48 83 ff 02          	cmp    $0x2,%rdi
  174989:	75 1c                	jne    1749a7 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x1f7>
  17498b:	4c 8b 69 08          	mov    0x8(%rcx),%r13
  17498f:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
  174996:	00 
  174997:	4d 85 ed             	test   %r13,%r13
  17499a:	74 72                	je     174a0e <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x25e>
  17499c:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
  1749a0:	48 85 ed             	test   %rbp,%rbp
  1749a3:	75 0e                	jne    1749b3 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x203>
  1749a5:	eb 37                	jmp    1749de <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x22e>
  1749a7:	45 31 ed             	xor    %r13d,%r13d
  1749aa:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
  1749ae:	48 85 ed             	test   %rbp,%rbp
  1749b1:	74 2b                	je     1749de <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x22e>
  1749b3:	4c 8d 7b 10          	lea    0x10(%rbx),%r15
  1749b7:	48 8d 7d 10          	lea    0x10(%rbp),%rdi
  1749bb:	48 8b 73 18          	mov    0x18(%rbx),%rsi
  1749bf:	31 d2                	xor    %edx,%edx
  1749c1:	31 c9                	xor    %ecx,%ecx
  1749c3:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  1749c9:	e8 a2 59 f9 ff       	call   10a370 <_ZN7vthread4wait11wait_select16enqueue_selected17h5a35090e1549dd93E.llvm.12585570228806776198>
  1749ce:	f0 48 ff 4d 00       	lock decq 0x0(%rbp)
  1749d3:	75 09                	jne    1749de <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x22e>
  1749d5:	4c 89 ff             	mov    %r15,%rdi
  1749d8:	ff 15 0a e1 01 00    	call   *0x1e10a(%rip)        # 192ae8 <_DYNAMIC+0x1140>
  1749de:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
  1749e2:	4c 89 63 18          	mov    %r12,0x18(%rbx)
  1749e6:	48 83 c4 08          	add    $0x8,%rsp
  1749ea:	5b                   	pop    %rbx
  1749eb:	41 5c                	pop    %r12
  1749ed:	41 5d                	pop    %r13
  1749ef:	41 5e                	pop    %r14
  1749f1:	41 5f                	pop    %r15
  1749f3:	5d                   	pop    %rbp
  1749f4:	c3                   	ret    
  1749f5:	48 8d 3d e0 99 ea ff 	lea    -0x156620(%rip),%rdi        # 1e3dc <anon.de2471ab41e489a293ba001b839d8fc3.694.llvm.12585570228806776198>
  1749fc:	48 8d 15 65 99 01 00 	lea    0x19965(%rip),%rdx        # 18e368 <anon.de2471ab41e489a293ba001b839d8fc3.695.llvm.12585570228806776198>
  174a03:	be 79 00 00 00       	mov    $0x79,%esi
  174a08:	ff 15 22 d2 01 00    	call   *0x1d222(%rip)        # 191c30 <_DYNAMIC+0x288>
  174a0e:	48 8d 3d f4 9a ea ff 	lea    -0x15650c(%rip),%rdi        # 1e509 <anon.de2471ab41e489a293ba001b839d8fc3.708.llvm.12585570228806776198>
  174a15:	48 8d 15 c4 99 01 00 	lea    0x199c4(%rip),%rdx        # 18e3e0 <anon.de2471ab41e489a293ba001b839d8fc3.710.llvm.12585570228806776198>
  174a1c:	be 1a 00 00 00       	mov    $0x1a,%esi
  174a21:	ff 15 a9 d3 01 00    	call   *0x1d3a9(%rip)        # 191dd0 <_DYNAMIC+0x428>
  174a27:	49 89 c6             	mov    %rax,%r14
  174a2a:	eb 18                	jmp    174a44 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x294>
  174a2c:	49 89 c6             	mov    %rax,%r14
  174a2f:	eb 40                	jmp    174a71 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x2c1>
  174a31:	49 89 c6             	mov    %rax,%r14
  174a34:	f0 48 ff 4d 00       	lock decq 0x0(%rbp)
  174a39:	75 09                	jne    174a44 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x294>
  174a3b:	4c 89 ff             	mov    %r15,%rdi
  174a3e:	ff 15 a4 e0 01 00    	call   *0x1e0a4(%rip)        # 192ae8 <_DYNAMIC+0x1140>
  174a44:	4d 89 2f             	mov    %r13,(%r15)
  174a47:	b8 18 00 00 00       	mov    $0x18,%eax
  174a4c:	4c 89 24 03          	mov    %r12,(%rbx,%rax,1)
  174a50:	4c 89 f7             	mov    %r14,%rdi
  174a53:	e8 d8 2b 01 00       	call   187630 <_Unwind_Resume@plt>
  174a58:	ff 15 8a d3 01 00    	call   *0x1d38a(%rip)        # 191de8 <_DYNAMIC+0x440>
  174a5e:	49 89 c6             	mov    %rax,%r14
  174a61:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  174a66:	75 09                	jne    174a71 <vthread::channel::publication::<impl vthread::channel::State<T>>::reserve_fronts+0x2c1>
  174a68:	48 89 df             	mov    %rbx,%rdi
  174a6b:	ff 15 77 e0 01 00    	call   *0x1e077(%rip)        # 192ae8 <_DYNAMIC+0x1140>
  174a71:	4c 89 3b             	mov    %r15,(%rbx)
  174a74:	b8 08 00 00 00       	mov    $0x8,%eax
  174a79:	4c 89 24 03          	mov    %r12,(%rbx,%rax,1)
  174a7d:	4c 89 f7             	mov    %r14,%rdi
  174a80:	e8 ab 2b 01 00       	call   187630 <_Unwind_Resume@plt>
  174a85:	ff 15 5d d3 01 00    	call   *0x1d35d(%rip)        # 191de8 <_DYNAMIC+0x440>
  174a8b:	cc                   	int3   
  174a8c:	cc                   	int3   
  174a8d:	cc                   	int3   
  174a8e:	cc                   	int3   
  174a8f:	cc                   	int3   
