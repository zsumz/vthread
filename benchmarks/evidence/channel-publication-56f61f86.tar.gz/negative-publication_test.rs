use crate::{
    CarrierId, Error, JoinHandle, Runtime,
    channel::bounded_with_wait_capacity,
    control::Shared,
    kernel::Kernel,
    wait::wait_publication_probe_test::{PausedPublication, Stage},
};
use std::{
    sync::{Arc, mpsc},
    time::Duration,
};

#[test]
fn selected_channel_wake_releases_metadata_before_publication_finishes() {
    let config = Runtime::builder()
        .max_vthreads(2)
        .carrier_queue_capacity(2)
        .stack_cache_capacity(2)
        .build()
        .unwrap()
        .config();
    let shared = Arc::new(Shared::new(config));
    let scope = shared.begin_scope().unwrap();
    let (sender, receiver) = bounded_with_wait_capacity(1, 1).unwrap();
    let waiting = receiver.clone();
    let spawned = shared
        .submit(scope, "cancelled receiver".into(), move || waiting.recv())
        .unwrap();
    let mut child = JoinHandle::new(
        Arc::clone(&shared),
        spawned.id,
        spawned.cell,
        spawned.record,
    );
    let mut kernel = Kernel::new(Arc::clone(&shared), CarrierId(0));
    kernel.receive();
    assert!(kernel.tick(false).unwrap());
    assert_eq!(receiver.waiting(), 1);
    let wait = receiver
        .core
        .state
        .lock()
        .recv_waits
        .front()
        .unwrap()
        .clone();
    let metadata = std::thread::scope(|threads| {
        let mut pause = PausedPublication::install(&wait);
        let publisher = threads.spawn(|| sender.try_send(42));
        pause.observe(Stage::NoticePublished);
        let (attempted, attempt) = mpsc::channel();
        let (observed, observation) = mpsc::channel();
        let inspect = &sender;
        let observer = threads.spawn(move || {
            attempted.send(()).unwrap();
            observed.send(inspect.len()).unwrap();
        });
        attempt.recv_timeout(Duration::from_secs(5)).unwrap();
        // This is a failure bound, not a latency assertion. The publisher stays
        // paused until after the observation: the old held lock cannot pass.
        let metadata = observation.recv_timeout(Duration::from_secs(5));
        child.cancel();
        pause.release();
        publisher.join().unwrap().unwrap();
        observer.join().unwrap();
        metadata
    });
    while kernel.tick(false).unwrap() {}
    assert!(child.is_finished());
    assert!(matches!(
        child.take_result().unwrap(),
        Err(Error::Cancelled)
    ));
    assert_eq!(receiver.waiting(), 0);
    assert_eq!(receiver.try_recv().unwrap(), 42);
    shared.finish_scope(scope);
    assert_eq!(
        metadata.ok(),
        Some(1),
        "channel metadata lock remained held across wake publication"
    );
}
