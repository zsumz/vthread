#!/usr/bin/env python3
"""Summarize independent paired processes; preserve guard failures and partial panels.

Counter totals cover the whole process (including warmup/setup). Tail measurements
are sampled call durations, not throughput-derived ns/op. Endpoint host checks do
not prove continuous isolation or exclude an unobservable VM host neighbor.
"""

import argparse
import csv
import json
from pathlib import Path
import re
from statistics import median


BUILD = re.compile(r"^\s*\d+\s+(cargo|rustc|clippy-driver|zrail)\s", re.MULTILINE)


def fields(line):
    return dict(re.findall(r"([a-zA-Z0-9_]+)=([^\s]+)", line))


def sample(prefix):
    required = [".log", ".csv", ".guard", ".before.host", ".after.host", ".before.cpu", ".after.cpu"]
    missing = [suffix for suffix in required if not Path(str(prefix) + suffix).exists()]
    if missing:
        raise ValueError(f"missing {missing}")
    if Path(str(prefix) + ".guard").read_text().strip():
        raise ValueError("build guard rejected run")
    for suffix in [".before.host", ".after.host"]:
        if BUILD.search(Path(str(prefix) + suffix).read_text()):
            raise ValueError(f"host build visible {suffix}")
    records = [fields(line) for line in Path(str(prefix) + ".log").read_text().splitlines()]
    reports = [row for row in records if "ns_per_operation" in row and "phase" not in row]
    if len(reports) != 1:
        raise ValueError("missing or ambiguous complete throughput report")
    result = {"ns_per_operation": float(reports[0]["ns_per_operation"])}
    for row in csv.reader(Path(str(prefix) + ".csv").read_text().splitlines()):
        if len(row) >= 3 and not row[0].startswith("#"):
            result[row[2]] = float(row[0])
    if not all(key in result for key in ["cycles", "instructions", "task-clock", "context-switches"]):
        raise ValueError("missing required hardware counters")
    for row in records:
        if row.get("phase") in {"channel-latency", "channel-fairness"}:
            direction = row["direction"]
            for key in ["p99_9_ns", "p99_99_ns", "max_ns", "task_p99_9_max_ns", "task_worst_ns"]:
                if key in row:
                    result[f"{direction}.{key}"] = float(row[key])
    return result


def panel(root, tag):
    groups = {}
    for path in sorted(root.glob(f"{tag}-*.guard")):
        match = re.fullmatch(re.escape(tag) + r"-(\d+)-(baseline|candidate)-(.+)\.guard", path.name)
        if match:
            round_id, arm, case = match.groups()
            groups.setdefault((case, int(round_id)), {})[arm] = Path(str(path)[:-6])
    accepted, excluded = {}, []
    for (case, round_id), arms in sorted(groups.items()):
        try:
            if arms.keys() != {"baseline", "candidate"}:
                raise ValueError("incomplete pair")
            pair = {arm: sample(prefix) for arm, prefix in arms.items()}
        except ValueError as error:
            excluded.append({"case": case, "round": round_id, "reason": str(error)})
            continue
        accepted.setdefault(case, []).append({"round": round_id, **pair})
    cases = {}
    for case, pairs in accepted.items():
        keys = set.intersection(*(set(pair["baseline"]) & set(pair["candidate"]) for pair in pairs))
        metrics = {}
        for key in sorted(keys):
            before = median(pair["baseline"][key] for pair in pairs)
            after = median(pair["candidate"][key] for pair in pairs)
            metrics[key] = {"baseline": before, "candidate": after,
                            "percent_change": 100 * (after / before - 1) if before else None}
        cases[case] = {"pairs": len(pairs), "metrics": metrics, "raw": pairs}
    return {"tag": tag, "cases": cases, "excluded_pairs": excluded}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("tags", nargs="+")
    args = parser.parse_args()
    print(json.dumps([panel(args.root, tag) for tag in args.tags], indent=2, sort_keys=True))
