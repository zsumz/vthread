import importlib.util
from pathlib import Path
import tempfile
import unittest


SPEC = importlib.util.spec_from_file_location("analyze", Path(__file__).with_name("analyze.py"))
ANALYZE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ANALYZE)


class PairedEvidence(unittest.TestCase):
    def fixture(self, root, arm):
        prefix = root / f"test-1-{arm}-channel"
        contents = {
            ".log": "engine=vthread operation=channel ns_per_operation=12.50\n",
            ".csv": "100,,cycles\n200,,instructions\n1,msec,task-clock\n2,,context-switches\n",
            ".guard": "",
            ".before.host": "PID COMMAND %CPU ELAPSED\n 99 benchmark 100 00:01\n",
            ".after.host": "PID COMMAND %CPU ELAPSED\n",
            ".before.cpu": "cpu 1 2 3 4\n",
            ".after.cpu": "cpu 2 3 4 5\n",
        }
        for suffix, text in contents.items():
            Path(str(prefix) + suffix).write_text(text)
        return prefix

    def test_counter_units_and_paired_percentages(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            self.fixture(root, "baseline")
            self.fixture(root, "candidate")
            result = ANALYZE.panel(root, "test")
            case = result["cases"]["channel"]
            self.assertEqual(case["pairs"], 1)
            self.assertEqual(case["metrics"]["cycles"]["percent_change"], 0)
            self.assertEqual(case["metrics"]["ns_per_operation"]["baseline"], 12.5)
            self.assertFalse(result["excluded_pairs"])

    def test_partial_pair_cannot_qualify(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            self.fixture(root, "baseline")
            result = ANALYZE.panel(root, "test")
            self.assertFalse(result["cases"])
            self.assertEqual(len(result["excluded_pairs"]), 1)

    def test_build_visible_at_either_endpoint_rejects_both_arms(self):
        for suffix in [".before.host", ".after.host"]:
            with tempfile.TemporaryDirectory() as name:
                root = Path(name)
                self.fixture(root, "baseline")
                prefix = self.fixture(root, "candidate")
                Path(str(prefix) + suffix).write_text(" 999 rustc 100 00:03\n")
                result = ANALYZE.panel(root, "test")
                self.assertFalse(result["cases"])
                self.assertIn("host build visible", result["excluded_pairs"][0]["reason"])

    def test_missing_after_state_rejects_completed_stdout(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            self.fixture(root, "baseline")
            prefix = self.fixture(root, "candidate")
            Path(str(prefix) + ".after.cpu").unlink()
            self.assertFalse(ANALYZE.panel(root, "test")["cases"])


if __name__ == "__main__":
    unittest.main()
