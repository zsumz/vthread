#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/channel-publication
run_one() {
    local round=$1 arm=$2 label=$3 mask=$4
    shift 4
    local prefix=$evidence_dir/screen-$round-$arm-$label
    test ! -e "$prefix.log"
    if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then return 125; fi
    local binary=$evidence_dir/baseline-benchmark
    if [[ $arm == candidate ]]; then binary=$evidence_dir/candidate-initial; fi
    ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
    sed -n '1,9p' /proc/stat > "$prefix.before.cpu"
    local command=(timeout 120s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations,syscalls:sys_enter_futex,syscalls:sys_enter_sched_yield
        -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@")
    printf '%q ' "${command[@]}" >> "$evidence_dir/screen-commands.log"
    printf '\n' >> "$evidence_dir/screen-commands.log"
    "${command[@]}" > "$prefix.log" 2>&1
    sed -n '1,9p' /proc/stat > "$prefix.after.cpu"
    ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
    printf 'screen round=%s arm=%s case=%s complete\n' "$round" "$arm" "$label"
}

for round in 1 2 3; do
    arms=(baseline candidate)
    if (( round % 2 == 0 )); then arms=(candidate baseline); fi
    for label in mpmc1c8 mpmc4c8 mpmc4c64 mpmc4c64-cap64 mpmc4c64-cap1024 mpmc8c64 mpmc4c64-spare tails4c8 park4 mutex4 yield1 spawn4; do
        for arm in "${arms[@]}"; do
            case $label in
                mpmc1c8) run_one "$round" "$arm" "$label" 7 channel-mpmc 10000 1 1 8 7 --pin-carriers ;;
                mpmc4c8) run_one "$round" "$arm" "$label" 0-3 channel-mpmc 10000 1 4 8 7 --pin-carriers ;;
                mpmc4c64) run_one "$round" "$arm" "$label" 0-3 channel-mpmc 2000 1 4 64 7 --pin-carriers ;;
                mpmc4c64-cap64) run_one "$round" "$arm" "$label" 0-3 channel-mpmc 2000 64 4 64 7 --pin-carriers ;;
                mpmc4c64-cap1024) run_one "$round" "$arm" "$label" 0-3 channel-mpmc 2000 1024 4 64 7 --pin-carriers ;;
                mpmc8c64) run_one "$round" "$arm" "$label" 0-7 channel-mpmc 2000 1 8 64 7 --pin-carriers ;;
                mpmc4c64-spare) run_one "$round" "$arm" "$label" 0-3 channel-mpmc 2000 1 4 64 3 --pin-carriers --max-vthreads 65536 ;;
                tails4c8) run_one "$round" "$arm" "$label" 0-3 channel-mpmc 10000 1 4 8 7 --pin-carriers --sample-channel-latency ;;
                park4) run_one "$round" "$arm" "$label" 0-3 park 10000 4 64 7 --pin-carriers ;;
                mutex4) run_one "$round" "$arm" "$label" 0-3 mutex 2000 4 64 7 --pin-carriers ;;
                yield1) run_one "$round" "$arm" "$label" 7 yield 1000 1 1000 7 ;;
                spawn4) run_one "$round" "$arm" "$label" 0-3 spawn 4 10000 63 ;;
            esac
        done
    done
done
