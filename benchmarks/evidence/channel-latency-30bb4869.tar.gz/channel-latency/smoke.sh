#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/channel-latency
binary=$evidence_dir/baseline-benchmark
for workers in 1 4; do
    if [[ $workers == 1 ]]; then mask=7; else mask=0-3; fi
    for capacity in 1 64 1024; do
        for mode in plain sampled; do
            options=()
            if [[ $mode == sampled ]]; then options+=(--sample-channel-latency); fi
            prefix=$evidence_dir/smoke-$workers-$capacity-$mode
            test ! -e "$prefix.log"
            printf '%q ' timeout 60s taskset -c "$mask" "$binary" vthread channel-mpmc 1000 "$capacity" "$workers" 8 3 --pin-carriers "${options[@]}" >> "$evidence_dir/smoke-commands.log"
            printf '\n' >> "$evidence_dir/smoke-commands.log"
            timeout 60s taskset -c "$mask" "$binary" vthread channel-mpmc 1000 "$capacity" "$workers" 8 3 --pin-carriers "${options[@]}" > "$prefix.log" 2>&1
        done
    done
done
if "$binary" may channel-mpmc 1000 1 4 8 3 --sample-channel-latency > "$evidence_dir/may-rejection.log" 2>&1; then
    printf 'May unexpectedly accepted a vthread-only control\n' >&2
    exit 1
fi
python3 "$evidence_dir/verify-smoke.py"
