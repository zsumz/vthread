# Optional channel endpoint latency: benchmark-only qualification

Baseline revision: 5ec3c9d25e9fa83cc19e1054f52b77572f43fe62.
Final source SHA-256: 30bb48693c14080d0a289f76a23943f9d67caf1507b20e7e69b8db302dcdad9c.
Runtime source and zrail.lock are unchanged. The candidate.patch includes all
benchmark source and README changes. No new architecture grants are required.

```sh
cargo fmt --manifest-path benchmarks/Cargo.toml
CARGO_TARGET_DIR=target CARGO_INCREMENTAL=0 cargo test --manifest-path benchmarks/Cargo.toml --locked --all-features
CARGO_TARGET_DIR=target CARGO_INCREMENTAL=0 cargo clippy --manifest-path benchmarks/Cargo.toml --locked --all-targets --all-features -- -D warnings
CARGO_INCREMENTAL=0 zcheck run check
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
bash target/finish-line/channel-latency/smoke.sh
```

All 51 benchmark tests, warning-denying Clippy and 11 canonical gates pass.
The canonical-receipt directory contains the full source-preservation receipt and
task logs from run-1788646342-4688439-2473375. The native API test exercises both
plain and sampled modes on one/four carriers and capacities 1/64/1024. Twelve
optimized CLI smokes verify exact delivery, directional observation counts,
warmup exclusion, quantile ordering, operation labels and explicit May rejection.
Smoke timings are not performance acceptance evidence.

The initial two compilation failures (ambiguous Result type, then SendError
conversion) are retained separately; the final source fixes both and is rerun.
Two unused diagnostic executables were checked with lsof, hashed, then losslessly
gzipped to recover build space. recoverable-artifacts.sha256 identifies them;
gunzip restores their original bytes. No runtime/performance evidence was deleted.

The optimized baseline-benchmark executable is copied locally before restoring
the shelved runtime experiment. Executables are excluded from the archive; their
hashes, commands, source, qualification logs and raw smoke outputs are included.

Sampling uses two Instant reads per API call, keeps sender join handles and adds
task-local timing vectors. It intentionally perturbs the workload. Each value
counts once for throughput but yields two latency samples. This is closed-loop
endpoint API latency, not open-loop offered-load or message delivery latency.
Direction and per-logical-stream summaries run after elapsed timing; whole-process
perf counters still include validation and summarization. Compare sampled arms
separately from the unchanged plain transfer loops. No May speedup is claimed.
