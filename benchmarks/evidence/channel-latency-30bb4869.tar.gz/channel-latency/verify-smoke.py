"""Reject missing, duplicated or warmup-contaminated directional CLI samples."""

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
for workers in (1, 4):
    for capacity in (1, 64, 1024):
        for mode in ("plain", "sampled"):
            path = ROOT / f"smoke-{workers}-{capacity}-{mode}.log"
            rows = [dict(re.findall(r"(\w+)=(\S+)", line))
                    for line in path.read_text().splitlines()]
            calls = [row for row in rows if row.get("phase") == "channel-latency"]
            fairness = [row for row in rows if row.get("phase") == "channel-fairness"]
            totals = [row for row in rows if "ns_per_operation" in row]
            assert len(totals) == 1, path
            assert totals[0]["operation"].endswith("-sampled") == (mode == "sampled"), path
            if mode == "plain":
                assert not calls and not fairness, path
                continue
            assert sorted(row["direction"] for row in calls) == ["receive", "send"], path
            assert sorted(row["direction"] for row in fairness) == ["receive", "send"], path
            assert all(int(row["observations"]) == 12_000 for row in calls), path
            assert all(int(row["task_streams"]) == 4 for row in fairness), path
            pooled = [row for row in rows if row.get("phase") == "latency"]
            assert len(pooled) == 1 and int(pooled[0]["observations"]) == 24_000, path
            for row in calls:
                values = [int(row[key]) for key in (
                    "median_ns", "p90_ns", "p95_ns", "p99_ns", "p99_9_ns", "p99_99_ns", "max_ns")]
                assert values == sorted(values), path
assert "vthread-only" in (ROOT / "may-rejection.log").read_text()
print("12 native CLI smokes: exact directional counts, warmup exclusion, labels and May rejection passed")
