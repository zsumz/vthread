"""Reject missing live-matrix coverage and repeat the held-client protocol."""

import copy
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import application_verify
import evidence

source = evidence.metadata('offered-load verification controls and 100 ordered harness repeats')
with (OUT / 'verification-source.json').open('x') as stream:
    json.dump(source, stream, indent=2)
receipt_path = OUT / 'canonical-application/receipt.json'
application_verify.verify(receipt_path, current=True)
original = json.loads(receipt_path.read_text())
missing = copy.deepcopy(original)
missing['cases'] = [case for case in missing['cases'] if case['kind'] != 'offered-load']
missing_path = receipt_path.with_name('missing-offered-receipt.json')
with missing_path.open('x') as stream:
    json.dump(missing, stream, indent=2)
try:
    application_verify.verify(missing_path)
except AssertionError:
    with (OUT / 'negative-matrix.log').open('x') as stream:
        stream.write('PASS: removing all requested offered-load cases is rejected\n')
else:
    raise AssertionError('missing offered-load matrix was accepted')
for index in range(100):
    command = ['python3', 'scripts/application_offered_test.py']
    with (OUT / f'repeat-{index:03}.command.json').open('x') as stream:
        json.dump(command, stream)
    with (OUT / f'repeat-{index:03}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=30)
    with (OUT / f'repeat-{index:03}.result.json').open('x') as stream:
        json.dump(dict(returncode=result.returncode), stream)
    assert result.returncode == 0, index
print('verified live receipt, rejected missing matrix, passed 700 further ordered tests')
