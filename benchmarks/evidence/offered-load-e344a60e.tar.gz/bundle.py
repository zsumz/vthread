"""Archive the final offered-load fixture and retain initial and negative runs."""

import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence
import application_verify

manifest = evidence.metadata('qualified bounded offered-load application control; runtime unchanged')
for label in ['canonical', 'final-smoke']:
    assert manifest['source_sha256'] == json.loads((OUT / f'{label}.command.json').read_text())['source']['source_sha256']
    assert json.loads((OUT / f'{label}.result.json').read_text())['returncode'] == 0
for label in ['negative-schedule', 'negative-backpressure', 'negative-tails']:
    assert json.loads((OUT / f'{label}.result.json').read_text())['returncode'] == 1
for index in range(100):
    assert json.loads((OUT / f'repeat-{index:03}.result.json').read_text())['returncode'] == 0
for name in ['canonical-application', 'final-smoke']:
    application_verify.verify(OUT / name / 'receipt.json', current=True)
with (OUT / 'source.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
binary_paths = sorted({name for log in (OUT / 'canonical').glob('*.log')
    for name in re.findall(r'Running (?:unittests|tests) \S+ \(([^)\s]+)\)', log.read_text())})
with (OUT / 'canonical-binaries.json').open('x') as stream:
    json.dump([dict(path=name, sha256=evidence.digest(Path(name))) for name in binary_paths], stream, indent=2)
with (OUT / 'candidate.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'scripts', 'zcheck.toml'], cwd=ROOT))
archive_path = ROOT / f'benchmarks/evidence/offered-load-{manifest["source_sha256"][:8]}.tar.gz'
paths = sorted(path for path in OUT.rglob('*') if path.is_file()
               and '__pycache__' not in path.parts and path.name != 'SHA256SUMS')
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(archive_path, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
verify = Path(tempfile.mkdtemp(prefix='offered-load-verify.', dir=ROOT / 'target/finish-line'))
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    assert all(member.isfile() and not Path(member.name).is_absolute()
               and '..' not in Path(member.name).parts for member in members)
    archive.extractall(verify, members=members)
with (verify / 'verification.log').open('x') as stream:
    subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=verify, stdout=stream,
                   stderr=subprocess.STDOUT, check=True)
print('archive', archive_path)
print('sha256', evidence.digest(archive_path))
print('verified', len(paths), 'internal hashes', verify)
