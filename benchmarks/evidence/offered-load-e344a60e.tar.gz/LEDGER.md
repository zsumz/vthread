# Fixed offered-load application control

Base fe53d4e. Python harness and qualification configuration only; no Rust,
engine, polling, affinity, mutex ownership, channel or readiness change.
This extends the existing binary-framed TCP application, not HTTP or a new
profiling framework. Existing native clients, service owner, response checking,
resource sampling, evidence manifest and matrix verifier are reused.

Every arrival has the absolute schedule origin + floor(sequence * 1e9 / rate).
Completion never advances the next scheduled arrival. A bounded pool of persistent
clients admits immediately or records a client-capacity drop. There is one bounded
mail slot per client and no submitted future or unbounded command queue per
request. Capacity returns only after the response is validated and recorded.
The offered timestamp can precede another request's completion when the actual
slot claim follows it; a separate admitted timestamp preserves that distinction.

All arrivals, including drops, retain their sequence, schedule and actual offer
time. Accepted records retain admission, start, completion and exchange duration.
Raw per-client sequences and response digests preserve delivery/accounting.
Quantiles retain p50/p90/p99/p99.9/p99.99/max; dispatcher lag is separate from
arrival-to-completion. Client-slot drops are not server queue rejections. Native
socket or worker failures invalidate the case and retain partial records; they
are never silently treated as backpressure or omitted samples.

The initial missing-module test failed before implementation (tool output only).
The first captured unit/restored runs have 18 tests. Negative-schedule shifts late
deadlines to now and fails the late-dispatch regression. Negative-backpressure
stops when the client pool is busy and fails four ordered cases, including a real
worker deliberately held inside exchange. Negative-tails removes summary
verification and fails both tail-corruption controls. Their full outputs and
exact source identities are retained; originals were byte-compared on restoration.
application_offered.py / application_offered_verify.py preserve that source.

Explicit Slots and dispatch bounds are then added; the final source has 19 unit
tests. First smoke retains eight offered cases, four existing closed-loop cases
and two existing failure panels on the preceding source. Final canonical and
final-smoke records identify the final bounded source independently. Do not
silently relabel the initial smoke as final-source coverage.

Canonical run-1788702445-108011326-3183809 passes all fourteen tasks with unchanged
zrail lock, including default-native debug/release and the offered-load smoke.
Its actual application receipt and logs are copied into this bundle. Removing
all requested offered cases from that receipt is a separate failing matrix
control. One hundred further ordered test-process repetitions and the final
one/four-carrier smoke are recorded independently; bundle.py requires success
before archiving. No missing or failed process is inferred to pass.

This is shared-host correctness qualification, not performance acceptance. The
Python generator, native clients, protocol construction/validation, OS scheduling
and service all contribute to endpoint samples. Scheduled-arrival latency retains
generator delays instead of hiding them; those delays can also produce catch-up
bursts and client-capacity drops. Small smoke counts cannot establish p99.99
stability or release tails. No headline runtime latency, speedup, May result,
fairness bound, native ARM64/sanitizer or large-lifetime claim follows.

Replay source/binary identities and exact commands are in the manifests. Binaries
are hashed, not included in the archive. Every file is checksummed and verified
after fresh-directory extraction. The complete implementation/configuration patch
is against fe53d4e; no rejected runtime experiment is included.
