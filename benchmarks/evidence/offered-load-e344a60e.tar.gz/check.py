"""Record offered-load fixture qualification, including deliberate failures."""

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

label = sys.argv[1]
environment = dict(os.environ, CARGO_INCREMENTAL='0',
    CARGO_TARGET_DIR='/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
commands = {
    'unit': ['python3', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'application_*test.py'],
    'negative-schedule': ['python3', 'scripts/application_offered_test.py'],
    'negative-backpressure': ['python3', 'scripts/application_offered_test.py'],
    'negative-tails': ['python3', 'scripts/application_offered_verify_test.py'],
    'restored': ['python3', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'application_*test.py'],
    'canonical': ['zcheck', 'run', 'check'],
    'smoke': ['python3', 'scripts/run-application.py', '--out', str(OUT / 'smoke'),
              '--carriers', '1', '4', '--concurrency', '1', '16', '--rounds', '8',
              '--fault-rounds', '1', '--offered-rates', '100', '20000', '--offered-count', '128',
              '--context', 'offered-load correctness smoke on shared host; no performance acceptance'],
}
if label == 'final-smoke':
    commands[label] = [piece.replace(str(OUT / 'smoke'), str(OUT / 'final-smoke'))
                       for piece in commands['smoke']]
command = commands[label]
with (OUT / f'{label}.command.json').open('x') as stream:
    json.dump(dict(command=command, source=evidence.metadata(label)), stream, indent=2)
with (OUT / f'{label}.log').open('x') as stream:
    result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream,
                            stderr=subprocess.STDOUT, timeout=1800)
with (OUT / f'{label}.result.json').open('x') as stream:
    json.dump(dict(returncode=result.returncode), stream)
print(label, result.returncode, flush=True)
sys.exit(result.returncode)
