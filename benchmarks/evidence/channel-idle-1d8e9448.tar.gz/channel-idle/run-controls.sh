#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/channel-idle

run_case() {
    local label=$1 mask=$2
    shift 2
    if [[ ${VTHREAD_CONTROL_CASES:-all} != all && " ${VTHREAD_CONTROL_CASES:-} " != *" $label "* ]]; then return; fi
    for round in ${VTHREAD_CONTROL_ROUNDS:-1 2 3 4}; do
        local engines
        case $round in
            1) engines='baseline eligibility idle combined' ;;
            2) engines='eligibility combined baseline idle' ;;
            3) engines='idle baseline combined eligibility' ;;
            4) engines='combined idle eligibility baseline' ;;
        esac
        for engine in $engines; do
            if [[ ${VTHREAD_CONTROL_ARMS:-all} != all && " ${VTHREAD_CONTROL_ARMS:-} " != *" $engine "* ]]; then continue; fi
            local binary
            case $engine in
                baseline) binary=target/finish-line/shared-channel-control/baseline-benchmark ;;
                eligibility) binary=target/finish-line/channel-eligibility/candidate-benchmark ;;
                idle) binary=$evidence_dir/idle-benchmark ;;
                combined) binary=$evidence_dir/combined-benchmark ;;
            esac
            local prefix=$evidence_dir/control-$round-$engine-$label
            if [[ -e $prefix.log ]]; then
                printf 'refusing to overwrite earlier output: %s\n' "$prefix" >&2
                return 126
            fi
            if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
                printf 'control deferred: other build activity before %s\n' "$prefix" >&2
                return 125
            fi
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            printf '%q ' timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@" >> "$evidence_dir/control-commands.log"
            printf '\n' >> "$evidence_dir/control-commands.log"
            timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@" > "$prefix.log" 2>&1
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'control round=%s engine=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

run_case mpmc8 0-3 channel-mpmc 10000 1 4 8 5 --pin-carriers
run_case mpmc64 0-3 channel-mpmc 10000 1 4 64 5 --pin-carriers
run_case park 0-3 park 10000 4 64 5 --pin-carriers
run_case wake 0-3 wake-tail 10000 4 64 5 --pin-carriers
run_case spawn10000 0-3 spawn 4 10000 301
