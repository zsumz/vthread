"""Four independently ordered processes per arm; incomplete cases stay unqualified."""

import json
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parent
ENGINES = ("baseline", "eligibility", "idle", "combined")


def record(path):
    match = re.fullmatch(r"control-(\d+)-(baseline|eligibility|idle|combined)-(.+)\.log", path.name)
    result = {"log": path.name, "round": int(match[1]), "engine": match[2], "case": match[3]}
    for line in path.read_text().splitlines():
        data = dict(re.findall(r"(\w+)=(\S+)", line))
        if "ns_per_operation" in data:
            result["ns_per_operation"] = float(data["ns_per_operation"])
        if data.get("phase") == "latency":
            result["latency"] = {key: int(value) for key, value in data.items() if key.endswith("_ns")}
        if data.get("phase") == "fairness":
            result["fairness"] = {key: int(value) for key, value in data.items() if key.endswith("_ns")}
    result["perf"] = {}
    if path.with_suffix(".csv").exists():
        for line in path.with_suffix(".csv").read_text().splitlines():
            columns = line.split(",")
            if len(columns) >= 3 and columns[0].isdigit():
                result["perf"][columns[2]] = int(columns[0])
    return result


records = [record(path) for path in sorted(ROOT.glob("control-*-*.log"))]
summary = {}
for case in sorted({item["case"] for item in records}):
    groups = {engine: [item for item in records if item["case"] == case and item["engine"] == engine]
              for engine in ENGINES}
    if any(sorted(item["round"] for item in group) != [1, 2, 3, 4] for group in groups.values()):
        summary[case] = {"status": "incomplete_not_compared"}
        continue
    if any("cycles" not in item["perf"] or "ns_per_operation" not in item
           for group in groups.values() for item in group):
        summary[case] = {"status": "incomplete_not_compared"}
        continue
    entry = {"status": "complete_experiment_not_full_acceptance"}
    for metric in ("ns_per_operation", "cycles", "instructions", "context-switches", "cpu-migrations"):
        values = {engine: [item[metric] if metric in item else item["perf"][metric] for item in group]
                  for engine, group in groups.items()}
        medians = {engine: statistics.median(group) for engine, group in values.items()}
        entry[metric] = {"values": values, "medians": medians,
                         "change_vs_baseline_percent": {
                             engine: 100 * (medians[engine] / medians["baseline"] - 1)
                             for engine in ENGINES[1:]}}
    summary[case] = entry

print(json.dumps({"summary": summary, "raw": records}, indent=2))
