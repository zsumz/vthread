# Channel eligibility and parked-carrier polling: four-way attribution

All four arms share the benchmark source at 5b63f266fd6dfc39de3c13d6e28c7ec850de2d42.
The baseline has neither change; eligibility changes only notification eligibility;
idle extends the parked-task polling horizon from 640 to 4096 probes; combined has
both. Admission-only idling remains 640 probes. Timer-backed waits skip polling.
No wait-word, queue, signaling atomic or affinity protocol changes in these arms.

Source and binary manifests identify all four inputs. idle-only.patch and
combined.patch apply to the baseline. The combined source remains shelved at
1478da7272640a6539dfac698304471e26e1c3c7. This is not final performance or canonical
acceptance. Its architecture inventory still needs a final refresh before zcheck.

```sh
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib kernel_idle -- --test-threads=1
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
CARGO_INCREMENTAL=0 cargo test --locked --workspace --all-targets
bash target/finish-line/channel-idle/run-controls.sh
python3 target/finish-line/channel-idle/analyze.py
```

The first control attempt stopped before collecting any sample because another
build was visible. Its log and guard are retained under deferred-before-start.*.
Native workspace tests then passed, including 519 runtime tests (one ignored), 70
stack tests and the supporting suites. No builds/tests overlapped the resumed panel.

run-controls.sh and control-commands.log preserve the 80 exact measured processes:
four independent binary orders across five cases. The 160 endpoint host snapshots
caught no compiler or process above 10% lifetime-average CPU. That is not proof of
uninterrupted physical-host exclusivity. All samples remain in analysis.json.

MPMC ns/op counts a transferred value; its validation occurs after elapsed timing,
but whole-process hardware counters include it. Wake-tail samples use the existing
portable timestamp contract. No channel-specific latency distribution, offered-load
test or idle-CPU qualification is claimed here. The bounded increase in worst-case
idle polling is an explicit tradeoff, not a new carrier event-word protocol.

Executables are excluded from the archive; patches, hashes, commands, raw counters,
timings, native results, host observations and analysis are included.
