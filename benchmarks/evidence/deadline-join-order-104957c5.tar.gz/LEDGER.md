# Deadline-first joins: selection, late completion, then resumption

Base 5c48027. Production join, wait, timer, native stack, affinity and ready policy
are unchanged. The only runtime-file edit declares the new cfg(test) module.
The existing cancellation-first and completion-first regressions are retained.

The original ordered-loaded-4.log only reports a Disconnected test-gate receive
at join_commit_test.rs:165; neither the parent result nor the particular local/
transferable subcase was preserved. A unique historical cause cannot be recovered.
The old fixture also blocked the timer owner while waiting for wall-clock expiry,
which did not establish timer selection before child completion or resumption.

## Explicit native order

Separate tests exercise transferable and genuinely borrowed child handles. Both
tasks park with their inherited deadline. The ordinary driver calls production
timer expiry, observes the exact parent generation as Published, rejects a late
ready selection, and confirms neither task has completed or become runnable.

The test dequeues exactly two owner-routed notices and retains just the parent's
exact task/route/token while requeueing the child's notice. The real kernel then
reclaims the child; its completion hook reports zero newly selected joiners.
The parent is still parked/unresumed, with the same published generation. Only
then is its retained notice delivered to the unchanged wake/ready/dispatch path.
This bounded test-only delivery delay changes neither the timer clock nor ready
policy; it is not a production transport implementation or OS latency claim.

Both typed reports preserve DeadlineExceeded first, 42 on the next join and
ResultAlreadyTaken on repetition. The next checkpoint/root policy observe the
deadline; the local case additionally checks local scope policy, borrowed writes
and complete borrowed-stack retirement. All active tasks/timers/waits drain.

A third case accepts a parent before expiry but mounts it afterwards. Its local
scope correctly returns DeadlineExceeded without invoking the callback; parent
completion then orders destruction of the unused observer sender. Nonblocking
receive reports Disconnected alongside the actual valid typed deadline outcome
and zero parks. This disproves the old unconditional observer-message oracle,
without inventing the missing historical parent result.

## Preserved attempts

- initial: all three ordered tests pass with both typed handle reports.
- negative-order: omit production expiry; both handle cases fail Stale/Published.
- negative-winner: after returning from park, disregard its error when completion
  is now visible. Both handle cases incorrectly consume 42 on the interrupted join
  and fail, preserving the complete typed report before assertions.
- negative-observer: require the unused callback message; the valid deadline and
  disconnected sender fail the old oracle. The two handle cases still pass.
- restored: all mutations removed and final test byte-compared to ordered-source.
- zrail/canonical/repeat artifacts preserve every attempt, command, source/binary
  identity, output and result. Bundle creation requires all planned runs pass.

Twenty default-native debug and twenty release repetitions are planned on CPU 6,
three tests per invocation. These are 120 ordered correctness executions, not
throughput, cycle, loaded-tail, ARM64 or sanitizer acceptance. The original log
is retained; quiet reruns do not reconstruct its unique scheduling trace.
