import unittest
from analyze_service import records, summarize


class DiagnosticParsing(unittest.TestCase):
    def test_test_harness_prefix_does_not_discard_the_first_sample(self):
        self.assertEqual(records('test path::profile ... wake-service diagnostic=true queue_tasks=1 first_pop_ns=140\n'),
                         [dict(diagnostic='true', queue_tasks='1', first_pop_ns='140')])

    def test_only_measured_diagnostic_rows_are_parsed(self):
        source = 'wake-service round=1\nnoise\nwake-service diagnostic=true tasks=64 local=false sentinel_ns=700\n'
        self.assertEqual(records(source), [dict(diagnostic='true', tasks='64', local='false', sentinel_ns='700')])

    def test_missing_repeats_are_not_silently_accepted(self):
        with self.assertRaises(AssertionError):
            summarize('wake-service diagnostic=true tasks=64 local=false sentinel_ns=700\n')

    def test_each_shape_keeps_its_own_work_counts(self):
        rows = []
        for count in [1, 64, 1024, 10000]:
            for local in ['false', 'true']:
                rows += [f'wake-service diagnostic=true tasks={count} local={local} sentinel_ns={value} dispatches=3 notices={count} maximum_notices_per_tick={count} reversed_links=0'
                         for value in range(9)]
            rows += [f'wake-service diagnostic=true queue_tasks={count} first_pop_ns={value} reversed_links={count} remaining_pop_ns=100'
                     for value in range(9)]
        rows += [f'wake-service diagnostic=true held={count} first_ns=400 epoch_revisit_ns=200 deferred_checks={count} quiet_rechecks=0'
                 for count in [16, 64, 128]]
        result = summarize('\n'.join(rows))
        self.assertEqual(result['burst'][0]['sentinel_ns'], 4)
        self.assertEqual(result['burst'][-1]['notices'], 10000)
        self.assertEqual(result['held'][-1]['deferred_checks'], 128)
