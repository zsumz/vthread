# Reviewed inventory-only update

`zrail diff --base HEAD --deny-grants --format json` initially reported no lock
changes, because the lock had not yet been refreshed. `zrail update --base HEAD
--format json` then refused one unknown inventory change, with zero grants,
revokes, debt, cleanup or neutral changes. Old inventory:
8a71411f89a73ec6009f6b29255cc112178e6ad71e7977f20e338c063afe4e16.
New inventory: 422971f33cd3d4004d3c1b979835edd6b25e3233ca2227388a76d4ffa85b9122.

The change adds two test-only modules. The analyzed package count remains five
and projected facts remain 29; no production dependency/permission edge changes.
Earlier unreviewed println calls were replaced with the existing reviewed writeln
macro, rather than granting another macro boundary. The delta was explained before
using the user's explicit standing session approval for future grants to accept
this inventory-only refresh. No policy setting is changed.
