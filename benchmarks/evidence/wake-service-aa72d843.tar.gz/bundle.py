"""Archive the rejected experiment, exact sources and restored qualification."""

import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def source_archive(manifest_path):
    manifest = json.loads(manifest_path.read_text())
    path = manifest_path.with_suffix('.tar.gz')
    expected_archive = manifest.get('source_archive_sha256', manifest.get('archive_sha256'))
    assert expected_archive == evidence.digest(path), path
    with tarfile.open(path) as archive:
        source = hashlib.sha256()
        members = sorted(archive.getmembers(), key=lambda member: member.name)
        assert len(members) == len({member.name for member in members})
        for member in members:
            assert member.isfile()
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            source.update(member.name.encode() + b'\0' + archive.extractfile(member).read() + b'\0')
        assert source.hexdigest() == manifest['source_sha256'], manifest_path
    return dict(manifest=manifest_path.name, source_sha256=manifest['source_sha256'])


def main():
    retained = json.loads((OUT / 'A-source.json').read_text())
    assert evidence.source_digest() == retained['source_sha256']
    assert json.loads((OUT / 'retained-canonical.result.json').read_text())['returncode'] == 1
    failed = json.loads((OUT / 'report-edit-canonical/receipt.json').read_text())
    assert failed['status'] == 'failed' and not failed['repository']['preserved']
    assert len(failed['tasks']) == 15
    assert [task['name'] for task in failed['tasks'] if task['status'] != 'passed'] == ['repository-state']
    assert json.loads((OUT / 'retained-canonical-frozen.result.json').read_text())['returncode'] == 0
    log = (OUT / 'retained-canonical-frozen.log').read_text()
    matches = re.findall(r'^receipt: (.+/receipt\.json)$', log, re.MULTILINE)
    assert len(matches) == 1
    receipt_path = Path(matches[0])
    assert receipt_path.parent.parent == Path('/root/.cache/zcheck')
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['repository']['preserved']
    assert len(receipt['tasks']) == 14 and all(task['status'] == 'passed' for task in receipt['tasks'])
    shutil.copytree(receipt_path.parent, OUT / 'retained-canonical')
    for name in ['bounded-work-negative', 'candidate-idle-negative']:
        assert json.loads((OUT / f'{name}.result.json').read_text())['returncode'] == 101
    assert '0 passed; 3 failed' in (OUT / 'bounded-work-negative.log').read_text()
    for arm in ['A', 'B']:
        manifest = json.loads((OUT / f'{arm}-source.json').read_text())
        assert manifest['binary_sha256'] == evidence.digest(OUT / f'benchmark-{arm}')
        for task in ['build', 'test', 'format', 'clippy', 'features']:
            assert json.loads((OUT / f'{arm}-{task}.result.json').read_text())['returncode'] == 0
    sources = [source_archive(path) for path in sorted(OUT.glob('*-source.json'))]
    assert len(sources) == 7
    with (OUT / 'verified-source-archives.json').open('x') as stream:
        json.dump(sources, stream, indent=2)
    with (OUT / 'verification-tests.log').open('x') as stream:
        subprocess.run([sys.executable, str(OUT / 'replay.py')], cwd=OUT,
                       stdout=stream, stderr=subprocess.STDOUT, check=True)
    paths = sorted(path for path in OUT.rglob('*') if path.is_file()
                   and '__pycache__' not in path.parts and path.name != 'SHA256SUMS')
    with (OUT / 'SHA256SUMS').open('x') as stream:
        for path in paths:
            stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
    destination = ROOT / 'benchmarks/evidence/wake-service-aa72d843.tar.gz'
    with tarfile.open(destination, 'x:gz') as archive:
        for path in [*paths, OUT / 'SHA256SUMS']:
            archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
    with tarfile.open(destination) as archive:
        assert len(archive.getmembers()) == len(paths) + 1
        for line in archive.extractfile('SHA256SUMS').read().decode().splitlines():
            expected, name = line.split('  ', 1)
            assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected, name
    print(destination, evidence.digest(destination), len(paths), 'verified files;',
          len(sources), 'reconstructed source digests; 144 processes; 14 retained gates')


if __name__ == '__main__':
    main()
