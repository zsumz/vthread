# Model exploration scope

The first unrestricted three-actor owner/sleep model was stopped after more than
five minutes, with the exact source and output retained as `unpartitioned-model`
and `candidate-composition-model`. Its completion is unestablished, not a pass.
The other 25 tests completed, including the intentional deadlock negative control;
there was no observed positive-test assertion failure before interruption.

The normal qualification partitions that exploration into (1) two concurrent
publishers against a budgeted owner pop and retained batch, then joining before
draining, and (2) one publisher covering two routes against an active/sleeping
owner with bounded routing and deferred continuation, for consume and abandon.
Neither panel caps schedule permutations or preemptions. They import the actual
queue, deferred sweep and wait-owner protocol. They do not establish exhaustive
three-actor composition. The existing Signal SC adapter limitation remains.

Separate ordered native tests exercise larger held-publication populations,
progress, no quiet rechecking, continuation, actual sleep, cancellation and
abandonment. No test-only timing stands in for default performance acceptance.

The first partitioned debug run completed 1,585,100 normal-resume schedules, then
found an invalid assertion in the abandonment oracle: `InFlight` does not imply
that a subsequent retirement must fail. The publisher may finish between those
operations. Preserve `partitioned-oracle-failure-source` and the failing log.
The duplicate optimized run finished with the same oracle failure before the
attempt to stop it (the exact PID no longer existed); both logs are retained.
The corrected oracle accepts legal retirement and checks exact resource recovery;
no production protocol change follows this test finding.

The corrected double-query abandonment exploration was also stopped incomplete
after more than eight minutes (normal resume again completed 1,585,100 schedules).
The final abort adapter invokes production retirement directly, matching abort
preflight, rather than first making a separate publication query. Retirement
itself registers completion interest or recovers selected ownership. The final
normal-resume arm continues to query publication. This is an explicit composition
scope, not exhaustive three-actor or full-kernel/shutdown proof.

The direct-retirement composition also remains incomplete after more than eight
minutes; normal resume completed its 1,585,100 schedules. Stop that exact model
process, preserve the result, and allow only the early performance rejection
screen. This does not qualify the abandonment composition or authorize promotion.
If the performance screen survives, proof qualification remains a required gate.
