"""Preserve collection scripts and collect exact dependencies for offline replay."""

from pathlib import Path
import shutil

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
original = OUT / 'collection-scripts'
original.mkdir(exist_ok=False)
for name in ['acceptance.py', 'acceptance_test.py', 'panel.py']:
    shutil.copy2(OUT / name, original / name)
dependencies = OUT / 'replay-dependencies'
dependencies.mkdir(exist_ok=False)
reference = ROOT / 'target/finish-line/may-refresh.yvxHtB'
for name in ['analyze.py', 'cases.py', 'bare-default-1-spawn1000-vthread.log']:
    shutil.copy2(reference / name, dependencies / name)
shutil.copy2(ROOT / 'scripts/evidence.py', dependencies / 'evidence.py')
shutil.copytree('/root/.cache/zcheck/run-1788725002-559959956-3292681',
                OUT / 'report-edit-canonical')
print('Preserved collector scripts, exact replay dependencies and the report-edit failure receipt.')
