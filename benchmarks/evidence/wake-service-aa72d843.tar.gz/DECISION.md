# One bounded-service candidate, selected after attribution

Optimized native test-build controls show 10,000 notices processed in one tick
before a normal head's third dispatch: median sentinel time 1,419,160 ns remote
and 758,814 ns local. At 1,024 notices these are 44,827 and 31,217 ns. An isolated
10,000-entry first pop reverses all 10,000 links and takes median 11,448 ns; this
cannot be hidden inside one supposedly bounded pop. These are mechanism timings,
not default benchmark acceptance or an explanation of the existing 64-task tails.

A changed epoch checks all 128 held publications in 3,315 ns in the single held
control. Unchanged epochs do zero further checks. Preserve that no-busy-loop result.

Candidate: 32 local notices, 32 remote work units (reversed links or dequeues) and
32 deferred queries per scheduler tick, with budgets shared across repeated wake
processing points in that tick. Keep FIFO remote-batch order with owner-retained
incremental reversal. Use a persistent deferred sweep cursor and a coalesced
refresh obligation so new signals cannot restart an unfinished sweep forever.
Unfinished work must keep the owner out of sleep until that service pass finishes;
paused publications alone must not continually restart passes.

These limits count wake-service units, not user-code execution or all shutdown/
revocation/timer work. They do not establish a wall-clock scheduling promise.
Negative controls must fail the retained runtime at the actual work bound. New
queue/cursor protocol tests must exercise exhaustion, exact FIFO order, route reuse,
stale cleanup, concurrent publication and sleep, without weakening atomics.

Default benchmark acceptance and stop margins remain the predeclared policy.
First screen local forced handoff, four-carrier eight-task handoff, then 64-task
handoff and protected lifecycle/tails. This is one candidate, not a budget search.
