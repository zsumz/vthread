"""Protect the reused parser and staged balanced plan before collecting results."""

import copy
from pathlib import Path
import unittest

from acceptance import DEPENDENCIES, paired, parse
from panel import cases, screen_plan


class AcceptanceTests(unittest.TestCase):
    def test_each_stage_balances_arms_and_collection_mode(self):
        for stage in ['local', 'remote', 'population']:
            jobs = screen_plan(stage)
            self.assertEqual(len(jobs), len(cases(stage)) * 16)
            self.assertEqual(len({job['prefix'] for job in jobs}), len(jobs))
            for case in cases(stage):
                group = [job for job in jobs if job['case'] == case]
                for collector in ['bare', 'perf']:
                    first = [job['arm'] for i, job in enumerate(group)
                             if i % 2 == 0 and job['collector'] == collector]
                    self.assertCountEqual(first, ['A', 'A', 'B', 'B'])
                self.assertCountEqual([job['collector'] for job in group[::4]],
                                      ['bare', 'bare', 'perf', 'perf'])

    def test_pinning_and_work_are_exact_not_inferred_from_names(self):
        for stage in ['local', 'remote', 'population']:
            for case in cases(stage):
                self.assertEqual(case['pinned'], '--pin-carriers' in case['args'])
                self.assertEqual(case['workers'], int(case['args'][2]))
                self.assertEqual(case['tasks'], int(case['args'][3]))
                self.assertEqual(case['rounds'], int(case['args'][4]))

    def test_paired_ratios_and_gross_stop(self):
        self.assertAlmostEqual(paired([1, 2, 4, 8], [1.2, 2.4, 4.8, 9.6])['upper_95'], 1.2)
        self.assertTrue(paired([1] * 4, [1.2] * 4)['gross_bare_stop'])
        self.assertFalse(paired([1] * 4, [.9, 1, 1.5, 1.5])['gross_bare_stop'])
        with self.assertRaises(AssertionError):
            paired([1] * 4, [1] * 3)

    def fixture(self):
        job = dict(case=dict(operation='task', workers=4, tasks=1000, rounds=101,
                             per_task=1, capacity=1000, pinned=False))
        path = DEPENDENCIES / 'bare-default-1-spawn1000-vthread.log'
        return job, path.read_text()

    def test_known_output_and_negative_configurations(self):
        job, text = self.fixture()
        self.assertAlmostEqual(parse(text, job)['ns_per_operation'], 411.54)
        for key, value in [('pinned', True), ('capacity', 65536), ('rounds', 501), ('workers', 1)]:
            changed = copy.deepcopy(job)
            changed['case'][key] = value
            with self.assertRaises(AssertionError):
                parse(text, changed)


if __name__ == '__main__':
    unittest.main()
