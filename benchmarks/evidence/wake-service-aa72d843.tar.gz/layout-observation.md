# Candidate-specific cache-line ownership finding

Read from frozen default B executable `ffae35bc` (source `aa72d843`) while the
unchanged remote screen continues. Inspection commands ran on CPUs 4-7, outside
the benchmark's 0-3 mask; they did not sample or attach to the benchmark process.

The aligned queue's consumer index is at offset 0x40. New owner-written reversal
cursors are at 0x80 and 0x88. The slots pointer and bound used by producers are at
0x90 and 0x98. All four latter fields occupy the same 64-byte line.

`pop_budgeted` writes the cursor fields at f7cb2/f7cb9 during a partial reversal,
and f7cd1/f7cdc when reversal finishes. `WaitHub::push` reads the slot bound at
130ef4 and pointer at 130f01 before claiming a slot. The complete relevant
disassembly is preserved. This proves sharing of an owner-written line with
producer-read metadata in this binary; it does not prove how much of the observed
remote loss comes from coherence traffic.

If B fails, a narrowly scoped attribution control could move these owner-only
cursors into the already allocated 64-byte consumer record. This need not add
padding or change the 32-unit budget, producer protocol, per-route slot size or
total queue header footprint. It is not permission for a padding/budget search,
and must first have a failing physical-ownership regression and matched B/control
measurements. No runtime source changes during the current screen.

Important limit: the new cursor stores execute on multi-entry reversal, not the
singleton pop path. Serialized mutex ownership ordinarily supplies one selected
successor at a time, so this finding cannot by itself explain the mutex loss.
Measure actual batch shape/recipient scheduling before attributing that result
to false sharing or treating cursor relocation as its solution.

The isolated optimized test-build queue control supplies another lead: consuming
the remaining 9,999 notices after a 10,000-entry first pop takes median 20,571 ns
in the retained diagnostic versus 80,652 ns in B. First-pop/reversal time is close
(11,448 versus 11,689 ns). B emits `WakeQueue::pop_budgeted` as an out-of-line
function with a mutable budget argument and aggregate result. This is not a
default-build cycle attribution, but points to dequeue/call cost as well as
layout. Do not assume header sharing is the only introduced cost.
