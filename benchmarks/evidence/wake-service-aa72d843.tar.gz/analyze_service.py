"""Summarize ordered test-build diagnostics, never benchmark acceptance."""

import json
from pathlib import Path
from statistics import median
import sys

OUT = Path(__file__).resolve().parent


def records(source):
    prefix = 'wake-service diagnostic=true '
    lines = [line[line.index(prefix):] for line in source.splitlines() if prefix in line]
    return [dict(word.split('=', 1) for word in line.split()[1:] if '=' in word)
            for line in lines]


def summarize(source):
    rows = records(source)
    result = dict(kind='ordered-test-build-diagnostics-not-headline', burst=[], queue=[], held=[])
    for count in [1, 64, 1024, 10000]:
        for local in ['false', 'true']:
            group = [row for row in rows if row.get('tasks') == str(count) and row.get('local') == local]
            assert len(group) == 9, (count, local, len(group))
            result['burst'].append(dict(tasks=count, local=local == 'true', repeats=len(group),
                **{key: median(int(row[key]) for row in group) for key in [
                    'sentinel_ns', 'dispatches', 'notices', 'maximum_notices_per_tick', 'reversed_links']}))
        group = [row for row in rows if row.get('queue_tasks') == str(count)]
        assert len(group) == 9, (count, len(group))
        result['queue'].append(dict(tasks=count, repeats=len(group),
            **{key: median(int(row[key]) for row in group) for key in [
                'first_pop_ns', 'reversed_links', 'remaining_pop_ns']}))
    held = [row for row in rows if 'held' in row]
    assert [int(row['held']) for row in held] == [16, 64, 128]
    result['held'] = [{key: int(value) for key, value in row.items() if key != 'diagnostic'}
                      for row in held]
    return result


if __name__ == '__main__':
    name = sys.argv[1]
    result = summarize((OUT / f'{name}.log').read_text())
    with (OUT / f'{name}.summary.json').open('x') as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2))
