# Wake-service attribution and bounded continuation

Retained base 0aea68f, source d38dcb86, including the qualified cold stall-count
repair. Freeze its default benchmark binary before any source changes.

First measure only: add test-only work counters, native-owner wake-burst/sentinel
and held-publication fixtures, and an isolated first-pop/reversal control. Count
ordinary notices, deferred publication queries and reversed links independently.
Record times as test-build mechanism diagnostics, not acceptance timing. Compare
fixed populations 1, 64, 1,024 and 10,000 where the fixture is practical; use a
bounded held-publisher population, not thousands of blocked native threads.

If the measured service work is consequential, one production candidate may bound
ordinary wake service and deferred revisits between dispatch opportunities. The
queue must not hide an unbounded full-batch reversal inside one counted pop. Keep
FIFO batch order, exact routes/generations, one outstanding notice per route and
completion interest. No new signal is required to continue unfinished service;
genuinely paused publication must eventually allow the owner to sleep.

Required negative/positive proof: a runnable sentinel beside a large wake burst;
local/remote service; continuation after one signal and no further producer work;
held and completing publishers; generation reuse and stale notices; cancellation,
abandonment and shutdown; the imported production queue/publication composition
model. Existing ready cohorts, admission fairness, affinity, stack engine, both
checkpoints, mutex ownership and all 640 polling probes remain unchanged.

Acceptance follows benchmarks/counter-free-acceptance.md without altered margins.
Screen one-carrier handoff, four-carrier 8/64-task handoff, tight/spare lifecycle,
wake tails and burst/idle CPU in separately recorded default/pinned and bare/counter
modes. Preserve every planned result. An optional candidate crossing the early
stop is rejected; a survivor receives one planned confirmation, not repeated
sampling until green. Test-only counters and clocked diagnostic binaries never
stand in for default-build counter-free acceptance.
