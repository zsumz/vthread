"""Summarize complete, separately collected paired screens without cherry-picking."""

import json
from pathlib import Path
import statistics

out = Path(__file__).resolve().parent
for stage in ['local', 'remote']:
    groups = json.loads((out / f'{stage}-analysis.json').read_text())
    for name, group in groups.items():
        switches = {arm: statistics.median(row['resources']['voluntary_switches']
                                          for row in group[arm]) for arm in ['A', 'B']}
        print(name, f"A={group['timing']['A']['median']:.2f}",
              f"B={group['timing']['B']['median']:.2f}",
              f"paired_time_pct={100*(group['timing_effect']['median_ratio']-1):.2f}",
              f"paired_cpu_pct={100*(group['cpu_effect']['median_ratio']-1):.2f}",
              f"voluntary_switches={switches}")
