# Bounded wake-service experiment, rejected

Read `STOP.md`, `model-scope.md` and `PLAN.md` before interpreting the numbers.
This archive preserves the first candidate, not a retained runtime optimization.
Default binaries and source manifests distinguish native A/B acceptance from
test-build mechanism diagnostics. The full abandonment model remains incomplete.

`local-plan.json` contains 48 processes; `remote-plan.json` contains 96. Both have
their original commands, raw outcomes, post-exit resource accounting and endpoint
build-overlap observations. No population-stage or confirmation samples exist.
Balanced candidate/baseline ratios are computed separately in bare and PMU modes.

After unpacking into an empty directory, run `python3 replay.py`. It checks the
eight analyzer tests, all 144 raw results, stored paired ratios and both diagnostic
summaries without Rust, PMU access, a running benchmark or the original checkout.
`SHA256SUMS` covers every archived file except itself. The bundle creator also
reconstructs every frozen source digest from sorted archive member names/bytes.

Original collection scripts are in `collection-scripts/`. Top-level copies only
change dependency lookup to prefer `replay-dependencies/`; no parser, pairing or
acceptance calculation changes. The collector/build/test runners retain original
absolute paths as execution provenance, not automatic portable benchmark runners.
Frozen source archives include build manifests and locks; benchmark binaries are
included with source/binary SHA-256 identities. Dependency/toolchain availability
is still required to rebuild or rerun native tests.

`report-edit-canonical/` retains all 14 passing task logs and the overall failed
receipt: the report changed while the repository-state guard was active. The
untouched-checkout rerun is separately preserved under `retained-canonical/`.
No benchmark outcome is replaced by that qualification rerun. Model failures,
interruptions and negative controls remain under their original attempt names.
