# Reject bounded-service candidate B

All 48 planned local and 96 planned small-remote processes completed, with no
replacement samples and clear build-overlap guards. The three gross-stop bare
cells are four-carrier/eight-task default mutex (+18.33% median paired time),
pinned mutex (+78.49%) and default channel (+12.27%). Respect the predeclared stop.

Do not run the 64-task protected stage, broader lifecycle/tails/CPU panel, fresh
12-pair confirmation or default-build burst promotion panel. The existing ordered
native test-build burst diagnostic may quantify the progress/cost tradeoff; it
does not rescue the candidate. Full abandonment composition is independently
unqualified and no complete B canonical run is claimed.

Preserve the candidate, every model attempt and both source/binary identities.
Restore baseline native source d38dcb86 and run the canonical retained check.
The physical cursor/producer-metadata sharing finding is a future attribution
lead, not an established explanation of the singleton mutex loss or permission
for a layout/polling search. No new May comparison or retained speedup follows.
