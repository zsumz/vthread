"""Verify archived raw results against recorded analysis without running benchmarks."""

import hashlib
import json
from pathlib import Path
import unittest

import acceptance
from acceptance import counters, paired, parse
from analyze_service import summarize as summarize_service
from panel import screen_plan

OUT = Path(__file__).resolve().parent


def check_analysis(stage):
    jobs = json.loads((OUT / f'{stage}-plan.json').read_text())
    assert jobs == screen_plan(stage)
    assert len(jobs) == len(list(OUT.glob(f'{stage}-*.result.json')))
    groups = json.loads((OUT / f'{stage}-analysis.json').read_text())
    covered = set()
    for group in groups.values():
        for arm in ['A', 'B']:
            for row in group[arm]:
                prefix = row['prefix']
                job = next(job for job in jobs if job['prefix'] == prefix)
                assert prefix not in covered
                covered.add(prefix)
                assert job['arm'] == arm and job['case'] == group['case']
                assert job['collector'] == group['collector']
                result = json.loads((OUT / f'{prefix}.result.json').read_text())
                assert result['returncode'] == 0
                assert row['resources'] == result['resources']
                for phase in ['before', 'after']:
                    assert not (OUT / f'{prefix}.{phase}.guard').read_text().strip()
                parsed = parse((OUT / f'{prefix}.log').read_text(), job)
                assert all(row[key] == value for key, value in parsed.items())
                cpu = sum(result['resources'][key] for key in ['user_seconds', 'system_seconds'])
                assert row['cpu_seconds_per_operation'] == cpu / parsed['process_operations']
                if job['collector'] == 'perf':
                    assert row['counters'] == counters(OUT / f'{prefix}.csv')
        for field, name in [('ns_per_operation', 'timing_effect'),
                            ('cpu_seconds_per_operation', 'cpu_effect')]:
            assert group[name] == paired([row[field] for row in group['A']],
                                         [row[field] for row in group['B']])
    assert covered == {job['prefix'] for job in jobs}
    return len(covered)


if __name__ == '__main__':
    assert acceptance.DEPENDENCIES == OUT / 'replay-dependencies'
    suite = unittest.defaultTestLoader.discover(str(OUT), pattern='*_test.py')
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.wasSuccessful()
    assert sum(check_analysis(stage) for stage in ['local', 'remote']) == 144
    for name in ['retained-service-release', 'candidate-service-release']:
        recorded = json.loads((OUT / f'{name}.summary.json').read_text())
        assert recorded == summarize_service((OUT / f'{name}.log').read_text())
    if (OUT / 'SHA256SUMS').is_file():
        for line in (OUT / 'SHA256SUMS').read_text().splitlines():
            expected, name = line.split('  ', 1)
            assert hashlib.sha256((OUT / name).read_bytes()).hexdigest() == expected, name
    print('Verified 144 planned raw processes, paired analyses and both ordered diagnostic summaries.')
