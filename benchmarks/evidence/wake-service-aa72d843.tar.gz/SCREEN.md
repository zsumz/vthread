# Protected early screen, before default candidate measurements

Preserve the existing benchmark contract and all A/B binaries. First local
forced handoff, then four carriers/eight tasks, then four carriers/64 tasks.
Each stage covers park, contended mutex and paired channel: 10,000 operations per
task and 101 measured rounds plus the existing warm-up. Local uses process CPU 0;
remote stages use CPUs 0-3 with default and individual pinning kept separate.
Four paired processes per collection mode and placement, balanced A/B and
bare/perf order. Reused parser checks work, rounds, capacity and pinning.

The existing gross bare stop applies to each complete stage. Preserve failures
and remaining unrun jobs; do not replace samples or rescue a losing stage with
later results. A survivor still needs protected lifecycle/tails/CPU and fresh
12-pair confirmation under the existing acceptance margins. No full promotion
claim from these early screens or native test-build mechanism timing alone.

The test-build burst fixture is the initial algorithmic target; any retained
performance claim also needs a matched default-build burst result. Test counters
and paused-publisher clock probes never enter headline acceptance binaries.
