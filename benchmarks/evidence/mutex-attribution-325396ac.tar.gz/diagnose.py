"""Reuse the frozen benchmark parser; separate default control and diagnostic distortion."""

import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

from acceptance import fields, paired, parse

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

KEYS = 'calls acquired failed_calls immediate recheck queued park_returns parks completed dropped removed abandoned attempts stored rejected same_owner other_owner'.split()


def cases():
    result = []
    for workers, tasks in [(1, 8), (4, 8), (4, 64)]:
        for per_task in [1000, 10000]:
            for pinned in ([False] if workers == 1 else [False, True]):
                name = f'{workers}c-{tasks}t-{per_task}n-' + ('pinned' if pinned else 'default')
                result.append(dict(name=name, workers=workers, tasks=tasks, per_task=per_task,
                    rounds=9, capacity=tasks, pinned=pinned, operation='mutex-handoff',
                    args=['mutex', str(per_task), str(workers), str(tasks), '9']
                         + (['--pin-carriers'] if pinned else []),
                    mask='0' if workers == 1 else '0-3'))
    return result


def plan():
    jobs = []
    orders = [('A', 'B', 'P'), ('P', 'B', 'A'), ('B', 'A', 'P'), ('P', 'A', 'B')]
    for repetition, order in enumerate(orders, 1):
        for case in (cases() if repetition % 2 else list(reversed(cases()))):
            for arm in order:
                jobs.append(dict(prefix=f'observe-{repetition}-{case["name"]}-{arm}',
                    repetition=repetition, arm=arm, case=case))
    assert len(jobs) == 120
    return jobs


def mutex_counts(text, case):
    rows = [fields(line) for line in text.splitlines() if 'phase=handoff-mutex ' in line]
    assert len(rows) == case['workers']
    assert sorted(int(row['carrier']) for row in rows) == list(range(case['workers']))
    values = []
    for row in rows:
        assert row['engine'] == 'vthread' and row['owner_identity'] == 'hub'
        assert row['sleep_inferred'] == 'false'
        c = {key: int(row[key]) for key in KEYS}
        assert all(value >= 0 for value in c.values())
        assert c['calls'] == c['acquired'] and c['failed_calls'] == 0
        assert c['queued'] == c['completed'] == c['park_returns']
        assert c['acquired'] == c['immediate'] + c['recheck'] + c['completed']
        assert c['dropped'] == c['removed'] == c['abandoned'] == c['rejected'] == 0
        assert c['parks'] <= c['completed']
        assert c['attempts'] == c['stored'] + c['same_owner'] + c['other_owner']
        values.append(c)
    total = {key: sum(row[key] for row in values) for key in KEYS}
    assert total['calls'] == case['tasks'] * case['per_task'] * (case['rounds'] + 1)
    # Only this fixture has all resource producers counted on mounted carriers.
    assert total['completed'] == total['attempts']
    if case['workers'] == 1:
        assert total['other_owner'] == total['stored'] == 0
        assert total['parks'] == total['completed'] == total['same_owner'] > 0
    return dict(total=total, carriers=values)


def observe(prefix, stage):
    result = subprocess.run(['pgrep', '-x', 'cargo|rustc|clippy-driver|zrail'], capture_output=True, text=True)
    with (OUT / f'{prefix}.{stage}.guard').open('x') as stream:
        stream.write(result.stdout + result.stderr)
    with (OUT / f'{prefix}.{stage}.host').open('x') as stream:
        stream.write(evidence.output('ps', '-eo', 'pid,comm,pcpu,etime') + '\n')
    with (OUT / f'{prefix}.{stage}.cpu').open('x') as stream:
        stream.write(''.join(Path('/proc/stat').read_text().splitlines(keepends=True)[:9]))
    assert result.returncode == 1, 'build overlap; preserve unrun jobs and every outcome'


def run():
    sources = {arm: json.loads((OUT / name).read_text()) for arm, name in [
        ('A', 'A-source.json'), ('B', 'B-source.json'), ('P', 'probe-B.json')]}
    binaries = {arm: OUT / ('probe-B' if arm == 'P' else f'benchmark-{arm}') for arm in sources}
    for arm, source in sources.items():
        assert evidence.digest(binaries[arm]) == source['binary_sha256']
    assert sources['B']['source_sha256'] == sources['P']['source_sha256'] == evidence.source_digest()
    jobs = plan()
    with (OUT / 'observation-plan.json').open('x') as stream:
        json.dump(jobs, stream, indent=2)
    with (OUT / 'observation-topology.json').open('x') as stream:
        stream.write(evidence.output('lscpu', '--json') + '\n')
    for index, job in enumerate(jobs):
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '120s', 'taskset', '-c', job['case']['mask'],
                   str(binaries[job['arm']]), 'vthread', *job['case']['args']]
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, started_unix=time.time(), job=job, source=sources[job['arm']]), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            process = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            pid, status, usage = os.wait4(process.pid, 0)
            assert pid == process.pid
            process.returncode = os.waitstatus_to_exitcode(status)
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(dict(returncode=process.returncode, finished_unix=time.time(), resources=dict(
                user_seconds=usage.ru_utime, system_seconds=usage.ru_stime, peak_rss_kib=usage.ru_maxrss,
                voluntary_switches=usage.ru_nvcsw, involuntary_switches=usage.ru_nivcsw)), stream, indent=2)
        observe(prefix, 'after')
        assert process.returncode == 0, (prefix, process.returncode)
        text = (OUT / f'{prefix}.log').read_text()
        row = parse(text, job)
        if job['arm'] == 'P':
            mutex_counts(text, job['case'])
        else:
            assert 'phase=handoff-' not in text
        print(f'{index + 1}/{len(jobs)} {prefix}: {row["ns_per_operation"]:.2f} ns/op', flush=True)
    assert sources['B']['source_sha256'] == evidence.source_digest()


def analyze():
    jobs = plan()
    assert json.loads((OUT / 'observation-plan.json').read_text()) == jobs
    assert len(list(OUT.glob('observe-*.result.json'))) == len(jobs)
    groups = {}
    for job in jobs:
        prefix = job['prefix']
        result = json.loads((OUT / f'{prefix}.result.json').read_text())
        assert result['returncode'] == 0
        for phase in ['before', 'after']:
            assert not (OUT / f'{prefix}.{phase}.guard').read_text().strip()
        text = (OUT / f'{prefix}.log').read_text()
        value = parse(text, job)
        value.update(resources=result['resources'], prefix=prefix)
        value['cpu_seconds_per_operation'] = (result['resources']['user_seconds'] + result['resources']['system_seconds']) / value['process_operations']
        if job['arm'] == 'P':
            value['mutex'] = mutex_counts(text, job['case'])
        else:
            assert 'phase=handoff-' not in text
        groups.setdefault(job['case']['name'], {arm: [] for arm in ['A', 'B', 'P']})[job['arm']].append(value)
    for name, group in groups.items():
        for label, first, last in [('default_control', 'A', 'B'), ('diagnostic_distortion', 'B', 'P')]:
            group[label] = {metric: paired([row[metric] for row in group[first]], [row[metric] for row in group[last]])
                            for metric in ['ns_per_operation', 'cpu_seconds_per_operation']}
        print(name, 'default B/A', group['default_control']['ns_per_operation']['median_ratio'],
              'clocked P/B', group['diagnostic_distortion']['ns_per_operation']['median_ratio'])
    return groups


if __name__ == '__main__':
    if sys.argv[1:] == ['run']:
        run()
    elif sys.argv[1:] == ['analyze']:
        with (OUT / 'observation-analysis.json').open('x') as stream:
            json.dump(analyze(), stream, indent=2)
    else:
        raise SystemExit('usage: diagnose.py run|analyze')
