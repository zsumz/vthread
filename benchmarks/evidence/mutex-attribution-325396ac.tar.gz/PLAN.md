# First production-mutex attribution slice: useful-path counters

Base 837f8d8, retained native source d38dcb86. This is measurement work, not a
runtime performance candidate or a May comparison. All ownership, cancellation,
affinity, queue, signal, fairness, admission and polling behavior stays frozen.

Extend the existing handoff-profiling owner-local accounting, without a new trace
framework, shared counter atomics, timestamps or per-observation allocation.
Distinguish lock calls and successful/failed returns; immediate and queued-recheck
acquisitions; queued tickets, normal completion and cleanup; actual parks;
resource selection attempts, active selections, non-active stored grants and
rejections; and owning-hub equality for selected grants. Do not infer another
owner merely because routing uses the shared queue. External producers without
the mounted carrier route remain outside owner-local counts, as in the existing
profiler. Stored offers are not proof of a distinct future acquisition.

Read target metadata only while the existing ResourcePublication owns a claimed
generation. No new atomic transition or early publication is allowed. A stored
grant has no such claim and must not inspect possibly old target metadata.
Never retain a profile borrow across suspension or wake publication.

First freeze a pristine default A. Add ordered accounting/owner-identity tests and
a forced-shared/same-owner negative control before drawing mechanism conclusions.
Require exact final ticket conservation and useful-acquisition counts in the
existing production mutex benchmark. Keep its multi-carrier 32-black-box critical
section and one-carrier yield-under-lock contracts unchanged.

Use separately identified default and clocked diagnostic builds, matching work
counts and pinning. Existing clocks still distort the diagnostic configuration;
these frequencies describe that execution, not automatically the bare 423.76 ns
historical mix. No new scheduling/ownership optimization follows these counters
alone. Publication-stage timestamps, actual native sleeping and OS scheduling
correlation remain follow-up attribution, not claims made by this first slice.

Qualify native/default and profiling tests, benchmark report negatives and the
canonical gate. Review any architecture inventory delta explicitly. Check default
binary/codegen changes separately; do not claim a speedup from instrumentation.
