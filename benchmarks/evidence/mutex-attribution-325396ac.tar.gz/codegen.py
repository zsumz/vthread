"""Read-only executable-section comparison; never rewrite the frozen binaries."""

import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
result = {}
for arm in ['A', 'B']:
    binary = OUT / f'benchmark-{arm}'
    command = ['objdump', '-h', str(binary)]
    headers = subprocess.check_output(command, text=True)
    match = re.search(r'^\s*\d+\s+\.text\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)', headers, re.M)
    assert match
    size, offset = int(match[1], 16), int(match[4], 16)
    read = ['dd', f'if={binary}', 'bs=65536', 'iflag=skip_bytes,count_bytes',
            f'skip={offset}', f'count={size}', 'status=none']
    code = subprocess.check_output(read)
    assert len(code) == size
    symbols = subprocess.check_output(['nm', '-C', str(binary)], text=True)
    assert not any(name in symbols for name in ['handoff_mutex', 'MutexCall', 'mutex_grant', 'is_owner_hub'])
    result[arm] = dict(headers_command=command, headers=headers, read_command=read,
                       bytes=size, offset=offset, text_sha256=hashlib.sha256(code).hexdigest(),
                       diagnostic_symbols=False)
assert result['A']['text_sha256'] == result['B']['text_sha256'], 'default executable code differs'
with (OUT / 'codegen.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print('identical default .text:', result['A']['bytes'], result['A']['text_sha256'])
