"""Print derived tables from the durable, validated four-process controls."""

import json
from pathlib import Path
import statistics as stats

OUT = Path(__file__).resolve().parent
groups = json.loads((OUT / 'observation-analysis.json').read_text())
for name, group in groups.items():
    counts = [row['mutex']['total'] for row in group['P']]
    parks = [c['parks'] / c['acquired'] * 100 for c in counts]
    remote = [c['other_owner'] / (c['other_owner'] + c['same_owner']) * 100 for c in counts]
    print(f'| {name} | {stats.median(row["ns_per_operation"] for row in group["B"]):.2f}'
          f' | {stats.median(row["ns_per_operation"] for row in group["P"]):.2f}'
          f' | {group["diagnostic_distortion"]["ns_per_operation"]["median_ratio"]:.3f}x'
          f' | {group["diagnostic_distortion"]["cpu_seconds_per_operation"]["median_ratio"]:.3f}x'
          f' | {min(parks):.3f}-{max(parks):.3f}% | {min(remote):.2f}-{max(remote):.2f}% |')
totals = {key: sum(row['mutex']['total'][key] for group in groups.values() for row in group['P'])
          for key in next(iter(groups.values()))['P'][0]['mutex']['total']}
print(totals)
