# Qualification attempts, including non-green setup runs

- `first-mutex-tests`: 2/4 passed. The new manual-kernel fixtures incorrectly kept
  the default stack-cache capacity while reducing task capacity to two. Fixed the
  fixture's explicit stack and ingress capacities; no runtime behavior was changed.
- `ordered-mutex-tests`: all four new accounting tests passed after that correction.
- `mutex-suite`: 25/26 passed. The new inactive-resource fixture consumed the
  resource but forgot to recycle its stored notification permit before expecting
  an active park. Added the ordinary recycle boundary to the test setup.
- `mutex-suite-fixed`: all 26 matching tests passed, including real mutex ownership,
  selected cancellation, publisher pause, global stop and failed-carrier cleanup.
- `negative-owner-classification`: expected exit 101. Temporarily treating all
  selected destinations as same-owner failed exactly at the foreign-hub assertion.
  The recorded patch captures the mutation. It was immediately restored.
- `initial-architecture`: 57 unresolved test macro origins in the new feature-gated
  sibling plus the changed source inventory. Qualified the test macros as core
  macros, preserving strict origin binding. No conservative allowance was added.
- Inventory update preview reported zero grants, revokes, debt, cleanup or neutral
  changes and one `lock.analysis` inventory change. Session-authorized update
  accepted only fingerprint 8a71411f89a73ec6009f6b29255cc112178e6ad71e7977f20e338c063afe4e16
  -> af3e2d1ec0c3fa18c15890f548e6f8ffbf364c6c6fc35d4df7fe4dec9f2ee1c3.
  Rust files 423->425, base contexts 2969->2972, source facts 142177->144148,
  projection queries 4077784->4097470. Contract/features/dependencies and all
  permissions are unchanged; unresolved bindings remain zero. Update succeeded.

No setup/test failure was turned into a performance sample. This file will be
read with the recorded results, not as a substitute for a green receipt.

Final source 325396ac passes all 14 canonical gates, with preserved repository:
`run-1788735189-317388508-3362164`. Native all-feature tests took 113.0s,
default debug 111.0s and default release 215.7s. Both benchmark feature worlds
pass formatting, tests (47 default / 53 profiling) and strict clippy. All 120
planned observations completed with endpoint guards clear and exact successful
acquisition counts; no process was replaced. The final native gate also reruns
the positive owner-identity regression after the deliberate mutation was restored.

The full default executable hashes differ, but their entire 1,277,172-byte .text
sections are identical and diagnostic symbols are absent. Clocked timings are
not promotion evidence; they quantify whole-feature distortion separately.
