import copy
import unittest

from diagnose import KEYS, cases, mutex_counts, plan


class MutexEvidence(unittest.TestCase):
    def fixture(self):
        case = dict(workers=2, tasks=2, per_task=2, rounds=1)
        counts = []
        for same, other in [(0, 4), (4, 0)]:
            c = dict.fromkeys(KEYS, 0)
            c.update(calls=4, acquired=4, queued=4, completed=4, park_returns=4,
                     parks=4, attempts=4, same_owner=same, other_owner=other)
            counts.append(c)
        return case, counts

    def text(self, counts):
        return '\n'.join(f'engine=vthread phase=handoff-mutex carrier={index} '
                         + ' '.join(f'{key}={value}' for key, value in c.items())
                         + ' owner_identity=hub sleep_inferred=false'
                         for index, c in enumerate(counts))

    def test_exact_acquisitions_and_ticket_grants(self):
        case, counts = self.fixture()
        result = mutex_counts(self.text(counts), case)
        self.assertEqual(result['total']['calls'], 8)
        self.assertEqual(result['total']['same_owner'], 4)
        self.assertEqual(result['total']['other_owner'], 4)
        for key in ['calls', 'acquired', 'queued', 'completed', 'park_returns', 'attempts']:
            broken = copy.deepcopy(counts)
            broken[0][key] += 1
            with self.assertRaises(AssertionError, msg=key):
                mutex_counts(self.text(broken), case)
        for key in ['dropped', 'failed_calls', 'rejected', 'removed', 'abandoned']:
            broken = copy.deepcopy(counts)
            broken[0][key] = 1
            with self.assertRaises(AssertionError, msg=key):
                mutex_counts(self.text(broken), case)

    def test_missing_carrier_false_sleep_and_local_foreign_owner_are_rejected(self):
        case, counts = self.fixture()
        for text in [self.text(counts[:1]), self.text(counts).replace('sleep_inferred=false', 'sleep_inferred=true'),
                     self.text(counts).replace('carrier=1', 'carrier=0')]:
            with self.assertRaises(AssertionError):
                mutex_counts(text, case)
        local = dict(workers=1, tasks=1, per_task=2, rounds=1)
        with self.assertRaises(AssertionError):
            mutex_counts(self.text(counts[:1]), local)

    def test_stored_grant_is_not_a_park_or_an_owner_classification(self):
        case, counts = self.fixture()
        counts[0].update(parks=0, stored=4, other_owner=0)
        result = mutex_counts(self.text(counts), case)['total']
        self.assertEqual(result['parks'], 4)
        self.assertEqual(result['stored'], 4)
        self.assertEqual(result['other_owner'], 0)

    def test_plan_balances_collection_order_and_protects_work_counts(self):
        jobs = plan()
        self.assertEqual(len(cases()), 10)
        self.assertEqual(len(jobs), 120)
        self.assertEqual(len({j['prefix'] for j in jobs}), 120)
        for case in cases():
            orders = [[j['arm'] for j in jobs if j['case'] == case and j['repetition'] == rep]
                      for rep in range(1, 5)]
            self.assertEqual(sum(o.index('A') < o.index('B') for o in orders), 2)
            self.assertEqual(sum(o.index('B') < o.index('P') for o in orders), 2)
            self.assertEqual(case['rounds'], 9)
            self.assertEqual(case['capacity'], case['tasks'])


if __name__ == '__main__':
    unittest.main()
