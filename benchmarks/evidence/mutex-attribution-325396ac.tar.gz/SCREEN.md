# Bounded diagnostic screen, declared before measurement

120 fresh processes, 10 cells, four ordered triplets per cell. Versions A and B
are separately frozen default native binaries before/after the opt-in accounting
extension; P is B with the existing clocked handoff-profiling feature. No PMU
collector runs. Keep B/A default controls separate from P/B diagnostic distortion.
This is neither a candidate speedup claim nor an authoritative performance panel.

Cells: 1 carrier / 8 tasks; 4 carriers / 8 or 64 tasks. Each uses 1,000 and 10,000
acquisitions per task, one warm-up and nine measured rounds. Four-carrier cells
run separately with and without individual carrier pinning; the process CPU mask
is always recorded. Capacity equals live task count. Existing yield-under-lock
and 32-black-box critical sections are unchanged. No latency distribution is
inferred from throughput-derived ns/op.

Triplet orders ABP, PBA, BAP, PAB balance A/B and B/P order independently. Reverse
cell order on alternating repetitions. Retain every planned outcome. A timeout,
bad acquisition count, guard overlap or parser failure stops the run; do not
replace failed outcomes. Require exact final useful acquisitions and ticket
conservation from P, plus grant/receipt conservation specifically for this
all-carrier-producer fixture. No shared-hub-to-foreign-owner inference is allowed.

Interpret same/different owner and stored/active proportions as the diagnostic
execution's distribution. Source/destination stage timestamps, actual recipient
sleep and OS scheduling delay remain unmeasured here. Native-wait invocation
counts, already present in the profiler, do not establish kernel descheduling.
