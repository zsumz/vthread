# Useful mutex-path evidence, native Linux x86-64

Measurement-only extension at source 325396ac, based on pristine d38dcb86 at
commit 837f8d8. No new runtime optimization or May panel. Preserve direct ownership,
both checkpoints, affinity, native engine, queues, polling, fairness and wake
publication/retirement. Full source snapshots and all three executed binaries are
included; the default executables have identical .text sections.

`PLAN.md` and `SCREEN.md` predeclare scope, meaning and ordering. `ATTEMPTS.md`
classifies all setup/qualification failures and the deliberate negative control.
`observation-plan.json` contains all 120 jobs. Every process has command/source,
raw stdout, exit/CPU/resource result and before/after host/build-guard observations.
The guards are endpoint samples, not proof of uninterrupted external quietness.
Nine timed rounds plus warm-up, four process triplets per cell; no PMU collector.
The 40 clocked executions describe that diagnostic mode, not default state mix.

Read `observation-analysis.json` for every process, paired ratios and four-pair
uncertainty summaries. `report.py` prints derived tables. `codegen.json` records
read-only whole-.text comparison, exact commands and absence of diagnostic symbols.
`qualification/receipt.json` and logs retain all 14 passing gates with repository
preservation, required default native debug/release and all-feature coverage.
This is not current-source ARM64, sanitizer, large-population, footprint or loaded
tail qualification. Whole-process RSS includes the launcher and is not a runtime
memory-layout measurement.

After extraction, run:

```
python3 replay.py
python3 report.py
```

Replay verifies every payload hash, reconstructs each frozen source digest from
the archive bytes, checks all executable/code-section identities, verifies the
negative owner oracle and positive qualification, runs four parser negatives,
and re-analyzes every observed process. It does not execute benchmark binaries.
The executed runners preserve original absolute paths in commands/manifests;
rebuilding elsewhere requires an explicit path/toolchain adaptation, not merely
rerunning those absolute commands.

The source archives contain the complete final A/B sources. Earlier fixture-setup
failures retain commands, source hashes, tracked patches and raw error evidence,
not a claim that every intermediate untracked fixture version has its own archive.
The tested owner-classification mutation is preserved in its tracked source patch.
No archived command or file may be silently overwritten to repair a failed run.
