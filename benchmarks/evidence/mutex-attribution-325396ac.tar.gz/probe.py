"""Reuse clocked, final-only diagnostics; never compare their timing for acceptance."""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def capture(prefix, command, source, environment=None):
    with (OUT / f'{prefix}.command.json').open('x') as stream:
        json.dump(dict(command=command, source=source, started_unix=time.time()), stream, indent=2)
    with (OUT / f'{prefix}.log').open('x') as stream:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        pid, status, usage = os.wait4(process.pid, 0)
        assert pid == process.pid
        process.returncode = os.waitstatus_to_exitcode(status)
    with (OUT / f'{prefix}.result.json').open('x') as stream:
        json.dump(dict(returncode=process.returncode, finished_unix=time.time(), resources=dict(
            user_seconds=usage.ru_utime, system_seconds=usage.ru_stime, peak_rss_kib=usage.ru_maxrss,
            voluntary_switches=usage.ru_nvcsw, involuntary_switches=usage.ru_nivcsw)), stream, indent=2)
    assert process.returncode == 0, (prefix, process.returncode)
    print(prefix, 'passed', flush=True)


def build(arm):
    manifest = evidence.metadata(f'clocked mutex diagnostic {arm}; events only, not acceptance')
    environment = dict(os.environ, CARGO_TARGET_DIR=str(BUILD), CARGO_INCREMENTAL='0')
    for name, command in [
        ('format', ['cargo', 'fmt', '--all', '--', '--check']),
        ('format-bench', ['cargo', 'fmt', '--manifest-path', 'benchmarks/Cargo.toml', '--', '--check']),
        ('report', ['cargo', 'test', '--locked', '--manifest-path', 'benchmarks/Cargo.toml',
                    '--features', 'handoff-profiling', '--', '--nocapture']),
        ('clippy', ['cargo', 'clippy', '--locked', '--manifest-path', 'benchmarks/Cargo.toml',
                    '--all-targets', '--features', 'handoff-profiling', '--', '-D', 'warnings']),
        ('build', ['cargo', 'build', '--locked', '--release', '--manifest-path',
                   'benchmarks/Cargo.toml', '--features', 'handoff-profiling']),
    ]:
        capture(f'probe-{arm}-{name}', ['timeout', '600s', *command], manifest, environment)
    assert evidence.source_digest() == manifest['source_sha256']
    binary = OUT / f'probe-{arm}'
    assert not binary.exists()
    shutil.copy2(BUILD / 'release/vthread-benchmarks', binary)
    manifest.update(binary_sha256=evidence.digest(binary), features=['handoff-profiling'],
                    build_environment=dict(CARGO_TARGET_DIR=str(BUILD), CARGO_INCREMENTAL='0'))
    with (OUT / f'probe-{arm}.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)

if __name__ == '__main__':
    build('B')
