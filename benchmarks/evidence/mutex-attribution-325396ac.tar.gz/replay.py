"""Verify a source-keyed bundle and replay analysis without rebuilding or benchmarking."""

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT / 'replay-dependencies'))
import evidence
# The executed runner retains its original working paths; analysis uses OUT only.
sys.modules['evidence'] = evidence
import diagnose


def digest(data):
    return hashlib.sha256(data).hexdigest()


for line in (OUT / 'SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    path = Path(name)
    assert not path.is_absolute() and '..' not in path.parts
    assert digest((OUT / path).read_bytes()) == expected, name

for arm in ['A', 'B']:
    manifest = json.loads((OUT / f'{arm}-source.json').read_text())
    archive = OUT / f'{arm}-source.tar.gz'
    assert digest(archive.read_bytes()) == manifest['source_archive_sha256']
    source = hashlib.sha256()
    with tarfile.open(archive) as snapshot:
        for member in sorted(snapshot.getmembers(), key=lambda member: member.name):
            assert member.isfile(), member.name
            source.update(member.name.encode() + b'\0' + snapshot.extractfile(member).read() + b'\0')
    assert source.hexdigest() == manifest['source_sha256'], arm
    assert digest((OUT / f'benchmark-{arm}').read_bytes()) == manifest['binary_sha256']

probe = json.loads((OUT / 'probe-B.json').read_text())
assert digest((OUT / 'probe-B').read_bytes()) == probe['binary_sha256']
assert probe['source_sha256'] == json.loads((OUT / 'B-source.json').read_text())['source_sha256']
code = json.loads((OUT / 'codegen.json').read_text())
for arm, row in code.items():
    binary = (OUT / f'benchmark-{arm}').read_bytes()
    assert digest(binary[row['offset']:row['offset'] + row['bytes']]) == row['text_sha256']
assert code['A']['text_sha256'] == code['B']['text_sha256']

negative = json.loads((OUT / 'negative-owner-classification.result.json').read_text())
assert negative['returncode'] == 101
assert 'left: true\n right: false' in (OUT / 'negative-owner-classification.log').read_text()
assert '1 failed' in (OUT / 'negative-owner-classification.log').read_text()
receipt = json.loads((OUT / 'qualification/receipt.json').read_text())
assert receipt['receipt'] in (OUT / 'canonical.log').read_text()
assert receipt['repository']['before']['head'] == json.loads((OUT / 'B-source.json').read_text())['head']
assert receipt['repository']['preserved'] is True
assert receipt['status'] == 'passed'
assert len(receipt['tasks']) == 14
assert all(task['status'] == 'passed' for task in receipt['tasks'])
assert json.loads((OUT / 'canonical.command.json').read_text())['source']['source_sha256'] == probe['source_sha256']

subprocess.run([sys.executable, str(OUT / 'diagnose_test.py')], check=True, cwd=OUT)
assert diagnose.analyze() == json.loads((OUT / 'observation-analysis.json').read_text())
print('bundle hashes, source snapshots, binaries, negative control, native qualification and all 120 processes verified')
