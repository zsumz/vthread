"""Preserve completed evidence; refuse to package a failed or source-mismatched gate."""

import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = ROOT / 'target/finish-line/mutex-attribution.jSLecM'
receipt_path = Path(sys.argv[1]).resolve()
receipt = json.loads(receipt_path.read_text())
assert str(receipt_path) in (OUT / 'canonical.log').read_text()
assert receipt['repository']['preserved'] is True
assert receipt['status'] == 'passed' and len(receipt['tasks']) == 14
assert all(task['status'] == 'passed' for task in receipt['tasks'])
source = json.loads((OUT / 'B-source.json').read_text())['source_sha256']
assert receipt['repository']['before']['head'] == json.loads((OUT / 'B-source.json').read_text())['head']
assert json.loads((OUT / 'canonical.command.json').read_text())['source']['source_sha256'] == source
assert json.loads((OUT / 'canonical.result.json').read_text())['returncode'] == 0
qualification = OUT / 'qualification'
assert not qualification.exists()
shutil.copytree(receipt_path.parent, qualification)
paths = sorted(path for path in OUT.rglob('*') if path.is_file() and '__pycache__' not in path.parts)
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + str(path.relative_to(OUT)) + '\n')
archive_path = ROOT / 'benchmarks/evidence' / f'mutex-attribution-{source[:8]}.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
print(archive_path, archive_path.stat().st_size, hashlib.sha256(archive_path.read_bytes()).hexdigest(), len(paths))
