# Replay

Base: 2abae58d63fdce689251f26603dca1df98402fd3.
Apply candidate.patch in a fresh checkout of that base, not atop another experiment.
The two negative patches are independent alternatives against the same base.
negative-assumption.patch deliberately retains the disputed expected count of 1.
negative-flush.patch deliberately removes the live-waiter flush condition; it is
not retained production source. Both negative commands must fail at their specified
counter assertions. rejected-fixture.log is an earlier invalid test configuration,
not protocol evidence. Initial publication source and both failed receipts are
included to identify the checkpoint at which the old test failed naturally.

```sh
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib a_target_observer_can_retire -- --nocapture
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib a_still_registered_target_waiter -- --nocapture
CARGO_INCREMENTAL=0 zcheck run check
CARGO_INCREMENTAL=0 cargo test --locked --workspace --all-targets
CARGO_INCREMENTAL=0 cargo test --release --locked -p vthread --lib completion -- --test-threads=1
```

ordered-repeat-cpu0.log runs the two exact native debug tests 50 times each with
`timeout 10s taskset -c 0 target/debug/deps/vthread-983657e34fb0f8af --exact NAME --nocapture`.
The artifact path is compiler/build dependent; use cargo's reported test executable
and record its hash before replay. The source/lock/toolchain/host are in environment.json.
Binary hashes are captured, but the executed binaries themselves are not archived.
This is a source-keyed test slice, not a complete stable-release evidence bundle.
