"""Small counter-on/off crossover; no runtime, flags or placement retuning."""

import json
import subprocess
import time

from analyze import selected, spread
from bare import load
from cases import CASES
from panel import OUT, ROOT, evidence, observe


def plan():
    cases = [case for case in CASES if case['name'] in ['spawn1000', 'spawn10000', 'tcp4']]
    jobs = []
    for rep in [1, 2]:
        for index, case in enumerate(cases if rep == 1 else reversed(cases)):
            for engine in (['may', 'vthread'] if rep == 1 else ['vthread', 'may']):
                collectors = ['perf', 'bare'] if rep == 1 else ['bare', 'perf']
                if engine == 'vthread':
                    collectors = list(reversed(collectors))
                for collector in collectors:
                    jobs.append(dict(prefix=f'cross-{rep}-{case["name"]}-{engine}-{collector}',
                                     repetition=rep, engine=engine, collector=collector, case=case))
    return jobs


def main():
    manifest = json.loads((OUT / 'source.json').read_text())
    assert manifest['source_sha256'] == evidence.source_digest()
    assert not evidence.output('git', 'status', '--porcelain')
    binary = OUT / 'benchmark'
    assert manifest['binary_sha256'] == evidence.digest(binary)
    jobs = plan()
    assert len(jobs) == 24 and len({job['prefix'] for job in jobs}) == 24
    with (OUT / 'crossover-plan.json').open('x') as stream:
        json.dump(jobs, stream, indent=2)
    rows = {}
    for index, job in enumerate(jobs):
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '180s']
        if job['collector'] == 'perf':
            command.extend(['perf', 'stat', '-x,', '-e',
                'task-clock,cycles,instructions,context-switches,cpu-migrations',
                '-o', str(OUT / f'{prefix}.csv')])
        command.extend(['taskset', '-c', job['case']['mask'], str(binary),
                        job['engine'], *job['case']['args']])
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, started_unix=time.time(), job=job), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(dict(returncode=result.returncode, finished_unix=time.time()), stream)
        observe(prefix, 'after')
        assert result.returncode == 0, (prefix, result.returncode)
        value = selected(job) if job['collector'] == 'perf' else load(job)
        key = f'{job["case"]["name"]}-{job["engine"]}-{job["collector"]}'
        rows.setdefault(key, []).append(value)
        print(f'{index + 1}/{len(jobs)} completed {prefix}: '
              f'{value["ns_per_operation"]:.2f} ns/op', flush=True)
    assert manifest['source_sha256'] == evidence.source_digest()
    assert not evidence.output('git', 'status', '--porcelain')
    assert len(rows) == 12 and all(len(values) == 2 for values in rows.values())
    with (OUT / 'crossover-analysis.json').open('x') as stream:
        json.dump({key: dict(ns_per_operation=spread([v['ns_per_operation'] for v in values]),
                             processes=values) for key, values in rows.items()}, stream, indent=2)
    print('all 24 guarded collector crossover processes completed', flush=True)


if __name__ == '__main__':
    main()
