# Quiet-window current-source controls, 2026-09-06

No runtime, benchmark Rust source, dependency, placement or polling change.
The checkout was clean bfdef5e before and after every measurement panel, with
source SHA-256 e344a60e6098206922dc615bad1bbbbfbff7c32badedc164d5b67f862f31a1b4.
The saved default-native/May 0.3.51 executable SHA-256 is
ebf3684d18be022b60470546ada4b6b5297b5d73af8781cf6947506857d27193.
Default features, no handoff timing/lifecycle profiling/allocation probe.

Five build/verification commands passed: benchmark format, 47 tests, strict
clippy, release build and feature tree. The source matches the preceding
fourteen-gate canonical receipt through its separate verification-source record.
That receipt was issued before the corresponding worktree was committed; it is
not a fresh canonical run for documentation-only measurement work. The complete
current source bytes, manifests, build logs and receipt bridge are archived.

## Complete inventory, with failures visible

| Plan | Successful benchmark processes | Failed processes | Unrun |
| --- | ---: | ---: | ---: |
| Default-contract perf counters | 80 | 0 | 0 |
| Counter-free default contract | 78 | 2 | 0 |
| Vthread-only capacity counters | 32 | 0 | 0 |
| Counter-free capacity | 32 | 0 | 0 |
| Collector on/off crossover | 24 | 0 | 0 |

Totals: 248 planned benchmark processes, 246 successful, two timed out. The five
build results are separate from these totals. All before/after build guards are
clear. There are no quietly retried or replacement samples. The initial bare
runner stopped after six successes and the first May park timeout; its explicit
continuation ran only the 73 untouched jobs from the original 80-job plan.

Both failed jobs are May park, repetitions one and three, exit 124 at the planned
180-second limit. The third received a short late diagnostic attachment after
it was already delayed, with exact data/report/stacks retained. That is not bare
timing. `bare-timeout.md` documents process observations, the unavailable gdb
attempt, sampling limitations and unclassified cause. The two other May park
jobs passed, but do not turn this into a complete four-process park comparison.

Nine complete counter-free cases have four independent processes per engine.
Each case has two V-first/two M-first pairs; case order reverses on even rounds.
Cells report medians of process-level round medians, not pooled pseudo-replicates.
All sorted whole-round samples are retained. Wake/TCP endpoint output contains
quantile and per-stream summaries, not individual raw endpoint observations.
Each wake process has 5,760,000 observations and each TCP process 72,000; these
are four independent processes, not millions of independent experimental runs.

## Measurement boundaries

Guest CPUs 0–3 for four-worker cases, CPU 7 for uncontended mutex. May retains
default worker pinning/migration; vthread carriers are not individually pinned
and started tasks never migrate. Warm-up placement is not measured topology.
64 KiB stacks and tight task admission capacity unless explicitly varied.
Historical channel: vthread bounded-one versus May unbounded MPSC. Capacity-one
control: vthread general bounded versus May SPSC plus semaphore. Neither implies
identical cancellation/fairness/API contracts or a general MPMC comparison.

Rust 1.96.1, LLVM 22.1.2, Linux 5.15.0-187, eight-vCPU KVM guest reporting AMD
EPYC 9555P. No competing guest builds were found by endpoint guards; they cannot
prove physical-host isolation, fixed frequency or absence of scheduling outliers.
All masks, commands, topology, timestamps and endpoint CPU/process state are saved.

Counter events are task-clock, cycles, instructions, context-switches and CPU
migrations. The analyzer requires every event and at least 99.5% counted coverage.
They cover whole process setup, warm-up, operations, reporting and shutdown, not
only timed operations. Normalization includes the warm-up count. No diagnostic
timing is substituted for the uninstrumented throughput comparison.

The small 24-process crossover reverses perf/bare order separately for each case
and engine. Enabling collection substantially changes May lifecycle and both TCP
timings here. Its exact raw values remain separate from the main four-process
scorecard. The tempting 25–40x lifecycle wall-time ratios from the first counter
panel are not promoted as default-runtime advantages. Underlying PMU/kernel
causality is not established, and no counter-specific runtime tuning follows.

## Capacity and remaining scope

The capacity controls keep code, live work, ready/refill policy, visible ingress,
signal ordering and polling unchanged. Counter-free 64-task channel medians rise
from 1,286 to 15,523 ns/value at capacity 65,536; park rises from 82 to 1,413 ns/op.
Channel spread is large and retained. At 1,000 live lifecycle tasks, capacity
65,536 costs 1,644 versus 386 ns/task. These are bounded baseline controls, not
a new implementation, May-equivalence claim or release-scale qualification.

Nine analyzer tests validate process order, exact counts/configuration/rounds,
counter coverage, failed/overlapping outcomes and diagnostic-exclusion policy.
They deliberately reject mutated evidence. Archives verify each member and
reproduce the current source digest from saved source bytes. The executable
stays local, identified by hash, rather than being embedded in the archive.

No complete May park qualification, multi-waiter fairness proof, offered-load tail
acceptance, large footprint/population/lifetime run, native ARM64 execution or
sanitizer support is newly claimed. Capacity-independent maintenance and held
incremental readiness remain open. HTTP, APIs, ownership, checkpoints and stacks
are unchanged. No push, fetch, hosted workflow, release tag or publication occurs.
