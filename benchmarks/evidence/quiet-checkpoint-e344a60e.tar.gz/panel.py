"""Serial current-source controls with fresh processes and immutable attempts."""

import json
from pathlib import Path
import subprocess
import sys
import time

from cases import plan

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence


def observe(prefix, stage):
    with (OUT / f'{prefix}.{stage}.host').open('x') as stream:
        stream.write(evidence.output('ps', '-eo', 'pid,comm,pcpu,etime') + '\n')
    with (OUT / f'{prefix}.{stage}.cpu').open('x') as stream:
        stream.write(''.join(Path('/proc/stat').read_text().splitlines(keepends=True)[:9]))
    result = subprocess.run(['pgrep', '-x', 'cargo|rustc|clippy-driver|zrail'], capture_output=True, text=True)
    with (OUT / f'{prefix}.{stage}.guard').open('x') as stream:
        stream.write(result.stdout + result.stderr)
    assert result.returncode == 1, 'build overlap: retain all attempts and stop; no silent replacement'


def main():
    manifest = json.loads((OUT / 'source.json').read_text())
    assert manifest['source_sha256'] == evidence.source_digest()
    assert not evidence.output('git', 'status', '--porcelain')
    binary = OUT / 'benchmark'
    assert manifest['binary_sha256'] == evidence.digest(binary)
    jobs = plan()
    with (OUT / 'plan.json').open('x') as stream:
        json.dump(jobs, stream, indent=2)
    with (OUT / 'topology.json').open('x') as stream:
        stream.write(evidence.output('lscpu', '--json') + '\n')
    with (OUT / 'cpuinfo.txt').open('x') as stream:
        stream.write(Path('/proc/cpuinfo').read_text())
    for index, job in enumerate(jobs):
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '180s', 'perf', 'stat', '-x,', '-e',
                   'task-clock,cycles,instructions,context-switches,cpu-migrations',
                   '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', job['case']['mask'],
                   str(binary), job['engine'], *job['case']['args']]
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, started_unix=time.time(), job=job), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(dict(returncode=result.returncode, finished_unix=time.time()), stream)
        observe(prefix, 'after')
        assert result.returncode == 0, (prefix, result.returncode)
        print(f'{index + 1}/{len(jobs)} completed {prefix}', flush=True)
    assert manifest['source_sha256'] == evidence.source_digest()
    assert not evidence.output('git', 'status', '--porcelain')
    print('all 80 guarded current-source default-contract processes completed', flush=True)


if __name__ == '__main__':
    main()
