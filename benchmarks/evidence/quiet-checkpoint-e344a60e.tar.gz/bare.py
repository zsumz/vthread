"""Fresh-process timing controls without perf; never merge with counter runs."""

import argparse
import json
import subprocess
import time

from analyze import parse, spread
from cases import plan
from panel import OUT, ROOT, evidence, observe


def jobs_for(kind):
    if kind == 'default':
        jobs = plan()
    else:
        jobs = json.loads((OUT / 'capacity-plan.json').read_text())
    return [dict(job, prefix='bare-' + job['prefix']) for job in jobs]


def load(job):
    prefix = job['prefix']
    assert json.loads((OUT / f'{prefix}.result.json').read_text())['returncode'] == 0
    assert not (OUT / f'{prefix}.late-diagnostic.data').exists(), 'diagnostic attachment is not bare timing'
    for stage in ['before', 'after']:
        assert not (OUT / f'{prefix}.{stage}.guard').read_text().strip()
    value = parse((OUT / f'{prefix}.log').read_text(), job)
    return dict(value, prefix=prefix)


def summarize(kind):
    jobs = jobs_for(kind)
    assert json.loads((OUT / f'bare-{kind}-plan.json').read_text()) == jobs
    assert len(list(OUT.glob(f'bare-{kind}-*.result.json'))) == len(jobs)
    groups = {}
    for job in jobs:
        group = groups.setdefault(job['case']['name'], dict(case=job['case'], engines={}))
        arm = group['engines'].setdefault(job['engine'], dict(passed=[], failed=[]))
        result = json.loads((OUT / f'{job["prefix"]}.result.json').read_text())
        if result['returncode']:
            arm['failed'].append(dict(prefix=job['prefix'], result=result))
        else:
            arm['passed'].append(load(job))
    for group in groups.values():
        for engine, arm in group['engines'].items():
            rows = arm['passed']
            assert len(rows) + len(arm['failed']) == 4
            group['engines'][engine] = dict(
                complete=not arm['failed'], failed_processes=arm['failed'],
                ns_per_operation=spread([row['ns_per_operation'] for row in rows]) if rows else None,
                phases={phase: {key: spread([row['phases'][phase][key] for row in rows])
                                for key in rows[0]['phases'][phase]}
                        for phase in rows[0]['phases']} if rows else {}, processes=rows)
    return groups


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=['default', 'capacity'])
    parser.add_argument('--resume-after-recorded-timeout', action='store_true')
    args = parser.parse_args()
    manifest = json.loads((OUT / 'source.json').read_text())
    assert manifest['source_sha256'] == evidence.source_digest()
    assert not evidence.output('git', 'status', '--porcelain')
    binary = OUT / 'benchmark'
    assert manifest['binary_sha256'] == evidence.digest(binary)
    jobs = jobs_for(args.kind)
    if args.resume_after_recorded_timeout:
        assert args.kind == 'default'
        assert json.loads((OUT / 'bare-default-plan.json').read_text()) == jobs
        existing = [job for job in jobs if (OUT / f'{job["prefix"]}.result.json').exists()]
        assert len(existing) == 7 and existing == jobs[:7]
        assert json.loads((OUT / f'{existing[-1]["prefix"]}.result.json').read_text())['returncode'] == 124
        with (OUT / 'bare-continuation.json').open('x') as stream:
            json.dump(dict(started_unix=time.time(), prior_attempts=[j['prefix'] for j in existing],
                           policy='Preserve first timeout; run only untouched planned processes. '
                           'Further failures remain failed observations, never replacement samples.'), stream, indent=2)
        jobs = jobs[7:]
    else:
        with (OUT / f'bare-{args.kind}-plan.json').open('x') as stream:
            json.dump(jobs, stream, indent=2)
    for index, job in enumerate(jobs):
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '180s', 'taskset', '-c', job['case']['mask'],
                   str(binary), job['engine'], *job['case']['args']]
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, started_unix=time.time(), job=job), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(dict(returncode=result.returncode, finished_unix=time.time()), stream)
        observe(prefix, 'after')
        if result.returncode:
            print(f'{index + 1}/{len(jobs)} FAILED {prefix}: exit {result.returncode}', flush=True)
            assert args.resume_after_recorded_timeout, (prefix, result.returncode)
            continue
        value = load(job)
        print(f'{index + 1}/{len(jobs)} completed {prefix}: '
              f'{value["ns_per_operation"]:.2f} ns/op', flush=True)
    assert manifest['source_sha256'] == evidence.source_digest()
    assert not evidence.output('git', 'status', '--porcelain')
    report = summarize(args.kind)
    with (OUT / f'bare-{args.kind}-analysis.json').open('x') as stream:
        json.dump(report, stream, indent=2)
    failures = [failure for group in report.values() for arm in group['engines'].values()
                for failure in arm['failed_processes']]
    print(f'no-perf plan finished: {len(failures)} failed processes retained; '
          'incomplete cells are not complete comparisons', flush=True)


if __name__ == '__main__':
    main()
