"""Decode the bounded sample of a delayed control; never headline timing."""

from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
prefix = 'bare-default-3-park4-may.late-diagnostic'
commands = [
    ('report', ['perf', 'report', '--stdio', '--header', '--no-children', '--sort', 'symbol,dso',
                '-i', str(OUT / f'{prefix}.data')]),
    ('stacks', ['perf', 'script', '-i', str(OUT / f'{prefix}.data')]),
]
for name, command in commands:
    with (OUT / f'{prefix}.{name}').open('x') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
        assert result.returncode == 0, (command, result.returncode)
print('bounded late diagnostic decoded; not an uninstrumented timing sample')
