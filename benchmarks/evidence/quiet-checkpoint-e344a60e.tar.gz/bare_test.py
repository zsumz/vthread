import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import bare


class BareTests(unittest.TestCase):
    def test_panels_keep_independent_complete_process_counts(self):
        for kind, count in [('default', 80), ('capacity', 32)]:
            jobs = bare.jobs_for(kind)
            self.assertEqual(len(jobs), count)
            self.assertEqual(len({job['prefix'] for job in jobs}), count)
            self.assertTrue(all(job['prefix'].startswith(f'bare-{kind}-') for job in jobs))

    def test_exit_and_overlap_cannot_become_valid_timing_observations(self):
        job = bare.jobs_for('default')[0]
        prefix = job['prefix']
        names = [f'{prefix}{suffix}' for suffix in
                 ['.log', '.result.json', '.before.guard', '.after.guard']]
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for name in names:
                (root / name).write_bytes((bare.OUT / name).read_bytes())
            with patch.object(bare, 'OUT', root):
                self.assertGreater(bare.load(job)['ns_per_operation'], 0)
                (root / f'{prefix}.result.json').write_text(json.dumps(dict(returncode=124)))
                with self.assertRaises(AssertionError):
                    bare.load(job)
                (root / f'{prefix}.result.json').write_text(json.dumps(dict(returncode=0)))
                (root / f'{prefix}.after.guard').write_text('12345\n')
                with self.assertRaises(AssertionError):
                    bare.load(job)
                (root / f'{prefix}.after.guard').write_text('')
                (root / f'{prefix}.late-diagnostic.data').write_bytes(b'diagnostic')
                with self.assertRaises(AssertionError):
                    bare.load(job)

    def test_raw_run_still_requires_its_exact_work_contract(self):
        job = bare.jobs_for('default')[0]
        damaged = copy.deepcopy(job)
        damaged['case']['rounds'] = 11
        with self.assertRaises(AssertionError):
            bare.load(damaged)

    def test_failed_process_is_retained_without_a_timing_value(self):
        source_job = bare.jobs_for('default')[0]
        source = bare.OUT
        jobs = [dict(source_job, prefix=f'bare-default-{i}-yield4-vthread') for i in range(1, 5)]
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'bare-default-plan.json').write_text(json.dumps(jobs))
            for index, job in enumerate(jobs):
                prefix = job['prefix']
                (root / f'{prefix}.log').write_bytes((source / f'{source_job["prefix"]}.log').read_bytes())
                (root / f'{prefix}.result.json').write_text(json.dumps(dict(returncode=124 if index == 2 else 0)))
                for stage in ['before', 'after']:
                    (root / f'{prefix}.{stage}.guard').write_text('')
            with patch.object(bare, 'OUT', root), patch.object(bare, 'jobs_for', return_value=jobs):
                arm = bare.summarize('default')['yield4']['engines']['vthread']
                self.assertFalse(arm['complete'])
                self.assertEqual(len(arm['processes']), 3)
                self.assertEqual(arm['failed_processes'][0]['result']['returncode'], 124)
                self.assertEqual(len(arm['ns_per_operation']['values']), 3)


if __name__ == '__main__':
    unittest.main()
