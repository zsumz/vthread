"""Same frozen binary; capacity-only controls, separate from the May scorecard."""

import json
import subprocess
import time

from panel import OUT, ROOT, evidence, observe
from analyze import selected, spread


def cases():
    result = []
    for capacity in [64, 1024, 65536]:
        result.append(dict(name=f'channel-{capacity}', family='channel', mask='0-3', workers=4,
            tasks=64, operation_tasks=32, capacity=capacity, operation='bounded-mpmc-channel-1-transfer',
            per_task=2000, rounds=3, args=['channel-mpmc', '2000', '1', '4', '64', '3',
                                         '--max-vthreads', str(capacity)]))
        result.append(dict(name=f'park-{capacity}', family='park', mask='0-3', workers=4,
            tasks=64, capacity=capacity, operation='park-handoff', per_task=2000, rounds=3,
            args=['park', '2000', '4', '64', '3', '--max-vthreads', str(capacity)]))
    for capacity in [1000, 65536]:
        result.append(dict(name=f'spawn-{capacity}', family='spawn', mask='0-3', workers=4,
            tasks=1000, capacity=capacity, operation='task', per_task=1, rounds=101,
            args=['spawn', '4', '1000', '101', '--max-vthreads', str(capacity)]))
    return result


def main():
    manifest = json.loads((OUT / 'source.json').read_text())
    assert manifest['source_sha256'] == evidence.source_digest()
    assert not evidence.output('git', 'status', '--porcelain')
    binary = OUT / 'benchmark'
    assert manifest['binary_sha256'] == evidence.digest(binary)
    jobs = []
    for repetition in range(1, 5):
        order = cases() if repetition % 2 else list(reversed(cases()))
        for case in order:
            jobs.append(dict(prefix=f'capacity-{repetition}-{case["name"]}', engine='vthread',
                             repetition=repetition, case=case))
    with (OUT / 'capacity-plan.json').open('x') as stream:
        json.dump(jobs, stream, indent=2)
    values = {}
    for index, job in enumerate(jobs):
        prefix = job['prefix']
        observe(prefix, 'before')
        command = ['timeout', '180s', 'perf', 'stat', '-x,', '-e',
                   'task-clock,cycles,instructions,context-switches,cpu-migrations',
                   '-o', str(OUT / f'{prefix}.csv'), 'taskset', '-c', job['case']['mask'],
                   str(binary), 'vthread', *job['case']['args']]
        with (OUT / f'{prefix}.command.json').open('x') as stream:
            json.dump(dict(command=command, started_unix=time.time(), job=job), stream, indent=2)
        with (OUT / f'{prefix}.log').open('x') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        with (OUT / f'{prefix}.result.json').open('x') as stream:
            json.dump(dict(returncode=result.returncode, finished_unix=time.time()), stream)
        observe(prefix, 'after')
        assert result.returncode == 0, (prefix, result.returncode)
        value = selected(job)
        values.setdefault(job['case']['name'], []).append(value)
        print(f'{index + 1}/{len(jobs)} completed {prefix}: {value["ns_per_operation"]:.2f} ns/op', flush=True)
    assert manifest['source_sha256'] == evidence.source_digest()
    assert not evidence.output('git', 'status', '--porcelain')
    summary = {}
    for case in cases():
        rows = values[case['name']]
        assert len(rows) == 4
        summary[case['name']] = dict(case=case, ns_per_operation=spread([v['ns_per_operation'] for v in rows]),
            process_counters={key: spread([v['process_counters_per_operation'][key] for v in rows])
                              for key in rows[0]['counters']}, processes=rows)
    with (OUT / 'capacity-analysis.json').open('x') as stream:
        json.dump(summary, stream, indent=2)
    print('all 32 guarded capacity controls completed; no candidate or May equivalence claim', flush=True)


if __name__ == '__main__':
    main()
