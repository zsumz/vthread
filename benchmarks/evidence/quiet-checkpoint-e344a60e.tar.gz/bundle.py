"""Archive immutable controls, source bytes and qualification identities."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

DESTINATION = ROOT / 'benchmarks/evidence/quiet-checkpoint-e344a60e.tar.gz'
manifest = json.loads((OUT / 'source.json').read_text())
assert evidence.source_digest() == manifest['source_sha256']
assert evidence.digest(OUT / 'benchmark') == manifest['binary_sha256']
assert all((OUT / name).is_file() for name in
           ['analysis.json', 'capacity-analysis.json', 'bare-default-analysis.json',
            'bare-capacity-analysis.json', 'crossover-analysis.json', 'LEDGER.md'])

source_paths = sorted(path for path in evidence.output('git', 'ls-files').splitlines()
                      if Path(path).suffix in {'.rs', '.toml', '.lock', '.py', '.sh', '.yml'})
with (OUT / 'source-files.json').open('x') as stream:
    json.dump({name: evidence.digest(ROOT / name) for name in source_paths}, stream, indent=2)
with tarfile.open(OUT / 'source.tar.gz', 'x:gz') as archive:
    for name in source_paths:
        archive.add(ROOT / name, arcname=name, recursive=False)

with (OUT / 'verification-tests.log').open('x') as stream:
    subprocess.run(['taskset', '-c', '4', 'python3', '-m', 'unittest', 'discover',
                    '-s', str(OUT), '-p', '*_test.py', '-v'], cwd=ROOT,
                   stdout=stream, stderr=subprocess.STDOUT, check=True)
receipt = ROOT / 'target/finish-line/offered-load.NMIxGQ/canonical/receipt.json'
with (OUT / 'preceding-canonical-receipt.json').open('xb') as stream:
    stream.write(receipt.read_bytes())
qualified = ROOT / 'target/finish-line/offered-load.NMIxGQ/verification-source.json'
assert json.loads(qualified.read_text())['source_sha256'] == manifest['source_sha256']
with (OUT / 'preceding-qualified-source.json').open('xb') as stream:
    stream.write(qualified.read_bytes())

paths = sorted(path for path in OUT.rglob('*') if path.is_file()
               and '__pycache__' not in path.parts and path.name not in {'benchmark', 'SHA256SUMS'})
with (OUT / 'SHA256SUMS').open('x') as stream:
    for path in paths:
        stream.write(f'{evidence.digest(path)}  {path.relative_to(OUT)}\n')
with tarfile.open(DESTINATION, 'x:gz') as archive:
    for path in [*paths, OUT / 'SHA256SUMS']:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
with tarfile.open(DESTINATION) as archive:
    members = archive.getmembers()
    assert len(members) == len(paths) + 1
    assert all(member.isfile() and not Path(member.name).is_absolute()
               and '..' not in Path(member.name).parts for member in members)
    sums = archive.extractfile('SHA256SUMS').read().decode().splitlines()
    for line in sums:
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
with tarfile.open(OUT / 'source.tar.gz') as archive:
    source = hashlib.sha256()
    for name in source_paths:
        source.update(name.encode() + b'\0' + archive.extractfile(name).read() + b'\0')
    assert source.hexdigest() == manifest['source_sha256']
print(DESTINATION, evidence.digest(DESTINATION), len(paths), 'verified internal hashes')
print('archived source hash reproduced:', source.hexdigest())
