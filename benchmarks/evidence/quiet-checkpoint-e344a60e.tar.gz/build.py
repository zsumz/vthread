"""Qualify and freeze one current-source default benchmark executable."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/root/vthread')
OUT = Path(__file__).resolve().parent
BUILD = Path('/mnt/volume_atl1_1787847588295/vthread-handoff-qualification.Q6QudI')
sys.path.insert(0, str(ROOT / 'scripts'))
import evidence

manifest = evidence.metadata('current bfdef5e native default benchmark; balanced May refresh, no runtime candidate')
assert manifest['head'].startswith('bfdef5e') and not manifest['dirty']
assert manifest['source_sha256'] == 'e344a60e6098206922dc615bad1bbbbfbff7c32badedc164d5b67f862f31a1b4'
environment = dict(os.environ, CARGO_TARGET_DIR=str(BUILD), CARGO_INCREMENTAL='0')
manifest['build_environment'] = {key: environment[key] for key in ('CARGO_TARGET_DIR', 'CARGO_INCREMENTAL')}
commands = [
    ('format', ['cargo', 'fmt', '--manifest-path', 'benchmarks/Cargo.toml', '--', '--check']),
    ('test', ['cargo', 'test', '--locked', '--manifest-path', 'benchmarks/Cargo.toml']),
    ('clippy', ['cargo', 'clippy', '--locked', '--manifest-path', 'benchmarks/Cargo.toml', '--', '-D', 'warnings']),
    ('build', ['cargo', 'build', '--locked', '--release', '--manifest-path', 'benchmarks/Cargo.toml']),
    ('features', ['cargo', 'tree', '--locked', '--manifest-path', 'benchmarks/Cargo.toml', '-e', 'features']),
]
for name, command in commands:
    with (OUT / f'{name}.command.json').open('x') as stream:
        json.dump(dict(command=command, source=manifest), stream, indent=2)
    with (OUT / f'{name}.log').open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=600)
    with (OUT / f'{name}.result.json').open('x') as stream:
        json.dump(dict(returncode=result.returncode), stream)
    assert result.returncode == 0, name
    print(name, 'passed', flush=True)
assert manifest['source_sha256'] == evidence.source_digest()
assert not evidence.output('git', 'status', '--porcelain')
binary = OUT / 'benchmark'
assert not binary.exists()
shutil.copy2(BUILD / 'release/vthread-benchmarks', binary)
manifest.update(binary_sha256=evidence.digest(binary), features='default; no profiling or allocation probe',
                benchmark_lock_sha256=evidence.digest(ROOT / 'benchmarks/Cargo.lock'))
with (OUT / 'source.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
print('frozen', manifest['binary_sha256'], flush=True)
