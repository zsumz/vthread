# Counter-free May park timeout retained

The first no-perf panel stopped at `bare-default-1-park4-may`, exit 124 under
the planned 180-second timeout. The preceding six invocations passed. Both build
guards were clear; the empty stdout log contains no final round report, so it
does not identify whether warm-up or a measured round was unfinished.

A read-only host `ps -eo pid,ppid,psr,pcpu,etime,stat,comm --sort=-pcpu`
observation before expiry showed the exact child benchmark PID 3210612 (parent
3210611, the timeout process) at 398% CPU after 2:39, state Sl. Its runner was
PID 3210520. The other substantial entries were Codex sessions at 2.6% and 1.5%
CPU; no build process was reported. This is an observation, not a scheduler
trace or proof of the failure's cause. The planned before/after CPU snapshots,
command, timestamps, result and clear guards remain in the original files.

The attempted read-only backtrace command was
`gdb -batch -ex 'set pagination off' -ex 'thread apply all bt 8' -p 3210612`.
It failed with exit 127 because gdb was not installed. No backtrace was captured
and no debugger was attached. The existing timeout terminated its own child.

The continuation runs only the 73 untouched planned processes. It neither reruns
this cell nor replaces its result. Further failures remain failed observations,
not timing values. The analyzer explicitly marks a cell incomplete when any of
its four scheduled processes fails, with a negative-control test for that rule.
A successful later repetition cannot establish why this invocation timed out.

This is an unresolved comparison-control progress finding, not established
evidence of a defect in either runtime. No May dependency, worker placement,
benchmark startup protocol or runtime source is changed to repair the scorecard.

## Second delayed control

The third planned May park invocation also exceeded 50 seconds without a report.
Read-only `ps` at 0:55 showed exact PID 3212035 (timeout parent 3212034) at 397%
CPU. A three-second diagnostic sample was then attached with:

```
perf record -e cycles:u -F 199 --call-graph dwarf,4096 -p 3212035 \
  -o bare-default-3-park4-may.late-diagnostic.data -- sleep 3
```

This is explicitly a **late diagnostic attachment**, not ordinary no-perf timing.
At 1:44, the process main thread and TID 3212036 were in `futex_wait_queue_me`;
TIDs 3212037–3212040 were runnable on CPUs 0–3 at 99.5–99.7% CPU each. These
read-only observations did not change affinity. The exact sampled data and
decoded report/stacks are retained. A diagnostic attachment cannot retrospectively
explain the first timeout or be silently treated as a clean timing observation.

The sampled process also reached its original 180-second timeout (exit 124).
The capture contains 1,339 samples over approximately 3.41 seconds, with zero
reported lost samples. Its weighted top labels are a monomorphized Rust worker
backtrace wrapper (71.07%) and `may::yield_now::yield_now` (17.92%); some stacks
also pass through `Park` destruction/native yielding. These names and a short
alternate-stack unwind are not enough to classify the exact wait or admission
dependency. No claim is made that either timeout was caused by a lost wake.
