import copy
from pathlib import Path
import tempfile
import unittest

import analyze
import crossover
from cases import CASES, plan


class AnalyzeTests(unittest.TestCase):
    def test_crossover_reverses_collector_order_for_each_case_and_engine(self):
        jobs = crossover.plan()
        self.assertEqual(len({job['prefix'] for job in jobs}), 24)
        for case in ['spawn1000', 'spawn10000', 'tcp4']:
            for engine in ['vthread', 'may']:
                selected = [j['collector'] for j in jobs
                            if j['case']['name'] == case and j['engine'] == engine]
                self.assertIn(selected, [['perf', 'bare', 'bare', 'perf'], ['bare', 'perf', 'perf', 'bare']])

    def test_counter_coverage_or_missing_events_cannot_pass(self):
        job = plan()[0]
        source = (analyze.OUT / f'{job["prefix"]}.csv').read_text()
        self.assertEqual(set(analyze.counters(analyze.OUT / f'{job["prefix"]}.csv')), analyze.EVENTS)
        rows = source.splitlines()
        cycle = next(row for row in rows if ',cycles,' in row)
        columns = cycle.split(',')
        columns[4] = '50.0'
        mutations = [source.replace(cycle, ','.join(columns)), source.replace(cycle, ''), source + '\n' + cycle]
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'counters.csv'
            for damaged in mutations:
                path.write_text(damaged)
                with self.assertRaises(AssertionError):
                    analyze.counters(path)

    def test_balanced_complete_unique_plan(self):
        jobs = plan()
        self.assertEqual(len({j['prefix'] for j in jobs}), 80)
        for case in CASES:
            selected = [job for job in jobs if job['case'] == case]
            self.assertEqual(len(selected), 8)
            self.assertEqual([j['engine'] for j in selected[::2]].count('vthread'), 2)

    def test_actual_round_accounting_and_mutations(self):
        job = plan()[0]
        text = (analyze.OUT / f'{job["prefix"]}.log').read_text()
        value = analyze.parse(text, job)
        self.assertEqual(len(value['round_samples_ns']), 9)
        self.assertEqual(value['process_operations'], 64000000)
        for damaged in [text.replace('workers=4', 'workers=5'), text.replace('pin_carriers=false', 'pin_carriers=true'),
                        text.replace('ns_per_operation=', 'bad_per_operation='),
                        text.replace('samples=[', 'samples=[1, '), text.replace('max_vthreads=64', 'max_vthreads=65536')]:
            with self.assertRaises((AssertionError, KeyError, TypeError)):
                analyze.parse(damaged, job)

    def test_wrong_engine_or_work_count_is_not_a_valid_comparison(self):
        job = plan()[0]
        text = (analyze.OUT / f'{job["prefix"]}.log').read_text()
        for field, value in [('engine', 'may'), ('tasks', 65), ('per_task', 99900), ('rounds', 11)]:
            damaged = copy.deepcopy(job)
            if field == 'engine':
                damaged[field] = value
            else:
                damaged['case'][field] = value
            with self.assertRaises(AssertionError):
                analyze.parse(text, damaged)


if __name__ == '__main__':
    unittest.main()
