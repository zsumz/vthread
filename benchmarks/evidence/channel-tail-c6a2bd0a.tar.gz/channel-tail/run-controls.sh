#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/channel-tail

run_case() {
    local label=$1 mask=$2
    shift 2
    if [[ ${VTHREAD_CONTROL_CASES:-all} != all && " ${VTHREAD_CONTROL_CASES:-} " != *" $label "* ]]; then return; fi
    for round in ${VTHREAD_CONTROL_ROUNDS:-1 2 3 4}; do
        local engines='baseline candidate'
        if (( round % 2 == 0 )); then engines='candidate baseline'; fi
        for engine in $engines; do
            local binary=$evidence_dir/candidate-benchmark
            if [[ $engine == baseline ]]; then binary=target/finish-line/channel-latency/baseline-benchmark; fi
            local prefix=$evidence_dir/control-$round-$engine-$label
            if [[ -e $prefix.log ]]; then
                printf 'refusing to overwrite earlier output: %s\n' "$prefix" >&2
                return 126
            fi
            if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
                printf 'control deferred: other build activity before %s\n' "$prefix" >&2
                return 125
            fi
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            printf '%q ' timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@" >> "$evidence_dir/control-commands.log"
            printf '\n' >> "$evidence_dir/control-commands.log"
            timeout 120s perf stat -x, -e cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c "$mask" "$binary" vthread "$@" > "$prefix.log" 2>&1
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'control round=%s engine=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

run_case tail-4c8 0-3 channel-mpmc 20000 1 4 8 5 --pin-carriers --sample-channel-latency
run_case tail-4c64 0-3 channel-mpmc 10000 1 4 64 5 --pin-carriers --sample-channel-latency
run_case tail-1c8 7 channel-mpmc 20000 1 1 8 5 --pin-carriers --sample-channel-latency
run_case tail-4c8-cap64 0-3 channel-mpmc 20000 64 4 8 5 --pin-carriers --sample-channel-latency
run_case tail-4c8-cap1024 0-3 channel-mpmc 20000 1024 4 8 5 --pin-carriers --sample-channel-latency
run_case tail-8c64 0-7 channel-mpmc 10000 1 8 64 5 --pin-carriers --sample-channel-latency
run_case mpmc-4c8 0-3 channel-mpmc 20000 1 4 8 5 --pin-carriers
run_case mpmc-4c64 0-3 channel-mpmc 10000 1 4 64 5 --pin-carriers
run_case mpmc-4c64-spare 0-3 channel-mpmc 10000 1 4 64 5 --pin-carriers --max-vthreads 65536
run_case mpmc-4c64-cap64 0-3 channel-mpmc 10000 64 4 64 5 --pin-carriers
run_case mpmc-4c64-cap1024 0-3 channel-mpmc 10000 1024 4 64 5 --pin-carriers
run_case mpmc-2c8 0-1 channel-mpmc 20000 1 2 8 5 --pin-carriers
run_case mpmc-8c64 0-7 channel-mpmc 10000 1 8 64 5 --pin-carriers
run_case mutex 0-3 mutex 10000 4 64 5 --pin-carriers
run_case paired-channel 0-3 channel-bounded-spsc 10000 1 4 64 5 --pin-carriers
run_case yield 0-3 yield 10000 4 64 5 --pin-carriers
run_case lifecycle-spare 0-3 spawn 4 10000 101 --max-vthreads 65536
