"""Keep independent process replications, directional tails and all raw controls."""

import json
from pathlib import Path
import re
import statistics
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
ENGINES = ("baseline", "candidate")


def record(path):
    match = re.fullmatch(r"control-(\d+)-(baseline|candidate)-(.+)\.log", path.name)
    result = {"log": path.name, "round": int(match[1]), "engine": match[2], "case": match[3]}
    for line in path.read_text().splitlines():
        data = dict(re.findall(r"(\w+)=(\S+)", line))
        if "ns_per_operation" in data:
            result["ns_per_operation"] = float(data["ns_per_operation"])
        phase = data.get("phase")
        if phase in ("latency", "fairness", "channel-latency", "channel-fairness"):
            key = phase if "direction" not in data else f'{phase}-{data["direction"]}'
            result[key] = {key: int(value) for key, value in data.items()
                           if key.endswith("_ns") or key in ("observations", "task_streams")}
    result["perf"] = {}
    if path.with_suffix(".csv").exists():
        for line in path.with_suffix(".csv").read_text().splitlines():
            columns = line.split(",")
            if len(columns) >= 3 and columns[0].isdigit():
                result["perf"][columns[2]] = int(columns[0])
    return result


records = [record(path) for path in sorted(ROOT.glob("control-*-*.log"))]
summary = {}
for case in sorted({item["case"] for item in records}):
    groups = {engine: [item for item in records if item["case"] == case and item["engine"] == engine]
              for engine in ENGINES}
    if any(sorted(item["round"] for item in group) != [1, 2, 3, 4] for group in groups.values()):
        summary[case] = {"status": "incomplete_not_compared"}
        continue
    if any("cycles" not in item["perf"] or "ns_per_operation" not in item
           for group in groups.values() for item in group):
        summary[case] = {"status": "incomplete_not_compared"}
        continue
    entry = {"status": "complete_experiment_not_full_acceptance"}
    metrics = ("ns_per_operation", "cycles", "instructions", "context-switches", "cpu-migrations")
    for metric in metrics:
        values = {engine: [item[metric] if metric in item else item["perf"][metric] for item in group]
                  for engine, group in groups.items()}
        medians = {engine: statistics.median(group) for engine, group in values.items()}
        change = None if medians["baseline"] == 0 else 100 * (medians["candidate"] / medians["baseline"] - 1)
        entry[metric] = {"values": values, "medians": medians, "change_percent": change}
    for direction in ("receive", "send"):
        key = f"channel-latency-{direction}"
        if all(key in item for group in groups.values() for item in group):
            entry[key] = {}
            for metric in ("median_ns", "p99_9_ns", "p99_99_ns", "max_ns"):
                values = {engine: [item[key][metric] for item in group] for engine, group in groups.items()}
                medians = {engine: statistics.median(group) for engine, group in values.items()}
                entry[key][metric] = {"values": values, "medians": medians,
                    "change_percent": 100 * (medians["candidate"] / medians["baseline"] - 1)}
    summary[case] = entry

print(json.dumps({"summary": summary, "raw": records}, indent=2))
