# Fixed extended polling: full comparison and rejection

Baseline: commit 070c11f2fda0a9f116cafb6c0afd41744c0a1d21, source SHA-256
30bb48693c14080d0a289f76a23943f9d67caf1507b20e7e69b8db302dcdad9c.
Candidate source: c6a2bd0a02d9d93b5fced5d98c6bb99df58c030b7100231081e23fd6470ca6cf.
The exact runtime patch and refreshed inventory-only lock are preserved in
candidate.patch and stash 31d268e859c985f6036fc14385fc2aff820fc6f9.
No new grants, dependencies, debt or atomic protocols were introduced.

```sh
zrail update --format json
zrail update --accept-grants --format json
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib channel:: -- --test-threads=1
CARGO_INCREMENTAL=0 cargo test --locked -p vthread --lib kernel_idle -- --test-threads=1
CARGO_TARGET_DIR=target CARGO_INCREMENTAL=0 cargo test --locked --manifest-path benchmarks/Cargo.toml --all-features
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
bash target/finish-line/channel-tail/run-controls.sh
python3 target/finish-line/channel-tail/analyze.py
bash target/finish-line/lifecycle-confirm/run-controls.sh
python3 target/finish-line/channel-tail/analyze.py target/finish-line/lifecycle-confirm
```

18 channel tests, the native idle-budget regression and 51 benchmark tests pass.
No final canonical acceptance is claimed for this rejected runtime candidate.
The benchmark-only baseline was independently qualified under all canonical gates.

The main panel contains 136 processes: four balanced pairs across 17 cases. All
272 endpoint host snapshots are preserved; none caught a compiler or a process
above 10% lifetime-average CPU. No samples are removed. The guest has eight vCPUs;
physical-host exclusivity, topology and uninterrupted availability are unproven.
No own builds/tests overlapped timing. A read-only cgroup check during the panel
found user.slice cpu.max=max 100000 and zero throttle counters; cumulative guest
steal time was nonzero. This is not a trace attributing any particular tail.

Shared-channel and tail improvements are substantial, especially capacity one,
eight carriers and spare admission capacity. Large-buffer gains are small, and
capacity 1024 elapsed throughput worsens 4.16% despite 2.21% fewer cycles. The first
spare-capacity lifecycle panel records +13.23% cycles with -0.14% instructions.
The separate 24-process, 301-sample follow-up does not reproduce that increase:
four-carrier normal -1.76%, four-carrier pinned +1.35%, one-carrier pinned +0.36%.
Both sets remain evidence; no exact causal explanation or zero regression is claimed.

The decisive rejection is the separately tested public-API idle/burst diagnostic:
fixed long polling raises burst CPU time approximately 2.6x. Its 48 processes,
source, binary/library hashes, native tests, command script, counts, CPU snapshots
and analysis are preserved in the sibling idle-budget directory. Executables are
excluded from the archive. An adaptive policy is a new experiment, not a reason
to retroactively accept fixed long polling or discard the failed gate.
