#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/lifecycle-confirm

run_case() {
    local label=$1 mask=$2
    shift 2
    for round in 1 2 3 4; do
        local engines='baseline candidate'
        if (( round % 2 == 0 )); then engines='candidate baseline'; fi
        for engine in $engines; do
            local binary=target/finish-line/channel-tail/candidate-benchmark
            if [[ $engine == baseline ]]; then binary=target/finish-line/channel-latency/baseline-benchmark; fi
            local prefix=$evidence_dir/control-$round-$engine-$label
            test ! -e "$prefix.log"
            if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
                printf 'control deferred before %s\n' "$prefix" >&2
                return 125
            fi
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            sed -n '1,9p' /proc/stat > "$prefix.before.cpu"
            printf '%q ' timeout 120s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c "$mask" "$binary" vthread spawn "$@" >> "$evidence_dir/control-commands.log"
            printf '\n' >> "$evidence_dir/control-commands.log"
            timeout 120s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c "$mask" "$binary" vthread spawn "$@" > "$prefix.log" 2>&1
            sed -n '1,9p' /proc/stat > "$prefix.after.cpu"
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'round=%s arm=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

run_case spare4-normal 0-3 4 10000 301 --max-vthreads 65536
run_case spare4-pinned 0-3 4 10000 301 --max-vthreads 65536 --pin-carriers
run_case spare1-pinned 7 1 10000 301 --max-vthreads 65536 --pin-carriers
