#!/usr/bin/env bash
set -euo pipefail
cd /root/vthread
evidence_dir=target/finish-line/idle-budget

run_case() {
    local label=$1 mask=$2
    shift 2
    for round in 1 2 3 4; do
        local engines='baseline candidate'
        if (( round % 2 == 0 )); then engines='candidate baseline'; fi
        for engine in $engines; do
            local prefix=$evidence_dir/control-$round-$engine-$label
            test ! -e "$prefix.log"
            if pgrep -x 'cargo|rustc|clippy-driver|zrail' > "$prefix.guard"; then
                printf 'control deferred before %s\n' "$prefix" >&2
                return 125
            fi
            ps -eo pid,comm,pcpu,etime > "$prefix.before.host"
            sed -n '1,9p' /proc/stat > "$prefix.before.cpu"
            printf '%q ' timeout 60s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations -o "$prefix.csv" taskset -c "$mask" "$evidence_dir/$engine-control" "$@" >> "$evidence_dir/control-commands.log"
            printf '\n' >> "$evidence_dir/control-commands.log"
            timeout 60s perf stat -x, -e task-clock,cycles,instructions,context-switches,cpu-migrations \
                -o "$prefix.csv" taskset -c "$mask" "$evidence_dir/$engine-control" "$@" > "$prefix.log" 2>&1
            sed -n '1,9p' /proc/stat > "$prefix.after.cpu"
            ps -eo pid,comm,pcpu,etime > "$prefix.after.host"
            printf 'round=%s arm=%s case=%s complete\n' "$round" "$engine" "$label"
        done
    done
}

run_case quiet4 0-3 4 8 8 2000000 0
run_case quiet4-spare 0-3 4 8 65536 2000000 0
run_case burst4-1ms 0-3 4 8 8 1000 2000
run_case burst4-100us 0-3 4 8 8 100 5000
run_case burst1-1ms 7 1 8 8 1000 2000
run_case burst8-1ms 0-7 8 16 16 1000 2000
