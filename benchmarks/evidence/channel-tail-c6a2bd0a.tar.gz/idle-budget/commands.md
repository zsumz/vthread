# Public-API idle and burst CPU diagnostic

control.rs is an independent diagnostic, not a shipped runtime change. It uses
only the public vthread API, forbids unsafe code, and keeps OS sleeps and blocking
acknowledgement receives on the native scope caller. Task acknowledgements use
bounded native try_send; they never block a carrier. The queue covers one result
per task. Every wave verifies exact task identity and generation; selected wakes
and stored permits are counted separately. All tasks must drain at the end.

Before timing, snapshots must show all tasks parked, carriers idle, zero runnable
work, no pending starts/wakes, and no timers. A 50ms settling interval follows.
There are no snapshots within the measured interval. A published Idle snapshot is
not proof that a carrier has already entered the kernel wait. Whole-process perf
includes startup, initial observation, settling, acknowledgements and shutdown.
Quiet cases use a two-second no-work interval; do not treat tiny total-CPU deltas
as isolated idle-loop instruction costs. Burst cases are closed-loop waves with a
quiet gap after acknowledgements, not independently scheduled offered load.

Both versions use the same control.rs and control_test.rs hashes. Runtime source,
library hashes, executables and test hashes are recorded separately. The candidate
is the fixed-poll source c6a2bd0a; the baseline is the independently qualified
source 30bb4869. Each library was built from its recorded source immediately before
linking. The same dependencies and compiler were used.

```sh
CARGO_INCREMENTAL=0 cargo build --locked --release --manifest-path benchmarks/Cargo.toml
rustc --edition=2024 -C opt-level=3 -D warnings --test --crate-name idle_budget target/finish-line/idle-budget/control.rs --extern vthread=benchmarks/target/release/deps/libvthread-d6eb8953727b0829.rlib -L dependency=benchmarks/target/release/deps -o target/finish-line/idle-budget/ARM-tests
target/finish-line/idle-budget/ARM-tests --test-threads=1
rustc --edition=2024 -C opt-level=3 -D warnings --crate-name idle_budget target/finish-line/idle-budget/control.rs --extern vthread=benchmarks/target/release/deps/libvthread-d6eb8953727b0829.rlib -L dependency=benchmarks/target/release/deps -o target/finish-line/idle-budget/ARM-control
bash target/finish-line/idle-budget/run-controls.sh
python3 target/finish-line/idle-budget/analyze.py
```

ARM is baseline or candidate, identifying an experimental arm, not CPU architecture.
Both test binaries pass bounds validation and actual one/four-carrier quiet/wave
workloads. This manual rustc diagnostic is not presented as canonical qualification.
The 48 performance processes are balanced across four pairs and six cases. Native
carrier placement is normal within the external process CPU mask, not individually
pinned. Raw /proc/stat snapshots include guest steal counters for later inspection.
All data is retained; executables are omitted from the durable source-keyed bundle.
